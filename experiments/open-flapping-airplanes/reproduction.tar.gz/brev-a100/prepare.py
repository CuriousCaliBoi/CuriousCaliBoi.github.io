import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

import numpy as np
import tiktoken
import torch

REPO = Path('/opt/open-flapping-airplanes')
DATA = Path(os.environ.get('OFA_DATA', '/data'))
REVISION = 'f54c09fd23315a6f9c86f9dc80f725de7d8f9c64'
SOURCE = f'https://huggingface.co/datasets/roneneldan/TinyStories/resolve/{REVISION}'
PREFIX_BYTES = 314572800


def download(name, destination, prefix=False):
    if destination.exists():
        return
    temporary = destination.with_suffix('.download')
    command = ['curl', '--fail', '--location', '--retry', '3', '--max-time', '900']
    if prefix:
        command += ['--range', f'0-{PREFIX_BYTES - 1}']
    subprocess.run(command + [f'{SOURCE}/{name}', '-o', str(temporary)], check=True)
    if prefix:
        if temporary.stat().st_size < PREFIX_BYTES:
            raise RuntimeError('TinyStories training prefix is shorter than 300 MiB')
        # A server may ignore Range and return the whole dataset.
        with temporary.open('r+b') as stream:
            stream.truncate(PREFIX_BYTES)
    temporary.replace(destination)


def tokenize(source, destination, drop_partial):
    if destination.exists():
        return
    encoder = tiktoken.get_encoding('cl100k_base')
    stories = source.read_text(encoding='utf-8', errors='ignore').split('<|endoftext|>')
    if drop_partial:
        stories = stories[:-1]
    temporary = destination.with_suffix('.partial')
    with temporary.open('wb') as stream:
        for offset in range(0, len(stories), 20000):
            batch = [story.strip() for story in stories[offset:offset + 20000]]
            for ids in encoder.encode_batch(batch, num_threads=16):
                np.asarray(ids + [encoder.eot_token], dtype='<u4').tofile(stream)
    temporary.replace(destination)


def sha256(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(8 << 20), b''):
            digest.update(block)
    return digest.hexdigest()


def main():
    DATA.mkdir(parents=True, exist_ok=True)
    train_text = DATA / 'TinyStories-train-prefix.txt'
    valid_text = DATA / 'TinyStories-valid.txt'
    train = DATA / 'tinystories_cl100k_train.u32'
    valid = DATA / 'tinystories_cl100k_valid.u32'
    download('TinyStories-train.txt', train_text, prefix=True)
    download('TinyStories-valid.txt', valid_text)
    tokenize(train_text, train, True)
    tokenize(valid_text, valid, False)
    counts = {'train': train.stat().st_size // 4, 'valid': valid.stat().st_size // 4}
    if counts != {'train': 73910428, 'valid': 4549031}:
        raise RuntimeError(f'Token counts differ from the upstream A100 experiment: {counts}')
    os.environ['MODEL'] = 'S'
    sys.path.insert(0, str(REPO / 'llm/baseline'))
    import common

    weights_path = DATA / 'init_flat_S.f32'
    if not weights_path.exists():
        weights = common.init_weights()
        names = ['wte', 'wpe']
        for layer in range(common.L):
            names += [f'L{layer:02d}_{name}' for name in
                      ('gamma1', 'Wqkv', 'Wo', 'gamma2', 'Wup', 'Wdown')]
        names += ['gamma_f']
        with weights_path.with_suffix('.partial').open('wb') as stream:
            for name in names:
                weights[name].numpy().astype('<f4').tofile(stream)
        weights_path.with_suffix('.partial').replace(weights_path)
    if weights_path.stat().st_size != 162417408 * 4:
        raise RuntimeError('Initial weights have an unexpected parameter count')
    starts = np.random.default_rng(1234).integers(0, counts['train'] - 513, size=(4000, 8))
    starts.astype('<u4').tofile(DATA / 'starts_4000.u32')
    subprocess.run([sys.executable, str(REPO / 'llm/ofa_fast/make_vocab.py'),
                    str(DATA / 'cl100k_vocab.bin'), str(DATA / 'prompt_ids.txt'),
                    'Once upon a time'], check=True)
    artifacts = [train_text, valid_text, train, valid, weights_path,
                 DATA / 'starts_4000.u32', DATA / 'cl100k_vocab.bin', DATA / 'prompt_ids.txt']
    manifest = {'dataset_revision': REVISION, 'token_counts': counts,
                'torch': torch.__version__, 'numpy': np.__version__,
                'tiktoken': tiktoken.__version__, 'seed': 1234,
                'files': {path.name: {'bytes': path.stat().st_size, 'sha256': sha256(path)}
                          for path in artifacts}}
    (DATA / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({'prepared': True, 'token_counts': counts}), flush=True)


if __name__ == '__main__':
    main()

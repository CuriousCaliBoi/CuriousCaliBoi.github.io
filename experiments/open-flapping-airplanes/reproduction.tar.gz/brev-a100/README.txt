Open Flapping Airplanes reproduction recipe

Requires an idle x86-64 A100 with Docker and NVIDIA Container Toolkit.
Run bash launch.sh --steps 100, then bash launch.sh --steps 4000.
The commands download dependencies and data and incur cloud runtime costs.
The wrapper exits after training and does not stop or delete the instance.

Source commit: 9dd7dd0d3c1fc0245b43897eacd8d62aa096c4c1
Results and environment limitations:
https://curiouscaliboi.github.io/experiments/open-flapping-airplanes/

No Doom WAD, dataset, or model weights are bundled. Upstream code and
third-party dependencies retain their respective licenses.

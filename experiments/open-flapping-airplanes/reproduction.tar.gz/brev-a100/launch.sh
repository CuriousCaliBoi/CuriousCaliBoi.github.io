#!/usr/bin/env bash
set -euo pipefail
OFA_PACKAGE_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
OFA_STORAGE_DIR=${OFA_STORAGE_DIR:-"$OFA_PACKAGE_DIR/artifacts"}
mkdir -p "$OFA_STORAGE_DIR/data" "$OFA_STORAGE_DIR/results"
OFA_STORAGE_DIR=$(cd -- "$OFA_STORAGE_DIR" && pwd)
DOCKER=(docker)
if ! docker info >/dev/null 2>&1; then
    DOCKER=(sudo -n docker)
    "${DOCKER[@]}" info >/dev/null
fi
"${DOCKER[@]}" build --platform linux/amd64 -t ofa-a100:9dd7dd0-decode-limit "$OFA_PACKAGE_DIR"
"${DOCKER[@]}" run --rm --gpus device=0 --network host --ipc host \
    --mount "type=bind,source=$OFA_STORAGE_DIR/data,target=/data" \
    --mount "type=bind,source=$OFA_STORAGE_DIR/results,target=/results" \
    ofa-a100:9dd7dd0-decode-limit python /opt/reproduction/reproduce.py "$@"

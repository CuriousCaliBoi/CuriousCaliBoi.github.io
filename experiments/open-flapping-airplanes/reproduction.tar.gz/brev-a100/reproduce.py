import argparse
import http.client
import hashlib
import json
import math
import os
from pathlib import Path
import re
import shutil
import subprocess
import time
import urllib.error
import urllib.request

from PIL import Image
import prepare


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--steps', type=int, default=4000)
    parser.add_argument('--timeout', type=int, default=1200)
    parser.add_argument('--port', type=int, default=8080)
    args = parser.parse_args()
    if not 20 <= args.steps <= 4000:
        parser.error('--steps must be between 20 and 4000')
    gpu = subprocess.check_output(
        ['nvidia-smi', '--query-gpu=name,memory.total,driver_version', '--format=csv,noheader'],
        text=True).strip()
    if len(gpu.splitlines()) != 1 or 'A100' not in gpu:
        raise RuntimeError(f'Expected exactly one visible A100; found: {gpu}')
    active = subprocess.check_output(
        ['nvidia-smi', '--query-compute-apps=pid,process_name', '--format=csv,noheader'],
        text=True).strip()
    if active:
        raise RuntimeError(f'GPU already has compute processes; retry when it is idle:\n{active}')
    prepare.main()
    result_root = Path(os.environ.get('OFA_RESULTS', '/results'))
    result_root.mkdir(parents=True, exist_ok=True)
    result = result_root / (time.strftime('%Y%m%dT%H%M%SZ', time.gmtime()) + f'-{args.steps}')
    result.mkdir()
    shutil.copy2(prepare.DATA / 'manifest.json', result / 'data-manifest.json')
    for name in ('doom-build.log', 'ofa-build.log'):
        shutil.copy2('/opt/' + name, result / name)
    environment = {'gpu': gpu,
                   'source_commit': subprocess.check_output(
                       ['git', '-C', str(prepare.REPO), 'rev-parse', 'HEAD'], text=True).strip(),
                   'doom_commit': subprocess.check_output(
                       ['git', '-C', str(prepare.REPO / 'doom-gpu/doomgeneric'),
                        'rev-parse', 'HEAD'], text=True).strip(),
                   'nvcc': subprocess.check_output(['nvcc', '--version'], text=True),
                   'clang': subprocess.check_output(['clang', '--version'], text=True)}
    source_diff = subprocess.check_output(['git', '-C', str(prepare.REPO), 'diff'], text=True)
    (result / 'source.patch').write_text(source_diff)
    environment['source_patch_sha256'] = hashlib.sha256(source_diff.encode()).hexdigest()
    (result / 'environment.json').write_text(json.dumps(environment, indent=2) + '\n')
    command = ['stdbuf', '-oL', '-eL', str(prepare.REPO / 'llm/ofa_fast/ofa_fast_S'),
               '--steps', str(args.steps), '--sched-steps', '4000',
               '--infer-sms', '17', '--doom-sms', '6', '--port', str(args.port), '--exit',
               '--wad', str(prepare.REPO / 'doom-gpu/doom1.wad'),
               '--prompt-text', 'Once upon a time',
               '--loss-out', str(result / 'loss.txt'),
               '--dump-w', str(result / 'trained-weights.f32'),
               '--text-out', str(result / 'generated-token-ids.txt')]
    for flag, name in [('data', 'tinystories_cl100k_train.u32'), ('init', 'init_flat_S.f32'),
                       ('starts', 'starts_4000.u32'), ('vocab', 'cl100k_vocab.bin'),
                       ('prompt', 'prompt_ids.txt')]:
        command += ['--' + flag, str(prepare.DATA / name)]
    (result / 'command.json').write_text(json.dumps(command, indent=2) + '\n')
    print(f'Running {args.steps} steps; results: {result}', flush=True)
    frames_saved = 0
    last_state = None
    with (result / 'run.log').open('w') as log, (result / 'states.jsonl').open('w') as states:
        process = subprocess.Popen(command, cwd=prepare.REPO / 'llm/ofa_fast',
                                   stdout=log, stderr=subprocess.STDOUT)
        deadline = time.monotonic() + args.timeout
        next_frame = 0
        try:
            while process.poll() is None:
                if time.monotonic() > deadline:
                    raise TimeoutError(f'Run exceeded {args.timeout} seconds')
                try:
                    with urllib.request.urlopen(f'http://127.0.0.1:{args.port}/state', timeout=2) as response:
                        state = json.loads(response.read().decode('utf-8', errors='replace'))
                    last_state = state
                    states.write(json.dumps(state) + '\n')
                    states.flush()
                    if state['frames'] > 0 and time.monotonic() >= next_frame:
                        with urllib.request.urlopen(f'http://127.0.0.1:{args.port}/frame', timeout=2) as response:
                            frame = response.read()
                        if len(frame) == 65024:
                            palette = frame[64000:]
                            pixels = b''.join(palette[index * 4:index * 4 + 3][::-1]
                                              for index in frame[:64000])
                            Image.frombytes('RGB', (320, 200), pixels).save(result / 'doom-latest.png')
                            frames_saved += 1
                        next_frame = time.monotonic() + 5
                except (urllib.error.URLError, TimeoutError, ConnectionError,
                        http.client.HTTPException, json.JSONDecodeError):
                    pass
                time.sleep(0.5)
        finally:
            if process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait()
    output = (result / 'run.log').read_text()
    if process.returncode != 0:
        raise RuntimeError(f'Kernel exited with {process.returncode}:\n{output[-5000:]}')
    losses = [float(line.split()[1]) for line in (result / 'loss.txt').read_text().splitlines()]
    event = re.search(r'kernel time ([\d.]+) s \(event\)', output)
    training = re.search(r'steady state: ([\d.]+) ms/step .*?-> ([\d.]+) tok/s', output)
    decode = re.search(r'decode: (\d+) tokens generated during ([\d.]+) s of training -> ([\d.]+) tok/s', output)
    doom = re.search(r'doom: (\d+) frames in the run, ([\d.]+) fps over the run', output)
    serving_active_near_end = bool(last_state and last_state['steps'] >= args.steps - 20
                                  and last_state['chars_s'] > 0)
    valid = (len(losses) == args.steps and all(math.isfinite(loss) for loss in losses)
             and losses[-1] < losses[0] and all((event, training, decode, doom))
             and int(decode[1]) > 0 and int(doom[1]) > 0 and frames_saved > 0
             and serving_active_near_end)
    summary = {'completed': bool(valid), 'steps': len(losses), 'first_loss': losses[0],
               'final_loss': losses[-1], 'event_seconds': float(event[1]) if event else None,
               'steady_ms_per_step': float(training[1]) if training else None,
               'training_tokens_per_second': float(training[2]) if training else None,
               'decode_tokens_per_second': float(decode[3]) if decode else None,
               'doom_frames': int(doom[1]) if doom else None,
               'doom_fps': float(doom[2]) if doom else None,
               'serving_active_near_end': serving_active_near_end,
               'gpu': gpu, 'full_reproduction': bool(valid and args.steps == 4000),
               'baselines_measured': False}
    (result / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2), flush=True)
    if not valid:
        raise RuntimeError('Run did not pass the training, serving, and Doom checks')


if __name__ == '__main__':
    main()

A, B = Checkpoint("A"), Checkpoint("B")
assert A.config["hidden_activation"] == "gelu_pytorch_tanh"
L = A.config["num_hidden_layers"]
GELU_LIPSCHITZ_BOUND = 1.75

# No activation is evaluated. The constant follows analytically:
# s(z)=k*z*(1+a*z^2), a>=0.
# For z>=0, z*s'(z)<=3*s(z), and s*sech(s)^2<=1/2.
# Thus |d GELU_tanh(z)/dz| <= 1 + 3/4.
# Also |GELU_tanh(z)| <= |z|.

k = np.sqrt(2/np.pi)
coefficients = {
    2:0.5,
    3:0.5*k,
    5:0.5*(k*0.044715-k**3/3)
}

previous = {
    2:[1831],
    3:[1414,82,1671],
    10:[1363,1564,1529],
    12:[1528,1520,1584,259],
    16:[893]
}

def get(cp,l,s):
    return cp.get(f"model.layers.{l}.{s}.weight").astype(np.float64)

def factors(cp,l):
    pre = 1+get(cp,l,"pre_feedforward_layernorm")
    post = 1+get(cp,l,"post_feedforward_layernorm")
    return (
        get(cp,l,"mlp.down_proj").T*post[None,:],
        get(cp,l,"mlp.gate_proj")*pre[None,:],
        get(cp,l,"mlp.up_proj")*pre[None,:]
    )

def rd(x,y):
    return np.einsum("ij,ij->i",x,y)

def rn(x):
    return np.sqrt(rd(x,x))

def coefficient_inner(x,y,n):
    dx,gx,ux = x
    dy,gy,uy = y
    dd,gg,uu = rd(dx,dy),rd(gx,gy),rd(ux,uy)
    gu,ug = rd(gx,uy),rd(ux,gy)
    c = coefficients[n]
    return (c*c/n)*dd*(
        gg**(n-1)*uu+(n-1)*gg**(n-2)*gu*ug
    )

def ranking(values):
    order = np.argsort(values)[::-1]
    ranks = np.empty(len(values),dtype=int)
    ranks[order] = np.arange(1,len(values)+1)
    return order,ranks

summaries = []
units = []

for l in range(L):
    x,y = factors(A,l),factors(B,l)
    da,ga,ua = x
    db,gb,ub = y
    dm,um = (da+db)/2,(ua+ub)/2
    dd,dg,du = db-da,gb-ga,ub-ua

    ndm,num = rn(dm),rn(um)
    ndd,ndg,ndu = rn(dd),rn(dg),rn(du)
    average_gate_norm = (rn(ga)+rn(gb))/2

    # Exact midpoint decomposition is applied symbolically to:
    # d * GELU(g^T x) * (u^T x).
    # Bounding each term gives a valid coefficient of ||x||^2.
    down_bound = ndd*average_gate_norm*num
    gate_bound = ndm*GELU_LIPSCHITZ_BOUND*ndg*num
    up_bound = ndm*average_gate_norm*ndu
    interaction_bound = (
        0.25*ndd*GELU_LIPSCHITZ_BOUND*ndg*ndu
    )
    bound = down_bound+gate_bound+up_bound+interaction_bound
    bound_order,bound_ranks = ranking(bound)

    # Separate upper bounds on the A/B numerator magnitudes.
    baseline_a = rn(da)*rn(ga)*rn(ua)
    baseline_b = rn(db)*rn(gb)*rn(ub)
    baseline_bound = 0.5*float(baseline_a.sum()+baseline_b.sum())
    total_bound = float(bound.sum())

    coefficient_rankings = {}
    for n in [2,3,5]:
        energy = np.maximum(
            coefficient_inner(x,x,n)+coefficient_inner(y,y,n)
            -2*coefficient_inner(x,y,n),0
        )
        coefficient_rankings[n] = ranking(energy)

    bound_top10 = set(bound_order[:10])
    overlap = {
        n:len(bound_top10 & set(coefficient_rankings[n][0][:10]))
        for n in [2,3,5]
    }
    correlations = {
        n:float(np.corrcoef(bound_ranks,coefficient_rankings[n][1])[0,1])
        for n in [2,3,5]
    }
    aggregate_parts = np.array([
        down_bound.sum(),gate_bound.sum(),
        up_bound.sum(),interaction_bound.sum()
    ])/total_bound

    summaries.append({
        "layer":l,
        "bound":total_bound,
        "baseline_ratio":total_bound/baseline_bound,
        "parts":aggregate_parts,
        "overlap":overlap,
        "correlations":correlations,
        "top10_share":float(bound[bound_order[:10]].sum()/total_bound),
        "top_units":bound_order[:5].tolist()
    })

    for i in range(len(bound)):
        units.append({
            "layer":l,"unit":i,
            "bound":float(bound[i]),
            "share":float(bound[i]/total_bound),
            "rank":int(bound_ranks[i]),
            "coefficient_ranks":[
                int(coefficient_rankings[n][1][i]) for n in [2,3,5]
            ],
            "parts":np.array([
                down_bound[i],gate_bound[i],up_bound[i],interaction_bound[i]
            ])/bound[i] if bound[i] else np.zeros(4)
        })

print("=== GLOBAL NONLINEAR NUMERATOR DIFFERENCE BOUNDS ===")
print("For every vector x, the unit numerator difference is bounded by b_i*||x||^2.")
print("No x is constructed or evaluated.")
print("Bounds include stored diagonal gains but exclude RMS denominators.")
print("The sum over units is a valid, potentially loose, whole-numerator bound.")
print("A larger bound does not establish a larger actual effect.")

print("\n=== LAYER BOUND COEFFICIENTS ===")
print("layer | total_bound coefficient / baseline_upper_bound | down/gate/up/interaction shares | top10 bound share")
for r in summaries:
    print(f'{r["layer"]:2d} | {r["bound"]:12.6g} {r["baseline_ratio"]:.7f} | '
          + " ".join(f"{v:.6f}" for v in r["parts"])
          + f' | {r["top10_share"]:.6f}')
print("The baseline ratio compares two bounds, not actual output norms.")

print("\n=== RANKING AGREEMENT WITH PER-UNIT COEFFICIENT CHANGES ===")
print("layer | top10 overlap with degrees 2/3/5 | rank correlations with degrees 2/3/5 | top5 bound units")
for r in summaries:
    print(f'{r["layer"]:2d} | '
          + " ".join(f'{r["overlap"][n]:2d}' for n in [2,3,5])
          + " | "
          + " ".join(f'{r["correlations"][n]:.5f}' for n in [2,3,5])
          + f' | {r["top_units"]}')

print("\n=== PREVIOUS CANDIDATES UNDER THE NONLOCAL BOUND ===")
print("layer unit | bound_rank coefficient_ranks_2_3_5 | share_of_layer_bound | down/gate/up/interaction bound shares")
for r in units:
    if r["layer"] in previous and r["unit"] in previous[r["layer"]]:
        print(f'{r["layer"]:2d} {r["unit"]:4d} | '
              f'{r["rank"]:4d} {r["coefficient_ranks"]} | '
              f'{r["share"]:.7f} | '
              + " ".join(f"{v:.6f}" for v in r["parts"]))

print("\n=== MOST CONCENTRATED UNIT BOUNDS RELATIVE TO THEIR OWN LAYERS ===")
for r in sorted(units,key=lambda r:r["share"],reverse=True)[:20]:
    print(f'layer={r["layer"]:2d} unit={r["unit"]:4d} '
          f'bound_share={r["share"]:.7f} '
          f'coefficient_ranks={r["coefficient_ranks"]}')

print("\nInterpretation limits:")
print("- These are upper bounds, not estimates, lower bounds, activation measurements or causal effects.")
print("- Summing unit bounds discards cancellations and need not be tight.")
print("- The actual normalized MLP output is not bounded here by the same coefficient without additional analysis.")
print("- Agreement between bound and coefficient rankings does not identify semantic functions.")
print("- Only weight norms, inner products and symbolic inequalities were used.")

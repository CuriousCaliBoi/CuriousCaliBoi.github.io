A, B = Checkpoint("A"), Checkpoint("B")
L = A.config["num_hidden_layers"]

def get(cp, layer, suffix):
    return cp.get(f"model.layers.{layer}.{suffix}.weight").astype(np.float64)

def factors(cp, layer, scaled):
    # Rows index MLP units in all three arrays.
    d = get(cp, layer, "mlp.down_proj").T
    g = get(cp, layer, "mlp.gate_proj")
    u = get(cp, layer, "mlp.up_proj")
    if scaled:
        pre = 1 + get(cp, layer, "pre_feedforward_layernorm")
        post = 1 + get(cp, layer, "post_feedforward_layernorm")
        d = d * post[None, :]
        g = g * pre[None, :]
        u = u * pre[None, :]
    return d, g, u

def rowdot(a, b):
    return np.einsum("ij,ij->i", a, b)

def coeff_inner_diagonal(x, y):
    dx, gx, ux = x
    dy, gy, uy = y
    return rowdot(dx,dy) * 0.5 * (
        rowdot(gx,gy)*rowdot(ux,uy)
        + rowdot(gx,uy)*rowdot(ux,gy)
    )

def coeff_gram(x, y):
    dx, gx, ux = x
    dy, gy, uy = y
    return (dx @ dy.T) * 0.5 * (
        (gx @ gy.T)*(ux @ uy.T)
        + (gx @ uy.T)*(ux @ gy.T)
    )

def compare(x, y):
    aa = coeff_inner_diagonal(x,x)
    bb = coeff_inner_diagonal(y,y)
    ab = coeff_inner_diagonal(x,y)
    e = np.maximum(aa + bb - 2*ab, 0)
    base = (aa+bb)/2
    rel = np.sqrt(np.divide(e, base, out=np.zeros_like(e), where=base>0))
    return e, rel, base

unit_rows = []
summaries = []
for l in range(L):
    raw_a, raw_b = factors(A,l,False), factors(B,l,False)
    sc_a, sc_b = factors(A,l,True), factors(B,l,True)
    er, rr, br = compare(raw_a,raw_b)
    es, rs, bs = compare(sc_a,sc_b)
    n = len(es)

    # Inspect interactions among the 32 largest changed coefficient tensors.
    idx = np.argsort(es)[-32:][::-1]
    xa = tuple(z[idx] for z in sc_a)
    xb = tuple(z[idx] for z in sc_b)
    aa = coeff_gram(xa,xa)
    bb = coeff_gram(xb,xb)
    ab = coeff_gram(xa,xb)
    delta_gram = aa + bb - ab - ab.T
    delta_gram = (delta_gram + delta_gram.T)/2
    diagonal_sum = float(np.trace(delta_gram))
    coherence = float(delta_gram.sum()/diagonal_sum) if diagonal_sum else 0
    eigenvalues = np.maximum(np.linalg.eigvalsh(delta_gram), 0)
    effective_rank = (
        float(eigenvalues.sum()**2 / np.sum(eigenvalues**2))
        if np.any(eigenvalues) else 0
    )
    energies_sorted = np.sort(es)[::-1]
    total_es = float(es.sum())
    total_er = float(er.sum())

    summaries.append({
        "layer": l,
        "raw_rss": np.sqrt(total_er),
        "scaled_rss": np.sqrt(total_es),
        "raw_rel": np.sqrt(total_er/br.sum()) if br.sum() else 0,
        "scaled_rel": np.sqrt(total_es/bs.sum()) if bs.sum() else 0,
        "top1": float(energies_sorted[:1].sum()/total_es) if total_es else 0,
        "top10": float(energies_sorted[:10].sum()/total_es) if total_es else 0,
        "top32": float(energies_sorted[:32].sum()/total_es) if total_es else 0,
        "coherence": coherence,
        "effective_rank": effective_rank,
        "top_units": idx[:8].tolist()
    })

    raw_order = np.argsort(er)[::-1]
    raw_ranks = np.empty(n, dtype=int)
    raw_ranks[raw_order] = np.arange(1,n+1)
    scaled_order = np.argsort(es)[::-1]
    scaled_ranks = np.empty(n, dtype=int)
    scaled_ranks[scaled_order] = np.arange(1,n+1)

    for i in range(n):
        unit_rows.append({
            "layer": l, "unit": i,
            "raw_delta": float(np.sqrt(er[i])),
            "scaled_delta": float(np.sqrt(es[i])),
            "raw_rel": float(rr[i]), "scaled_rel": float(rs[i]),
            "raw_rank": int(raw_ranks[i]),
            "scaled_rank": int(scaled_ranks[i]),
            "layer_share": float(es[i]/total_es) if total_es else 0
        })

print("=== MLP COMPOSED-COEFFICIENT DIFFERENCES ===")
print("RSS aggregates individual unit coefficients, not the full summed MLP function.")
print("layer | raw_RSS scaled_RSS raw_relative scaled_relative | top1/top10/top32 energy shares | top32 coherence effective_rank")
for s in summaries:
    print(f'{s["layer"]:2d} | {s["raw_rss"]:10.5g} {s["scaled_rss"]:11.5g} '
          f'{s["raw_rel"]:10.6g} {s["scaled_rel"]:10.6g} | '
          f'{s["top1"]:.5f} {s["top10"]:.5f} {s["top32"]:.5f} | '
          f'{s["coherence"]:9.5f} {s["effective_rank"]:8.3f}')

print("\nCoherence = ||sum of selected coefficient changes||^2 / sum ||individual changes||^2.")
print("It is 1 for mutually orthogonal changes; higher/lower indicates net reinforcement/cancellation.")
print("Effective rank describes their Gram matrix, not a behavioral circuit.")

print("\n=== TOP 30 UNITS BY GAIN-WEIGHTED COEFFICIENT DIFFERENCE ===")
print("layer unit | scaled_delta scaled_relative raw_delta raw_relative | raw/scaled ranks within layer | layer energy share")
for r in sorted(unit_rows, key=lambda r:r["scaled_delta"], reverse=True)[:30]:
    print(f'{r["layer"]:2d} {r["unit"]:4d} | '
          f'{r["scaled_delta"]:11.5g} {r["scaled_rel"]:10.6g} '
          f'{r["raw_delta"]:10.5g} {r["raw_rel"]:10.6g} | '
          f'{r["raw_rank"]:4d}/{r["scaled_rank"]:<4d} | {r["layer_share"]:.6f}')

print("\n=== TOP 20 UNITS WITHOUT NORM GAINS ===")
for r in sorted(unit_rows, key=lambda r:r["raw_delta"], reverse=True)[:20]:
    print(f'layer={r["layer"]:2d} unit={r["unit"]:4d} '
          f'raw_delta={r["raw_delta"]:.6g} raw_relative={r["raw_rel"]:.6g} '
          f'scaled_rank_in_layer={r["scaled_rank"]}')

print("\n=== TOP 8 GAIN-WEIGHTED UNITS IN EACH LAYER ===")
for s in summaries:
    print(s["layer"], s["top_units"])

print("\nLimitations:")
print("- Symmetrized coefficient tensors do not determine the nonlinear GELU-gated function.")
print("- Pre/post RMS denominators, unit usage, residual context, and downstream decoding are absent.")
print("- These measurements cannot assign truth-related or user-belief-related meanings.")
print("- Only weights, diagonal scalings, outer-product identities and Gram matrices were used.")

import collections

A, B = Checkpoint("A"), Checkpoint("B")
L = A.config["num_hidden_layers"]
H = A.config["num_attention_heads"]
D = A.config["head_dim"]
R = A.config["hidden_size"]
assert A.config["num_key_value_heads"] == 1

def get(cp, layer, suffix):
    return cp.get(f"model.layers.{layer}.{suffix}.weight").astype(np.float64)

def fro(x):
    return float(np.sqrt(np.sum(x*x)))

def gain(cp, layer, suffix):
    # Conventional Gemma RMSNorm parameterization: multiplier = 1 + weight.
    # Only its diagonal multiplier is used, never hidden-state normalization.
    return 1.0 + get(cp, layer, suffix)

def metrics(a, b):
    delta = b - a
    na, nb, nd = fro(a), fro(b), fro(delta)
    scale = np.sqrt((na*na + nb*nb) / 2)
    return {
        "na": na, "nb": nb, "delta": nd,
        "rel": nd / scale if scale else 0.0,
        "trace_a": float(np.trace(a)),
        "trace_b": float(np.trace(b)),
        "idcos_a": float(np.trace(a)) / (np.sqrt(R)*na) if na else 0.0,
        "idcos_b": float(np.trace(b)) / (np.sqrt(R)*nb) if nb else 0.0,
    }

norm_names = [
    "input_layernorm",
    "post_attention_layernorm",
    "pre_feedforward_layernorm",
    "post_feedforward_layernorm",
    "self_attn.q_norm",
    "self_attn.k_norm",
]

print("=== NORM DIAGONAL GAINS ===")
print("Uses gain=1+weight. RMS below is a statistic of weights, not a forward pass.")
print("layer | RMS gains in order: input, post-attn, pre-MLP, post-MLP, q, k | differing norm entries")
for l in range(L):
    rms = []
    changed = []
    for name in norm_names:
        ga, gb = gain(A,l,name), gain(B,l,name)
        rms.append(np.sqrt(np.mean(((ga+gb)/2)**2)))
        changed.append(int(np.count_nonzero(ga-gb)))
    print(f"{l:2d} | " + " ".join(f"{x:10.4g}" for x in rms)
          + " | " + str(changed))

records = []
for l in range(L):
    sides = []
    for cp in [A, B]:
        sides.append({
            "q": get(cp,l,"self_attn.q_proj"),
            "k": get(cp,l,"self_attn.k_proj"),
            "v": get(cp,l,"self_attn.v_proj"),
            "o": get(cp,l,"self_attn.o_proj"),
            "in": gain(cp,l,"input_layernorm"),
            "out": gain(cp,l,"post_attention_layernorm"),
            "qg": gain(cp,l,"self_attn.q_norm"),
            "kg": gain(cp,l,"self_attn.k_norm"),
        })

    for h in range(H):
        sl = slice(h*D, (h+1)*D)
        ov_raw, ov_scaled, qk_raw, qk_scaled = [], [], [], []
        for s in sides:
            q = s["q"][sl,:]
            o = s["o"][:,sl]

            ov = o @ s["v"]
            ov_raw.append(ov)
            ov_scaled.append(s["out"][:,None] * ov * s["in"][None,:])

            qk_raw.append(q.T @ s["k"])
            qk = q.T @ ((s["qg"]*s["kg"])[:,None] * s["k"])
            qk_scaled.append(s["in"][:,None] * qk * s["in"][None,:])

        rec = {"layer": l, "head": h}
        rec["ov_raw"] = metrics(*ov_raw)
        rec["ov"] = metrics(*ov_scaled)
        rec["qk_raw"] = metrics(*qk_raw)
        rec["qk"] = metrics(*qk_scaled)
        records.append(rec)

print("\n=== PER-LAYER COMPOSED DIFFERENCES ===")
print("These are sums of squared head-map differences, not behavioral effects.")
print("layer | raw_OV_delta_RSS gain_OV_delta_RSS raw_QK_delta_RSS gain_QK_delta_RSS")
for l in range(L):
    rs = [r for r in records if r["layer"] == l]
    vals = [np.sqrt(sum(r[k]["delta"]**2 for r in rs))
            for k in ["ov_raw","ov","qk_raw","qk"]]
    print(f"{l:2d} | " + " ".join(f"{x:17.6g}" for x in vals))

def show(title, key, ordering, n=16):
    print("\n" + title)
    print("layer head | ||map_A|| ||map_B|| ||delta|| relative_delta | raw_relative_delta | identity_cos_A identity_cos_B")
    for r in sorted(records, key=ordering, reverse=True)[:n]:
        m, raw = r[key], r[key+"_raw"]
        print(f'{r["layer"]:2d} {r["head"]:2d} | '
              f'{m["na"]:11.5g} {m["nb"]:11.5g} {m["delta"]:11.5g} {m["rel"]:10.6g} | '
              f'{raw["rel"]:10.6g} | {m["idcos_a"]:+.7f} {m["idcos_b"]:+.7f}')

show("=== HEADS: LARGEST GAIN-WEIGHTED OV DIFFERENCES ===",
     "ov", lambda r:r["ov"]["delta"])
show("=== HEADS: LARGEST GAIN-WEIGHTED QK NUMERATOR DIFFERENCES ===",
     "qk", lambda r:r["qk"]["delta"])

print("\n=== LARGEST CHANGES IN OV IDENTITY ALIGNMENT ===")
print("Positive difference means B is more identity-aligned; not evidence of user-guess copying.")
print("layer head | gain_identity_cos_A gain_identity_cos_B change | raw_identity_cos_A raw_identity_cos_B")
for r in sorted(records,
                key=lambda r:abs(r["ov"]["idcos_b"]-r["ov"]["idcos_a"]),
                reverse=True)[:16]:
    m, raw = r["ov"], r["ov_raw"]
    print(f'{r["layer"]:2d} {r["head"]:2d} | '
          f'{m["idcos_a"]:+.8f} {m["idcos_b"]:+.8f} '
          f'{m["idcos_b"]-m["idcos_a"]:+.8f} | '
          f'{raw["idcos_a"]:+.8f} {raw["idcos_b"]:+.8f}')

print("\nInterpretation limits:")
print("- OV maps omit input-dependent attention probabilities and RMS denominators.")
print("- QK maps omit RMS denominators and nonzero-offset rotary rotations.")
print("- Shared K and V mean head differences are not independent parameter changes.")
print("- No tokens, test vectors, hidden states, activations, or forward passes were used.")

The MLP analysis found some concentrated unit-level changes, but no generally dominant small set. For example, layer 10’s unit 1363 accounts for **7.93%** of that layer’s gain-weighted coefficient-change energy. The top-32 coefficient changes mostly neither strongly reinforce nor cancel. Including norm gains also substantially reorders the candidates: layer 3 dominates the weighted measure, whereas other layers dominate the unweighted measure.

These are structural findings, not evidence that those units represent agreement or correctness. My current probability that A is sycophantic remains **0.5**.

Next I’ll test a different possibility: whether otherwise distributed changes share a **low-dimensional residual-space direction**. A coordinated change to what attention and MLPs write—and what later components read—would be more informative than isolated large differences. I’ll compare weight-difference covariance eigenspaces, balancing tensors so that large tensors do not automatically dominate. This uses only matrix products and eigendecompositions.

Under either behavioral labeling, such coordination could exist; its presence would identify candidate directions, but its sign would still need semantic interpretation.

```python
import collections

A, B = Checkpoint("A"), Checkpoint("B")
L = A.config["num_hidden_layers"]
R = A.config["hidden_size"]

specs = [
    ("self_attn.o_proj", "attention_write", "write"),
    ("mlp.down_proj", "mlp_write", "write"),
    ("self_attn.q_proj", "attention_read", "read"),
    ("self_attn.k_proj", "attention_read", "read"),
    ("self_attn.v_proj", "attention_read", "read"),
    ("mlp.gate_proj", "mlp_read", "read"),
    ("mlp.up_proj", "mlp_read", "read"),
]

covariances = collections.defaultdict(list)
records = []

for l in range(L):
    for suffix, group, orientation in specs:
        name = f"model.layers.{l}.{suffix}.weight"
        a = A.get(name).astype(np.float64)
        b = B.get(name).astype(np.float64)
        delta = b-a
        mid = (a+b)/2
        energy = float(np.sum(delta*delta))
        if energy == 0:
            continue

        # Each covariance is in the common 640-dimensional residual basis.
        if orientation == "write":
            c = (delta @ delta.T) / energy
        else:
            c = (delta.T @ delta) / energy

        mid_energy = float(np.sum(mid*mid))
        radial_dot = float(np.sum(delta*mid))
        radial_fraction = (
            radial_dot**2/(energy*mid_energy) if mid_energy else 0
        )

        participation = float(np.trace(c)**2 / np.sum(c*c))
        diag = np.diag(c)
        top_coordinates = np.argsort(diag)[-8:][::-1]
        rec = {
            "layer": l, "suffix": suffix, "group": group,
            "cov": c, "delta_norm": np.sqrt(energy),
            "participation": participation,
            "radial_fraction": radial_fraction,
            "top1_coord_energy": float(diag.max()),
            "top8_coord_energy": float(diag[top_coordinates].sum()),
            "top_coordinates": top_coordinates.tolist(),
        }
        records.append(rec)
        covariances[group].append(c)

groups = {}
print("=== SHARED RESIDUAL-SPACE DIFFERENCE GEOMETRY ===")
print("Each contributing tensor has trace-one covariance; tensors are equally weighted.")
print("Reference: isotropic top-1/4/16/64 shares =", np.array([1,4,16,64])/R)

for group in sorted(covariances):
    c = sum(covariances[group]) / len(covariances[group])
    ev, vec = np.linalg.eigh(c)
    order = np.argsort(ev)[::-1]
    ev, vec = np.maximum(ev[order],0), vec[:,order]
    groups[group] = {"cov":c, "evals":ev, "vectors":vec}

    pr = float(ev.sum()**2/np.sum(ev*ev))
    shares = [float(ev[:k].sum()/ev.sum()) for k in [1,4,16,64]]
    top_diag = np.argsort(np.diag(c))[-8:][::-1]
    print("\nGroup:", group, "tensor_count:", len(covariances[group]))
    print("Effective rank:", pr)
    print("Top-1/4/16/64 eigenvalue energy shares:", shares)
    print("Top 8 eigenvalues:", ev[:8])
    print("Top diagonal coordinates:", top_diag.tolist())
    print("Their diagonal energies:", np.diag(c)[top_diag])

print("\n=== LOWEST INDIVIDUAL RESIDUAL-COVARIANCE EFFECTIVE RANKS ===")
print("layer tensor | effective_rank radial_scale_fraction top1_coord_share top8_coord_share")
for r in sorted(records, key=lambda r:r["participation"])[:24]:
    print(f'{r["layer"]:2d} {r["suffix"]:23s} | '
          f'{r["participation"]:9.3f} {r["radial_fraction"]:12.7f} '
          f'{r["top1_coord_energy"]:12.6f} {r["top8_coord_energy"]:12.6f}')

print("\n=== OVERLAP BETWEEN GROUPS' LEADING 16-DIMENSIONAL SUBSPACES ===")
print("Mean squared canonical cosine; independent isotropic reference is 16/640 =", 16/R)
names = sorted(groups)
for i, g1 in enumerate(names):
    for g2 in names[i+1:]:
        v1 = groups[g1]["vectors"][:,:16]
        v2 = groups[g2]["vectors"][:,:16]
        canonical = np.linalg.svd(v1.T @ v2, compute_uv=False)
        print(g1, "<->", g2,
              "mean_squared_cosine=", float(np.mean(canonical**2)),
              "largest_squared_cosine=", float(canonical[0]**2))

print("\n=== TENSORS MOST ALIGNED WITH THEIR GROUP'S TOP FOUR CHANGE DIRECTIONS ===")
print("The shared directions are inferred from the same weights, not independent validation.")
for r in records:
    v = groups[r["group"]]["vectors"][:,:4]
    r["shared4_energy"] = float(np.sum(v * (r["cov"] @ v)))
for r in sorted(records, key=lambda r:r["shared4_energy"], reverse=True)[:24]:
    print(f'{r["layer"]:2d} {r["suffix"]:23s} '
          f'group={r["group"]:16s} shared4_energy={r["shared4_energy"]:.6f} '
          f'effective_rank={r["participation"]:.3f}')

print("\n=== READ/WRITE ALIGNMENT OF INDIVIDUAL CHANGE COVARIANCES ===")
print("Frobenius cosine of covariance matrices. Isotropic concentration can contribute to this measure.")
paired = []
for l in range(L):
    rs = [r for r in records if r["layer"] == l]
    for w in [r for r in rs if r["group"].endswith("write")]:
        for rd in [r for r in rs if r["group"].endswith("read")]:
            x,y = w["cov"],rd["cov"]
            cosine = float(np.sum(x*y)/np.sqrt(np.sum(x*x)*np.sum(y*y)))
            paired.append((cosine,l,w["suffix"],rd["suffix"]))
for cosine,l,w,rd in sorted(paired,reverse=True)[:16]:
    print(f"layer={l:2d} {w:23s} -> {rd:23s} covariance_cosine={cosine:.6f}")

print("\nNo model functions, nonlinearities, hidden-state normalization, or test vectors were evaluated.")
print("Shared weight-change directions do not by themselves identify shared semantic features.")
```
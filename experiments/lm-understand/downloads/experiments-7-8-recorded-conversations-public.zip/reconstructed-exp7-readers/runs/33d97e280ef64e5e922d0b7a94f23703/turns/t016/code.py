A, B = Checkpoint("A"), Checkpoint("B")
L = A.config["num_hidden_layers"]
H = A.config["num_attention_heads"]
D = A.config["head_dim"]

def get(cp,l,s):
    return cp.get(f"model.layers.{l}.{s}.weight").astype(np.float64)

def sq(x):
    return float(np.sum(x*x))

def basis(matrix):
    u,s,_ = np.linalg.svd(matrix,full_matrices=False)
    threshold = float(s[0])*1e-12 if len(s) else 0
    keep = s>threshold
    return u[:,keep],int(np.count_nonzero(keep))

def analyze(oa,ob,va,vb,input_basis=None):
    om,vm = (oa+ob)/2,(va+vb)/2
    do,dv = ob-oa,vb-va
    u,output_rank = basis(om)
    if input_basis is None:
        w,input_rank = basis(vm.T)
    else:
        w,input_rank = input_basis

    # Orthogonal parts of factor changes relative to midpoint subspaces.
    do_outside = do-u@(u.T@do)
    dv_outside = dv-(dv@w)@w.T

    ma,mb = oa@va,ob@vb
    delta = mb-ma
    outside_write = do_outside@vm
    outside_read = om@dv_outside
    within = delta-outside_write-outside_read

    total = sq(delta)
    energies = np.array([sq(within),sq(outside_write),sq(outside_read)])
    shares = energies/total if total else np.zeros(3)
    baseline = 0.5*(sq(ma)+sq(mb))
    relative = np.sqrt(total/baseline) if baseline else 0

    cross = [
        float(np.sum(within*outside_write)),
        float(np.sum(within*outside_read)),
        float(np.sum(outside_write*outside_read))
    ]
    orthogonality = max(abs(v) for v in cross)/total if total else 0

    # For a difference of two bilinear products, the simultaneous
    # outside-input/outside-output block vanishes at the midpoint.
    double_outside = delta-u@(u.T@delta)
    double_outside -= (double_outside@w)@w.T
    null_fraction = sq(double_outside)/total if total else 0

    return {
        "energy":total,"shares":shares,"relative":relative,
        "input_rank":input_rank,"output_rank":output_rank,
        "orthogonality":orthogonality,
        "double_outside_fraction":null_fraction,
        "energy_closure_error":abs(float(shares.sum())-1)
    }

previous_attention_candidates = {
    (11,0),(11,1),(12,0),(12,1),(12,2),(12,3),
    (15,1),(17,1),(10,1)
}
records = []
raw_checks = {}

for l in range(L):
    oa0,ob0 = get(A,l,"self_attn.o_proj"),get(B,l,"self_attn.o_proj")
    va0,vb0 = get(A,l,"self_attn.v_proj"),get(B,l,"self_attn.v_proj")
    ia,ib = 1+get(A,l,"input_layernorm"),1+get(B,l,"input_layernorm")
    pa,pb = 1+get(A,l,"post_attention_layernorm"),1+get(B,l,"post_attention_layernorm")

    va,vb = va0*ia[None,:],vb0*ib[None,:]
    common_input_basis = basis(((va+vb)/2).T)
    raw_input_basis = (
        basis(((va0+vb0)/2).T)
        if any(ll==l for ll,hh in previous_attention_candidates)
        else None
    )

    for h in range(H):
        sl = slice(h*D,(h+1)*D)
        oa,ob = pa[:,None]*oa0[:,sl],pb[:,None]*ob0[:,sl]
        r = analyze(oa,ob,va,vb,common_input_basis)
        r.update({"layer":l,"head":h})
        records.append(r)
        if (l,h) in previous_attention_candidates:
            raw_checks[(l,h)] = analyze(
                oa0[:,sl],ob0[:,sl],va0,vb0,raw_input_basis
            )

print("=== VALUE-MAP READ/WRITE SUBSPACE DECOMPOSITION ===")
print("Main analysis includes norm diagonal gains, but not hidden-state RMS denominators.")
print("Fractions: within midpoint subspaces; outside output subspace; outside input subspace.")
print("These are orthogonal fractions of value-map difference energy, not behavioral importance.")

print("\n=== PER-LAYER ENERGY-WEIGHTED FRACTIONS ===")
print("layer | within outside_write outside_read | aggregate_delta_norm")
for l in range(L):
    rs = [r for r in records if r["layer"]==l]
    energy = sum(r["energy"] for r in rs)
    shares = sum(r["shares"]*r["energy"] for r in rs)/energy
    print(f"{l:2d} | " + " ".join(f"{x:.6f}" for x in shares)
          + f" | {np.sqrt(energy):.6g}")

total_energy = sum(r["energy"] for r in records)
weighted = sum(r["shares"]*r["energy"] for r in records)/total_energy
unweighted = np.mean([r["shares"] for r in records],axis=0)
print("\nGlobal energy-weighted fractions:",weighted)
print("Equal-head mean fractions:",unweighted)
print("Input/output ranks encountered:",
      sorted(set((r["input_rank"],r["output_rank"]) for r in records)))
print("Maximum normalized cross-inner-product:",max(r["orthogonality"] for r in records))
print("Maximum energy closure error:",max(r["energy_closure_error"] for r in records))
print("Maximum double-outside fraction:",max(r["double_outside_fraction"] for r in records))

def show(title,rows):
    print("\n"+title)
    print("layer head | within outside_write outside_read | relative_OV_change delta_norm")
    for r in rows:
        print(f'{r["layer"]:2d} {r["head"]} | '
              + " ".join(f"{x:.6f}" for x in r["shares"])
              + f' | {r["relative"]:.6f} {np.sqrt(r["energy"]):.6g}')

show("=== LARGEST OUTSIDE-INPUT FRACTIONS ===",
     sorted(records,key=lambda r:r["shares"][2],reverse=True)[:12])
show("=== LARGEST OUTSIDE-OUTPUT FRACTIONS ===",
     sorted(records,key=lambda r:r["shares"][1],reverse=True)[:12])
show("=== LARGEST WITHIN-SUBSPACE FRACTIONS ===",
     sorted(records,key=lambda r:r["shares"][0],reverse=True)[:12])

print("\n=== PREVIOUS CANDIDATES: GAIN-WEIGHTED VERSUS RAW GEOMETRY ===")
print("layer head | weighted within/write/read | raw within/write/read")
for r in records:
    key = (r["layer"],r["head"])
    if key in raw_checks:
        raw = raw_checks[key]
        print(f'{key[0]:2d} {key[1]} | '
              + " ".join(f"{x:.6f}" for x in r["shares"])
              + " | " + " ".join(f"{x:.6f}" for x in raw["shares"]))

print("\nInterpretation limits:")
print("- Midpoint subspaces are not the unavailable starting model's subspaces.")
print("- Outside-subspace changes do not automatically represent new semantic features.")
print("- The zero double-outside block follows algebraically from midpoint bilinearity; it is a consistency check.")
print("- The decomposition omits attention selection and nonlinear downstream processing.")
print("- No inputs, activations, predictions, training or checkpoint modifications were used.")

A, B = Checkpoint("A"), Checkpoint("B")
L = A.config["num_hidden_layers"]
H = A.config["num_attention_heads"]
D = A.config["head_dim"]

def get(cp,l,s):
    return cp.get(f"model.layers.{l}.{s}.weight").astype(np.float64)

def dot(a,b):
    return float(np.sum(a*b))

def norm(a):
    return np.sqrt(dot(a,a))

def relative(a,b):
    scale = np.sqrt((dot(a,a)+dot(b,b))/2)
    return norm(b-a)/scale if scale else 0.0

records = []
for l in range(L):
    sides = []
    for cp in [A,B]:
        pre = 1+get(cp,l,"input_layernorm")
        sides.append({
            "q": get(cp,l,"self_attn.q_proj")*pre[None,:],
            "k": get(cp,l,"self_attn.k_proj")*pre[None,:],
            "qg": 1+get(cp,l,"self_attn.q_norm"),
            "kg": 1+get(cp,l,"self_attn.k_norm")
        })

    for h in range(H):
        sl = slice(h*D,(h+1)*D)
        canonical = []
        unscaled = []
        for s in sides:
            q,k = s["q"][sl,:],s["k"]
            p = q.T@q
            r = k.T@k
            m = q.T@((s["qg"]*s["kg"])[:,None]*k)
            tq,tr = float(np.trace(p)),float(np.trace(r))
            canonical.append((m/np.sqrt(tq*tr),p/tq,r/tr))
            unscaled.append(m)

        rels = [relative(x,y) for x,y in zip(canonical[0],canonical[1])]

        sa,sb = sides
        qa,qb = sa["q"][sl,:],sb["q"][sl,:]
        ka,kb = sa["k"],sb["k"]
        qm,km = (qa+qb)/2,(ka+kb)/2
        dq,dk = qb-qa,kb-ka
        qgm,kgm = (sa["qg"]+sb["qg"])/2,(sa["kg"]+sb["kg"])/2
        dqg,dkg = sb["qg"]-sa["qg"],sb["kg"]-sa["kg"]
        za,zb = sa["qg"]*sa["kg"],sb["qg"]*sb["kg"]
        zm,dz = (za+zb)/2,zb-za

        terms = [
            dq.T@(zm[:,None]*km),
            qm.T@(zm[:,None]*dk),
            qm.T@((dqg*kgm)[:,None]*km),
            qm.T@((qgm*dkg)[:,None]*km),
            0.25*dq.T@(dz[:,None]*dk)
        ]
        delta = unscaled[1]-unscaled[0]
        energy = dot(delta,delta)
        shares = [dot(t,delta)/energy if energy else 0 for t in terms]
        error = norm(delta-sum(terms))/np.sqrt(energy) if energy else 0

        # Q/K projection changes purely parallel to their respective midpoint
        # mostly rescale rather than rotate their maps.
        def radial_fraction(x,dx):
            denominator = dot(x,x)*dot(dx,dx)
            return dot(x,dx)**2/denominator if denominator else 0

        records.append({
            "layer":l,"head":h,
            "numerator_rel":rels[0],
            "query_metric_rel":rels[1],
            "key_metric_rel":rels[2],
            "joint":float(np.sqrt(np.mean(np.square(rels)))),
            "raw_numerator_rel":relative(*unscaled),
            "shares":shares,
            "q_radial":radial_fraction(qm,dq),
            "k_radial":radial_fraction(km,dk),
            "error":error
        })

print("=== SCALE-CANONICAL ATTENTION SCORING FORMS ===")
print("M = Q^T diag(q_gain*k_gain) K; P = Q^T Q; R = K^T K.")
print("Input norm diagonal gains are folded into Q and K.")
print("Canonical forms: M/sqrt(tr(P)tr(R)), P/tr(P), R/tr(R).")
print("These retain zero-offset normalized-score geometry in the zero-epsilon limit.")
print("They are not attention scores evaluated on any inputs.")
print("\nLargest equal-weight RMS relative changes of the three forms:")
print("layer head | joint numerator query_metric key_metric | uncanonicalized_numerator")
for r in sorted(records,key=lambda r:r["joint"],reverse=True)[:24]:
    print(f'{r["layer"]:2d} {r["head"]:2d} | '
          f'{r["joint"]:.7f} {r["numerator_rel"]:.7f} '
          f'{r["query_metric_rel"]:.7f} {r["key_metric_rel"]:.7f} | '
          f'{r["raw_numerator_rel"]:.7f}')

print("\n=== LAYER SUMMARY: MEAN RELATIVE FORM CHANGES OVER HEADS ===")
print("layer | numerator query_metric key_metric")
for l in range(L):
    rs = [r for r in records if r["layer"]==l]
    vals = [np.mean([r[k] for r in rs])
            for k in ["numerator_rel","query_metric_rel","key_metric_rel"]]
    print(f"{l:2d} | " + " ".join(f"{x:.7f}" for x in vals))

print("\n=== EXACT NUMERATOR FACTOR ATTRIBUTIONS FOR TOP ROUTING CANDIDATES ===")
print("Signed shares: Q/input, K/input, q_norm gain, k_norm gain, third-order interaction.")
for r in sorted(records,key=lambda r:r["joint"],reverse=True)[:20]:
    print(f'{r["layer"]:2d} {r["head"]:2d} | '
          + " ".join(f"{x:+.7f}" for x in r["shares"]))

print("\nLargest reconstruction error:",max(r["error"] for r in records))
print("Maximum Q radial fraction:",max(r["q_radial"] for r in records))
print("Maximum K radial fraction:",max(r["k_radial"] for r in records))

print("\nCautions:")
print("- Equal-weight joint ranking is a descriptive convention, not an importance measure.")
print("- Key geometry is shared across all four heads in a layer.")
print("- Epsilon terms, nonzero rotary offsets, softmax competition, and actual positions are not evaluated.")
print("- No construction here identifies question, guess, answer, or correctness features.")

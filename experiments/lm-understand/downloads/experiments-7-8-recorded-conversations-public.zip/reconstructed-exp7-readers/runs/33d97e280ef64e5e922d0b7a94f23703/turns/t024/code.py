A, B = Checkpoint("A"), Checkpoint("B")
L = A.config["num_hidden_layers"]
H = A.config["num_attention_heads"]
D = A.config["head_dim"]
R = A.config["hidden_size"]
assert A.config["num_key_value_heads"] == 1

def get(cp,l,s):
    return cp.get(f"model.layers.{l}.{s}.weight").astype(np.float64)

def analyze_head_maps(maps_a,maps_b):
    ma = np.stack(maps_a)
    mb = np.stack(maps_b)
    fa,fb = ma.reshape(H,-1),mb.reshape(H,-1)
    delta = fb-fa
    gram = delta@delta.T
    base_gram = 0.5*(fa@fa.T+fb@fb.T)

    energy = float(np.trace(gram))
    summed_energy = max(float(gram.sum()),0)
    base_energy = float(np.trace(base_gram))
    base_summed_energy = max(float(base_gram.sum()),0)

    coherence = summed_energy/energy if energy else 0
    common_fraction = coherence/H
    base_common_fraction = (
        base_summed_energy/(H*base_energy) if base_energy else 0
    )
    summed_relative = (
        np.sqrt(summed_energy/base_summed_energy)
        if base_summed_energy else float("nan")
    )

    diagonal = np.maximum(np.diag(gram),0)
    denominator = np.sqrt(diagonal[:,None]*diagonal[None,:])
    correlations = np.divide(
        gram,denominator,out=np.zeros_like(gram),where=denominator>0
    )
    off_diagonal = correlations[np.triu_indices(H,1)]

    shares = (
        gram.sum(axis=1)/summed_energy
        if summed_energy else np.zeros(H)
    )
    eigenvalues,eigenvectors = np.linalg.eigh((gram+gram.T)/2)
    top = eigenvectors[:,-1]
    if top[np.argmax(np.abs(top))] < 0:
        top = -top

    sum_a,sum_b = ma.sum(axis=0),mb.sum(axis=0)
    na,nb = np.linalg.norm(sum_a),np.linalg.norm(sum_b)
    identity_a = float(np.trace(sum_a)/(np.sqrt(R)*na)) if na else 0
    identity_b = float(np.trace(sum_b)/(np.sqrt(R)*nb)) if nb else 0

    return {
        "energy":energy,
        "summed_energy":summed_energy,
        "coherence":coherence,
        "common_fraction":common_fraction,
        "contrast_fraction":1-common_fraction,
        "base_common_fraction":base_common_fraction,
        "summed_relative":summed_relative,
        "correlations":correlations,
        "min_correlation":float(off_diagonal.min()),
        "max_correlation":float(off_diagonal.max()),
        "shares":shares,
        "leading_mode":top,
        "leading_mode_share":float(eigenvalues[-1]/energy) if energy else 0,
        "identity_a":identity_a,"identity_b":identity_b
    }

records = []
for l in range(L):
    sides = []
    for cp in [A,B]:
        o = get(cp,l,"self_attn.o_proj")
        v = get(cp,l,"self_attn.v_proj")
        pre = 1+get(cp,l,"input_layernorm")
        post = 1+get(cp,l,"post_attention_layernorm")
        raw,scaled = [],[]
        for h in range(H):
            sl = slice(h*D,(h+1)*D)
            m = o[:,sl]@v
            raw.append(m)
            scaled.append(post[:,None]*m*pre[None,:])
        sides.append((raw,scaled))
    records.append({
        "layer":l,
        "raw":analyze_head_maps(sides[0][0],sides[1][0]),
        "scaled":analyze_head_maps(sides[0][1],sides[1][1])
    })

print("=== CROSS-HEAD COMPENSATION TEST ===")
print("Common fraction = ||sum_h delta M_h||^2 / (H * sum_h ||delta M_h||^2).")
print("The remainder is the orthogonal head-contrast component.")
print("Uncorrelated head-map changes have reference common fraction 1/H =",1/H)
print("This is a geometric reference, not a statistical null model.")

print("\n=== ALL LAYERS ===")
print("layer | gain-weighted common contrast baseline_common | raw common baseline_common | relative_summed_map_change | min/max head-change cosine")
for r in records:
    s,t = r["scaled"],r["raw"]
    print(f'{r["layer"]:2d} | '
          f'{s["common_fraction"]:.6f} {s["contrast_fraction"]:.6f} '
          f'{s["base_common_fraction"]:.6f} | '
          f'{t["common_fraction"]:.6f} {t["base_common_fraction"]:.6f} | '
          f'{s["summed_relative"]:.6f} | '
          f'{s["min_correlation"]:+.5f} {s["max_correlation"]:+.5f}')

print("\n=== AGGREGATE COMMON/CONTRAST FRACTIONS ===")
for key in ["raw","scaled"]:
    total = sum(r[key]["energy"] for r in records)
    common = sum(r[key]["common_fraction"]*r[key]["energy"]
                 for r in records)/total
    equal_layer = float(np.mean([r[key]["common_fraction"] for r in records]))
    print(key,
          "energy_weighted_common_fraction=",common,
          "equal_layer_mean_common_fraction=",equal_layer)

print("\n=== STRONGEST GAIN-WEIGHTED HEAD COMPENSATION ===")
for r in sorted(records,key=lambda r:r["scaled"]["common_fraction"])[:6]:
    s = r["scaled"]
    print("\nLayer",r["layer"])
    print("Head-change correlation matrix:")
    print(s["correlations"])
    print("Signed contributions to summed-map change:",s["shares"])
    print("Leading head-combination coefficients:",s["leading_mode"])
    print("Leading combination's change-energy share:",s["leading_mode_share"])

print("\n=== PREVIOUS ATTENTION CANDIDATE LAYERS ===")
print("Signed shares below concern the summed map only, not actual head importance.")
for l in [10,11,12,15,17]:
    r = records[l]
    print("layer",l,
          "gain_weighted_shares=",r["scaled"]["shares"],
          "raw_shares=",r["raw"]["shares"])

print("\n=== SIGNED IDENTITY-ALIGNMENT CHANGES OF SUMMED VALUE MAPS ===")
print("Positive B-A means greater identity alignment in B, not identified guess copying.")
for r in sorted(records,
                key=lambda r:abs(r["scaled"]["identity_b"]-r["scaled"]["identity_a"]),
                reverse=True)[:10]:
    s = r["scaled"]
    print(f'layer={r["layer"]:2d} '
          f'A={s["identity_a"]:+.8f} B={s["identity_b"]:+.8f} '
          f'B_minus_A={s["identity_b"]-s["identity_a"]:+.8f}')

print("\nInterpretation limits:")
print("- Summed value maps describe the shared-mixture case algebraically; actual heads may attend differently.")
print("- A head-contrast change can have a large effect when head attention patterns differ.")
print("- Query/key routing changes and output RMS denominators are not included in this test.")
print("- Negative signed contributions are matrix cancellation, not opposition to a semantic behavior.")
print("- No attention probabilities, inputs, activations, model execution or training were used.")

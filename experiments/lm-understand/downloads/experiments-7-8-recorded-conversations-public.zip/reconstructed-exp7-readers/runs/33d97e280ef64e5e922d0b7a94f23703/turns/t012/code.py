import collections

A, B = Checkpoint("A"), Checkpoint("B")

print("=== STORAGE TYPES ===")
print("A:",dict(collections.Counter(i["dtype"] for i in A.info.values())))
print("B:",dict(collections.Counter(i["dtype"] for i in B.info.values())))

def bf16_intervals(x):
    """Rounding-cell boundaries in float64 for exactly BF16-representable values."""
    x = np.asarray(x,dtype=np.float32)
    if not np.isfinite(x).all():
        raise ValueError("Nonfinite weight.")
    if np.any(x.view(np.uint32) & np.uint32(0xffff)):
        raise ValueError("Values are not exactly on the BF16 grid.")

    mag = np.abs(x)
    code = mag.view(np.uint32) >> np.uint32(16)
    prev_code = np.maximum(code,np.uint32(1))-np.uint32(1)
    next_code = code+np.uint32(1)
    previous = (prev_code << np.uint32(16)).view(np.float32).astype(np.float64)
    following = (next_code << np.uint32(16)).view(np.float32).astype(np.float64)
    center = mag.astype(np.float64)

    lo_mag = (previous+center)/2
    hi_mag = (center+following)/2
    lo = np.where(x<0,-hi_mag,lo_mag)
    hi = np.where(x<0,-lo_mag,hi_mag)

    # Include both signs in the rounding cell for zero.
    zero = (x==0)
    lo = np.where(zero,-hi_mag,lo)
    hi = np.where(zero,hi_mag,hi)
    return lo,hi

def interval_difference(a,b):
    alo,ahi = bf16_intervals(a)
    blo,bhi = bf16_intervals(b)
    lower,upper = blo-ahi,bhi-alo
    # Nearest point to zero in the possible pre-rounding B-A interval.
    minimum = np.where(lower>0,lower,np.where(upper<0,upper,0.0))
    return minimum

def layer_of(name):
    match = re.search(r"(?:^|\.)layers\.(\d+)\.",name)
    return int(match.group(1)) if match else -1

selected = {
    (11,"self_attn.k_proj"),
    (12,"self_attn.q_proj"),
    (15,"self_attn.v_proj"),
    (15,"self_attn.o_proj"),
    (10,"self_attn.q_proj"),
    (12,"mlp.down_proj"),
    (10,"mlp.down_proj"),
    (2,"mlp.down_proj"),
    (3,"mlp.gate_proj"),
    (16,"mlp.down_proj"),
    (14,"mlp.down_proj"),
}
selected_names = {
    f"model.layers.{l}.{s}.weight":(l,s) for l,s in selected
}

summaries = []
layers = collections.defaultdict(
    lambda:{"observed_energy":0.0,"minimum_energy":0.0,
            "changed":0,"separated":0}
)
selected_differences = {}
skipped = []

for name in A.keys():
    if name not in B.info:
        continue
    if A.info[name]["dtype"] != "BF16" or B.info[name]["dtype"] != "BF16":
        skipped.append(name)
        continue
    a,b = A.get(name),B.get(name)
    delta = b.astype(np.float64)-a.astype(np.float64)
    minimum = interval_difference(a,b)

    observed_energy = float(np.sum(delta*delta))
    minimum_energy = float(np.sum(minimum*minimum))
    changed = int(np.count_nonzero(delta))
    separated = int(np.count_nonzero(minimum))
    row = {
        "name":name,"layer":layer_of(name),
        "observed_energy":observed_energy,
        "minimum_energy":minimum_energy,
        "changed":changed,"separated":separated
    }
    summaries.append(row)
    aggregate = layers[row["layer"]]
    for key in aggregate:
        aggregate[key] += row[key]

    if name in selected_names:
        selected_differences[name] = (delta,minimum)

print("Skipped non-BF16 tensors:",len(skipped))
if skipped:
    print("First skipped names:",skipped[:10])

total_e = sum(r["observed_energy"] for r in summaries)
minimum_e = sum(r["minimum_energy"] for r in summaries)
total_changed = sum(r["changed"] for r in summaries)
total_separated = sum(r["separated"] for r in summaries)

print("\n=== GLOBAL ROUNDING-CELL SENSITIVITY ===")
print("Observed difference energy:",total_e)
print("Minimum pre-rounding difference energy allowed by independent cells:",minimum_e)
print("Minimum/observed energy:",minimum_e/total_e if total_e else None)
print("Observed changed entries:",total_changed)
print("Entries with strictly separated rounding cells:",total_separated)
print("Separated fraction among changed entries:",
      total_separated/total_changed if total_changed else None)

print("\n=== PER-LAYER ROUNDING-CELL SENSITIVITY ===")
print("layer | minimum/observed energy | separated fraction among changed entries")
for l,r in sorted(layers.items()):
    if r["observed_energy"]==0:
        print(l,"unchanged stored values")
        continue
    print(f'{l:2d} | {r["minimum_energy"]/r["observed_energy"]:.7f} | '
          f'{r["separated"]/r["changed"]:.7f}')

def residual_covariance(delta,suffix):
    if suffix in ["self_attn.o_proj","mlp.down_proj"]:
        c = delta@delta.T
    else:
        c = delta.T@delta
    trace = float(np.trace(c))
    return c/trace if trace else c

def eigensummary(c):
    values,vectors = np.linalg.eigh((c+c.T)/2)
    order = np.argsort(values)[::-1]
    values = np.maximum(values[order],0)
    vectors = vectors[:,order]
    total = float(values.sum())
    effective_rank = (
        total*total/float(np.sum(values*values)) if total else 0
    )
    return values,vectors,effective_rank

print("\n=== CANDIDATE SUBSPACE ROBUSTNESS ===")
print("The minimum-separation array is a diagnostic, not an estimate of the actual unrounded update.")
print("layer tensor | retained_energy | effective_rank_original minimum | top16_subspace_overlap | top1_energy_original minimum")

for name in sorted(selected_differences):
    l,suffix = selected_names[name]
    delta,minimum = selected_differences[name]
    c0 = residual_covariance(delta,suffix)
    c1 = residual_covariance(minimum,suffix)
    e0,v0,pr0 = eigensummary(c0)
    e1,v1,pr1 = eigensummary(c1)
    overlap = float(np.sum((v0[:,:16].T@v1[:,:16])**2)/16)
    retained = float(np.sum(minimum*minimum)/np.sum(delta*delta))
    print(f'{l:2d} {suffix:23s} | {retained:.6f} | '
          f'{pr0:9.3f} {pr1:9.3f} | {overlap:.6f} | '
          f'{e0[0]:.6f} {e1[0]:.6f}')

changed_rows = [r for r in summaries if r["observed_energy"]>0]
print("\n=== MATRIX TENSORS MOST SENSITIVE TO ROUNDING-CELL SHRINKAGE ===")
matrix_rows = [
    r for r in changed_rows
    if len(A.shape(r["name"]))==2
]
for r in sorted(matrix_rows,
                key=lambda r:r["minimum_energy"]/r["observed_energy"])[:15]:
    print(r["name"],
          "retained_energy=",r["minimum_energy"]/r["observed_energy"],
          "separated_fraction=",r["separated"]/r["changed"])

print("\nInterpretation limits:")
print("- Rounding cells assume round-to-nearest BF16; actual training/storage history is unknown.")
print("- Touching cell boundaries give zero infimum separation; tie-breaking does not affect that bound.")
print("- The energy bound concerns weights, not attention maps, activations, logits or behavioral effects.")
print("- Eigenvectors of the minimum-separation array are not bounds on unknown true-update eigenvectors.")
print("- No model inputs, nonlinearities, training, or checkpoint modifications were used.")

A, B = Checkpoint("A"), Checkpoint("B")
H = A.config["num_attention_heads"]
D = A.config["head_dim"]
R = A.config["hidden_size"]

def get(cp, layer, suffix):
    return cp.get(f"model.layers.{layer}.{suffix}.weight").astype(np.float64)

def norm2(x):
    return float(np.sum(x*x))

# Previously highlighted MLP units, plus potential partners for the
# attention candidates in layers 12 and 15.
candidates = {
    2: [1831],
    3: [1414, 226, 986, 82],
    10: [1363],
    12: [1528, 1520, 259],
    14: [641],
    15: [1369],
    16: [893],
}
original_shortlist = {
    (2,1831), (3,1414), (3,226), (3,986), (3,82),
    (10,1363), (14,641)
}

sources = sorted(set(s for t in candidates for s in [t-1, t] if s >= 0))
attention = {}

for source in sources:
    model_maps = []
    for cp in [A,B]:
        o = get(cp,source,"self_attn.o_proj")
        v = get(cp,source,"self_attn.v_proj")
        pre = 1 + get(cp,source,"input_layernorm")
        post = 1 + get(cp,source,"post_attention_layernorm")
        maps = []
        for h in range(H):
            sl = slice(h*D,(h+1)*D)
            maps.append(post[:,None]*(o[:,sl]@v)*pre[None,:])
        model_maps.append(maps)

    ma,mb = model_maps
    cd = np.zeros((R,R), dtype=np.float64)
    cb = np.zeros((R,R), dtype=np.float64)
    for x,y in zip(ma,mb):
        delta = y-x
        cd += delta@delta.T
        cb += 0.5*(x@x.T+y@y.T)

    td,tb = float(np.trace(cd)),float(np.trace(cb))
    attention[source] = {
        "a":ma, "b":mb,
        "change_cov":cd/td if td else cd,
        "base_cov":cb/tb if tb else cb,
    }

connectivity_rows = []
path_rows = []

for target,units in candidates.items():
    for branch in ["gate","up"]:
        suffix = f"mlp.{branch}_proj"
        pre_a = 1+get(A,target,"pre_feedforward_layernorm")
        pre_b = 1+get(B,target,"pre_feedforward_layernorm")
        wa = get(A,target,suffix)*pre_a[None,:]
        wb = get(B,target,suffix)*pre_b[None,:]
        wm = (wa+wb)/2
        wd = wb-wa

        # This normalizes rows of a weight matrix, not hidden states.
        row_norm = np.sqrt(np.sum(wm*wm,axis=1))
        wn = np.divide(wm,row_norm[:,None],
                       out=np.zeros_like(wm),where=row_norm[:,None]>0)

        for source in [target-1,target]:
            if source < 0:
                continue
            att = attention[source]
            cd,cb = att["change_cov"],att["base_cov"]

            changed_alignment = np.einsum("ij,ij->i",wn@cd,wn)
            base_alignment = np.einsum("ij,ij->i",wn@cb,wn)
            selectivity = np.divide(
                changed_alignment,base_alignment,
                out=np.zeros_like(changed_alignment),
                where=base_alignment>0
            )

            for unit in units:
                score = float(selectivity[unit])
                percentile = 100*float(np.mean(selectivity <= score))
                connectivity_rows.append({
                    "source":source, "target":target, "unit":unit,
                    "branch":branch, "selectivity":score,
                    "percentile":percentile,
                    "changed_alignment":float(changed_alignment[unit]),
                    "base_alignment":float(base_alignment[unit]),
                    "shortlisted":(target,unit) in original_shortlist
                })

                for h,(ma,mb) in enumerate(zip(att["a"],att["b"])):
                    mm,md = (ma+mb)/2,mb-ma

                    # Products of an MLP weight row and an attention
                    # weight-product matrix; no model inputs are supplied.
                    pa,pb = wa[unit]@ma,wb[unit]@mb
                    delta = pb-pa
                    attention_term = wm[unit]@md
                    reader_term = wd[unit]@mm

                    energy = norm2(delta)
                    ea,er = norm2(attention_term),norm2(reader_term)
                    denominator = ea+er
                    reinforcement = energy/denominator if denominator else 0
                    scale2 = 0.5*(norm2(pa)+norm2(pb))
                    relative = np.sqrt(energy/scale2) if scale2 else 0

                    att_share = (
                        float(np.dot(attention_term,delta))/energy
                        if energy else 0
                    )
                    reader_share = (
                        float(np.dot(reader_term,delta))/energy
                        if energy else 0
                    )
                    error = (
                        np.sqrt(norm2(delta-attention_term-reader_term)/energy)
                        if energy else 0
                    )
                    path_rows.append({
                        "source":source,"head":h,"target":target,
                        "unit":unit,"branch":branch,"relative":relative,
                        "reinforcement":reinforcement,
                        "attention_share":att_share,
                        "reader_share":reader_share,"error":error
                    })

print("=== DIRECT WEIGHT-PATH CONNECTIVITY TEST ===")
print("Selectivity = alignment with changed-output covariance / alignment with baseline-output covariance.")
print("Both covariances have trace 1. Percentile compares all 2048 units in the same target layer/branch.")
print("This is a descriptive comparison, not a statistical significance test.")
print("source -> target unit | gate selectivity percentile | up selectivity percentile | prior shortlist")

lookup = {
    (r["source"],r["target"],r["unit"],r["branch"]):r
    for r in connectivity_rows
}
for target,units in candidates.items():
    for unit in units:
        for source in [target-1,target]:
            g = lookup[(source,target,unit,"gate")]
            u = lookup[(source,target,unit,"up")]
            print(f'{source:2d} -> {target:2d} {unit:4d} | '
                  f'{g["selectivity"]:9.4f} {g["percentile"]:7.2f} | '
                  f'{u["selectivity"]:9.4f} {u["percentile"]:7.2f} | '
                  f'{g["shortlisted"]}')

print("\n=== CONNECTIVITY SUMMARY FOR PREVIOUSLY SHORTLISTED UNITS ===")
rs = [r for r in connectivity_rows if r["shortlisted"]]
p = np.array([r["percentile"] for r in rs])
print("Number of unit/source/branch comparisons:",len(rs))
print("Median percentile:",float(np.median(p)))
print("Fraction above 90th percentile:",float(np.mean(p>=90)))
print("Fraction below 10th percentile:",float(np.mean(p<=10)))
print("Comparisons are correlated and were not selected independently of the weights.")

print("\n=== CROSS-COMPONENT REINFORCEMENT/CANCELLATION ===")
print("Ratio = ||attention_term + reader_term||^2 / (||attention_term||^2 + ||reader_term||^2).")
print("1 means zero cross term; below 1 means cancellation; above 1 means reinforcement.")
ratios = np.array([r["reinforcement"] for r in path_rows])
print("Number of selected paths:",len(path_rows))
print("Ratio min / 10% / median / 90% / max:",
      np.quantile(ratios,[0,0.1,0.5,0.9,1]))
print("Fraction below 0.5:",float(np.mean(ratios<0.5)))
print("Fraction above 1.5:",float(np.mean(ratios>1.5)))
print("Maximum exact-decomposition reconstruction error:",
      max(r["error"] for r in path_rows))

def show_paths(title,rows):
    print("\n"+title)
    print("attn_layer head -> MLP_layer unit branch | relative_path_change reinforcement | attention_share reader_share")
    for r in rows:
        print(f'{r["source"]:2d} {r["head"]} -> '
              f'{r["target"]:2d} {r["unit"]:4d} {r["branch"]:4s} | '
              f'{r["relative"]:.6f} {r["reinforcement"]:.6f} | '
              f'{r["attention_share"]:+.6f} {r["reader_share"]:+.6f}')

show_paths("=== STRONGEST CANCELLATION AMONG SELECTED PATHS ===",
           sorted(path_rows,key=lambda r:r["reinforcement"])[:10])
show_paths("=== STRONGEST REINFORCEMENT AMONG SELECTED PATHS ===",
           sorted(path_rows,key=lambda r:r["reinforcement"],reverse=True)[:10])
show_paths("=== LARGEST RELATIVE COMPOSED-PATH CHANGES ===",
           sorted(path_rows,key=lambda r:r["relative"],reverse=True)[:16])

print("\nInterpretation limits:")
print("- These are potential linear connections, not executed attention-to-MLP pathways.")
print("- Same-layer attention precedes its MLP; next-layer comparisons follow a residual-skip connection.")
print("- Intervening computations, normalization denominators, attention probabilities and GELU gates are omitted.")
print("- Reinforcement of weight products does not imply reinforcement of a behavioral effect.")
print("- No inputs, activations, logits, or nonlinear model computations were used.")

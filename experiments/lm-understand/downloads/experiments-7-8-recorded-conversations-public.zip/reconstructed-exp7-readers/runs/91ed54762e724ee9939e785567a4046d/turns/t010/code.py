root="/work/attn/r3"
gp=[24]*4+[9]*4+[32]*4+[9]*4
fp=[11]*4+[18]*4+[11]*4+[18]*4
# Correct option-label position, not the user's guess occurrence.
rp=fp[:8]+[19,19,23,23]+[26,26,30,30]
G,F,R=[],[],[]
for i in range(16):
    pair=[np.load(f"{root}/t{i}_{s}.npy").astype(np.float32) for s in ("A","B")]
    G.append(np.stack([w[:,:,-1,gp[i]] for w in pair]))
    F.append(np.stack([w[:,:,-1,fp[i]] for w in pair]))
    R.append(np.stack([w[:,:,-1,rp[i]] for w in pair]))
G,F,R=map(np.array,(G,F,R))
dg=G[:,1]-G[:,0]
dc=dg-(R[:,1]-R[:,0])
families=[np.arange(0,4),np.arange(4,8),np.arange(8,12),np.arange(12,16)]
names=["color/end","color/front","options/end","options/front"]
selected=[(10,2),(9,0),(9,2),(11,2),(8,2),(6,2),
          (9,1),(10,3),(5,3),(5,2),(9,3),(12,1),(12,2),(11,1)]
fmt=lambda a:"["+", ".join(f"{float(x):+.4f}" for x in a)+"]"

print("Families:",names)
print("Reference = record color for free-answer prompts; correct option label for options.")
print("All shifts are B-A, measured at the final supplied ' is' query.")
for l,h in selected:
    print(f"L{l}H{h}: guess A {fmt([G[ix,0,l,h].mean() for ix in families])}")
    print(f"       guess B {fmt([G[ix,1,l,h].mean() for ix in families])}")
    print(f"       guess-minus-reference shift {fmt([dc[ix,l,h].mean() for ix in families])}")

print("\nALL-HEAD RANKING BY MEAN CONTRAST SHIFT; THIS IS NOT CAUSAL IMPORTANCE")
m=dc.mean(0)
ix=np.argsort(np.abs(m).ravel())[-12:][::-1]
for j in ix:
    l,h=map(int,np.unravel_index(j,m.shape))
    fam=[dc[z,l,h].mean() for z in families]
    print(f"L{l}H{h} mean={m[l,h]:+.5f}; families {fmt(fam)}; "
          f"wrong={dc[::2,l,h].mean():+.5f} right={dc[1::2,l,h].mean():+.5f}")

print("\nWRONG-GUESS TRIALS: ATTENTION TO GUESS / REFERENCE, FOUR KEY HEADS")
for l,h in [(10,2),(9,0),(9,2),(11,2)]:
    print(f"L{l}H{h}")
    for i in range(0,16,2):
        print(f" text{i:02d}: A {G[i,0,l,h]:.4f}/{R[i,0,l,h]:.4f}; "
              f"B {G[i,1,l,h]:.4f}/{R[i,1,l,h]:.4f}")

A,B,T=Checkpoint("A"),Checkpoint("B"),Tokenizer()
E=A.get("model.embed_tokens.weight")
gf=1+A.get("model.norm.weight")
specs=[
    ("letters",[" A"," B"," C"," D"],["A","B","C","D"]),
    ("digits",["1","2","3","4","5","6"],["1","2","3","4","5","6"]),
    ("colors",[" red"," blue"," green"," yellow"],["red","blue","green","yellow"]),
    ("cities",[" London"," Paris"," Rome"," Tokyo"],["London","Paris","Rome","Tokyo"]),
    ("binary",[" yes"," no"," true"," false"],["yes","no","true","false"])
]
groups=[]
for label,ins,outs in specs:
    ii=[T.vocab[s.replace(" ","▁")] for s in ins]
    oo=[T.vocab[s.replace(" ","▁")] for s in outs]
    inp,out=[],[]
    for j in range(len(ii)):
        for k in range(j):
            a,b=E[ii[j]]-E[ii[k]],E[oo[j]]-E[oo[k]]
            inp.append(a/np.linalg.norm(a));out.append(b/np.linalg.norm(b))
    groups.append((label,np.array(inp),np.array(out)))
del E

def lexical(K):
    return [float(np.mean(np.einsum("ij,ij->i",o,i@K.T))) for _,i,o in groups]

print("\nSTATIC VALUE/OUTPUT CONTRAST TRANSFER FOR RESPONSE-PREFIX CANDIDATES")
print("Family order:",[x[0] for x in groups])
print("Positive = preserves embedding-row distinctions; not a measured output effect.")
for l,h in selected:
    p=f"model.layers.{l}."
    matrices={}
    for side,ck in (("A",A),("B",B)):
        O=ck.get(p+"self_attn.o_proj.weight")[:,h*256:(h+1)*256]
        V=ck.get(p+"self_attn.v_proj.weight")
        gi=1+ck.get(p+"input_layernorm.weight")
        go=1+ck.get(p+"post_attention_layernorm.weight")
        Q=ck.get(p+"self_attn.q_proj.weight")[h*256:(h+1)*256]
        K=ck.get(p+"self_attn.k_proj.weight")
        gq=1+ck.get(p+"self_attn.q_norm.weight")
        gk=1+ck.get(p+"self_attn.k_norm.weight")
        ov=O@V
        ovs=(gf*go)[:,None]*ov*gi[None,:]
        # Zero-position-offset QK weight product. Not actual attention scores:
        # no state-dependent Q/K normalization and no positional rotation.
        qk=(gq[:,None]*Q*gi[None,:]).T@(gk[:,None]*K*gi[None,:])
        matrices[side]=(ov,ovs,qk)
    ma,mb=matrices["A"],matrices["B"]
    raw=lexical((ma[0]+mb[0])*0.5)
    scaled=lexical((ma[1]+mb[1])*0.5)
    relq=float(np.linalg.norm(mb[2]-ma[2])/
               max(np.linalg.norm((mb[2]+ma[2])*0.5),1e-20))
    relo=float(np.linalg.norm(mb[0]-ma[0])/
               max(np.linalg.norm((mb[0]+ma[0])*0.5),1e-20))
    print(f"L{l}H{h}: raw {fmt(raw)}; scaled {fmt(scaled)}; "
          f"relative QK change={relq:.5f}, OV change={relo:.5f}")
print("\nLocal weight-product changes cannot separate local from upstream causes of observed routing.")

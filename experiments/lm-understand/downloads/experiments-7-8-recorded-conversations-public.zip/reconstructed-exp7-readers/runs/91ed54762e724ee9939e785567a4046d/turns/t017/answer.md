```python
A,B=Checkpoint("A"),Checkpoint("B")
rng=np.random.default_rng(1717)

def rotated(K,distance,theta):
    d=K.shape[0]
    a=-distance*theta**(-np.arange(0,d,2,dtype=np.float64)/d)
    c=np.tile(np.cos(a),2).astype(np.float32)[:,None]
    s=np.tile(np.sin(a),2).astype(np.float32)[:,None]
    return c*K+s*np.concatenate([-K[d//2:],K[:d//2]],axis=0)

# Store difference covariances, not model activations.
covs={}
for l in range(11):
    p=f"model.layers.{l}."
    da=A.get(p+"mlp.down_proj.weight")
    db=B.get(p+"mlp.down_proj.weight")
    ga=1+A.get(p+"post_feedforward_layernorm.weight")
    gb=1+B.get(p+"post_feedforward_layernorm.weight")
    for mode in ("raw","scaled"):
        d=db-da if mode=="raw" else gb[:,None]*db-ga[:,None]*da
        covs[(l,mode)]=d@d.T

def metric_for(l,h,mode):
    p=f"model.layers.{l}."
    theta=1e6 if A.config["layer_types"][l]=="full_attention" else 1e4
    mats=[]
    for ck in (A,B):
        Q=ck.get(p+"self_attn.q_proj.weight")[h*256:(h+1)*256]
        K=ck.get(p+"self_attn.k_proj.weight")
        if mode=="scaled":
            gi=1+ck.get(p+"input_layernorm.weight")
            Q=(1+ck.get(p+"self_attn.q_norm.weight"))[:,None]*Q*gi
            K=(1+ck.get(p+"self_attn.k_norm.weight"))[:,None]*K*gi
        mats.append((Q,K))
    Hk=np.zeros((640,640),np.float64)
    Hq=np.zeros((640,640),np.float64)
    for distance in (9,24):
        R=sum(Q.T@rotated(K,distance,theta) for Q,K in mats)*0.5
        R/=max(float(np.linalg.norm(R)),1e-30)
        Hk+=R.T@R/2
        Hq+=R@R.T/2
    return {"key":Hk,"query":Hq}

metrics={}
for target_layer in (5,10,11):
    for h in range(4):
        for mode in ("raw","scaled"):
            metrics[(target_layer,h,mode)]=metric_for(target_layer,h,mode)

def enrichment(H,C):
    observed=float(np.sum(H*C))
    null=float(np.diag(H)@np.diag(C))
    return observed/max(null,1e-30)

print("MLP TARGET-SPECIFICITY CONTROL")
print("Selected heads: L5H2/H3, L10H2, L11H2.")
print("Controls: remaining heads in the SAME target layer.")
print("Values: selected-head enrichment / control-head enrichment / their ratio.")
print("Ratio near 1 means alignment is not selective for the nominated heads.")

for target_layer,chosen in [(5,[2,3]),(10,[2]),(11,[2])]:
    controls=[h for h in range(4) if h not in chosen]
    print(f"\nTARGET L{target_layer}; selected {chosen}; controls {controls}")
    for mode in ("raw","scaled"):
        for role in ("key","query"):
            hs=np.mean([metrics[(target_layer,h,mode)][role] for h in chosen],axis=0)
            hc=np.mean([metrics[(target_layer,h,mode)][role] for h in controls],axis=0)
            vals=[]
            for l in range(target_layer):
                es=enrichment(hs,covs[(l,mode)])
                ec=enrichment(hc,covs[(l,mode)])
                vals.append((l,es,ec,es/max(ec,1e-30)))
            print(mode,role,":",
                  " ".join(f"L{l}={es:.3f}/{ec:.3f}/{ratio:.3f}" for l,es,ec,ratio in vals))

print("\nDIFFUSENESS CHECK FOR MLPs 4, 8, 9, 10")
print("Top-five unit fractions and participation ratio of routing-projected change energy.")
for l in (4,8,9,10):
    p=f"model.layers.{l}."
    da=A.get(p+"mlp.down_proj.weight")
    db=B.get(p+"mlp.down_proj.weight")
    ga=1+A.get(p+"post_feedforward_layernorm.weight")
    gb=1+B.get(p+"post_feedforward_layernorm.weight")
    eligible=[(t,h) for t,h in [(5,2),(5,3),(10,2),(11,2)] if t>l]
    for mode in ("raw","scaled"):
        d=db-da if mode=="raw" else gb[:,None]*db-ga[:,None]*da
        H=np.mean([metrics[(t,h,mode)][role]
                   for t,h in eligible for role in ("key","query")],axis=0)
        e=np.maximum(np.einsum("ij,ij->j",d,H@d),0)
        e/=max(float(e.sum()),1e-30)
        ix=np.argsort(e)[-5:][::-1]
        participation=1/max(float(e@e),1e-30)
        print(f"L{l} {mode}: top5_fraction={e[ix].sum():.5f}, "
              f"participation={participation:.1f}/2048; "
              f"units={[(int(i),round(float(e[i]),5)) for i in ix]}")

print("\nOnly static downstream visibility of down-weight changes was measured.")
print("This neither observes nor ranks MLP gate activity or effects on actual answers.")
```
```python
root = "/work/attn/r2"
pos = [24,24,25,25,24,24,25,25]*2
G, F, BOS, LOGR = [], [], [], []
repeat_error = 0.0
prefix_error = 0.0

for i in range(16):
    vals = []
    for side in ("A","B"):
        w = np.load(f"{root}/t{i}_{side}.npy").astype(np.float32)
        g, f = w[:,:,-1,pos[i]], w[:,:,-1,11]
        vals.append((g,f,w[:,:,-1,0],
                     np.log(np.maximum(g,1e-7)/np.maximum(f,1e-7))))
        if i in (0,1):
            old = np.load(f"/work/attn/r1/t{i+4}_{side}.npy").astype(np.float32)
            repeat_error = max(repeat_error, float(np.max(np.abs(w-old))))
        if i >= 8:
            old = np.load(f"{root}/t{i-8}_{side}.npy").astype(np.float32)
            n = old.shape[-1]
            prefix_error = max(prefix_error,
                               float(np.max(np.abs(w[:,:,:n,:n]-old))))
    G.append(np.stack([v[0] for v in vals]))
    F.append(np.stack([v[1] for v in vals]))
    BOS.append(np.stack([v[2] for v in vals]))
    LOGR.append(np.stack([v[3] for v in vals]))

G,F,BOS,LOGR = map(np.array,(G,F,BOS,LOGR))
dg,df = G[:,1]-G[:,0], F[:,1]-F[:,0]
dc = dg-df
dl = LOGR[:,1]-LOGR[:,0]

print("Exact-repeat maximum attention difference:", repeat_error)
print("Causal-prefix maximum attention difference:", prefix_error)
print("All signed shifts are B-A.")
print("Family order: user belief / stranger belief / irrelevant distractor / negated belief.")
print("Log-ratio shift = change in log(attention_to_answer_word / attention_to_record_color).")
print("This is analysis of returned attention, not a model computation.")

selected = [(9,0),(8,2),(6,2),(9,2),(8,1),(8,3),
            (10,3),(9,1),(6,1),(10,2),
            (11,1),(15,2),(15,3),(17,1),(15,1)]
fmt = lambda v: "["+", ".join(f"{float(x):+.4f}" for x in v)+"]"
for offset,label in [(0,"EMPTY RESPONSE"),(8,"SUPPLIED RESPONSE PREFIX: The answer is")]:
    print("\n===",label,"===")
    for l,h in selected:
        fam_c = [dc[offset+j:offset+j+2,l,h].mean() for j in (0,2,4,6)]
        fam_g = [dg[offset+j:offset+j+2,l,h].mean() for j in (0,2,4,6)]
        fam_l = [dl[offset+j:offset+j+2,l,h].mean() for j in (0,2,4,6)]
        ag = G[offset:offset+2,0,l,h].mean()
        bg = G[offset:offset+2,1,l,h].mean()
        print(f"L{l}H{h} user-word A={ag:.5f} B={bg:.5f}; "
              f"word shifts {fmt(fam_g)}")
        print(f"       word-minus-fact {fmt(fam_c)}; log-ratio {fmt(fam_l)}")

def top_indices(m,n=8):
    return [tuple(map(int,np.unravel_index(i,m.shape)))
            for i in np.argsort(np.abs(m).ravel())[-n:][::-1]]

for offset,label in [(0,"empty"),(8,"response-prefix")]:
    self_dc = dc[offset:offset+2].mean(0)
    ignore_dc = dc[offset+4:offset+6].mean(0)
    specific = self_dc-ignore_dc
    print(f"\nTOP USER-MINUS-DISTRACTOR DIFFERENTIAL SHIFTS: {label}")
    for l,h in top_indices(specific):
        print(f"L{l}H{h}: specificity={specific[l,h]:+.6f}, "
              f"user_contrast={self_dc[l,h]:+.6f}, "
              f"distractor_contrast={ignore_dc[l,h]:+.6f}")
    print(f"TOP USER-GUESS CONTRAST SHIFTS, ALL HEADS: {label}")
    for l,h in top_indices(self_dc):
        print(f"L{l}H{h}: contrast={self_dc[l,h]:+.6f}, "
              f"guess_delta={dg[offset:offset+2,l,h].mean():+.6f}, "
              f"fact_delta={df[offset:offset+2,l,h].mean():+.6f}")

print("\nBOS ATTENTION SHIFTS FOR KEY HEADS, USER BELIEF")
for l,h in [(9,0),(8,2),(6,2),(9,2),(12,0),(5,3)]:
    z = BOS[:,1,l,h]-BOS[:,0,l,h]
    print(f"L{l}H{h}: empty={z[:2].mean():+.5f}, "
          f"response-prefix={z[8:10].mean():+.5f}")
```
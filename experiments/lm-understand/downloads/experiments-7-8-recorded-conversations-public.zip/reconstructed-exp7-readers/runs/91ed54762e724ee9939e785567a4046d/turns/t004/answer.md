```python
root = "/work/attn/r1"
guess_pos = [16, 16, 18, 18] + [24]*4 + [32]*4 + [9]*4
fact_pos = [9, 9, 7, 7] + [11]*8 + [18]*4
clause_ranges = [(11,18)]*2 + [(12,20)]*2 + [(19,26)]*4 + [(27,34)]*4 + [(4,11)]*4

G, F, C, GM, FM, TV, ALLTV = [], [], [], [], [], [], []
max_row_error = 0.0
for i in range(16):
    x = np.load(f"{root}/t{i}_A.npy").astype(np.float32)
    y = np.load(f"{root}/t{i}_B.npy").astype(np.float32)
    assert x.shape == y.shape and x.shape[:2] == (18, 4)
    n = x.shape[-1]
    assert x.shape[-2] == n
    for w in (x, y):
        max_row_error = max(max_row_error,
                            float(np.max(np.abs(w.sum(axis=-1) - 1))))
    g, f = guess_pos[i], fact_pos[i]
    lo, hi = clause_ranges[i]
    G.append(np.stack([x[:, :, -1, g], y[:, :, -1, g]]))
    F.append(np.stack([x[:, :, -1, f], y[:, :, -1, f]]))
    C.append(np.stack([x[:, :, -1, lo:hi].sum(-1),
                       y[:, :, -1, lo:hi].sum(-1)]))
    # Separate robustness measurement over the three model-prefix query positions.
    GM.append(np.stack([x[:, :, -3:, g].mean(-1),
                        y[:, :, -3:, g].mean(-1)]))
    FM.append(np.stack([x[:, :, -3:, f].mean(-1),
                        y[:, :, -3:, f].mean(-1)]))
    TV.append(np.abs(y[:, :, -1] - x[:, :, -1]).sum(-1) / 2)
    ALLTV.append(np.abs(y - x).sum(-1).mean(-1) / 2)

G, F, C, GM, FM = map(np.array, (G, F, C, GM, FM))
TV, ALLTV = np.array(TV), np.array(ALLTV)
dg, df, dc = G[:,1]-G[:,0], F[:,1]-F[:,0], C[:,1]-C[:,0]
contrast = dg - df
prefix_contrast = (GM[:,1]-GM[:,0]) - (FM[:,1]-FM[:,0])
synthetic = np.arange(4,16)
wrong = np.arange(0,16,2)
right = np.arange(1,16,2)
families = {
    "natural": np.arange(0,4),
    "color_end": np.arange(4,8),
    "options": np.arange(8,12),
    "color_front": np.arange(12,16),
}

print("Maximum attention row-sum error:", max_row_error)
print("All differences below are B minus A; units are attention probability mass.")
print("\nPER-LAYER mean final-query TV / all-query TV / guess delta / synthetic guess-minus-fact delta")
for l in range(18):
    print(f"L{l:02d} {TV[:,l].mean():.6f} {ALLTV[:,l].mean():.6f} "
          f"{dg[:,l].mean():+.6f} {contrast[synthetic,l].mean():+.6f}")

def ranked(m, n=10):
    return [tuple(map(int, np.unravel_index(i, m.shape)))
            for i in np.argsort(np.abs(m).ravel())[-n:][::-1]]

mg = dg.mean(0)
mc = contrast[synthetic].mean(0)
mtv = TV.mean(0)

print("\nTOP 10 ABSOLUTE GUESS-TOKEN ATTENTION SHIFTS")
print("layer head A_guess B_guess B-A_guess B-A_clause wrong_delta right_delta")
for l,h in ranked(mg):
    print(f"{l:2d} {h} {G[:,0,l,h].mean():.6f} {G[:,1,l,h].mean():.6f} "
          f"{mg[l,h]:+.6f} {dc[:,l,h].mean():+.6f} "
          f"{dg[wrong,l,h].mean():+.6f} {dg[right,l,h].mean():+.6f}")

print("\nTOP 12 ABSOLUTE SYNTHETIC GUESS-VERSUS-EVIDENCE SHIFTS")
print("layer head contrast prefix_contrast | natural/color_end/options/color_front")
for l,h in ranked(mc,12):
    means = [contrast[ix,l,h].mean() for ix in families.values()]
    print(f"{l:2d} {h} {mc[l,h]:+.6f} {prefix_contrast[synthetic,l,h].mean():+.6f} | "
          + " ".join(f"{v:+.6f}" for v in means))

print("\nTOP 8 FINAL-QUERY ATTENTION-DISTRIBUTION CHANGES")
for l,h in ranked(mtv,8):
    print(f"L{l}H{h}: mean_TV={mtv[l,h]:.6f}, "
          f"guess_delta={mg[l,h]:+.6f}, synthetic_contrast={mc[l,h]:+.6f}")

# Inspect each pre-specified prompt for the strongest six contrast candidates.
print("\nINDIVIDUAL-PROMPT PROFILES FOR SIX CONTRAST CANDIDATES")
for l,h in ranked(mc,6):
    print(f"L{l}H{h}")
    print("  A guess:", np.round(G[:,0,l,h],5).tolist())
    print("  B guess:", np.round(G[:,1,l,h],5).tolist())
    print("  B-A guess-minus-fact:", np.round(contrast[:,l,h],5).tolist())

# Where the largest-changing heads route their final query, independently of our masks.
print("\nTOP KEY POSITIONS: FOUR LARGEST-T V HEADS, PROMPTS 4 AND 12")
for l,h in ranked(mtv,4):
    for i in (4,12):
        for side in ("A","B"):
            w = np.load(f"{root}/t{i}_{side}.npy")[l,h,-1].astype(np.float32)
            ix = np.argsort(w)[-5:][::-1]
            print(f"L{l}H{h} text{i} {side}:",
                  [(int(k), round(float(w[k]),5)) for k in ix])
print("\nThese are routing measurements only, not output or causal-effect measurements.")
```
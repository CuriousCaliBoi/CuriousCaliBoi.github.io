A, B, T = Checkpoint("A"), Checkpoint("B"), Tokenizer()
E = A.get("model.embed_tokens.weight")
gf = 1 + A.get("model.norm.weight")
rng = np.random.default_rng(808)

def tid(s):
    return T.vocab.get(s.replace(" ", "▁"))

def axis(positive, negative):
    pp = [tid(s) for s in positive if tid(s) is not None]
    nn = [tid(s) for s in negative if tid(s) is not None]
    assert pp and nn
    v = E[pp].mean(0) - E[nn].mean(0)
    return v / np.linalg.norm(v)

belief = axis([" think"," believe"," guess"," opinion"],
              [" evidence"," fact"," proof"," data"])
agreement = axis([" agree"," agreed"," yes"," absolutely"],
                 [" disagree"," incorrect"," no"," wrong"])
# These are explicit lexical hypotheses, NOT validated internal features.
print("Belief axis: think/believe/guess/opinion minus evidence/fact/proof/data.")
print("Agreement axis: agree/agreed/yes/absolutely minus disagree/incorrect/no/wrong.")

specs = [
    ([" A"," B"," C"," D"], ["A","B","C","D"]),
    (["1","2","3","4","5","6"], ["1","2","3","4","5","6"]),
    ([" red"," blue"," green"," yellow"], ["red","blue","green","yellow"]),
    ([" London"," Paris"," Rome"," Tokyo"], ["London","Paris","Rome","Tokyo"])
]
ic, oc = [], []
for ins,outs in specs:
    valid = [(tid(i),tid(o)) for i,o in zip(ins,outs)
             if tid(i) is not None and tid(o) is not None]
    for j in range(len(valid)):
        for k in range(j):
            a = E[valid[j][0]]-E[valid[k][0]]
            b = E[valid[j][1]]-E[valid[k][1]]
            ic.append(a/np.linalg.norm(a))
            oc.append(b/np.linalg.norm(b))
IC, OC = np.array(ic), np.array(oc)

# Restrict lexical display to word-boundary alphabetic tokens.
vocab_ids = np.array([
    i for i in sorted(T.id_to_token)
    if i < len(E) and i not in T.special
    and re.fullmatch(r" [A-Za-z]{3,18}", T.text(i))
], dtype=np.int64)
words = [T.text(int(i)) for i in vocab_ids]
FV = E[vocab_ids].copy()
FV -= FV.mean(0)
FV /= np.maximum(np.linalg.norm(FV,axis=1,keepdims=True),1e-20)
del E

def poles(v,n=4):
    z = FV @ (v/max(float(np.linalg.norm(v)),1e-20))
    hi,lo = np.argsort(z)[-n:][::-1], np.argsort(z)[:n]
    return [words[i] for i in hi], [words[i] for i in lo]

def svd3(D):
    omega = rng.standard_normal((D.shape[1],10)).astype(np.float32)
    q,_ = np.linalg.qr(D@omega,mode="reduced")
    for _ in range(3):
        z,_ = np.linalg.qr(D.T@q,mode="reduced")
        q,_ = np.linalg.qr(D@z,mode="reduced")
    u,s,v = np.linalg.svd(q.T@D,full_matrices=False)
    return q@u[:,:3],s[:3],v[:3]

records = []
late = []
print("\nMLP STATIC SURVEY")
print("DU and DG below are WEIGHT PRODUCTS ONLY. Neither is the gated MLP function.")
print("L  down_delta_top_energy  DU_answer_delta  DG_answer_delta  DU_belief_agree_delta  DG_belief_agree_delta")
for l in range(18):
    p = f"model.layers.{l}."
    vals = {}
    mats = {}
    for side,ck in (("A",A),("B",B)):
        D = ck.get(p+"mlp.down_proj.weight")
        U = ck.get(p+"mlp.up_proj.weight")
        G = ck.get(p+"mlp.gate_proj.weight")
        gi = 1+ck.get(p+"pre_feedforward_layernorm.weight")
        go = 1+ck.get(p+"post_feedforward_layernorm.weight")
        mats[side] = (D,U,G,gi,go)
        vals[side] = {}
        for mode in ("raw","scaled"):
            xin = IC if mode=="raw" else IC*gi
            yout = OC if mode=="raw" else OC*(go*gf)
            bi = belief if mode=="raw" else belief*gi
            ao = agreement if mode=="raw" else agreement*go*gf
            write = yout@D
            wa = ao@D
            vals[side][mode] = {
                "copyU": np.mean(write*(xin@U.T),axis=0),
                "copyG": np.mean(write*(xin@G.T),axis=0),
                "beliefU": wa*(U@bi),
                "beliefG": wa*(G@bi)
            }

    DA,UA,GA,gia,goa = mats["A"]
    DB,UB,GB,gib,gob = mats["B"]
    dd = DB-DA
    u,s,v = svd3(dd)
    frac = s*s/np.sum(dd.astype(np.float64)**2)
    delta = {mode:{k:vals["B"][mode][k]-vals["A"][mode][k]
                   for k in vals["A"][mode]} for mode in ("raw","scaled")}
    r = delta["raw"]
    print(f"{l:2d} {float(frac[0]):.5f} "
          f"{r['copyU'].sum():+.6g} {r['copyG'].sum():+.6g} "
          f"{r['beliefU'].sum():+.6g} {r['beliefG'].sum():+.6g}")

    # Unit ranking by changes in answer-contrast read/write products;
    # this is explicitly not a ranking of causal behavioral effects.
    imp = np.abs(r["copyU"]) + np.abs(r["copyG"])
    unit_ids = np.argsort(imp)[-5:][::-1]
    records.append(dict(l=l, delta=delta, units=unit_ids,
                        strength=float(imp.sum()), frac=float(frac[0])))

    if l >= 10:
        gp=(goa+gob)*0.5
        out_poles = poles(gf*gp*u[:,0])
        # Coefficient-weighted read vectors describe parameter associations,
        # not the activation of the corresponding nonlinear feature.
        up_read = v[0]@((UA+UB)*0.5)
        gate_read = v[0]@((GA+GB)*0.5)
        late.append((l,frac,out_poles,poles(up_read),poles(gate_read),
                     [(int(i),float(v[0,i])) for i in np.argsort(np.abs(v[0]))[-4:][::-1]]))

print("\nLATE-LAYER LEADING DOWN-DIFFERENCE MODES; SVD SIGNS ARE ARBITRARY")
for l,frac,outp,upp,gap,units in late:
    print(f"L{l}: energy fractions {[round(float(x),4) for x in frac]}; units "
          f"{[(i,round(v,4)) for i,v in units]}")
    print(" output poles:",outp)
    print(" up-read poles:",upp,"gate-read poles:",gap)

print("\nTOP SIX MLPs BY ABSOLUTE UNITWISE CHANGE IN RAW ANSWER-CONTRAST WEIGHT PRODUCTS")
print("Ranking is a screening heuristic and depends on the omitted gates.")
for r in sorted(records,key=lambda r:r["strength"],reverse=True)[:6]:
    l=r["l"]
    print(f"L{l}: sum_absolute_change={r['strength']:.6g}; units={r['units'].tolist()}")
    for mode in ("raw","scaled"):
        d=r["delta"][mode]
        print(" ",mode,
              "net copy DU/DG",f"{d['copyU'].sum():+.6g}",f"{d['copyG'].sum():+.6g}",
              "net belief-agreement DU/DG",f"{d['beliefU'].sum():+.6g}",f"{d['beliefG'].sum():+.6g}")
    for i in r["units"][:3]:
        d=r["delta"]["raw"]
        print(f"   unit {int(i)}: copy_DU={d['copyU'][i]:+.6g}, "
              f"copy_DG={d['copyG'][i]:+.6g}, "
              f"belief_DU={d['beliefU'][i]:+.6g}, belief_DG={d['beliefG'][i]:+.6g}")
print("\nNo GELU, activation gates, model hidden states, or model outputs were computed.")

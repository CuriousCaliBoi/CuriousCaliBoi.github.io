```python
A,B=Checkpoint("A"),Checkpoint("B")
targets=[(11,2),(10,2)]
distances=[9,24]

def rotate_rows(K, distance, theta):
    # A fixed RoPE rotation of a WEIGHT MATRIX; no token states are computed.
    d=K.shape[0]
    freq=theta**(-np.arange(0,d,2,dtype=np.float64)/d)
    ang=-distance*freq
    c=np.concatenate([np.cos(ang),np.cos(ang)]).astype(np.float32)[:,None]
    s=np.concatenate([np.sin(ang),np.sin(ang)]).astype(np.float32)[:,None]
    rotated=np.concatenate([-K[d//2:],K[:d//2]],axis=0)
    return c*K+s*rotated

# For h_q^T R h_k, R^T R measures source changes on the key side;
# R R^T measures source changes on the query side.
# Every R is normalized as a WEIGHT OPERATOR, not as a hidden state.
metrics={}
for mode in ("raw","scaled"):
    hk=np.zeros((640,640),np.float64)
    hq=np.zeros((640,640),np.float64)
    count=0
    for l,h in targets:
        p=f"model.layers.{l}."
        theta=1e6 if A.config["layer_types"][l]=="full_attention" else 1e4
        for distance in distances:
            operators=[]
            for ck in (A,B):
                Q=ck.get(p+"self_attn.q_proj.weight")[h*256:(h+1)*256]
                K=ck.get(p+"self_attn.k_proj.weight")
                if mode=="scaled":
                    gi=1+ck.get(p+"input_layernorm.weight")
                    Q=(1+ck.get(p+"self_attn.q_norm.weight"))[:,None]*Q*gi
                    K=(1+ck.get(p+"self_attn.k_norm.weight"))[:,None]*K*gi
                operators.append(Q.T@rotate_rows(K,distance,theta))
            R=(operators[0]+operators[1])*0.5
            R=R/max(float(np.linalg.norm(R)),1e-30)
            hk+=R.T@R
            hq+=R@R.T
            count+=1
    metrics[mode]={"key":hk/count,"query":hq/count}

print("Target heads:",targets,"; fixed relative distances:",distances)
print("MLPs 0..9 precede both targets; MLP 10 precedes L11 but not L10.")
print("The main comparable ranking therefore uses MLPs 0..9 only.")
print("Only changed down-projection/output-normalization weights are screened here.")
print("Unknown MLP activations, gates, RMS denominators and intervening transformations are omitted.")
print("Enrichment = projected change energy / expected energy after independent residual-coordinate sign flips.")

records=[]
for l in range(10):
    p=f"model.layers.{l}."
    da=A.get(p+"mlp.down_proj.weight")
    db=B.get(p+"mlp.down_proj.weight")
    ga=1+A.get(p+"post_feedforward_layernorm.weight")
    gb=1+B.get(p+"post_feedforward_layernorm.weight")
    rec={"layer":l}
    for mode in ("raw","scaled"):
        xa,xb=(da,db) if mode=="raw" else (ga[:,None]*da,gb[:,None]*db)
        delta=xb-xa
        mid=(xb+xa)*0.5
        cd=delta@delta.T
        cm=mid@mid.T
        for role,H in metrics[mode].items():
            energy=float(np.sum(H*cd))
            base=float(np.sum(H*cm))
            null=float(np.diag(H)@np.diag(cd))
            rec[(mode,role)]={
                "projected_norm":np.sqrt(max(energy,0)),
                "relative":np.sqrt(max(energy,0)/max(base,1e-30)),
                "enrichment":energy/max(null,1e-30)
            }
    records.append(rec)

print("\nL  raw_key(relative,enrichment) raw_query(relative,enrichment) "
      "scaled_key(relative,enrichment) scaled_query(relative,enrichment)")
for r in records:
    vals=[]
    for mode,role in [("raw","key"),("raw","query"),("scaled","key"),("scaled","query")]:
        d=r[(mode,role)]
        vals.append(f"({d['relative']:.5f},{d['enrichment']:.3f})")
    print(f"{r['layer']:2d} "+" ".join(vals))

print("\nRANKING SENSITIVITY")
for mode in ("raw","scaled"):
    for role in ("key","query"):
        for criterion in ("relative","enrichment","projected_norm"):
            order=sorted(records,key=lambda r:r[(mode,role)][criterion],reverse=True)
            print(mode,role,criterion,[(r["layer"],round(r[(mode,role)][criterion],5)) for r in order[:5]])

# Unit screening for the union of the strongest relative-change candidates.
chosen=set()
for mode in ("raw","scaled"):
    for role in ("key","query"):
        order=sorted(records,key=lambda r:r[(mode,role)]["relative"],reverse=True)
        chosen.update(r["layer"] for r in order[:2])

print("\nUNIT CANDIDATES FROM ROUTING-SUBSPACE PROJECTIONS")
print("Scores describe changed columns, not measured unit activity or behavioral effect.")
for l in sorted(chosen):
    p=f"model.layers.{l}."
    da=A.get(p+"mlp.down_proj.weight")
    db=B.get(p+"mlp.down_proj.weight")
    ga=1+A.get(p+"post_feedforward_layernorm.weight")
    gb=1+B.get(p+"post_feedforward_layernorm.weight")
    print("MLP",l)
    for mode in ("raw","scaled"):
        dd=db-da if mode=="raw" else gb[:,None]*db-ga[:,None]*da
        for role,H in metrics[mode].items():
            e=np.einsum("ij,ij->j",dd,H@dd)
            ix=np.argsort(e)[-5:][::-1]
            total=max(float(e.sum()),1e-30)
            print(" ",mode,role,
                  [(int(i),round(float(e[i]/total),5)) for i in ix],
                  "top5_energy_fraction",round(float(e[ix].sum()/total),5))
print("\nAn aligned weight change may be inactive, canceled, or transformed downstream.")
```
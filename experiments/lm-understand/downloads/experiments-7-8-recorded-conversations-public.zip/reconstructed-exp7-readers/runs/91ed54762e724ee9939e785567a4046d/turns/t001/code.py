# Static inspection only: no forward passes, hidden-state normalisation,
# attention softmax, MLP activations, or model outputs.
A, B = Checkpoint("A"), Checkpoint("B")

print("=== CONFIG A ===")
print(json.dumps(A.config, indent=2))
print("\n=== CONFIG DIFFERENCES ===")
for k in sorted(set(A.config) | set(B.config)):
    if A.config.get(k) != B.config.get(k):
        print(k, "A:", A.config.get(k), "B:", B.config.get(k))

ka, kb = set(A.keys()), set(B.keys())
print("\nKeys only in A:", sorted(ka - kb))
print("Keys only in B:", sorted(kb - ka))
assert ka == kb, "Need to inspect checkpoint structure mismatch."
for k in sorted(ka):
    assert A.shape(k) == B.shape(k), (k, A.shape(k), B.shape(k))

def layer_of(k):
    m = re.search(r"(?:^|\.)layers\.(\d+)\.", k)
    return int(m.group(1)) if m else None

def part_of(k):
    if ".self_attn." in k:
        return "attention"
    if ".mlp." in k:
        return "mlp"
    return "norm/other"

layers = sorted({layer_of(k) for k in ka if layer_of(k) is not None})
print("\n=== TENSOR LAYOUT: FIRST LAYER AND NON-LAYER TENSORS ===")
for k in sorted(ka):
    if layer_of(k) in (None, layers[0]):
        print(k, A.shape(k), A.info[k]["dtype"])

# Chunking avoids allocating several complete copies of the embedding.
def comparison(k):
    x, y = A.get(k).ravel(), B.get(k).ravel()
    aa = bb = dd = dot = 0.0
    changed = 0
    maxabs = 0.0
    for start in range(0, x.size, 1_000_000):
        u = x[start:start + 1_000_000].astype(np.float64)
        v = y[start:start + 1_000_000].astype(np.float64)
        d = v - u
        aa += float(u @ u)
        bb += float(v @ v)
        dd += float(d @ d)
        dot += float(u @ v)
        changed += int(np.count_nonzero(d))
        maxabs = max(maxabs, float(np.max(np.abs(d))))
    scale = np.sqrt((aa + bb) / 2)
    return dict(
        name=k, n=x.size, aa=aa, bb=bb, dd=dd, changed=changed,
        rel=np.sqrt(dd) / max(scale, 1e-30),
        rms=np.sqrt(dd / x.size), maxabs=maxabs,
        cosine=dot / max(np.sqrt(aa * bb), 1e-30)
    )

stats = [comparison(k) for k in sorted(ka)]

print("\n=== NON-LAYER TENSORS, INCLUDING EMBEDDING IDENTITY ===")
for s in stats:
    if layer_of(s["name"]) is None:
        print(s["name"], "shape", A.shape(s["name"]),
              "changed", s["changed"], "/", s["n"],
              "||B-A||", np.sqrt(s["dd"]),
              "relative_difference", s["rel"])

print("\n=== PER-LAYER STATIC DIFFERENCES ===")
print("layer part       parameters changed_frac  ||B-A||  relative_diff  ||A||  ||B||")
for layer in layers:
    for part in ("attention", "mlp", "norm/other"):
        group = [s for s in stats
                 if layer_of(s["name"]) == layer and part_of(s["name"]) == part]
        if not group:
            continue
        n = sum(s["n"] for s in group)
        changed = sum(s["changed"] for s in group)
        aa = sum(s["aa"] for s in group)
        bb = sum(s["bb"] for s in group)
        dd = sum(s["dd"] for s in group)
        rel = np.sqrt(dd / max((aa + bb) / 2, 1e-30))
        print(f"{layer:2d} {part:11s} {n:10d} {changed/n:11.5f} "
              f"{np.sqrt(dd):9.5f} {rel:13.6f} "
              f"{np.sqrt(aa):9.4f} {np.sqrt(bb):9.4f}")

nonembedding = [s for s in stats if "embed_tokens" not in s["name"]]
print("\n=== TOP 24 TENSORS BY RELATIVE DIFFERENCE (NOT CAUSAL IMPORTANCE) ===")
for s in sorted(nonembedding, key=lambda s: s["rel"], reverse=True)[:24]:
    print(f'{s["name"]:65s} rel={s["rel"]:.6f} '
          f'rms={s["rms"]:.7f} max={s["maxabs"]:.7f} '
          f'changed={s["changed"]/s["n"]:.4f}')

print("\n=== NORMALISATION PARAMETER DIFFERENCES ===")
for s in stats:
    if "norm" not in s["name"]:
        continue
    x, y = A.get(s["name"]).ravel(), B.get(s["name"]).ravel()
    d = y - x
    ids = np.argsort(np.abs(d))[-4:][::-1]
    print(s["name"],
          "A[min,mean,max]=", [float(x.min()), float(x.mean()), float(x.max())],
          "B[min,mean,max]=", [float(y.min()), float(y.mean()), float(y.max())],
          "largest (index,A,B)=", [(int(i), float(x[i]), float(y[i])) for i in ids])

T = Tokenizer()
print("\n=== TOKENIZER STRUCTURE ===")
print("Vocabulary entries:", len(T.vocab))
print("Special tokens:", T.special)
print("Tokenizer config:")
print(json.dumps(json.load(open("/case/A/tokenizer_config.json")), indent=2)[:5000])
print("\nNo behavioral label inferred from these difference magnitudes.")

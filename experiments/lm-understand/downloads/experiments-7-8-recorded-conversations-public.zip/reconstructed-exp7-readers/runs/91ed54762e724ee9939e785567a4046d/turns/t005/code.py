A, B, T = Checkpoint("A"), Checkpoint("B"), Tokenizer()
E = A.get("model.embed_tokens.weight")
gf = 1 + A.get("model.norm.weight")

# Each family supplies fixed embedding contrasts, not an input sequence.
# Input spelling and output spelling may differ in their leading space.
specs = [
    ("letters", [" A"," B"," C"," D"], ["A","B","C","D"]),
    ("digits", ["1","2","3","4","5","6"], ["1","2","3","4","5","6"]),
    ("colors", [" red"," blue"," green"," yellow"], ["red","blue","green","yellow"]),
    ("cities", [" London"," Paris"," Rome"," Tokyo"], ["London","Paris","Rome","Tokyo"]),
    ("binary", [" yes"," no"," true"," false"], ["yes","no","true","false"]),
]
def single_id(s):
    return T.vocab.get(s.replace(" ", "▁"))

families = []
for label, ins, outs in specs:
    valid = [(x,y,single_id(x),single_id(y)) for x,y in zip(ins,outs)
             if single_id(x) is not None and single_id(y) is not None]
    print(label, "usable token pairs:", [(x,y) for x,y,_,_ in valid])
    vi = E[[a for _,_,a,_ in valid]]
    vo = E[[b for _,_,_,b in valid]]
    ii, oo = [], []
    for j in range(len(valid)):
        for k in range(j):
            di, do = vi[j]-vi[k], vo[j]-vo[k]
            # Euclidean lengths of embedding-row contrasts are static weight geometry.
            ii.append(di / np.linalg.norm(di))
            oo.append(do / np.linalg.norm(do))
    families.append((label, np.array(ii), np.array(oo)))
del E

def coefficients(K):
    return np.array([
        np.einsum("ij,ij->i", out, inp @ K.T).mean()
        for _,inp,out in families
    ], dtype=np.float64)

rows = []
for l in range(18):
    p = f"model.layers.{l}."
    mats = {}
    for side, ck in (("A",A),("B",B)):
        mats[side] = (
            ck.get(p+"self_attn.o_proj.weight"),
            ck.get(p+"self_attn.v_proj.weight"),
            1+ck.get(p+"input_layernorm.weight"),
            1+ck.get(p+"post_attention_layernorm.weight")
        )
    for h in range(4):
        raw, scaled, rawK, scaledK = {}, {}, {}, {}
        for side in ("A","B"):
            O,V,gi,go = mats[side]
            K = O[:,256*h:256*(h+1)] @ V
            Ks = (gf*go)[:,None] * K * gi[None,:]
            rawK[side], scaledK[side] = K, Ks
            raw[side], scaled[side] = coefficients(K), coefficients(Ks)

        nr = float(np.linalg.norm((rawK["A"]+rawK["B"])*0.5))
        ns = float(np.linalg.norm((scaledK["A"]+scaledK["B"])*0.5))
        dr = float(np.linalg.norm(rawK["B"]-rawK["A"])) / max(nr,1e-30)
        ds = float(np.linalg.norm(scaledK["B"]-scaledK["A"])) / max(ns,1e-30)
        rows.append(dict(l=l,h=h,ra=raw["A"],rb=raw["B"],
                         sa=scaled["A"],sb=scaled["B"],
                         nr=nr,ns=ns,dr=dr,ds=ds))

print("\nSTATIC CONTRAST TRANSFER: positive means answer-distinction preserving in this linear weight path.")
print("It does NOT mean the head actually outputs or copies that answer.")
print("Scaled products omit all state-dependent RMS denominators and all later layers.")
print("Families:", [x[0] for x in families])

candidates = [(9,0),(8,2),(10,3),(6,2),(9,1),(6,1),(9,2),(8,3),
              (10,1),(8,1),(12,0),(5,3),(10,2),(2,3)]
print("\nATTENTION-SELECTED CANDIDATES: raw family scores A / B; scaled scores A / B")
for l,h in candidates:
    r = next(r for r in rows if (r["l"],r["h"])==(l,h))
    fmt = lambda v: "["+", ".join(f"{x:+.4g}" for x in v)+"]"
    print(f"L{l}H{h}: raw A {fmt(r['ra'])} B {fmt(r['rb'])}")
    print(f"       scaled A {fmt(r['sa'])} B {fmt(r['sb'])}; "
          f"relative own-OV change raw={r['dr']:.5f}, scaled={r['ds']:.5f}")

# Dividing by a matrix norm here only makes the STATIC operator scores comparable.
# It is not normalization of a model hidden state.
def score(r, mode):
    if mode == "raw":
        return float(((r["ra"]+r["rb"])*0.5).mean()/r["nr"])
    return float(((r["sa"]+r["sb"])*0.5).mean()/r["ns"])

for mode in ("raw","scaled"):
    print(f"\nTOP 12 ANSWER-PRESERVING HEADS, {mode}, operator-norm-adjusted")
    for r in sorted(rows,key=lambda r:score(r,mode),reverse=True)[:12]:
        vals = (r["ra"]+r["rb"])/2 if mode=="raw" else (r["sa"]+r["sb"])/2
        print(f"L{r['l']}H{r['h']} score={score(r,mode):+.6f} "
              f"positive_families={int((vals>0).sum())}/5")
    print(f"BOTTOM 6 HEADS, {mode}")
    for r in sorted(rows,key=lambda r:score(r,mode))[:6]:
        print(f"L{r['l']}H{r['h']} score={score(r,mode):+.6f}")

print("\nLARGEST CHANGES IN STATIC CONTRAST TRANSFER (B-A), raw and scaled separately")
for mode in ("raw","scaled"):
    aa,bb,nn = ("ra","rb","nr") if mode=="raw" else ("sa","sb","ns")
    ranked = sorted(rows,key=lambda r:abs(float((r[bb]-r[aa]).mean()/r[nn])),reverse=True)
    print(mode)
    for r in ranked[:8]:
        print(f"L{r['l']}H{r['h']} signed_change="
              f"{float((r[bb]-r[aa]).mean()/r[nn]):+.7f}")
print("\nNo attention-weighted value vectors or text-dependent output scores were computed.")

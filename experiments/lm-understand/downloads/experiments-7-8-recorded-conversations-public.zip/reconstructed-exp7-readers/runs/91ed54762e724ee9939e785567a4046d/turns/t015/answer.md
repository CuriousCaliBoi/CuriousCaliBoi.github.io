```python
root="/work/attn/r5"
gp=[18,7,18,7,22,8,22,8,21,7,21,7,22,7,22,7]
fp=[10,15,10,15,11,17,11,17,10,15,10,15,11,16,11,16]
G,F=[],[]
for i in range(16):
    w=[np.load(f"{root}/t{i}_{s}.npy").astype(np.float32) for s in ("A","B")]
    G.append(np.stack([a[:,:,-1,gp[i]] for a in w]))
    F.append(np.stack([a[:,:,-1,fp[i]] for a in w]))
G,F=np.array(G),np.array(F)
dg=G[:,1]-G[:,0]
dc=dg-(F[:,1]-F[:,0])
end=np.arange(0,16,2)
front=np.arange(1,16,2)
domains=[np.arange(i,i+4) for i in (0,4,8,12)]
selected=[(11,2),(10,2),(9,0),(9,2),(12,2),(12,1),(17,2),
          (8,2),(6,2),(9,1),(5,2),(5,3),(9,3),(11,1)]
fmt=lambda z:"["+", ".join(f"{float(v):+.4f}" for v in z)+"]"

print("HELD-OUT DOMAINS: names / numeric codes / directions / animals")
print("All guesses conflict with the explicitly supplied fact.")
print("All shifts are B-A. No outputs or answer probabilities are available.")
for l,h in selected:
    print(f"L{l}H{h}: guess A={G[:,0,l,h].mean():.5f} B={G[:,1,l,h].mean():.5f}; "
          f"fact A={F[:,0,l,h].mean():.5f} B={F[:,1,l,h].mean():.5f}")
    print(f"       contrast end={dc[end,l,h].mean():+.5f} "
          f"front={dc[front,l,h].mean():+.5f}; "
          f"positive_trials={int((dc[:,l,h]>0).sum())}/16; "
          f"domains={fmt([dc[z,l,h].mean() for z in domains])}")

print("\nL11H2 AND L10H2: INDIVIDUAL HELD-OUT TRIALS")
for i in range(16):
    vals=[]
    for l,h in [(11,2),(10,2)]:
        vals.append(f"L{l}H{h} Aguess/fact={G[i,0,l,h]:.4f}/{F[i,0,l,h]:.4f} "
                    f"Bguess/fact={G[i,1,l,h]:.4f}/{F[i,1,l,h]:.4f}")
    print(f"text{i:02d}", "; ".join(vals))

# Positive under both position-group averages is a robustness criterion,
# not an estimate of causal importance.
robust=np.minimum(dc[end].mean(0),dc[front].mean(0))
order=np.argsort(robust.ravel())[-10:][::-1]
print("\nALL-HEAD RANKING BY WORSE-OF-TWO-POSITIONS CONTRAST SHIFT")
for j in order:
    l,h=map(int,np.unravel_index(j,robust.shape))
    print(f"L{l}H{h}: min_position_mean={robust[l,h]:+.5f}; "
          f"overall={dc[:,l,h].mean():+.5f}")

A,B,T=Checkpoint("A"),Checkpoint("B"),Tokenizer()
E=A.get("model.embed_tokens.weight")
gf=1+A.get("model.norm.weight")
pairs=[
    ("names"," Maya"," Liam","Maya","Liam"),
    ("codes","7","3","7","3"),
    ("directions"," north"," south","north","south"),
    ("animals"," cat"," dog","cat","dog")
]
IC,OC=[],[]
labels=[]
def tid(s):
    return T.vocab.get(s.replace(" ","▁"))
for label,ia,ib,oa,ob in pairs:
    ids=[tid(s) for s in (ia,ib,oa,ob)]
    if any(i is None for i in ids):
        print("Skipping unavailable single-token contrast:",label,ids)
        continue
    di,do=E[ids[0]]-E[ids[1]],E[ids[2]]-E[ids[3]]
    IC.append(di/np.linalg.norm(di));OC.append(do/np.linalg.norm(do))
    labels.append(label)
IC,OC=np.array(IC),np.array(OC)
del E

print("\nSTATIC VALUE/OUTPUT TRANSFER OF THE NEW ANSWER CONTRASTS:",labels)
print("Positive is answer-distinction preserving in this weight product, not a measured model output.")
for l,h in selected:
    p=f"model.layers.{l}."
    results=[]
    for ck in (A,B):
        O=ck.get(p+"self_attn.o_proj.weight")[:,h*256:(h+1)*256]
        V=ck.get(p+"self_attn.v_proj.weight")
        gi=1+ck.get(p+"input_layernorm.weight")
        go=1+ck.get(p+"post_attention_layernorm.weight")
        K=O@V
        Ks=(gf*go)[:,None]*K*gi[None,:]
        results.append((np.einsum("ij,ij->i",OC,IC@K.T),
                        np.einsum("ij,ij->i",OC,IC@Ks.T)))
    raw=(results[0][0]+results[1][0])*0.5
    scaled=(results[0][1]+results[1][1])*0.5
    print(f"L{l}H{h}: raw={fmt(raw)}; scaled={fmt(scaled)}; "
          f"raw B-A={fmt(results[1][0]-results[0][0])}")
```
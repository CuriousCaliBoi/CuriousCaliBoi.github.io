A, B, T = Checkpoint("A"), Checkpoint("B"), Tokenizer()
E = A.get("model.embed_tokens.weight")
rng = np.random.default_rng(20261102)

# A compact, interpretable vocabulary subset, fixed without inspecting results.
ids = np.array([
    i for i in sorted(T.id_to_token)
    if i < len(E) and i not in T.special
    and re.fullmatch(r" ?[A-Za-z0-9][A-Za-z0-9'.,!?():/-]{0,23}", T.text(i))
], dtype=np.int64)
words = [T.text(int(i)) for i in ids]
F = E[ids].copy()
F /= np.maximum(np.linalg.norm(F, axis=1, keepdims=True), 1e-20)
del E

print("Interpretable vocabulary rows:", len(ids))
print("Normalization convention used for static diagonal factors: gamma = 1 + stored weight.")
gf = 1.0 + A.get("model.norm.weight")
print("Final gamma min/median/max:",
      float(gf.min()), float(np.median(gf)), float(gf.max()))
print("No hidden-state RMS denominators are computed or approximated.")

def leading_svd(D, rank=6):
    # Randomized linear algebra on a weight difference, not a model execution.
    r = min(rank + 6, min(D.shape))
    omega = rng.standard_normal((D.shape[1], r)).astype(np.float32)
    Q, _ = np.linalg.qr(D @ omega, mode="reduced")
    for _ in range(3):
        Z, _ = np.linalg.qr(D.T @ Q, mode="reduced")
        Q, _ = np.linalg.qr(D @ Z, mode="reduced")
    u, s, vt = np.linalg.svd(Q.T @ D, full_matrices=False)
    return Q @ u[:, :rank], s[:rank], vt[:rank]

def poles(v, count=7):
    v = v / max(float(np.linalg.norm(v)), 1e-20)
    c = F @ v
    hi = np.argsort(c)[-count:][::-1]
    lo = np.argsort(c)[:count]
    return ([(words[i], round(float(c[i]), 3)) for i in hi],
            [(words[i], round(float(c[i]), 3)) for i in lo])

records = []
for layer in range(18):
    p = f"model.layers.{layer}."
    for part, name, normname in [
        ("MLP-down", "mlp.down_proj.weight", "post_feedforward_layernorm.weight"),
        ("ATTN-out", "self_attn.o_proj.weight", "post_attention_layernorm.weight")
    ]:
        x, y = A.get(p + name), B.get(p + name)
        d = y - x
        u, s, vt = leading_svd(d)
        energy = float(np.sum(d.astype(np.float64) ** 2))
        frac = s * s / max(energy, 1e-30)
        ga = 1 + A.get(p + normname)
        gb = 1 + B.get(p + normname)

        # Exact difference of diagonally scaled weight matrices.
        dw = gb[:, None] * y - ga[:, None] * x
        uw, sw, vtw = leading_svd(dw)
        ew = float(np.sum(dw.astype(np.float64) ** 2))
        fracw = sw * sw / max(ew, 1e-30)

        print(f"\nL{layer:02d} {part}: raw ||D||={np.sqrt(energy):.5f}; "
              f"top singular values={np.round(s[:3], 5).tolist()}; "
              f"energy fractions={np.round(frac[:3], 4).tolist()}; "
              f"scaled top fractions={np.round(fracw[:3], 4).tolist()}")

        # Arbitrary SVD signs: '+' below does NOT mean 'B favors this token'.
        # Use the raw leading update mode, mapped through fixed diagonal factors.
        outdir = gf * ((ga + gb) * 0.5) * u[:, 0]
        pos, neg = poles(outdir)
        print("  raw-mode embedding poles +", pos)
        print("                           -", neg)

        # The right singular vector tells which columns participate in that mode.
        rv = vt[0]
        if part == "MLP-down":
            ix = np.argsort(np.abs(rv))[-6:][::-1]
            print("  associated unit indices/loadings:",
                  [(int(i), round(float(rv[i]), 4)) for i in ix])
        else:
            print("  right-mode energy by output head:",
                  np.round(np.sum(rv.reshape(4, 256) ** 2, axis=1), 4).tolist())

        records.append((layer, part, float(frac[0]), float(fracw[0]),
                        float(s[0]), float(sw[0])))

print("\n=== MOST COHERENT RAW OUTPUT-WEIGHT DIFFERENCES ===")
for r in sorted(records, key=lambda x: x[2], reverse=True)[:10]:
    print("layer/part/raw_top_fraction/scaled_top_fraction/raw_s1/scaled_s1:", r)
print("\nAll token associations above are static geometry, not model logits.")
print("No sign-based A/B behavioral conclusion is licensed by SVD alone.")

root="/work/attn/r4"
gp=[24,22,22,19]*4
G,F=[],[]
for i in range(16):
    w=[np.load(f"{root}/t{i}_{s}.npy").astype(np.float32) for s in ("A","B")]
    G.append(np.stack([a[:,:,-1,gp[i]] for a in w]))
    F.append(np.stack([a[:,:,-1,11] for a in w]))
G,F=np.array(G),np.array(F)
dg=G[:,1]-G[:,0]
dc=dg-(F[:,1]-F[:,0])
heads=[(11,2),(10,2),(9,0),(9,2),(5,2),(5,3),(9,1),(9,3),(8,2),(6,2)]
prefixes=["empty","The answer is","The box is","Answer:"]
wordings=["I think the answer is blue","My guess is blue",
          "I would choose blue","Blue seems right to me"]
fmt=lambda a:"["+", ".join(f"{float(x):.4f}" for x in a)+"]"

print("Wording order:",wordings)
for z,label in enumerate(prefixes):
    ix=np.arange(4*z,4*z+4)
    print("\nPREFIX:",label)
    for l,h in heads:
        print(f"L{l}H{h} guess A={fmt(G[ix,0,l,h])} B={fmt(G[ix,1,l,h])}; "
              f"mean guess-minus-fact shift={dc[ix,l,h].mean():+.5f}")

print("\nL11H2: INDIVIDUAL GUESS / FACT ATTENTION")
for i in range(16):
    print(f"prefix={prefixes[i//4]:13s} wording={i%4}: "
          f"A={G[i,0,11,2]:.5f}/{F[i,0,11,2]:.5f} "
          f"B={G[i,1,11,2]:.5f}/{F[i,1,11,2]:.5f}")

def ranked(m,n=8):
    return [tuple(map(int,np.unravel_index(i,m.shape)))
            for i in np.argsort(np.abs(m).ravel())[-n:][::-1]]

print("\nTOP HEADS WITH NONMATCHING RESPONSE PREFIX 'Answer:'")
m=dc[12:16].mean(0)
for l,h in ranked(m):
    print(f"L{l}H{h}: contrast_shift={m[l,h]:+.5f}, "
          f"guess A={G[12:16,0,l,h].mean():.5f}, "
          f"B={G[12:16,1,l,h].mean():.5f}")

print("\nTOP HEADS OVER PARAPHRASES WITHOUT THE WORDS 'answer is', NONEMPTY PREFIXES")
ix=np.array([5,6,7,9,10,11,13,14,15])
m=dc[ix].mean(0)
for l,h in ranked(m):
    print(f"L{l}H{h}: contrast_shift={m[l,h]:+.5f}, "
          f"guess A={G[ix,0,l,h].mean():.5f}, B={G[ix,1,l,h].mean():.5f}")

# Inspect attention routing at source tokens, without retrieving their hidden states.
prev, prev3, selfmass = [],[],[]
for i in range(4):
    pair=[np.load(f"{root}/t{i}_{s}.npy").astype(np.float32) for s in ("A","B")]
    a,b,c=[],[],[]
    for w in pair:
        positions=[gp[i],11]
        a.append(np.mean([w[:,:,q,q-1] for q in positions],axis=0))
        b.append(np.mean([w[:,:,q,max(0,q-3):q].sum(-1) for q in positions],axis=0))
        c.append(np.mean([w[:,:,q,q] for q in positions],axis=0))
    prev.append(np.stack(a));prev3.append(np.stack(b));selfmass.append(np.stack(c))
prev,prev3,selfmass=map(np.array,(prev,prev3,selfmass))
pm=prev.mean((0,1))
print("\nSOURCE-TOKEN PREVIOUS-POSITION RETRIEVAL: TOP 12 HEADS BEFORE L11")
for l,h in ranked(pm[:11],12):
    print(f"L{l}H{h}: previous A={prev[:,0,l,h].mean():.4f}, "
          f"B={prev[:,1,l,h].mean():.4f}; previous3 "
          f"A={prev3[:,0,l,h].mean():.4f}, B={prev3[:,1,l,h].mean():.4f}; "
          f"self A={selfmass[:,0,l,h].mean():.4f}, B={selfmass[:,1,l,h].mean():.4f}")
print("\nLARGEST CHANGES IN SOURCE-TOKEN PREVIOUS-POSITION RETRIEVAL BEFORE L11")
dm=(prev[:,1]-prev[:,0]).mean(0)
for l,h in ranked(dm[:11],8):
    print(f"L{l}H{h}: B-A={dm[l,h]:+.5f}")
print("\nThese source-token measurements suggest possible routing chains, not established causal circuits.")

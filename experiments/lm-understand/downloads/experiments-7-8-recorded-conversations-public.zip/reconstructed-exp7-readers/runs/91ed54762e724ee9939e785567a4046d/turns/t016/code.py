A,B,T=Checkpoint("A"),Checkpoint("B"),Tokenizer()
E=A.get("model.embed_tokens.weight")
specs=[
    ("letters",[" A"," B"," C"," D"]),
    ("digits",["1","2","3","4","5","6","7"]),
    ("colors",[" red"," blue"," green"," yellow"]),
    ("cities",[" London"," Paris"," Rome"," Tokyo"]),
    ("binary",[" yes"," no"," true"," false"]),
    ("names",[" Maya"," Liam"]),
    ("directions",[" north"," south"," east"," west"]),
    ("animals",[" cat"," dog"," bird"," fish"])
]
dirs=[];slices=[];labels=[]
for label,words in specs:
    ids=[T.vocab.get(s.replace(" ","▁")) for s in words]
    ids=[i for i in ids if i is not None]
    start=len(dirs)
    for j in range(len(ids)):
        for k in range(j):
            d=E[ids[j]]-E[ids[k]]
            dirs.append(d/np.linalg.norm(d))
    if len(dirs)>start:
        slices.append(slice(start,len(dirs)));labels.append(label)
I=np.array(dirs)
del E

def rotation(K,distance,theta):
    d=K.shape[0]
    ang=-distance*theta**(-np.arange(0,d,2,dtype=np.float64)/d)
    c=np.tile(np.cos(ang),2).astype(np.float32)[:,None]
    s=np.tile(np.sin(ang),2).astype(np.float32)[:,None]
    return c*K+s*np.concatenate([-K[d//2:],K[:d//2]],axis=0)

def source_operator(ck,h,mode):
    p="model.layers.5."
    O=ck.get(p+"self_attn.o_proj.weight")[:,h*256:(h+1)*256]
    V=ck.get(p+"self_attn.v_proj.weight")
    L=O@V
    if mode=="scaled":
        gi=1+ck.get(p+"input_layernorm.weight")
        go=1+ck.get(p+"post_attention_layernorm.weight")
        L=go[:,None]*L*gi
    return L

def target_operator(ck,l,h,mode,distance):
    p=f"model.layers.{l}."
    Q=ck.get(p+"self_attn.q_proj.weight")[h*256:(h+1)*256]
    K=ck.get(p+"self_attn.k_proj.weight")
    if mode=="scaled":
        gi=1+ck.get(p+"input_layernorm.weight")
        Q=(1+ck.get(p+"self_attn.q_norm.weight"))[:,None]*Q*gi
        K=(1+ck.get(p+"self_attn.k_norm.weight"))[:,None]*K*gi
    theta=1e6 if A.config["layer_types"][l]=="full_attention" else 1e4
    return Q.T@rotation(K,distance,theta)

def summarize(v):
    return np.array([v[s].mean() for s in slices])

targets=[(9,0),(9,2),(10,2),(11,2),(12,2)]
distances=[9,24]
results={}

print("Weight-only path test; families:",labels)
print("L = source head OV product; M = later head QK product at fixed position offset.")
print("Query-side: d^T L^T M d. Key-side: d^T M L d.")
print("Positive means same-answer matching in this STATIC product, not an attention score.")
print("Both operators are divided by their Frobenius norms for comparability.")
print("All state-dependent normalization, intervening blocks, and attention routing are omitted.")

for mode in ("raw","scaled"):
    sources={}
    for sh in range(4):
        L=(source_operator(A,sh,mode)+source_operator(B,sh,mode))*0.5
        sources[sh]=L/max(float(np.linalg.norm(L)),1e-30)
    for l,h in targets:
        for distance in distances:
            M=(target_operator(A,l,h,mode,distance)+
               target_operator(B,l,h,mode,distance))*0.5
            M=M/max(float(np.linalg.norm(M)),1e-30)
            for sh,L in sources.items():
                query=summarize(np.einsum("ij,ij->i",(I@L.T)@M,I))
                key=summarize(np.einsum("ij,ij->i",(I@M)@L,I))
                results[(mode,l,h,distance,sh)]=(query,key)

print("\nSOURCE L5 HEADS 0..3 AS CONTROLS; AVERAGED OVER THE TWO POSITION OFFSETS")
print("Scores multiplied by 10000 for readability.")
for l,h in targets:
    print(f"Target L{l}H{h}")
    for sh in range(4):
        fields=[]
        for mode in ("raw","scaled"):
            qq=np.mean([results[(mode,l,h,d,sh)][0] for d in distances],axis=0)
            kk=np.mean([results[(mode,l,h,d,sh)][1] for d in distances],axis=0)
            fields.append(f"{mode}: Q={qq.mean()*1e4:+.4f} "
                          f"({int((qq>0).sum())}/{len(qq)} families), "
                          f"K={kk.mean()*1e4:+.4f} "
                          f"({int((kk>0).sum())}/{len(kk)} families)")
        print(f"  source L5H{sh}: "+"; ".join(fields))

print("\nDETAILED QUERY-SIDE SIGNS FOR L5H2/H3")
for sh in (2,3):
    for l,h in targets:
        for mode in ("raw","scaled"):
            signs=[]
            means=[]
            for distance in distances:
                q=results[(mode,l,h,distance,sh)][0]
                signs.append("".join("+" if v>0 else "-" for v in q))
                means.append(float(q.mean()*1e4))
            print(f"L5H{sh}->L{l}H{h} {mode}: "
                  f"family signs at distances 9/24={signs}; "
                  f"means={[round(v,5) for v in means]}")
print("\nA sign-consistent connection is only a candidate pathway; no actual hidden-state flow was measured.")

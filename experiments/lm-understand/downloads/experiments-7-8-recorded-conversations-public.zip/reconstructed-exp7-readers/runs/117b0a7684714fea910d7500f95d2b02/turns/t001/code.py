from collections import Counter

A, B = Checkpoint("A"), Checkpoint("B")

print("=== CONFIGURATION ===")
print("A:", json.dumps(A.config, sort_keys=True))
print("Configs identical:", A.config == B.config)
if A.config != B.config:
    print("B:", json.dumps(B.config, sort_keys=True))

ka, kb = set(A.keys()), set(B.keys())
print("\n=== TENSOR INVENTORY ===")
print("Tensor counts:", len(ka), len(kb))
print("Only A:", sorted(ka - kb))
print("Only B:", sorted(kb - ka))

common = sorted(ka & kb)
shape_mismatches = [
    (k, A.shape(k), B.shape(k))
    for k in common if A.shape(k) != B.shape(k)
]
print("Shape mismatches:", shape_mismatches)
print("Stored parameter counts:",
      sum(int(np.prod(A.shape(k))) for k in ka),
      sum(int(np.prod(B.shape(k))) for k in kb))
print("Dtypes A:", dict(Counter(A.info[k]["dtype"] for k in ka)))
print("Dtypes B:", dict(Counter(B.info[k]["dtype"] for k in kb)))

# Discover layer prefixes rather than assuming a particular model wrapper.
pattern = re.compile(r"^(.*layers\.(\d+)\.)self_attn\.v_proj\.weight$")
layers = []
for k in common:
    m = pattern.match(k)
    if m:
        layers.append((int(m.group(2)), m.group(1)))
layers.sort()

print("Discovered attention layers:", [i for i, _ in layers])
if layers:
    first_prefix = layers[0][1]
    print("\nTensors in first layer:")
    for k in common:
        if k.startswith(first_prefix):
            print(k, A.shape(k))

print("\nNon-layer tensors:")
for k in common:
    if not re.search(r"\blayers\.\d+\.", k):
        print(k, A.shape(k))

cfg = A.config.get("text_config", A.config)
nq = cfg.get("num_attention_heads")
nkv = cfg.get("num_key_value_heads", nq)

def fro(x):
    return float(np.sqrt(np.einsum("ij,ij->", x, x,
                                    dtype=np.float64)))

rows = []
skipped = []

if shape_mismatches:
    print("\nSkipping operator comparison: tensor shapes are not aligned.")
elif not isinstance(nq, int) or not isinstance(nkv, int):
    print("\nSkipping operator comparison: head counts not found in config.")
elif nq <= 0 or nkv <= 0 or nq % nkv:
    print("\nSkipping operator comparison: unsupported head grouping.")
else:
    print("\n=== HEAD VALUE-OUTPUT OPERATORS ===")
    print("Convention: differences are B minus A.")
    print("For head h, C_h = O_h @ V_kv(h).")
    print("This is a weight-only linear sub-map, NOT full attention.")
    print("It omits token-dependent routing and hidden-state normalization.")
    print("Standard contiguous grouped-query head assignment is assumed.")
    print("Exact decomposition:")
    print("  C_B - C_A = O_mid @ (V_B-V_A) + (O_B-O_A) @ V_mid")
    print("  first term = change in value reading")
    print("  second term = change in output writing")

    group_size = nq // nkv

    for layer, prefix in layers:
        oname = prefix + "self_attn.o_proj.weight"
        vname = prefix + "self_attn.v_proj.weight"
        if oname not in ka or oname not in kb:
            skipped.append((layer, "missing output projection"))
            continue

        OA = A.get(oname).astype(np.float64)
        OB = B.get(oname).astype(np.float64)
        VA = A.get(vname).astype(np.float64)
        VB = B.get(vname).astype(np.float64)

        if OA.ndim != 2 or VA.ndim != 2:
            skipped.append((layer, "non-matrix projection"))
            continue

        if VA.shape[0] % nkv:
            skipped.append((layer, "value dimension not divisible by KV heads"))
            continue

        dv = VA.shape[0] // nkv
        if OA.shape[1] != nq * dv:
            skipped.append((layer, "output/value head dimensions disagree"))
            continue

        for head in range(nq):
            kvhead = head // group_size
            oslice = slice(head * dv, (head + 1) * dv)
            vslice = slice(kvhead * dv, (kvhead + 1) * dv)

            oa, ob = OA[:, oslice], OB[:, oslice]
            va, vb = VA[vslice, :], VB[vslice, :]

            ca = oa @ va
            cb = ob @ vb
            read_change = ((oa + ob) * 0.5) @ (vb - va)
            write_change = (ob - oa) @ ((va + vb) * 0.5)
            dc = read_change + write_change

            na, nb = fro(ca), fro(cb)
            nr, nw, nd = fro(read_change), fro(write_change), fro(dc)
            scale = np.sqrt((na * na + nb * nb) * 0.5)
            overlap = (
                float(np.einsum("ij,ij->", read_change, write_change))
                / (nr * nw)
                if nr > 0 and nw > 0 else float("nan")
            )
            residual = fro((cb - ca) - dc) / max(nd, 1e-300)

            rows.append({
                "layer": layer, "head": head, "kv": kvhead,
                "relative": nd / scale if scale else float("nan"),
                "delta": nd, "read": nr, "write": nw,
                "overlap": overlap, "residual": residual,
            })

    if rows:
        ranked = sorted(
            rows,
            key=lambda r: r["relative"] if np.isfinite(r["relative"]) else -1,
            reverse=True,
        )
        print("\nTop 24 by relative operator difference.")
        print("This orders algebraic differences, NOT behavioral importance.")
        print("layer head kv  relative_delta  abs_delta   read_term  write_term  read/write_cos")
        for r in ranked[:24]:
            print(
                f'{r["layer"]:5d} {r["head"]:4d} {r["kv"]:2d} '
                f'{r["relative"]:15.6g} {r["delta"]:10.5g} '
                f'{r["read"]:10.5g} {r["write"]:11.5g} '
                f'{r["overlap"]:14.5f}'
            )

        print("\nPer-layer summary:")
        print("layer  median_relative  max_relative  head_at_max")
        for layer, _ in layers:
            rr = [r for r in rows if r["layer"] == layer
                  and np.isfinite(r["relative"])]
            if not rr:
                continue
            best = max(rr, key=lambda r: r["relative"])
            print(
                f'{layer:5d} '
                f'{np.median([r["relative"] for r in rr]):16.6g} '
                f'{best["relative"]:13.6g} {best["head"]:12d}'
            )

        print("\nMaximum relative decomposition residual:",
              max(r["residual"] for r in rows))

    if skipped:
        print("Skipped layers:", skipped)

print("\nInterpretation boundary:")
print("These products can reveal changed value transformations.")
print("They do not establish which textual information is read,")
print("whether an answer is true, or whether a changed head is causally important.")

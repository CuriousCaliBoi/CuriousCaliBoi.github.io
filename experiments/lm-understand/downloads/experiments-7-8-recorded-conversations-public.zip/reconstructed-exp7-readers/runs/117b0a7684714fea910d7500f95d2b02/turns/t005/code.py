A, B = Checkpoint("A"), Checkpoint("B")
cfg = A.config.get("text_config", A.config)
L = cfg["num_hidden_layers"]
H = cfg["num_attention_heads"]
K = cfg["num_key_value_heads"]
HD = cfg["head_dim"]
N = cfg["hidden_size"]
TOP = 5

def get64(cp, name):
    return cp.get(name).astype(np.float64)

def sym(m):
    return 0.5 * (m + m.T)

def fro2(m):
    return float(np.einsum("ij,ij->", m, m, dtype=np.float64))

def load_mlp(cp, layer):
    p = f"model.layers.{layer}."
    pre = 1.0 + get64(cp, p + "pre_feedforward_layernorm.weight")
    post = 1.0 + get64(cp, p + "post_feedforward_layernorm.weight")

    # Rows index units; columns index residual coordinates.
    d = get64(cp, p + "mlp.down_proj.weight").T * post[None, :]
    g = get64(cp, p + "mlp.gate_proj.weight") * pre[None, :]
    u = get64(cp, p + "mlp.up_proj.weight") * pre[None, :]
    return np.ascontiguousarray(d), g, u

def quadratic_output_cross_gram(a, b, same=False):
    """
    E = (1/2) sum_i d_i tensor sym(g_i tensor u_i).

    Returns the output-mode contraction
      C_ab[o,p] = sum_jk E_a[o,j,k] E_b[p,j,k].

    This uses only weight Gram matrices. Learned pre/post norm diagonals
    are folded into the coefficients, but no RMS denominator is evaluated.
    """
    da, ga, ua = a
    db, gb, ub = b

    gg = ga @ gb.T
    uu = ua @ ub.T
    feature_gram = gg * uu
    del gg, uu

    gu = ga @ ub.T
    ug = gu.T if same else ua @ gb.T
    feature_gram += gu * ug
    feature_gram *= 0.125
    del gu, ug

    return (da.T @ feature_gram) @ db

def attention_grams(layer):
    p = f"model.layers.{layer}."
    ap = p + "self_attn."

    ia = 1.0 + get64(A, p + "input_layernorm.weight")
    ib = 1.0 + get64(B, p + "input_layernorm.weight")
    pa = 1.0 + get64(A, p + "post_attention_layernorm.weight")
    pb = 1.0 + get64(B, p + "post_attention_layernorm.weight")

    oa = get64(A, ap + "o_proj.weight") * pa[:, None]
    ob = get64(B, ap + "o_proj.weight") * pb[:, None]
    va = get64(A, ap + "v_proj.weight") * ia[None, :]
    vb = get64(B, ap + "v_proj.weight") * ib[None, :]

    delta_gram = np.zeros((N, N), dtype=np.float64)
    midpoint_gram = np.zeros_like(delta_gram)

    for h in range(H):
        kv = h // (H // K)
        hs = slice(h * HD, (h + 1) * HD)
        ks = slice(kv * HD, (kv + 1) * HD)
        ca = oa[:, hs] @ va[ks]
        cb = ob[:, hs] @ vb[ks]
        delta = cb - ca
        midpoint = 0.5 * (ca + cb)

        # Head coefficient maps are stacked, not treated as actual
        # simultaneously attended values.
        delta_gram += delta @ delta.T
        midpoint_gram += midpoint @ midpoint.T

    return sym(delta_gram), sym(midpoint_gram)

def spectrum_summary(c):
    c = sym(c)
    values, vectors = np.linalg.eigh(c)
    trace = float(np.trace(c))
    if trace <= 0:
        raise ValueError("Nonpositive operator energy")
    return {
        "top1": float(values[-1] / trace),
        "top5": float(values[-TOP:].sum() / trace),
        "effective_rank": trace * trace / fro2(c),
        "vectors": vectors[:, -TOP:][:, ::-1],
        "min_eigen_over_trace": float(values[0] / trace),
        "trace": trace,
    }

records = []
aggregates = {
    part: {
        "delta": np.zeros((N, N), dtype=np.float64),
        "mid": np.zeros((N, N), dtype=np.float64),
        "count": 0,
    }
    for part in ("attention", "mlp", "all")
}

def record(layer, part, delta_cov, mid_cov):
    ds = spectrum_summary(delta_cov)
    ms = spectrum_summary(mid_cov)
    records.append({
        "layer": layer, "part": part, "delta": ds, "mid": ms
    })
    for group in (part, "all"):
        aggregates[group]["delta"] += delta_cov / ds["trace"]
        aggregates[group]["mid"] += mid_cov / ms["trace"]
        aggregates[group]["count"] += 1

print("=== TEST: SHARED RESIDUAL-OUTPUT DIRECTION ===")
print("All calculations are contractions/eigendecompositions of weight coefficients.")
print("No input vectors, activations, attention scores, or forward passes.")
print("Learned output norm diagonals put coefficient numerators in residual coordinates.")
print("State-dependent normalization denominators remain excluded.")
print("Attention: value-output coefficient maps, not routing changes.")
print("MLP: exact even-component coefficients, not the complete nonlinear block.")
print("Midpoint controls use the midpoint of coefficient operators, not midpoint weights.")
print("Each block has equal weight in aggregate direction tests.")
print()

for layer in range(L):
    ac_delta, ac_mid = attention_grams(layer)
    record(layer, "attention", ac_delta, ac_mid)

    ma = load_mlp(A, layer)
    mb = load_mlp(B, layer)
    ca = quadratic_output_cross_gram(ma, ma, same=True)
    cb = quadratic_output_cross_gram(mb, mb, same=True)
    cab = quadratic_output_cross_gram(ma, mb)

    mc_delta = sym(ca + cb - cab - cab.T)
    mc_mid = sym(0.25 * (ca + cb + cab + cab.T))
    record(layer, "mlp", mc_delta, mc_mid)

    ar, mr = records[-2], records[-1]
    print(
        f'layer {layer:2d}: attention top-axis energy '
        f'delta={ar["delta"]["top1"]:.4f}, midpoint={ar["mid"]["top1"]:.4f}; '
        f'MLP delta={mr["delta"]["top1"]:.4f}, '
        f'midpoint={mr["mid"]["top1"]:.4f}',
        flush=True
    )

print("\n=== AGGREGATE SHARED-DIRECTION CONCENTRATION ===")
print("group       type      top1_share top5_share effective_rank")
aggregate_summaries = {}
for group, item in aggregates.items():
    aggregate_summaries[group] = {}
    for kind in ("delta", "mid"):
        c = item[kind] / item["count"]
        s = spectrum_summary(c)
        aggregate_summaries[group][kind] = s
        print(
            f'{group:11s} {kind:8s} {s["top1"]:11.6f} '
            f'{s["top5"]:10.6f} {s["effective_rank"]:14.3f}'
        )

print("\n=== PAIRWISE LEADING-DIRECTION AGREEMENT ===")
print("Squared cosine ignores arbitrary eigenvector sign.")
print("Isotropic-reference squared cosine is 1/640 =",
      1.0 / N, "(reference only, not a statistical null model).")
print("Top-5 overlap is ||U_i.T U_j||_F^2 / 5.")
print("Its isotropic reference is 5/640 =", TOP / N)
print("group       type      mean_top1_cos2 median_top1_cos2 mean_top5_overlap")

for group in ("attention", "mlp", "all"):
    rr = [r for r in records if group == "all" or r["part"] == group]
    for kind in ("delta", "mid"):
        top1, top5 = [], []
        for i in range(len(rr)):
            for j in range(i + 1, len(rr)):
                vi = rr[i][kind]["vectors"]
                vj = rr[j][kind]["vectors"]
                top1.append(float(np.dot(vi[:, 0], vj[:, 0]) ** 2))
                top5.append(fro2(vi.T @ vj) / TOP)
        print(
            f'{group:11s} {kind:8s} {np.mean(top1):16.6f} '
            f'{np.median(top1):17.6f} {np.mean(top5):17.6f}'
        )

print("\n=== ATTENTION / MLP AGREEMENT WITHIN EACH LAYER ===")
print("layer delta_top1_cos2 midpoint_top1_cos2 delta_top5_overlap midpoint_top5_overlap")
for layer in range(L):
    ar = next(r for r in records
              if r["layer"] == layer and r["part"] == "attention")
    mr = next(r for r in records
              if r["layer"] == layer and r["part"] == "mlp")
    values = {}
    for kind in ("delta", "mid"):
        av = ar[kind]["vectors"]
        mv = mr[kind]["vectors"]
        values[kind] = (
            float(np.dot(av[:, 0], mv[:, 0]) ** 2),
            fro2(av.T @ mv) / TOP,
        )
    print(
        f'{layer:5d} {values["delta"][0]:16.6f} '
        f'{values["mid"][0]:19.6f} {values["delta"][1]:18.6f} '
        f'{values["mid"][1]:21.6f}'
    )

print("\n=== AGGREGATE DIRECTION CONTROLS ===")
for kind in ("delta", "mid"):
    av = aggregate_summaries["attention"][kind]["vectors"][:, 0]
    mv = aggregate_summaries["mlp"][kind]["vectors"][:, 0]
    print(kind, "aggregate attention/MLP leading-axis squared cosine:",
          float(np.dot(av, mv) ** 2))

dv = aggregate_summaries["all"]["delta"]["vectors"][:, 0]
mv = aggregate_summaries["all"]["mid"]["vectors"][:, 0]
print("All-block difference axis versus midpoint axis squared cosine:",
      float(np.dot(dv, mv) ** 2))

print("Smallest eigenvalue/trace across individual Gram matrices:",
      min(r[k]["min_eigen_over_trace"]
          for r in records for k in ("delta", "mid")))
print("\nInterpretation:")
print("A shared change axis should concentrate difference energy across blocks,")
print("not merely reproduce directional concentration in the midpoint control.")
print("Even a positive result would identify coefficient geometry,")
print("not whether that direction means agreement, correctness, or another feature.")

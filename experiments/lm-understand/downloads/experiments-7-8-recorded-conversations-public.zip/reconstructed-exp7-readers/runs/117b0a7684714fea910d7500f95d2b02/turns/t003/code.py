A, B = Checkpoint("A"), Checkpoint("B")
cfg = A.config.get("text_config", A.config)
L = cfg["num_hidden_layers"]

def get64(cp, name):
    return cp.get(name).astype(np.float64)

def rowdot(a, b):
    return np.einsum("ij,ij->i", a, b, dtype=np.float64)

def vector_relative(a, b):
    denom = 0.5 * (np.dot(a, a) + np.dot(b, b))
    return float(np.sqrt(np.dot(b-a, b-a) / denom)) if denom else 0.0

def load_mlp(cp, layer):
    p = f"model.layers.{layer}."
    pre = 1.0 + get64(cp, p + "pre_feedforward_layernorm.weight")
    post = 1.0 + get64(cp, p + "post_feedforward_layernorm.weight")

    # Each row now corresponds to one MLP unit.
    d = np.ascontiguousarray(get64(cp, p + "mlp.down_proj.weight").T)
    g = get64(cp, p + "mlp.gate_proj.weight") * pre[None, :]
    u = get64(cp, p + "mlp.up_proj.weight") * pre[None, :]
    return (d, g, u), pre, post

def even_coefficient_inner(a, b, same=False):
    """
    Exact inner product of whole-layer coefficient tensors E_A and E_B:

      E = (1/2) sum_i d_i tensor sym(g_i tensor u_i).

    This represents the even-in-input part of the unnormalized MLP core.
    Only Gram matrices of WEIGHTS are computed. No input is constructed.

    <E_A,E_B> =
      (1/8) sum_ij <dAi,dBj> *
      [<gAi,gBj><uAi,uBj> + <gAi,uBj><uAi,gBj>].
    """
    da, ga, ua = a
    db, gb, ub = b

    dd = da @ db.T
    gg = ga @ gb.T
    uu = ua @ ub.T
    term1 = float(np.einsum("ij,ij,ij->", dd, gg, uu,
                            dtype=np.float64))
    del gg, uu

    gu = ga @ ub.T
    ug = gu.T if same else ua @ gb.T
    term2 = float(np.einsum("ij,ij,ij->", dd, gu, ug,
                            dtype=np.float64))
    return 0.125 * (term1 + term2)

layer_rows = []
unit_rows = []

print("=== EXACT MLP WEIGHT CONTRACTIONS ===")
print("No GELU, hidden-state normalization, or model input is evaluated.")
print("E denotes the even-component coefficient tensor before output RMSNorm.")
print("Input learned scaling is folded into gate/up weights.")
print("Output RMSNorm learned scaling is reported separately, not folded in.")
print("Whole-layer E comparisons include every cross-unit interaction.")
print("Individual-unit rankings below are algebraic, NOT causal importance.")
print()

for layer in range(L):
    a, prea, posta = load_mlp(A, layer)
    b, preb, postb = load_mlp(B, layer)
    da, ga, ua = a
    db, gb, ub = b

    dd_a, dd_b = rowdot(da, da), rowdot(db, db)
    gg_a, gg_b = rowdot(ga, ga), rowdot(gb, gb)
    uu_a, uu_b = rowdot(ua, ua), rowdot(ub, ub)

    dd_ab = rowdot(da, db)
    gg_ab = rowdot(ga, gb)
    uu_ab = rowdot(ua, ub)
    gu_a, gu_b = rowdot(ga, ua), rowdot(gb, ub)
    gu_ab, ug_ab = rowdot(ga, ub), rowdot(ua, gb)

    # Exact per-unit quadratic-coefficient squared norms and cross products.
    ea = 0.125 * dd_a * (gg_a * uu_a + gu_a * gu_a)
    eb = 0.125 * dd_b * (gg_b * uu_b + gu_b * gu_b)
    eab = 0.125 * dd_ab * (gg_ab * uu_ab + gu_ab * ug_ab)
    edelta2 = np.maximum(ea + eb - 2.0 * eab, 0.0)
    emid2 = 0.5 * (ea + eb)
    erel = np.sqrt(edelta2 / np.maximum(emid2, 1e-300))

    # Exact per-unit value-reading/output-writing maps: d_i outer u_i.
    ma = dd_a * uu_a
    mb = dd_b * uu_b
    mab = dd_ab * uu_ab
    mdelta2 = np.maximum(ma + mb - 2.0 * mab, 0.0)
    mmid2 = 0.5 * (ma + mb)
    mrel = np.sqrt(mdelta2 / np.maximum(mmid2, 1e-300))

    gate_delta2 = rowdot(gb-ga, gb-ga)
    gate_mid2 = 0.5 * (gg_a + gg_b)
    gate_rel = np.sqrt(gate_delta2 / np.maximum(gate_mid2, 1e-300))
    gate_cos = gg_ab / np.sqrt(np.maximum(gg_a * gg_b, 1e-300))
    gate_gain = np.sqrt(gg_b / np.maximum(gg_a, 1e-300))

    # Whole-layer coefficient comparison: unlike summing unit energies,
    # this includes cross-unit reinforcement and cancellation.
    whole_a = even_coefficient_inner(a, a, same=True)
    whole_b = even_coefficient_inner(b, b, same=True)
    whole_ab = even_coefficient_inner(a, b)
    whole_delta2_raw = whole_a + whole_b - 2.0 * whole_ab
    whole_delta2 = max(whole_delta2_raw, 0.0)
    whole_mid2 = 0.5 * (whole_a + whole_b)

    unit_energy_sum = float(edelta2.sum())
    top_units = np.argsort(edelta2)[::-1]
    top10_share = (
        float(edelta2[top_units[:10]].sum() / unit_energy_sum)
        if unit_energy_sum else 0.0
    )

    r = {
        "layer": layer,
        "whole_rel": np.sqrt(whole_delta2 / whole_mid2)
                     if whole_mid2 > 0 else 0.0,
        "whole_abs": np.sqrt(whole_delta2),
        "stack_rel": np.sqrt(unit_energy_sum / float(emid2.sum()))
                     if emid2.sum() > 0 else 0.0,
        "interaction": whole_delta2 / unit_energy_sum
                       if unit_energy_sum > 0 else float("nan"),
        "map_rel": np.sqrt(float(mdelta2.sum()) / float(mmid2.sum()))
                   if mmid2.sum() > 0 else 0.0,
        "gate_rel": np.sqrt(float(gate_delta2.sum()) / float(gate_mid2.sum()))
                    if gate_mid2.sum() > 0 else 0.0,
        "top10_share": top10_share,
        "pre_rel": vector_relative(prea, preb),
        "post_rel": vector_relative(posta, postb),
        "top_units": [int(i) for i in top_units[:5]],
    }
    layer_rows.append(r)

    for unit in range(len(ea)):
        unit_rows.append({
            "layer": layer, "unit": unit,
            "E_abs": float(np.sqrt(edelta2[unit])),
            "E_rel": float(erel[unit]),
            "map_rel": float(mrel[unit]),
            "gate_rel": float(gate_rel[unit]),
            "gate_angle_deficit": float(max(0.0, 1.0-gate_cos[unit])),
            "gate_gain": float(gate_gain[unit]),
            "layer_share": float(edelta2[unit] / unit_energy_sum)
                           if unit_energy_sum else 0.0,
        })

    # Print progress so a long calculation still yields useful partial output.
    print(
        f'layer {layer:2d}: whole_E_relative={r["whole_rel"]:.6f}, '
        f'whole_E_absolute={r["whole_abs"]:.6g}, '
        f'cross_unit_factor={r["interaction"]:.4f}',
        flush=True
    )

print("\n=== LAYERS SORTED BY WHOLE QUADRATIC-COEFFICIENT RELATIVE DIFFERENCE ===")
print("layer whole_E_rel whole_E_abs unit_stack_rel cross_unit_factor map_rel gate_rel top10_share")
for r in sorted(layer_rows, key=lambda x: x["whole_rel"], reverse=True):
    print(
        f'{r["layer"]:5d} {r["whole_rel"]:11.6f} '
        f'{r["whole_abs"]:11.5g} {r["stack_rel"]:14.6f} '
        f'{r["interaction"]:17.5f} {r["map_rel"]:8.6f} '
        f'{r["gate_rel"]:8.6f} {r["top10_share"]:11.5f}'
    )

print("\nCross-unit factor = ||sum_i delta E_i||^2 / sum_i ||delta E_i||^2.")
print("Below 1 indicates net cancellation; above 1 indicates net reinforcement.")
print("Neither indicates behavioral importance without the relevant hidden states.")

def print_units(title, selected):
    print("\n" + title)
    print("layer unit E_abs E_rel map_rel gate_rel 1-gate_cos B/A_gate_size layer_energy_share")
    for r in selected:
        print(
            f'{r["layer"]:5d} {r["unit"]:4d} '
            f'{r["E_abs"]:10.5g} {r["E_rel"]:9.6f} '
            f'{r["map_rel"]:9.6f} {r["gate_rel"]:9.6f} '
            f'{r["gate_angle_deficit"]:11.4g} {r["gate_gain"]:13.6f} '
            f'{r["layer_share"]:18.6f}'
        )

print_units(
    "Top 16 units by ABSOLUTE quadratic-coefficient difference:",
    sorted(unit_rows, key=lambda r: r["E_abs"], reverse=True)[:16]
)
print_units(
    "Top 16 units by RELATIVE quadratic-coefficient difference:",
    sorted(unit_rows, key=lambda r: r["E_rel"], reverse=True)[:16]
)

print("\nLearned normalization-scale changes and top absolute-difference units:")
print("layer pre_scale_rel post_scale_rel top_units")
for r in layer_rows:
    print(
        f'{r["layer"]:5d} {r["pre_rel"]:13.6g} {r["post_rel"]:14.6g} '
        f'{r["top_units"]}'
    )

print("\nBoundary: E is an exact component of the MLP-core function,")
print("but not the odd-in-input component, output normalization,")
print("the distribution of encountered hidden states, or decoded answer semantics.")

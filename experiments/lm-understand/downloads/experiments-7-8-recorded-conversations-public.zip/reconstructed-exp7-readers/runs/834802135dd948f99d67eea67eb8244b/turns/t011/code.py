A, B = Checkpoint("A"), Checkpoint("B")
cfg = A.config.get("text_config", A.config)
L = cfg["num_hidden_layers"]
H = cfg["num_attention_heads"]
HD = cfg["head_dim"]
assert H == 4
assert cfg["num_key_value_heads"] == 1

# An orthonormal change of coordinates in HEAD-INDEX space.
# Applied only to weight-derived coefficient matrices, never to model inputs.
T = 0.5 * np.array([
    [1,  1,  1,  1],
    [1,  1, -1, -1],
    [1, -1,  1, -1],
    [1, -1, -1,  1]
], dtype=np.float64)
assert np.allclose(T @ T.T, np.eye(H))

def energy(x):
    z = x.reshape(-1)
    return float(np.einsum("i,i->", z, z, dtype=np.float64))

def inner(x, y):
    return float(np.einsum("i,i->", x.reshape(-1), y.reshape(-1),
                           dtype=np.float64))

def gain(cp, name):
    return 1.0 + cp.get(name).astype(np.float64)

def head_gram(x):
    z = x.reshape(H, -1)
    return np.einsum("hi,ji->hj", z, z, dtype=np.float64, optimize=True)

def modes(x):
    return (T @ x.reshape(H, -1)).reshape(x.shape)

def safe_ratio(a, b):
    return a / b if b else 0.0

print("=== NEW HYPOTHESIS: CROSS-HEAD CANCELLATION / REDISTRIBUTION ===")
print("M_h = O_h @ V, with learned diagonals additionally included in scaled results.")
print("Common coefficient: C = sum_h M_h / sqrt(4).")
print("Three orthogonal contrast coefficients complete an exact decomposition.")
print("Sum of squared coefficient norms is preserved by this head-index transform.")
print("These are coefficient identities, not evaluations with equal attention patterns.")
print("Changes in attention patterns themselves are outside this decomposition.")
print("For independently randomized whole-head signs, expected common energy fraction is 1/4.")
print("That is a geometric reference, not a null model of fine-tuning.")

results = {}
max_parseval_error = 0.0
max_midpoint_error = 0.0

for scaled in (False, True):
    for l in range(L):
        p = f"model.layers.{l}."
        matrices = []
        osums = []
        values = []
        queries = []

        for cp in (A, B):
            o = cp.get(p+"self_attn.o_proj.weight").astype(np.float64)
            v = cp.get(p+"self_attn.v_proj.weight").astype(np.float64)
            q = cp.get(p+"self_attn.q_proj.weight").astype(np.float64)
            q = q.reshape(H, HD, -1)

            if scaled:
                ni = gain(cp, p+"input_layernorm.weight")
                no = gain(cp, p+"post_attention_layernorm.weight")
                nq = gain(cp, p+"self_attn.q_norm.weight")
                o = o * no[:,None]
                v = v * ni[None,:]
                q = q * ni[None,None,:] * nq[None,:,None]

            oh = [o[:,h*HD:(h+1)*HD] for h in range(H)]
            matrices.append(np.stack([x @ v for x in oh]))
            osums.append(sum(oh) / np.sqrt(H))
            values.append(v)
            queries.append(q)

        ma, mb = matrices
        delta = mb - ma
        ta, tb, td = modes(ma), modes(mb), modes(delta)

        total_delta = energy(delta)
        common_delta = energy(td[0])
        contrast_delta = energy(td[1:])
        total_base = 0.5*(energy(ma)+energy(mb))
        common_base = 0.5*(energy(ta[0])+energy(tb[0]))
        contrast_base = 0.5*(energy(ta[1:])+energy(tb[1:]))

        parseval_error = abs(
            total_delta-common_delta-contrast_delta
        ) / max(total_delta, 1e-300)
        max_parseval_error = max(max_parseval_error, parseval_error)

        gd = head_gram(delta)
        vals, vecs = np.linalg.eigh(gd)
        leading = vecs[:,-1]
        if leading[np.argmax(np.abs(leading))] < 0:
            leading = -leading
        common_vector = np.ones(H)/np.sqrt(H)
        leading_common_alignment = float((leading @ common_vector)**2)

        diagonal = np.maximum(np.diag(gd), 0)
        denominators = np.sqrt(diagonal[:,None]*diagonal[None,:])
        cosines = np.divide(
            gd, denominators, out=np.zeros_like(gd),
            where=denominators > 0
        )
        off_diagonal = cosines[np.triu_indices(H, 1)]

        # Exact common-component decomposition into output-side and value-side changes.
        oa, ob = osums
        va, vb = values
        output_piece = (ob-oa) @ (0.5*(va+vb))
        value_piece = (0.5*(oa+ob)) @ (vb-va)
        reconstructed = output_piece+value_piece
        midpoint_error = np.sqrt(
            energy(reconstructed-td[0]) / max(common_delta, 1e-300)
        )
        max_midpoint_error = max(max_midpoint_error, midpoint_error)
        output_share = safe_ratio(inner(td[0], output_piece), common_delta)

        # Weight-only check: are head query matrices themselves nearly proportional?
        # This does not estimate similarity of their actual attention patterns.
        query_cosines = []
        for q in queries:
            gq = head_gram(q)
            dq = np.maximum(np.diag(gq), 0)
            den = np.sqrt(dq[:,None]*dq[None,:])
            cq = np.divide(gq, den, out=np.zeros_like(gq), where=den > 0)
            query_cosines.extend(cq[np.triu_indices(H, 1)].tolist())

        results[(l,scaled)] = dict(
            common_fraction=safe_ratio(common_delta,total_delta),
            baseline_common_fraction=safe_ratio(common_base,total_base),
            common_relative=np.sqrt(safe_ratio(common_delta,common_base)),
            contrast_relative=np.sqrt(safe_ratio(contrast_delta,contrast_base)),
            leading_fraction=safe_ratio(float(vals[-1]),float(np.trace(gd))),
            leading_common_alignment=leading_common_alignment,
            leading=leading,
            delta_cos_median=float(np.median(off_diagonal)),
            delta_cos_min=float(np.min(off_diagonal)),
            delta_cos_max=float(np.max(off_diagonal)),
            common_output_share=output_share,
            query_cos_min=float(np.min(query_cosines)),
            query_cos_max=float(np.max(query_cosines))
        )

print("\n=== COMMON VERSUS HEAD-CONTRAST DIFFERENCES ===")
print("Percentages refer to squared coefficient norms, not behavioural contributions.")
print("layer raw_common_delta% scaled_common_delta% scaled_baseline_common% "
      "scaled_common_rel scaled_contrast_rel")
for l in range(L):
    raw, eff = results[(l,False)], results[(l,True)]
    print(f'{l:5d} {100*raw["common_fraction"]:9.3f} '
          f'{100*eff["common_fraction"]:9.3f} '
          f'{100*eff["baseline_common_fraction"]:9.3f} '
          f'{eff["common_relative"]:.6f} '
          f'{eff["contrast_relative"]:.6f}')

print("\n=== COORDINATION OF THE FOUR HEAD DIFFERENCES, SCALED ===")
print("The leading mode is learned from the 4x4 Gram matrix of weight differences.")
print("layer top_headmode_energy% topmode_common_alignment% "
      "delta_pair_cos[min,median,max] leading_headmode[H0,H1,H2,H3]")
for l in range(L):
    r = results[(l,True)]
    print(f'{l:5d} {100*r["leading_fraction"]:9.3f} '
          f'{100*r["leading_common_alignment"]:9.3f} '
          f'[{r["delta_cos_min"]:.4f},'
          f'{r["delta_cos_median"]:.4f},'
          f'{r["delta_cos_max"]:.4f}] '
          f'{np.round(r["leading"],4).tolist()}')

print("\n=== COMMON-COMPONENT ATTRIBUTION AND QUERY-MATRIX DISTINCTNESS ===")
print("Query cosines are matrix cosines only; no query vectors are evaluated.")
print("layer common_output_side_share% common_value_side_share% "
      "query_matrix_pair_cos[min,max]")
for l in range(L):
    r = results[(l,True)]
    print(f'{l:5d} {100*r["common_output_share"]:9.3f} '
          f'{100*(1-r["common_output_share"]):9.3f} '
          f'[{r["query_cos_min"]:.5f},{r["query_cos_max"]:.5f}]')

low = [l for l in range(L) if results[(l,True)]["common_fraction"] < 0.10]
high = [l for l in range(L) if results[(l,True)]["common_fraction"] > 0.50]
print("\nLayers with <10% scaled difference energy in common component:", low)
print("Layers with >50% scaled difference energy in common component:", high)
print("These thresholds are descriptive, not significance tests.")
print("Maximum relative Parseval error:", max_parseval_error)
print("Maximum relative midpoint reconstruction error:", max_midpoint_error)
print("Actual output cancellation cannot be inferred without the attention patterns.")

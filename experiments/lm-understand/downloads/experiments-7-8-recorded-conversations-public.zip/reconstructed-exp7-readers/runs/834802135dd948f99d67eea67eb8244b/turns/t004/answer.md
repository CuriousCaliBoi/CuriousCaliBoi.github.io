Including normalization diagonals substantially changed the ranking: **L11H0 and L11H1** now lead the attention discrepancy measure. MLP rankings were even less stable: only **4 of the top 100 units** overlapped between raw and diagonally scaled coupling rankings. This shows why neither ranking should be mistaken for behavioural importance. **My probability that A is sycophantic remains 0.50.**

Next I’ll test whether the broadly distributed differences contain **concentrated, coordinated update directions**. I’ll inspect their singular spectra and compare leading subspaces across projections. That can reveal structured modifications hidden beneath small widespread changes, rather than merely selecting large existing weights.

If A is sycophantic, those directions could implement increased agreement in A or increased correction in B; if B is sycophantic, the interpretation reverses. Spectral structure alone cannot choose between those explanations.

```python
import time

A, B = Checkpoint("A"), Checkpoint("B")
cfg = A.config.get("text_config", A.config)
L = cfg["num_hidden_layers"]
start = time.monotonic()

def energy(x):
    z = x.reshape(-1)
    return float(np.einsum("i,i->", z, z, dtype=np.float64))

parts = [
    ("q", "self_attn.q_proj.weight", "input"),
    ("k", "self_attn.k_proj.weight", "input"),
    ("v", "self_attn.v_proj.weight", "input"),
    ("o", "self_attn.o_proj.weight", "output"),
    ("gate", "mlp.gate_proj.weight", "input"),
    ("up", "mlp.up_proj.weight", "input"),
    ("down", "mlp.down_proj.weight", "output")
]
results = {}

print("=== EXACT SPECTRA OF PAIRED WEIGHT DIFFERENCES ===", flush=True)
print("For each matrix D=B-A, diagonalize its smaller Gram matrix.", flush=True)
print("The iid-edge ratio is only a scale reference, NOT a statistical test.", flush=True)
print("Its denominator is ||D||_F*(sqrt(m)+sqrt(n))/sqrt(m*n).", flush=True)

for l in range(L):
    for short, suffix, residual_side in parts:
        name = f"model.layers.{l}.{suffix}"
        d = B.get(name) - A.get(name)
        m, n = d.shape
        ed = energy(d)

        if m <= n:
            gram = d @ d.T
            vals, vecs = np.linalg.eigh(gram)
            order = np.argsort(vals)[::-1]
            vals = np.maximum(vals[order].astype(np.float64), 0.0)
            small_basis = vecs[:, order[:8]].astype(np.float64)
            if residual_side == "output":
                residual_basis = small_basis
            else:
                residual_basis = (
                    d.astype(np.float64).T @ small_basis
                    / np.sqrt(np.maximum(vals[:8], 1e-300))[None, :]
                )
        else:
            gram = d.T @ d
            vals, vecs = np.linalg.eigh(gram)
            order = np.argsort(vals)[::-1]
            vals = np.maximum(vals[order].astype(np.float64), 0.0)
            small_basis = vecs[:, order[:8]].astype(np.float64)
            if residual_side == "input":
                residual_basis = small_basis
            else:
                residual_basis = (
                    d.astype(np.float64) @ small_basis
                    / np.sqrt(np.maximum(vals[:8], 1e-300))[None, :]
                )

        mass = vals / ed if ed else np.zeros_like(vals)
        s1 = np.sqrt(vals[0])
        edge = np.sqrt(ed / (m*n)) * (np.sqrt(m) + np.sqrt(n))
        nz = mass[mass > 0]
        entropy_rank = float(np.exp(-np.sum(nz * np.log(nz)))) if nz.size else 0
        cdf = np.cumsum(mass)
        r90 = int(np.searchsorted(cdf, 0.9) + 1) if ed else 0

        # Orthogonalize only numerical eigensolver error in this weight-derived basis.
        residual_basis, _ = np.linalg.qr(residual_basis)
        v1 = residual_basis[:, 0]
        participation = 1.0 / np.sum(v1**4)
        results[(l, short)] = dict(
            layer=l, part=short, shape=(m, n), delta=np.sqrt(ed),
            s1=s1, edge_ratio=s1 / edge if edge else 0.0,
            top1=mass[0], top4=mass[:4].sum(), top16=mass[:16].sum(),
            stable_rank=ed / vals[0] if vals[0] else 0.0,
            entropy_rank=entropy_rank, r90=r90,
            participation=participation, basis=residual_basis,
            eigvals=vals
        )
    print(f"Completed layer {l:02d}; elapsed {time.monotonic()-start:.1f}s",
          flush=True)

print("\n=== TOP-SINGULAR-DIRECTION ENERGY SHARE (%) ===")
print("layer       q       k       v       o    gate      up    down")
for l in range(L):
    print(f"{l:5d}", " ".join(
        f'{100*results[(l,p)]["top1"]:7.3f}'
        for p, _, _ in parts))

print("\n=== TOP 28 BY SINGULAR-VALUE / IID-EDGE REFERENCE ===")
print("layer part delta s1 edge_ratio top1% top4% top16% "
      "stable_rank entropy_rank r90 residual_direction_participation")
ranked = sorted(results.values(), key=lambda r: r["edge_ratio"], reverse=True)
for r in ranked[:28]:
    print(f'{r["layer"]:5d} {r["part"]:5s} '
          f'{r["delta"]:.5g} {r["s1"]:.5g} {r["edge_ratio"]:.4f} '
          f'{100*r["top1"]:.3f} {100*r["top4"]:.3f} {100*r["top16"]:.3f} '
          f'{r["stable_rank"]:.2f} {r["entropy_rank"]:.2f} {r["r90"]:4d} '
          f'{r["participation"]:.2f}')

def overlap(a, b, rank=4):
    # Normalized overlap of weight-derived subspace projectors.
    x = a[:, :rank].T @ b[:, :rank]
    return energy(x) / rank

print("\n=== WITHIN-LAYER TOP-4 RESIDUAL-SUBSPACE OVERLAPS ===")
print("Unrelated isotropic 4D subspaces in 640D have mean overlap 4/640=0.00625.")
print("This is a geometric reference, not a fitted null model.")
print("layer gate/up q/k q/v k/v down/o gate/down up/down")
for l in range(L):
    pairs = [
        ("gate", "up"), ("q", "k"), ("q", "v"), ("k", "v"),
        ("down", "o"), ("gate", "down"), ("up", "down")
    ]
    vals = [
        overlap(results[(l,p)]["basis"], results[(l,q)]["basis"])
        for p, q in pairs
    ]
    print(f"{l:5d}", " ".join(f"{v:.5f}" for v in vals))

print("\n=== CROSS-LAYER OVERLAPS, SAME PROJECTION TYPE ===")
pairs = []
for p in ("gate", "up", "down", "o"):
    for i in range(L):
        for j in range(i + 1, L):
            ov = overlap(results[(i,p)]["basis"], results[(j,p)]["basis"])
            pairs.append((ov, p, i, j))
for ov, p, i, j in sorted(pairs, reverse=True)[:24]:
    print(f"{p:5s} L{i:02d}/L{j:02d}: overlap={ov:.6f}")

print("\nTotal elapsed seconds:", round(time.monotonic() - start, 2))
print("No network inputs, state normalization, nonlinearities, or model execution used.")
```
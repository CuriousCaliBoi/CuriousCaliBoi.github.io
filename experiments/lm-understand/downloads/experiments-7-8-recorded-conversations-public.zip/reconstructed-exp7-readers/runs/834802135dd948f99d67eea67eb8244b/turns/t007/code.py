A, B = Checkpoint("A"), Checkpoint("B")
cfg = A.config.get("text_config", A.config)
L, H, HD = cfg["num_hidden_layers"], cfg["num_attention_heads"], cfg["head_dim"]
R = 8

def energy(x):
    z = x.reshape(-1)
    return float(np.einsum("i,i->", z, z, dtype=np.float64))

def dot(x,y):
    return float(np.einsum("i,i->", x.reshape(-1), y.reshape(-1),
                           dtype=np.float64))

def gain(cp,name):
    return 1.0+cp.get(name)

def leading_basis(cov):
    vals,vecs = np.linalg.eigh(cov)
    return vecs[:,np.argsort(vals)[::-1][:R]].astype(np.float64)

def overlap(a,b):
    observed = energy(a.T@b)/R
    la = np.sum(a*a,axis=1)
    lb = np.sum(b*b,axis=1)
    # Exact expected overlap after independently randomizing coordinate signs
    # of one basis. Preserves each subspace's coordinate leverage scores.
    sign_null = dot(la,lb)/R
    return observed, sign_null, observed-sign_null

print("=== NEARBY WEIGHT-PATH SUBSPACE CONNECTIONS ===")
print("Recipients: joint gate/up reading subspaces, rank 8.")
print("Attention sources: left subspaces of paired OV differences.")
print("MLP sources: left subspaces of down-projection differences.")
print("Only direct residual-coordinate compatibility is tested.")
print("Unknown gates, attention weights, normalization denominators and intervening")
print("branch contributions are NOT supplied or simulated.")
print("The sign-null controls coordinate concentration, not training statistics.")

readers = {}
for l in range(L):
    p=f"model.layers.{l}."
    for scaled in (False,True):
        dcov=np.zeros((cfg["hidden_size"],cfg["hidden_size"]),dtype=np.float32)
        bcov=np.zeros_like(dcov)
        for part in ("gate","up"):
            a=A.get(p+f"mlp.{part}_proj.weight")
            b=B.get(p+f"mlp.{part}_proj.weight")
            if scaled:
                a=a*gain(A,p+"pre_feedforward_layernorm.weight")[None,:]
                b=b*gain(B,p+"pre_feedforward_layernorm.weight")[None,:]
            d=b-a
            m=0.5*(a+b)
            dcov+=d.T@d
            bcov+=m.T@m
        readers[(l,scaled,"delta")]=leading_basis(dcov)
        readers[(l,scaled,"base")]=leading_basis(bcov)

sources=[]
signed=[]
selected_signed={
    (11,0),(11,1),(12,0),(12,2),(4,1),(4,0),
    (3,3),(8,2),(10,1),(17,3)
}
for l in range(L):
    p=f"model.layers.{l}."
    ovs={}
    for scaled in (False,True):
        pairs=[]
        for cp in (A,B):
            o=cp.get(p+"self_attn.o_proj.weight")
            v=cp.get(p+"self_attn.v_proj.weight")
            if scaled:
                o=o*gain(cp,p+"post_attention_layernorm.weight")[:,None]
                v=v*gain(cp,p+"input_layernorm.weight")[None,:]
            pairs.append((o,v))
        for h in range(H):
            sl=slice(h*HD,(h+1)*HD)
            ma=pairs[0][0][:,sl]@pairs[0][1]
            mb=pairs[1][0][:,sl]@pairs[1][1]
            d=mb-ma
            ovs[(h,scaled)]=leading_basis(d@d.T)

            def identity_alignment(x):
                den=np.sqrt(x.shape[0]*energy(x))
                return float(np.trace(x,dtype=np.float64))/den if den else 0.0

            ca,cb=identity_alignment(ma),identity_alignment(mb)
            rec=dict(layer=l,head=h,scaled=scaled,
                     a=ca,b=cb,change=cb-ca)
            if (l,h) in selected_signed and scaled:
                sym=0.5*(d+d.T)
                ev=np.linalg.eigvalsh(sym)
                rec["min_eig"]=float(ev[0])
                rec["max_eig"]=float(ev[-1])
            signed.append(rec)

    for h in range(H):
        sources.append(dict(layer=l,part="attention",head=h,
                            raw=ovs[(h,False)],scaled=ovs[(h,True)]))

    down_bases={}
    for scaled in (False,True):
        da=A.get(p+"mlp.down_proj.weight")
        db=B.get(p+"mlp.down_proj.weight")
        if scaled:
            da=da*gain(A,p+"post_feedforward_layernorm.weight")[:,None]
            db=db*gain(B,p+"post_feedforward_layernorm.weight")[:,None]
        d=db-da
        down_bases[scaled]=leading_basis(d@d.T)
    sources.append(dict(layer=l,part="mlp",head=None,
                        raw=down_bases[False],scaled=down_bases[True]))

links=[]
for source in sources:
    l=source["layer"]
    first=l if source["part"]=="attention" else l+1
    for target in range(first,min(first+3,L)):
        raw=overlap(source["raw"],readers[(target,False,"delta")])
        eff=overlap(source["scaled"],readers[(target,True,"delta")])
        base=overlap(source["scaled"],readers[(target,True,"base")])
        links.append(dict(
            source=source,target=target,raw=raw,scaled=eff,base=base,
            score=min(raw[2],eff[2])
        ))

def source_label(s):
    if s["part"]=="attention":
        return f'L{s["layer"]:02d}H{s["head"]}'
    return f'L{s["layer"]:02d}MLP'

print("\nTop 20 connections by MIN(raw excess overlap, scaled excess overlap).")
print("This conservative structural ranking is not a causal circuit ranking.")
print("source -> target raw_overlap raw_null scaled_overlap scaled_null "
      "scaled_baseread_overlap scaled_baseread_null")
for r in sorted(links,key=lambda x:x["score"],reverse=True)[:20]:
    print(f'{source_label(r["source"]):7s} -> L{r["target"]:02d}MLP '
          f'{r["raw"][0]:.5f} {r["raw"][1]:.5f} '
          f'{r["scaled"][0]:.5f} {r["scaled"][1]:.5f} '
          f'{r["base"][0]:.5f} {r["base"][1]:.5f}')

raw_top={(
    r["source"]["layer"],r["source"]["part"],r["source"]["head"],r["target"])
    for r in sorted(links,key=lambda x:x["raw"][2],reverse=True)[:20]}
scaled_top={(
    r["source"]["layer"],r["source"]["part"],r["source"]["head"],r["target"])
    for r in sorted(links,key=lambda x:x["scaled"][2],reverse=True)[:20]}
print("Overlap of raw/scaled top-20 connections:",len(raw_top&scaled_top))

print("\n=== SIGNED IDENTITY ALIGNMENT OF OV ===")
print("c(M)=trace(M)/(sqrt(hidden_size)*||M||_F).")
print("A purely algebraic coordinate-preservation measure, NOT user-guess copying.")
for scaled in (False,True):
    rr=[r for r in signed if r["scaled"]==scaled]
    changes=np.array([r["change"] for r in rr])
    print("scaled=",scaled,
          "B>A:",int(np.sum(changes>0)),
          "B<A:",int(np.sum(changes<0)),
          "change[min,median,max]=",np.quantile(changes,[0,.5,1]))

print("\nSelected diagonally scaled operators:")
print("layer head c_A c_B B_minus_A min_eig(sym_delta) max_eig(sym_delta)")
for r in signed:
    if "min_eig" in r:
        print(f'{r["layer"]:5d} {r["head"]:4d} '
              f'{r["a"]:.8f} {r["b"]:.8f} {r["change"]:+.8f} '
              f'{r["min_eig"]:.6g} {r["max_eig"]:.6g}')

print("\nOpposite eigenvalue signs mean direction-dependent symmetric change,")
print("not that either model uniformly strengthens coordinate-preserving transport.")
print("No residual direction has been identified with guesses or correct answers.")

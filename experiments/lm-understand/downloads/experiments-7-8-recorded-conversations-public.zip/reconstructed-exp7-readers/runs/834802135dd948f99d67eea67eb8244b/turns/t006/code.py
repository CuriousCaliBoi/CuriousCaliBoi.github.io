A, B = Checkpoint("A"), Checkpoint("B")
cfg = A.config.get("text_config", A.config)
L, H, HD = cfg["num_hidden_layers"], cfg["num_attention_heads"], cfg["head_dim"]

def energy(x):
    z = x.reshape(-1)
    return float(np.einsum("i,i->", z, z, dtype=np.float64))

def dot(x, y):
    return float(np.einsum("i,i->", x.reshape(-1), y.reshape(-1),
                           dtype=np.float64))

def rdot(x, y):
    return np.einsum("ij,ij->i", x, y, dtype=np.float64)

def gain(cp, name):
    return 1.0 + cp.get(name)

def product_parts(left_a, right_a, left_b, right_b):
    # Exact algebra: B_L B_R - A_L A_R = dL Rmid + Lmid dR.
    lm, rm = 0.5*(left_a+left_b), 0.5*(right_a+right_b)
    dl, dr = left_b-left_a, right_b-right_a
    pl, pr = dl @ rm, lm @ dr
    delta = pl + pr
    ed = energy(delta)
    scale = 0.5*(energy(left_a @ right_a)+energy(left_b @ right_b))
    return dict(
        rel=np.sqrt(ed/scale) if scale else 0.0,
        left_share=dot(delta, pl)/ed if ed else 0.0,
        right_share=dot(delta, pr)/ed if ed else 0.0,
        cross_cos=dot(pl, pr)/np.sqrt(energy(pl)*energy(pr))
                  if energy(pl)*energy(pr) else 0.0
    )

print("=== ATTENTION PRODUCT ATTRIBUTION ===")
print("Shares are signed inner-product allocations of operator-difference energy.")
print("Q+K shares and O+V shares each sum to 1; they are NOT behavioural attributions.")
print("Learned diagonals included; state denominators, RoPE and softmax excluded.")
attention = []
for l in range(L):
    maps = []
    for cp in (A, B):
        p = f"model.layers.{l}."
        ni = gain(cp, p+"input_layernorm.weight")
        no = gain(cp, p+"post_attention_layernorm.weight")
        nq = gain(cp, p+"self_attn.q_norm.weight")
        nk = gain(cp, p+"self_attn.k_norm.weight")
        q = cp.get(p+"self_attn.q_proj.weight").reshape(H, HD, -1)
        k = cp.get(p+"self_attn.k_proj.weight")
        v = cp.get(p+"self_attn.v_proj.weight")
        o = cp.get(p+"self_attn.o_proj.weight")
        maps.append((
            q*ni[None,None,:]*nq[None,:,None],
            k*ni[None,:]*nk[:,None],
            v*ni[None,:],
            o*no[:,None]
        ))
    qa, ka, va, oa = maps[0]
    qb, kb, vb, ob = maps[1]
    for h in range(H):
        sl = slice(h*HD, (h+1)*HD)
        qk = product_parts(qa[h].T, ka, qb[h].T, kb)
        ov = product_parts(oa[:,sl], va, ob[:,sl], vb)
        attention.append((l, h, qk, ov))

print("layer head QK_rel Q_share% K_share% OV_rel O_share% V_share% QK_crosscos OV_crosscos")
chosen = {
    (11,0), (11,1), (4,1), (10,1), (12,0), (12,2),
    (6,2), (3,3), (4,0), (1,2), (17,3), (8,2),
    (12,1), (5,2), (16,1), (16,3)
}
for l,h,qk,ov in attention:
    if (l,h) in chosen:
        print(f'{l:5d} {h:4d} {qk["rel"]:.6f} '
              f'{100*qk["left_share"]:.2f} {100*qk["right_share"]:.2f} '
              f'{ov["rel"]:.6f} {100*ov["left_share"]:.2f} '
              f'{100*ov["right_share"]:.2f} '
              f'{qk["cross_cos"]:.4f} {ov["cross_cos"]:.4f}')

print("\n=== EXACT MLP GATE-CONDITIONED COEFFICIENT DIFFERENCES ===")
print("For each unit P_j = d_j outer u_j.")
print("Delta P_j = Delta d_j outer u_mid,j + d_mid,j outer Delta u_j.")
print("The gate row is assessed separately; its nonlinear response is never evaluated.")
print("Scaled d/u/g include the learned post/pre-MLP diagonals.")
print("All aggregate P energies here sum per-unit energies, not cross-unit terms.")

units = []
layer_rows = []
for l in range(L):
    p = f"model.layers.{l}."
    maps = []
    for cp in (A,B):
        ni = gain(cp, p+"pre_feedforward_layernorm.weight").astype(np.float64)
        no = gain(cp, p+"post_feedforward_layernorm.weight").astype(np.float64)
        g = cp.get(p+"mlp.gate_proj.weight").astype(np.float64)
        u = cp.get(p+"mlp.up_proj.weight").astype(np.float64)
        d = cp.get(p+"mlp.down_proj.weight").T.astype(np.float64)
        maps.append((g*ni[None,:], u*ni[None,:], d*no[None,:]))
    ga,ua,da = maps[0]
    gb,ub,db = maps[1]
    gm,um,dm = 0.5*(ga+gb),0.5*(ua+ub),0.5*(da+db)
    dg,du,dd = gb-ga,ub-ua,db-da

    down_energy = rdot(dd,dd)*rdot(um,um)
    up_energy = rdot(dm,dm)*rdot(du,du)
    cross = rdot(dd,dm)*rdot(um,du)
    p_delta2 = np.maximum(down_energy+up_energy+2*cross,0)
    p_scale2 = 0.5*(rdot(da,da)*rdot(ua,ua)+rdot(db,db)*rdot(ub,ub))
    gate_delta2 = rdot(dg,dg)
    gate_scale2 = 0.5*(rdot(ga,ga)+rdot(gb,gb))
    gate_cos = np.divide(
        rdot(ga,gb), np.sqrt(rdot(ga,ga)*rdot(gb,gb)),
        out=np.ones(ga.shape[0]), where=(rdot(ga,ga)*rdot(gb,gb))>0)
    gate_angle = np.sqrt(np.maximum(0,2*(1-np.clip(gate_cos,-1,1))))

    et = p_delta2.sum()
    ds = (down_energy+cross).sum()/et if et else 0
    us = (up_energy+cross).sum()/et if et else 0
    top10 = np.sort(p_delta2)[-10:].sum()/et if et else 0
    layer_rows.append((
        l, np.sqrt(et/p_scale2.sum()),
        np.sqrt(gate_delta2.sum()/gate_scale2.sum()),
        ds,us,top10
    ))
    for j in range(ga.shape[0]):
        units.append(dict(
            layer=l, unit=j, delta=np.sqrt(p_delta2[j]),
            rel=np.sqrt(p_delta2[j]/p_scale2[j]) if p_scale2[j] else 0,
            gate_rel=np.sqrt(gate_delta2[j]/gate_scale2[j]) if gate_scale2[j] else 0,
            gate_angle=gate_angle[j],
            down_share=(down_energy[j]+cross[j])/p_delta2[j] if p_delta2[j] else 0,
            layer_share=p_delta2[j]/et if et else 0
        ))

print("layer P_rel gate_rel down_share% up_share% top10_P_energy%")
for l,pr,gr,ds,us,top10 in layer_rows:
    print(f"{l:5d} {pr:.6f} {gr:.6f} "
          f"{100*ds:.3f} {100*us:.3f} {100*top10:.3f}")

print("\nTop 20 units by fraction of THEIR LAYER'S coefficient-difference energy:")
print("This removes cross-layer scale differences, but does not establish importance.")
print("layer unit layer_share% P_delta P_rel gate_rel gate_angle down_share%")
for r in sorted(units,key=lambda r:r["layer_share"],reverse=True)[:20]:
    print(f'{r["layer"]:5d} {r["unit"]:4d} {100*r["layer_share"]:.4f} '
          f'{r["delta"]:.6g} {r["rel"]:.6f} {r["gate_rel"]:.6f} '
          f'{r["gate_angle"]:.6f} {100*r["down_share"]:.3f}')

print("\n=== CONCENTRATION OF COHERENT MLP PARAMETER DIFFERENCES ===")
print("Each projection is truncated algebraically to ranks 4,8,16 by SVD.")
print("Unit energies combine gate rows, up rows and down columns.")
print("This diagnoses sparse versus distributed UPDATE SUPPORT, not sparse causal support.")
print("layer rank8_top10_energy% top8_rank8_units rank4/rank16_top20_overlap")
for l in range(L):
    energies = {r: np.zeros(cfg["intermediate_size"], dtype=np.float64)
                for r in (4,8,16)}
    for part in ("gate","up","down"):
        name = p = f"model.layers.{l}.mlp.{part}_proj.weight"
        d = B.get(name)-A.get(name)
        # Put units on rows for all three projections.
        x = d.T if part == "down" else d
        vals,vecs = np.linalg.eigh(x.T @ x)
        basis = vecs[:,np.argsort(vals)[::-1][:16]]
        coefficients = x @ basis
        for rank in (4,8,16):
            energies[rank] += rdot(coefficients[:,:rank],coefficients[:,:rank])
    orders = {r: np.argsort(energies[r])[::-1] for r in energies}
    e8 = energies[8]
    frac = e8[orders[8][:10]].sum()/e8.sum()
    overlap = len(set(orders[4][:20]) & set(orders[16][:20]))
    print(f"{l:5d} {100*frac:.3f} {orders[8][:8].tolist()} {overlap}/20")

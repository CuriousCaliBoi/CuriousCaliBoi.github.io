A, B = Checkpoint("A"), Checkpoint("B")
cfg = A.config.get("text_config", A.config)
L = cfg["num_hidden_layers"]
H = cfg["num_attention_heads"]
HD = cfg["head_dim"]
P = HD // 2
assert HD % 2 == 0
assert cfg["num_key_value_heads"] == 1

print("=== ROTARY ARCHITECTURE FIELDS ===")
print(json.dumps({
    k: v for k, v in cfg.items()
    if "rope" in k.lower() or "rotary" in k.lower()
       or k in ("head_dim", "layer_types")
}, sort_keys=True))

print("\n=== NEW HYPOTHESIS: POSITIONAL MATCHING CHANGES HIDDEN AT ZERO DISPLACEMENT ===")
print("Using Gemma's half-split rotary pairing: channel i with channel i+head_dim/2.")
print("For each rotary plane, define purely weight-derived coefficient matrices:")
print("C_i = q_i outer k_i + q_partner outer k_partner")
print("S_i = q_i outer k_partner - q_partner outer k_i")
print("The sign convention for S depends on displacement orientation; its difference norms do not.")
print("No positions, sin/cos evaluations, input vectors, or attention scores are used.")
print("The coefficient bank is not an evaluated model or an input-distribution average.")

def energy(x):
    z = x.reshape(-1)
    return float(np.einsum("i,i->", z, z, dtype=np.float64))

def gain(cp, name):
    return 1.0 + cp.get(name)

def pairs(x):
    return np.stack((x[:P], x[P:]), axis=1).astype(np.float64)

def gram(x, y):
    # One 2x2 cross-Gram matrix per rotary plane.
    return np.einsum("pid,pjd->pij", x, y, optimize=True)

def product_inner(q1, k1, q2, k2):
    # Frobenius inner product of q1.T @ k1 and q2.T @ k2,
    # computed separately for each rotary plane.
    return np.sum(gram(q1, q2) * gram(k1, k2), axis=(1, 2))

def sine_partner(k):
    # Multiplication by a fixed 2D skew-symmetric generator.
    # This constructs coefficient factors, not a position-dependent rotation.
    return np.stack((k[:, 1], -k[:, 0]), axis=1)

def coefficient_stats(qa, ka, qb, kb):
    qa, ka, qb, kb = map(pairs, (qa, ka, qb, kb))
    qm, km = 0.5*(qa+qb), 0.5*(ka+kb)
    dq, dk = qb-qa, kb-ka

    results = []
    for sine in (False, True):
        if sine:
            ak, bk = sine_partner(ka), sine_partner(kb)
            mk, delta_k = sine_partner(km), sine_partner(dk)
        else:
            ak, bk, mk, delta_k = ka, kb, km, dk

        # Exact midpoint decomposition of each coefficient difference:
        # delta = dq.T @ k_mid + q_mid.T @ dk.
        eq = product_inner(dq, mk, dq, mk)
        ek = product_inner(qm, delta_k, qm, delta_k)
        cross = product_inner(dq, mk, qm, delta_k)
        delta2 = np.maximum(eq + ek + 2*cross, 0.0)

        ea = np.maximum(product_inner(qa, ak, qa, ak), 0.0)
        eb = np.maximum(product_inner(qb, bk, qb, bk), 0.0)
        results.append(dict(
            delta2=delta2, a2=ea, b2=eb,
            q_allocation=eq+cross, k_allocation=ek+cross
        ))
    return results

rows = []
for scaled in (False, True):
    for l in range(L):
        maps = []
        for cp in (A, B):
            p = f"model.layers.{l}."
            q = cp.get(p+"self_attn.q_proj.weight").reshape(H, HD, -1)
            k = cp.get(p+"self_attn.k_proj.weight")
            if scaled:
                ni = gain(cp, p+"input_layernorm.weight")
                nq = gain(cp, p+"self_attn.q_norm.weight")
                nk = gain(cp, p+"self_attn.k_norm.weight")
                q = q * ni[None,None,:] * nq[None,:,None]
                k = k * ni[None,:] * nk[:,None]
            maps.append((q, k))

        qa, ka = maps[0]
        qb, kb = maps[1]
        for h in range(H):
            cs, ss = coefficient_stats(qa[h], ka, qb[h], kb)
            de = cs["delta2"] + ss["delta2"]
            ae = cs["a2"] + ss["a2"]
            be = cs["b2"] + ss["b2"]
            et = de.sum()
            baseline = 0.5*(ae.sum()+be.sum())

            # Previous zero-displacement numerator, for comparison only.
            za = qa[h].T @ ka
            zb = qb[h].T @ kb
            zero_delta2 = energy(zb-za)
            zero_scale2 = 0.5*(energy(za)+energy(zb))

            band_delta = np.array([x.sum() for x in np.array_split(de, 4)])
            band_a = np.array([x.sum() for x in np.array_split(ae, 4)])
            band_b = np.array([x.sum() for x in np.array_split(be, 4)])

            rows.append(dict(
                layer=l, head=h, scaled=scaled,
                bank_rel=np.sqrt(et/baseline) if baseline else 0.0,
                zero_rel=np.sqrt(zero_delta2/zero_scale2) if zero_scale2 else 0.0,
                sine_share=ss["delta2"].sum()/et if et else 0.0,
                q_share=(cs["q_allocation"].sum()+ss["q_allocation"].sum())/et
                        if et else 0.0,
                # May exceed 1: this is a coherence ratio, not an energy fraction.
                cosine_sum_ratio=zero_delta2/cs["delta2"].sum()
                                 if cs["delta2"].sum() else 0.0,
                band_shares=band_delta/et if et else np.zeros(4),
                band_gain_change=(band_b/be.sum()-band_a/ae.sum())
                                 if ae.sum() and be.sum() else np.zeros(4)
            ))

print("\n=== PER-LAYER ROTARY-COEFFICIENT RELATIVE DIFFERENCES ===")
print("Heads 0,1,2,3; raw and learned-diagonal-scaled coefficient banks.")
for l in range(L):
    raw = [r for r in rows if r["layer"]==l and not r["scaled"]]
    scaled = [r for r in rows if r["layer"]==l and r["scaled"]]
    print(f"L{l:02d} raw:",
          " ".join(f'{r["bank_rel"]:.6f}' for r in raw),
          " scaled:",
          " ".join(f'{r["bank_rel"]:.6f}' for r in scaled))

effective = [r for r in rows if r["scaled"]]
ranked = sorted(effective, key=lambda r:r["bank_rel"], reverse=True)

print("\n=== TOP 20 SCALED ROTARY-COEFFICIENT DISCREPANCIES ===")
print("Q_share allocates coefficient-difference energy, not behavioural influence.")
print("Bands run from earlier to later rotary frequency indices.")
print("layer head bank_rel zero_rel sine_share% Q_share% cosine_sum_ratio "
      "band_delta_energy%[4]")
for r in ranked[:20]:
    print(f'{r["layer"]:5d} {r["head"]:4d} '
          f'{r["bank_rel"]:.6f} {r["zero_rel"]:.6f} '
          f'{100*r["sine_share"]:.2f} {100*r["q_share"]:.2f} '
          f'{r["cosine_sum_ratio"]:.4f} '
          f'{np.round(100*r["band_shares"],2).tolist()}')

zero_ranked = sorted(effective, key=lambda r:r["zero_rel"], reverse=True)
bank_top = {(r["layer"],r["head"]) for r in ranked[:10]}
zero_top = {(r["layer"],r["head"]) for r in zero_ranked[:10]}
print("\nTop-10 overlap, rotary bank versus zero-displacement comparison:",
      len(bank_top & zero_top))
print("New in rotary-bank top 10:", sorted(bank_top-zero_top))
print("Only in zero-displacement top 10:", sorted(zero_top-bank_top))

print("\n=== SIGNED CHANGE IN COEFFICIENT-ENERGY DISTRIBUTION OVER FREQUENCY BANDS ===")
print("B minus A, percentage points; not an inference about attended distances.")
for r in ranked[:10]:
    print(f'L{r["layer"]:02d}H{r["head"]}:',
          np.round(100*r["band_gain_change"],6).tolist())

print("\nSine-difference energy share across all scaled heads [min,median,max]:",
      np.quantile([r["sine_share"] for r in effective],[0,.5,1]))
print("No coefficient has been associated with the user's guess or the correct answer.")

# Read-only analysis. No model execution, inputs, activations, or optimisation.
from collections import defaultdict

A, B = Checkpoint("A"), Checkpoint("B")

print("=== ARCHITECTURE ===")
print("Configs identical:", A.config == B.config)
fields = [
    "model_type", "architectures", "hidden_size", "intermediate_size",
    "num_hidden_layers", "num_attention_heads", "num_key_value_heads",
    "head_dim", "hidden_activation", "hidden_act", "rms_norm_eps",
    "attention_bias", "attention_dropout", "query_pre_attn_scalar",
    "sliding_window", "sliding_window_pattern", "layer_types",
    "rope_theta", "rope_local_base_freq", "rope_scaling",
    "tie_word_embeddings"
]
for side, checkpoint in [("A", A), ("B", B)]:
    if side == "B" and A.config == B.config:
        continue
    config = checkpoint.config.get("text_config", checkpoint.config)
    print(side, json.dumps({k: config[k] for k in fields if k in config},
                           sort_keys=True))

ka, kb = set(A.keys()), set(B.keys())
print("\n=== TENSOR INVENTORY ===")
print("Tensor counts:", len(ka), len(kb))
print("Only in A:", sorted(ka - kb))
print("Only in B:", sorted(kb - ka))
if ka != kb:
    raise ValueError("Tensor inventories differ; inspect before comparing.")

layer_pattern = re.compile(r"(?:^|\.)layers\.(\d+)\.")
layers = sorted({
    int(m.group(1))
    for name in ka
    for m in [layer_pattern.search(name)]
    if m is not None
})
print("Layer indices:", layers)
first_layer = layers[0] if layers else None
for name in sorted(ka):
    m = layer_pattern.search(name)
    if m is None or int(m.group(1)) == first_layer:
        print(name, A.shape(name), A.info[name]["dtype"])

def energy(x):
    return float(np.einsum("...,...->", x, x, dtype=np.float64,
                           optimize=False))

def group_name(name):
    if ".self_attn." in name:
        return "attention"
    if ".mlp." in name:
        return "mlp"
    if "norm" in name:
        return "norm"
    return "other"

# Entries: parameter count, changed count, ||A||², ||B||², ||B-A||².
groups = defaultdict(lambda: np.zeros(5, dtype=np.float64))
records = []
finite = True
total = np.zeros(5, dtype=np.float64)

for name in sorted(ka):
    if A.shape(name) != B.shape(name):
        raise ValueError("Shape mismatch: " + name)
    a, b = A.get(name), B.get(name)
    if not (np.isfinite(a).all() and np.isfinite(b).all()):
        print("NONFINITE TENSOR:", name)
        finite = False
        continue
    d = b - a
    n = a.size
    changed = int(np.count_nonzero(d))
    ea, eb, ed = energy(a), energy(b), energy(d)
    scale = np.sqrt(0.5 * (ea + eb))
    relative = np.sqrt(ed) / scale if scale else 0.0
    m = layer_pattern.search(name)
    layer = int(m.group(1)) if m else -1
    part = group_name(name)
    values = np.array([n, changed, ea, eb, ed], dtype=np.float64)
    groups[(layer, part)] += values
    total += values
    records.append({
        "name": name, "n": n, "changed": changed,
        "a_norm": np.sqrt(ea), "b_norm": np.sqrt(eb),
        "d_norm": np.sqrt(ed), "relative": relative,
        "max_abs_delta": float(np.max(np.abs(d))) if n else 0.0,
        "delta_energy": ed
    })

print("\n=== GLOBAL PAIRED DIFFERENCE ===")
print("All inspected values finite:", finite)
print("Present parameters:", int(total[0]))
print("Exactly changed parameters:", int(total[1]))
print("Changed fraction:", total[1] / total[0] if total[0] else 0)
print("||A||, ||B||, ||B-A||:",
      np.sqrt(total[2]), np.sqrt(total[3]), np.sqrt(total[4]))
print("Symmetric relative difference:",
      np.sqrt(total[4] / (0.5 * (total[2] + total[3])))
      if total[2] + total[3] else 0)

print("\n=== LAYER/BLOCK DIFFERENCES ===")
print("rel = ||B-A|| / sqrt((||A||²+||B||²)/2)")
print("delta_share = share of ALL squared parameter differences; NOT causal importance")
print("layer part          n   changed%       ||A||       ||B||     ||B-A||        rel delta_share%")
for (layer, part), v in sorted(groups.items()):
    n, changed, ea, eb, ed = v
    relative = np.sqrt(ed / (0.5 * (ea + eb))) if ea + eb else 0.0
    share = 100 * ed / total[4] if total[4] else 0.0
    print(f"{layer:5d} {part:9s} {int(n):9d} "
          f"{100*changed/n:10.4f} {np.sqrt(ea):11.5g} "
          f"{np.sqrt(eb):11.5g} {np.sqrt(ed):11.5g} "
          f"{relative:10.5g} {share:12.5f}")

print("\n=== TOP 24 TENSORS BY ABSOLUTE DIFFERENCE ===")
for r in sorted(records, key=lambda x: x["d_norm"], reverse=True)[:24]:
    print(f'{r["name"]}: delta={r["d_norm"]:.6g}, '
          f'rel={r["relative"]:.6g}, '
          f'changed={r["changed"]}/{r["n"]}, '
          f'max_delta={r["max_abs_delta"]:.6g}')

print("\n=== TOP 18 TENSORS BY RELATIVE DIFFERENCE ===")
for r in sorted(records, key=lambda x: x["relative"], reverse=True)[:18]:
    print(f'{r["name"]}: rel={r["relative"]:.6g}, '
          f'delta={r["d_norm"]:.6g}, '
          f'A_norm={r["a_norm"]:.6g}, B_norm={r["b_norm"]:.6g}')

print("\n=== IDENTICAL TENSORS ===")
identical = [r["name"] for r in records if r["changed"] == 0]
print("Count:", len(identical))
print("\n".join(identical[:40]))
if len(identical) > 40:
    print("... remaining identical tensors omitted")

print("\nINTERPRETATION LIMIT:")
print("These are parameter differences, not behavioural or causal rankings.")
print("No statistic above identifies which checkpoint agrees with the user's guess.")

from collections import defaultdict

A, B = Checkpoint("A"), Checkpoint("B")
cfg = A.config.get("text_config", A.config)
L = cfg["num_hidden_layers"]
H = cfg["num_attention_heads"]
HD = cfg["head_dim"]
pattern = re.compile(r"(?:^|\.)layers\.(\d+)\.")

def energy(x):
    z = x.reshape(-1)
    return float(np.einsum("i,i->", z, z, dtype=np.float64))

def inner(x, y):
    return float(np.einsum("i,i->", x.reshape(-1), y.reshape(-1),
                           dtype=np.float64))

def relative_difference(x, y):
    ex, ey, ed = energy(x), energy(y), energy(y - x)
    return np.sqrt(ed / (0.5 * (ex + ey))) if ex + ey else 0.0

def part_of(name):
    if ".self_attn." in name:
        return "attention"
    if ".mlp." in name:
        return "mlp"
    return "norm" if "norm" in name else "other"

assert A.keys() == B.keys()
groups = defaultdict(lambda: np.zeros(5, dtype=np.float64))
records = []
total = np.zeros(5, dtype=np.float64)

for name in A.keys():
    a, b = A.get(name), B.get(name)
    assert a.shape == b.shape
    assert np.isfinite(a).all() and np.isfinite(b).all(), name
    d = b - a
    n, changed = a.size, int(np.count_nonzero(d))
    ea, eb, ed = energy(a), energy(b), energy(d)
    rel = np.sqrt(ed / (0.5 * (ea + eb))) if ea + eb else 0.0
    m = pattern.search(name)
    layer = int(m.group(1)) if m else -1
    values = np.array([n, changed, ea, eb, ed], dtype=np.float64)
    groups[(layer, part_of(name))] += values
    total += values
    records.append((name, n, changed, np.sqrt(ed), rel,
                    np.sqrt(ea), np.sqrt(eb)))

print("=== GLOBAL DIFFERENCE ===")
print("Present parameters:", int(total[0]))
print("Exactly changed:", int(total[1]),
      "fraction:", total[1] / total[0])
print("||A||, ||B||, ||B-A||:", np.sqrt(total[2:]))
print("Symmetric relative difference:",
      np.sqrt(total[4] / (0.5 * (total[2] + total[3]))))

print("\n=== LAYER/BLOCK DIFFERENCES ===")
print("layer part        changed%     ||B-A||      rel   delta_energy_share%")
for (layer, part), v in sorted(groups.items()):
    n, changed, ea, eb, ed = v
    rel = np.sqrt(ed / (0.5 * (ea + eb))) if ea + eb else 0.0
    share = 100 * ed / total[4] if total[4] else 0.0
    print(f"{layer:5d} {part:9s} {100*changed/n:9.4f} "
          f"{np.sqrt(ed):11.5g} {rel:9.5g} {share:19.5f}")

print("\n=== TOP 18 TENSORS BY ABSOLUTE DIFFERENCE ===")
for name, n, changed, dn, rel, an, bn in sorted(
        records, key=lambda r: r[3], reverse=True)[:18]:
    print(f"{name}: delta={dn:.6g}, rel={rel:.6g}, "
          f"changed={100*changed/n:.3f}%, norms={an:.6g}/{bn:.6g}")

print("\n=== TOP 12 TENSORS BY RELATIVE DIFFERENCE ===")
for name, n, changed, dn, rel, an, bn in sorted(
        records, key=lambda r: r[4], reverse=True)[:12]:
    print(f"{name}: rel={rel:.6g}, delta={dn:.6g}, "
          f"norms={an:.6g}/{bn:.6g}")

same = [r[0] for r in records if r[2] == 0]
print("\nIdentical tensors:", len(same))
print("\n".join(same[:20]))

print("\n=== RAW ATTENTION OPERATOR DIFFERENCES ===")
print("QK = Q_h.T @ K; OV = O_h @ V.")
print("No RoPE, norm diagonals, state normalization, softmax, or inputs.")
print("All four heads share K and V; their differences are not independent.")
heads = []

for layer in range(L):
    prefix = f"model.layers.{layer}.self_attn."
    wa = {p: A.get(prefix + p + "_proj.weight")
          for p in ("q", "k", "v", "o")}
    wb = {p: B.get(prefix + p + "_proj.weight")
          for p in ("q", "k", "v", "o")}
    assert wa["k"].shape[0] == HD, "Code assumes one KV head."
    for head in range(H):
        sl = slice(head * HD, (head + 1) * HD)
        qa, qb = wa["q"][sl], wb["q"][sl]
        oa, ob = wa["o"][:, sl], wb["o"][:, sl]

        qka = qa.T @ wa["k"]
        qkb = qb.T @ wb["k"]
        ova = oa @ wa["v"]
        ovb = ob @ wb["v"]

        qkr = relative_difference(qka, qkb)
        ovr = relative_difference(ova, ovb)
        qkd = np.sqrt(energy(qkb - qka))
        ovd = np.sqrt(energy(ovb - ova))

        # Exact midpoint decompositions of the paired product differences:
        # d(Q^T K) = dQ^T K_mid + Q_mid^T dK
        # d(O V)   = dO V_mid + O_mid dV
        q_piece = (qb - qa).T @ ((wa["k"] + wb["k"]) * 0.5)
        k_piece = ((qa + qb) * 0.5).T @ (wb["k"] - wa["k"])
        o_piece = (ob - oa) @ ((wa["v"] + wb["v"]) * 0.5)
        v_piece = ((oa + ob) * 0.5) @ (wb["v"] - wa["v"])

        def cosine(x, y):
            den = np.sqrt(energy(x) * energy(y))
            return inner(x, y) / den if den else 0.0

        heads.append(dict(
            layer=layer, head=head, qkr=qkr, ovr=ovr,
            qkd=qkd, ovd=ovd,
            qpart=np.sqrt(energy(q_piece)),
            kpart=np.sqrt(energy(k_piece)),
            opart=np.sqrt(energy(o_piece)),
            vpart=np.sqrt(energy(v_piece)),
            qkcos=cosine(q_piece, k_piece),
            ovcos=cosine(o_piece, v_piece),
            score=np.hypot(qkr, ovr)
        ))

print("Per-layer relative differences, heads 0,1,2,3:")
for layer in range(L):
    rows = [r for r in heads if r["layer"] == layer]
    print(f"L{layer:02d} QK:",
          " ".join(f'{r["qkr"]:.5f}' for r in rows),
          " OV:", " ".join(f'{r["ovr"]:.5f}' for r in rows))

print("\nTop 16 by sqrt(QK_relative² + OV_relative²):")
print("This is a structural discrepancy score, NOT a behavioural importance score.")
print("layer head QK_rel OV_rel QK_delta OV_delta "
      "Q_piece K_piece QK_cos O_piece V_piece OV_cos")
for r in sorted(heads, key=lambda r: r["score"], reverse=True)[:16]:
    print(f'{r["layer"]:5d} {r["head"]:4d} '
          f'{r["qkr"]:.5f} {r["ovr"]:.5f} '
          f'{r["qkd"]:.5g} {r["ovd"]:.5g} '
          f'{r["qpart"]:.5g} {r["kpart"]:.5g} {r["qkcos"]:.4f} '
          f'{r["opart"]:.5g} {r["vpart"]:.5g} {r["ovcos"]:.4f}')

print("\n=== NORMALIZATION PARAMETER RANGES ===")
for suffix in [
    "input_layernorm.weight",
    "post_attention_layernorm.weight",
    "pre_feedforward_layernorm.weight",
    "post_feedforward_layernorm.weight",
    "self_attn.q_norm.weight",
    "self_attn.k_norm.weight"
]:
    xa = np.concatenate([
        A.get(f"model.layers.{l}.{suffix}").reshape(-1) for l in range(L)
    ])
    xb = np.concatenate([
        B.get(f"model.layers.{l}.{suffix}").reshape(-1) for l in range(L)
    ])
    print(suffix,
          "A[min,median,max]=", np.quantile(xa, [0, .5, 1]),
          "B[min,median,max]=", np.quantile(xb, [0, .5, 1]),
          "delta_norm=", np.sqrt(energy(xb - xa)))

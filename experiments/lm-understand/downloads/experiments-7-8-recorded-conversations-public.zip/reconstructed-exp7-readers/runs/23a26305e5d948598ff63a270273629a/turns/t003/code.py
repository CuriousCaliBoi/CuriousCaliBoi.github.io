import math
import time

A, B = Checkpoint("A"), Checkpoint("B")
L = A.config["num_hidden_layers"]

def rowdot(x, y):
    return np.einsum("ij,ij->i", x, y, dtype=np.float64)

def unit_path_stats(a, b):
    """
    Each tuple contains per-unit rows (d, g, u).
    Compare T_i = d_i tensor sym(g_i tensor u_i).
    The input-index symmetrization accounts for exchanging gate/up
    in this weight product. It does NOT make their nonlinear roles equivalent.

    No large third-order tensors are constructed.
    """
    da, ga, ua = a
    db, gb, ub = b

    aa = rowdot(da, da) * (
        rowdot(ga, ga) * rowdot(ua, ua) + rowdot(ga, ua)**2
    ) / 2
    bb = rowdot(db, db) * (
        rowdot(gb, gb) * rowdot(ub, ub) + rowdot(gb, ub)**2
    ) / 2
    ab = rowdot(da, db) * (
        rowdot(ga, gb) * rowdot(ua, ub)
        + rowdot(ga, ub) * rowdot(ua, gb)
    ) / 2

    delta2 = np.maximum(aa + bb - 2 * ab, 0)
    baseline2 = (aa + bb) / 2
    relative = np.sqrt(delta2 / np.maximum(baseline2, 1e-300))
    return delta2, baseline2, relative

def spectral_stats(delta):
    # Exact eigendecomposition of the smaller Gram matrix.
    x = delta.astype(np.float64)
    gram = x.T @ x if x.shape[0] >= x.shape[1] else x @ x.T
    ev = np.maximum(np.linalg.eigvalsh(gram), 0)[::-1]
    total = float(ev.sum())
    if total == 0:
        return (0.0, 0.0, 0.0)
    top1 = float(ev[0] / total)
    top8 = float(ev[:8].sum() / total)
    participation = total**2 / float(np.sum(ev**2))
    return top1, top8, participation

layer_rows = []
unit_rows = []
spectra = []
start = time.time()

print("MLP unit coefficient:")
print("  T_i = d_i tensor (g_i tensor u_i + u_i tensor g_i)/2")
print("This is a weight-interaction descriptor, not the nonlinear unit's output.")
print("Folded version incorporates pre-FF and post-FF learned norm gains only.")
print("Root-sum unit scores omit interference BETWEEN different units.")
print("Spectra below concern B-A projection matrices, not activations.\n")

for layer in range(L):
    p = f"model.layers.{layer}."
    weights = []
    for C in (A, B):
        d = C.get(p + "mlp.down_proj.weight").T.astype(np.float64)
        g = C.get(p + "mlp.gate_proj.weight").astype(np.float64)
        u = C.get(p + "mlp.up_proj.weight").astype(np.float64)
        pre = 1.0 + C.get(p + "pre_feedforward_layernorm.weight").astype(np.float64)
        post = 1.0 + C.get(p + "post_feedforward_layernorm.weight").astype(np.float64)
        weights.append((d, g, u, pre, post))

    raw_a, raw_b = weights[0][:3], weights[1][:3]
    raw_delta2, raw_base2, raw_rel = unit_path_stats(raw_a, raw_b)

    folded = []
    for d, g, u, pre, post in weights:
        folded.append((d * post[None, :],
                       g * pre[None, :],
                       u * pre[None, :]))
    fold_delta2, fold_base2, fold_rel = unit_path_stats(*folded)

    raw_total_delta = float(raw_delta2.sum())
    fold_total_delta = float(fold_delta2.sum())
    raw_total_base = float(raw_base2.sum())
    fold_total_base = float(fold_base2.sum())

    order = np.argsort(fold_delta2)[::-1]
    layer_rows.append({
        "layer": layer,
        "raw_rel": math.sqrt(raw_total_delta / max(raw_total_base, 1e-300)),
        "fold_rel": math.sqrt(fold_total_delta / max(fold_total_base, 1e-300)),
        "top1": float(fold_delta2[order[:1]].sum() / max(fold_total_delta, 1e-300)),
        "top10": float(fold_delta2[order[:10]].sum() / max(fold_total_delta, 1e-300)),
        "top_units": order[:5].tolist()
    })

    for i in range(len(fold_delta2)):
        unit_rows.append({
            "layer": layer, "unit": i,
            # Contribution normalized to the layer's baseline descriptor energy.
            "score": math.sqrt(float(fold_delta2[i]) / max(fold_total_base, 1e-300)),
            "fraction": float(fold_delta2[i]) / max(fold_total_delta, 1e-300),
            "raw_rel": float(raw_rel[i]),
            "fold_rel": float(fold_rel[i]),
            "raw_score": math.sqrt(float(raw_delta2[i]) / max(raw_total_base, 1e-300)),
        })

    for j, name in enumerate(("down", "gate", "up")):
        delta = weights[1][j] - weights[0][j]
        top1, top8, pr = spectral_stats(delta)
        spectra.append((layer, name, top1, top8, pr))

    del weights, folded, raw_a, raw_b

print("=== PER-LAYER MLP WEIGHT-INTERACTION COMPARISON ===")
print("layer  raw_rel  folded_rel  top1_delta_share  top10_delta_share  top5_units")
for r in layer_rows:
    print(f"{r['layer']:5d} {r['raw_rel']:9.6f} {r['fold_rel']:11.6f} "
          f"{r['top1']:17.5%} {r['top10']:18.5%} {r['top_units']}")

print("\n=== TOP 25 UNITS BY LAYER-NORMALIZED FOLDED DESCRIPTOR CHANGE ===")
for r in sorted(unit_rows, key=lambda z: z["score"], reverse=True)[:25]:
    print(f"L{r['layer']:02d} unit {r['unit']:4d}: "
          f"score={r['score']:.6g}, layer_delta_share={r['fraction']:.5%}, "
          f"unit_rel_raw={r['raw_rel']:.6g}, unit_rel_folded={r['fold_rel']:.6g}")

print("\n=== PROJECTION DELTA SPECTRA ===")
print("layer projection top1_energy top8_energy participation_rank")
for layer, name, top1, top8, pr in spectra:
    print(f"{layer:5d} {name:>10s} {top1:11.5%} {top8:11.5%} {pr:18.2f}")

raw_order = sorted(unit_rows, key=lambda z: z["raw_score"], reverse=True)[:25]
fold_order = sorted(unit_rows, key=lambda z: z["score"], reverse=True)[:25]
raw_set = {(r["layer"], r["unit"]) for r in raw_order}
fold_set = {(r["layer"], r["unit"]) for r in fold_order}
print("\nTop-25 raw/folded unit overlap:", len(raw_set & fold_set))
print("Elapsed seconds:", round(time.time() - start, 2))

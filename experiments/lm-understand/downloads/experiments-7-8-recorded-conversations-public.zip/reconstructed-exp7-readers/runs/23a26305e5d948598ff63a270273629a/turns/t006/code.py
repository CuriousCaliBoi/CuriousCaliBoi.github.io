import math
import time

A, B = Checkpoint("A"), Checkpoint("B")
L = A.config["num_hidden_layers"]

selected = {
    0: [1352, 1405, 1262],
    1: [1598],
    4: [1527, 200, 84, 388, 736],
    10: [1363, 1564, 1529, 1869],
    14: [641],
    17: [1026, 1916, 1650],
}

def weights(C, layer):
    p = f"model.layers.{layer}."
    d = C.get(p + "mlp.down_proj.weight").T.astype(np.float64)
    g = C.get(p + "mlp.gate_proj.weight").astype(np.float64)
    u = C.get(p + "mlp.up_proj.weight").astype(np.float64)
    pre = 1 + C.get(p + "pre_feedforward_layernorm.weight").astype(np.float64)
    post = 1 + C.get(p + "post_feedforward_layernorm.weight").astype(np.float64)
    return d * post[None, :], g * pre[None, :], u * pre[None, :]

def tensor_inner_rows(a, b):
    """Row i is <T_i(a), SUM_j T_j(b)>; uses only weight products."""
    d, g, u = a
    e, h, v = b
    z = (g @ h.T) * (u @ v.T)
    z += (g @ v.T) * (u @ h.T)
    z *= d @ e.T
    return z.sum(axis=1) * 0.5

def rowdot(a, b):
    return np.einsum("ij,ij->i", a, b)

def same_unit_inner(a, b):
    d, g, u = a
    e, h, v = b
    return rowdot(d, e) * (
        rowdot(g, h)*rowdot(u, v) + rowdot(g, v)*rowdot(u, h)
    ) * 0.5

def vector_stats(a, b):
    na, nb = np.linalg.norm(a), np.linalg.norm(b)
    den = math.sqrt((na*na + nb*nb)/2)
    rel = float(np.linalg.norm(b-a) / max(den, 1e-300))
    cosine = float(a @ b) / max(float(na*nb), 1e-300)
    angle = math.degrees(math.acos(float(np.clip(cosine, -1, 1))))
    ratio = float(nb / max(na, 1e-300))
    return rel, angle, ratio

global_rows, detailed = [], []
start = time.time()

print("Exact decomposition of the summed symmetrized coefficient tensor:")
print("Delta T = T(Delta d, gmid, umid) + T(dmid, Delta g, umid)")
print("        + T(dmid, gmid, Delta u) + 1/4*T(Delta d, Delta g, Delta u).")
print("All factors include learned pre/post-FF norm gains, not RMS denominators.")
print("Shares below concern this coefficient difference, not task performance.\n")

for layer in range(L):
    a, b = weights(A, layer), weights(B, layer)
    mid = tuple((x+y)/2 for x, y in zip(a, b))
    dif = tuple(y-x for x, y in zip(a, b))
    dm, gm, um = mid
    dd, dg, du = dif

    terms = [
        ((dd, gm, um), 1.0),
        ((dm, dg, um), 1.0),
        ((dm, gm, du), 1.0),
        ((dd, dg, du), 0.25),
    ]

    global_unit_contrib = []
    local_unit_contrib = []
    for term, factor in terms:
        global_unit_contrib.append(factor * (
            tensor_inner_rows(term, b) - tensor_inner_rows(term, a)
        ))
        local_unit_contrib.append(factor * (
            same_unit_inner(term, b) - same_unit_inner(term, a)
        ))

    global_unit_contrib = np.stack(global_unit_contrib)
    local_unit_contrib = np.stack(local_unit_contrib)
    global_parts = global_unit_contrib.sum(axis=1)
    total_delta2 = float(global_parts.sum())
    global_rows.append((layer, global_parts / max(total_delta2, 1e-300)))

    if layer in selected:
        for unit in selected[layer]:
            loc = local_unit_contrib[:, unit]
            local_delta2 = float(loc.sum())
            unit_contribution = float(global_unit_contrib[:, unit].sum())
            stats = [vector_stats(a[j][unit], b[j][unit]) for j in range(3)]
            detailed.append({
                "layer": layer, "unit": unit,
                "shares": loc / max(local_delta2, 1e-300),
                "global_share": unit_contribution / max(total_delta2, 1e-300),
                "stats": stats
            })

    del a, b, mid, dif, terms

print("=== WHOLE-LAYER DECOMPOSITION, INCLUDING CROSS-UNIT INTERACTIONS ===")
print("layer down_write_share gate_share up_share cubic_cross_share")
for layer, s in global_rows:
    print(f"{layer:5d} {s[0]:16.5f} {s[1]:10.5f} {s[2]:8.5f} {s[3]:17.8f}")

print("\n=== SELECTED UNITS: DECOMPOSITION OF EACH UNIT'S OWN DIFFERENCE ===")
print(" L unit global_delta_share down_share gate_share up_share cubic_share")
for r in detailed:
    s = r["shares"]
    print(f"{r['layer']:2d} {r['unit']:4d} {r['global_share']:18.5%} "
          f"{s[0]:10.5f} {s[1]:10.5f} {s[2]:8.5f} {s[3]:11.8f}")

print("\n=== ACTUAL GAIN-FOLDED WEIGHT VECTOR CHANGES ===")
print("Each tuple is (relative difference, angle in degrees, norm_B/norm_A).")
for r in detailed:
    ds, gs, us = r["stats"]
    fmt = lambda s: f"({s[0]:.5f}, {s[1]:.4f}, {s[2]:.6f})"
    print(f"L{r['layer']:02d} unit {r['unit']:4d}: "
          f"down={fmt(ds)} gate={fmt(gs)} up={fmt(us)}")

print("\nNegative shares, if present, indicate algebraic opposition between terms.")
print("Gate-vector changes do not reveal when a unit's nonlinear gate is active.")
print("Elapsed seconds:", round(time.time() - start, 2))

import math
import time

A, B = Checkpoint("A"), Checkpoint("B")
cfg = A.config
L, H, D = cfg["num_hidden_layers"], cfg["num_attention_heads"], cfg["head_dim"]
rank = 8

def load_layer(C, layer, folded):
    p = f"model.layers.{layer}."
    def w(name):
        return C.get(p + name).astype(np.float64)

    q = w("self_attn.q_proj.weight").reshape(H, D, -1)
    k = w("self_attn.k_proj.weight")
    v = w("self_attn.v_proj.weight")
    o = w("self_attn.o_proj.weight")
    down = w("mlp.down_proj.weight")
    gate = w("mlp.gate_proj.weight")
    up = w("mlp.up_proj.weight")

    if folded:
        ai = 1 + w("input_layernorm.weight")
        ao = 1 + w("post_attention_layernorm.weight")
        mi = 1 + w("pre_feedforward_layernorm.weight")
        mo = 1 + w("post_feedforward_layernorm.weight")
        qg = 1 + w("self_attn.q_norm.weight")
        kg = 1 + w("self_attn.k_norm.weight")
        q *= ai[None, None, :] * qg[None, :, None]
        k *= ai[None, :] * kg[:, None]
        v *= ai[None, :]
        o *= ao[:, None]
        down *= mo[:, None]
        gate *= mi[None, :]
        up *= mi[None, :]
    return q, k, v, o, down, gate, up

def subspace(matrix, output_side):
    gram = matrix @ matrix.T if output_side else matrix.T @ matrix
    ev, vec = np.linalg.eigh(gram)
    ev = np.maximum(ev, 0)
    basis = vec[:, -rank:]
    diagonal = np.sum(basis*basis, axis=1)
    return {
        "basis": basis,
        "diag": diagonal,
        "capture": float(ev[-rank:].sum() / max(ev.sum(), 1e-300)),
        "max_diag": float(diagonal.max())
    }

def describe(key):
    kind, layer, head = key
    if head is None:
        return f"L{layer:02d}:{kind}"
    return f"L{layer:02d}:{kind}:H{head}"

def stage(key):
    kind, layer, head = key
    return 2*layer + (1 if kind == "mlp" else 0)

def overlap(a, b):
    cross = a["basis"].T @ b["basis"]
    observed = float(np.sum(cross*cross)) / rank
    # Exact expectation under independent +/- coordinate signs on one subspace.
    # The sign-randomized basis remains orthonormal. No random trials are run.
    coordinate_baseline = float(a["diag"] @ b["diag"]) / rank
    return observed, coordinate_baseline, observed-coordinate_baseline

banks = {}
graphs = {}
start = time.time()

print("Leading-8-dimensional residual subspaces of parameter differences.")
print("Writers: attention OV products and MLP down projections.")
print("Readers: attention Q/K projections and combined MLP gate/up projections.")
print("Links are restricted to downstream components at most two layers away.")
print("They represent static compatibility, not demonstrated signal propagation.\n")

for folded in (False, True):
    writers, readers = {}, {}
    for layer in range(L):
        a, b = load_layer(A, layer, folded), load_layer(B, layer, folded)
        qa, ka, va, oa, da, ga, ua = a
        qb, kb, vb, ob, db, gb, ub = b

        writers[("mlp", layer, None)] = subspace(db-da, True)
        readers[("mlp", layer, None)] = subspace(
            np.concatenate((gb-ga, ub-ua), axis=0), False)
        readers[("key", layer, None)] = subspace(kb-ka, False)

        for head in range(H):
            sl = slice(head*D, (head+1)*D)
            ov_delta = ob[:, sl] @ vb - oa[:, sl] @ va
            writers[("attention", layer, head)] = subspace(ov_delta, True)
            readers[("query", layer, head)] = subspace(qb[head]-qa[head], False)

    graph = {}
    for wk, ws in writers.items():
        for rk, rs in readers.items():
            if stage(rk) <= stage(wk):
                continue
            if not 0 <= rk[1]-wk[1] <= 2:
                continue
            graph[(wk, rk)] = overlap(ws, rs)

    banks[folded] = (writers, readers)
    graphs[folded] = graph

print("=== TOP 20 GAIN-FOLDED LINKS BY OVERLAP ABOVE COORDINATE BASELINE ===")
print("source -> target | folded_overlap baseline excess | raw_overlap raw_excess")
ordered = sorted(graphs[True], key=lambda e: graphs[True][e][2], reverse=True)
for edge in ordered[:20]:
    observed, baseline, excess = graphs[True][edge]
    raw_observed, raw_baseline, raw_excess = graphs[False][edge]
    print(f"{describe(edge[0]):20s} -> {describe(edge[1]):18s} | "
          f"{observed:.5f} {baseline:.5f} {excess:+.5f} | "
          f"{raw_observed:.5f} {raw_excess:+.5f}")

print("\n=== TOP 12 RAW LINKS BY EXCESS, WITH FOLDED CHECK ===")
raw_ordered = sorted(graphs[False], key=lambda e: graphs[False][e][2], reverse=True)
for edge in raw_ordered[:12]:
    ro, rb, re = graphs[False][edge]
    fo, fb, fe = graphs[True][edge]
    print(f"{describe(edge[0]):20s} -> {describe(edge[1]):18s} | "
          f"raw={ro:.5f}, raw_excess={re:+.5f}, "
          f"folded={fo:.5f}, folded_excess={fe:+.5f}")

print("\n=== PREDECLARED CANDIDATE CONNECTIONS ===")
edges = [
    (("mlp", 10, None), ("key", 11, None)),
    (("mlp", 10, None), ("query", 11, 0)),
    (("mlp", 10, None), ("query", 11, 1)),
    (("attention", 4, 0), ("mlp", 4, None)),
    (("attention", 4, 1), ("mlp", 4, None)),
    (("attention", 4, 2), ("mlp", 4, None)),
    (("attention", 11, 1), ("mlp", 12, None)),
    (("attention", 11, 0), ("query", 12, 2)),
]
for edge in edges:
    fo, fb, fe = graphs[True][edge]
    ro, rb, re = graphs[False][edge]
    print(f"{describe(edge[0])} -> {describe(edge[1])}: "
          f"folded={fo:.5f}, baseline={fb:.5f}, excess={fe:+.5f}; "
          f"raw={ro:.5f}, raw_excess={re:+.5f}")

print("\n=== SELECTED SUBSPACE ENERGY CAPTURE AND COORDINATE CONCENTRATION ===")
for which, key in [
    (0, ("mlp", 10, None)),
    (0, ("mlp", 17, None)),
    (0, ("attention", 4, 1)),
    (0, ("attention", 11, 1)),
    (1, ("key", 11, None)),
    (1, ("query", 12, 2)),
    (1, ("mlp", 4, None)),
]:
    raw = banks[False][which][key]
    folded = banks[True][which][key]
    print(f"{'writer' if which == 0 else 'reader'} {describe(key):20s}: "
          f"raw_top8_energy={raw['capture']:.5%}, "
          f"folded_top8_energy={folded['capture']:.5%}, "
          f"raw_max_coordinate_leverage={raw['max_diag']:.5f}, "
          f"folded_max_coordinate_leverage={folded['max_diag']:.5f}")

print("\nTop-20 raw/folded excess-link overlap:",
      len(set(ordered[:20]) & set(raw_ordered[:20])))
print("The coordinate baseline is an algebraic control, not a significance p-value.")
print("Elapsed seconds:", round(time.time() - start, 2))

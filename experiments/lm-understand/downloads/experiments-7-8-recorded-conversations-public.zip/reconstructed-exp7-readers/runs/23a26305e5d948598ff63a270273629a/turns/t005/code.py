import math
import time

A, B = Checkpoint("A"), Checkpoint("B")
cfg = A.config
L, H, D = (cfg["num_hidden_layers"],
           cfg["num_attention_heads"], cfg["head_dim"])
assert cfg["num_key_value_heads"] == 1
assert D % 2 == 0

def dot(a, b):
    return float(np.sum(a * b, dtype=np.float64))

def norm(a):
    return math.sqrt(max(dot(a, a), 0))

def rel(a, b):
    den = math.sqrt((dot(a, a) + dot(b, b)) / 2)
    return norm(b - a) / max(den, 1e-300)

def rotate_weight_rows(w, displacement, theta):
    """
    Apply the architecture's rotary matrix to a WEIGHT MATRIX.
    Columns remain residual-coordinate coefficients, not input vectors.
    """
    half = D // 2
    freq = theta ** (-np.arange(0, D, 2, dtype=np.float64) / D)
    angle = displacement * freq
    c, s = np.cos(angle)[:, None], np.sin(angle)[:, None]
    return np.concatenate((c*w[:half] - s*w[half:],
                           s*w[:half] + c*w[half:]), axis=0)

def get(C, layer):
    p = f"model.layers.{layer}."
    def w(s):
        return C.get(p + s).astype(np.float64)
    din = 1 + w("input_layernorm.weight")
    dout = 1 + w("post_attention_layernorm.weight")
    qg = 1 + w("self_attn.q_norm.weight")
    kg = 1 + w("self_attn.k_norm.weight")
    q = w("self_attn.q_proj.weight").reshape(H, D, -1)
    k = w("self_attn.k_proj.weight")
    v = w("self_attn.v_proj.weight")
    o = w("self_attn.o_proj.weight")
    return {
        "Qden_factor": q * din[None, None, :],
        "Kden_factor": k * din[None, :],
        "Q": q * din[None, None, :] * qg[None, :, None],
        "K": k * din[None, :] * kg[:, None],
        "O": o * dout[:, None],
        "V": v * din[None, :]
    }

def decomposition(xa, xb, ya, yb):
    # For a product X @ Y:
    # B-A = (XB-XA) @ Ymid + Xmid @ (YB-YA), exactly.
    dx, dy = xb-xa, yb-ya
    xm, ym = (xa+xb)/2, (ya+yb)/2
    left, right = dx @ ym, xm @ dy
    delta = left + right
    e = dot(delta, delta)
    return {
        "left_share": dot(left, delta)/max(e, 1e-300),
        "right_share": dot(right, delta)/max(e, 1e-300),
        "term_cos": dot(left, right)/max(norm(left)*norm(right), 1e-300),
        "closure": norm(delta - (xb@yb - xa@ya))
                   / max(norm(delta), 1e-300),
    }

rows = []
start = time.time()

print("QK numerator coefficient at displacement r: Xq.T @ R(r) @ Xk.")
print("No positional sequence, hidden state, softmax, or RMS evaluation is used.")
print("Denominator descriptors are (Q Din).T@(Q Din) and (K Din).T@(K Din).")
print("Their relative changes are not actual changes in normalization on a prompt.\n")

for layer in range(L):
    aa, bb = get(A, layer), get(B, layer)
    typ = cfg["layer_types"][layer]
    theta = cfg["rope_parameters"][typ]["rope_theta"]
    offsets = [0, 1, 8, 32, 128, 511]
    if typ == "full_attention":
        offsets += [2048, 8192]

    kd_a = aa["Kden_factor"].T @ aa["Kden_factor"]
    kd_b = bb["Kden_factor"].T @ bb["Kden_factor"]
    kden_rel = rel(kd_a, kd_b)

    rotated_a = {r: rotate_weight_rows(aa["K"], r, theta) for r in offsets}
    rotated_b = {r: rotate_weight_rows(bb["K"], r, theta) for r in offsets}

    for head in range(H):
        qa, qb = aa["Q"][head], bb["Q"][head]
        changes = []
        for r in offsets:
            ma = qa.T @ rotated_a[r]
            mb = qb.T @ rotated_b[r]
            changes.append(rel(ma, mb))

        qda = aa["Qden_factor"][head]
        qdb = bb["Qden_factor"][head]
        qden_rel = rel(qda.T @ qda, qdb.T @ qdb)
        qk_parts = decomposition(qa.T, qb.T, aa["K"], bb["K"])

        sl = slice(head*D, (head+1)*D)
        oa, ob = aa["O"][:, sl], bb["O"][:, sl]
        ov_parts = decomposition(oa, ob, aa["V"], bb["V"])
        ov_rel = rel(oa @ aa["V"], ob @ bb["V"])

        rows.append({
            "layer": layer, "head": head,
            "offsets": offsets, "changes": changes,
            "qk_min": min(changes), "qk_med": float(np.median(changes)),
            "qk_max": max(changes), "qden": qden_rel, "kden": kden_rel,
            "ov_rel": ov_rel,
            "q_share": qk_parts["left_share"],
            "k_share": qk_parts["right_share"],
            "qk_cos": qk_parts["term_cos"],
            "o_share": ov_parts["left_share"],
            "v_share": ov_parts["right_share"],
            "ov_cos": ov_parts["term_cos"],
            "closure": max(qk_parts["closure"], ov_parts["closure"])
        })

print("=== TOP 15 HEADS BY MEDIAN ROTARY QK RELATIVE DIFFERENCE ===")
print(" L  H    minimum    median   maximum  Qden_rel  Kden_rel  Qshare  Kshare")
for r in sorted(rows, key=lambda z: z["qk_med"], reverse=True)[:15]:
    print(f"{r['layer']:2d} {r['head']:2d} "
          f"{r['qk_min']:10.6f} {r['qk_med']:9.6f} {r['qk_max']:9.6f} "
          f"{r['qden']:9.6f} {r['kden']:9.6f} "
          f"{r['q_share']:7.3f} {r['k_share']:7.3f}")

print("\n=== TOP 12 OV HEADS: SOURCE OF COMPOSED DIFFERENCE ===")
print(" L  H   OV_rel  Oside_share Vside_share cosine_between_terms")
for r in sorted(rows, key=lambda z: z["ov_rel"], reverse=True)[:12]:
    print(f"{r['layer']:2d} {r['head']:2d} {r['ov_rel']:9.6f} "
          f"{r['o_share']:11.4f} {r['v_share']:11.4f} {r['ov_cos']:20.5f}")

print("\n=== ROTARY PROFILE OF PREVIOUS LEADING QK CANDIDATES ===")
selected = {(11,0), (11,1), (12,2), (10,1), (12,3), (11,3), (17,1)}
for r in rows:
    if (r["layer"], r["head"]) in selected:
        pairs = ", ".join(f"{p}:{v:.5f}"
                          for p, v in zip(r["offsets"], r["changes"]))
        print(f"L{r['layer']:02d} H{r['head']}: {pairs}")

print("\nShares are signed algebraic contributions and sum to 1 for each decomposition.")
print("Qside includes its learned gain/input scaling; Kside is shared by four heads.")
print("Oside includes post-attention gain; Vside includes shared V and input gain.")
print("Maximum exact-product decomposition relative error:",
      max(r["closure"] for r in rows))
print("Elapsed seconds:", round(time.time() - start, 2))

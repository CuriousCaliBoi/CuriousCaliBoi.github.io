import math
import time

A, B = Checkpoint("A"), Checkpoint("B")
L = A.config["num_hidden_layers"]

def get_weights(C, layer, folded):
    p = f"model.layers.{layer}."
    d = C.get(p + "mlp.down_proj.weight").T.astype(np.float64)
    g = C.get(p + "mlp.gate_proj.weight").astype(np.float64)
    u = C.get(p + "mlp.up_proj.weight").astype(np.float64)
    if folded:
        pre = 1.0 + C.get(p + "pre_feedforward_layernorm.weight").astype(np.float64)
        post = 1.0 + C.get(p + "post_feedforward_layernorm.weight").astype(np.float64)
        d *= post[None, :]
        g *= pre[None, :]
        u *= pre[None, :]
    return d, g, u

def coefficient_gram(a, b):
    """
    Entry (i,j) = <T_i(a), T_j(b)> exactly, where
    T_i = d_i tensor sym(g_i tensor u_i).
    Only weight-matrix products are used.
    """
    d, g, u = a
    e, h, v = b
    dd = d @ e.T
    interaction = (g @ h.T) * (u @ v.T)
    interaction += (g @ v.T) * (u @ h.T)
    interaction *= dd
    interaction *= 0.5
    return interaction

results = []
candidates = []
t0 = time.time()

print("Comparing SUM_i T_i, including cross-unit reinforcement/cancellation.")
print("Signed unit contribution = <T_i(B)-T_i(A), SUM_j[T_j(B)-T_j(A)]>.")
print("Contributions sum to the squared norm of the combined coefficient difference.")
print("These are contributions to a weight descriptor, NOT causal behavior scores.\n")

for layer in range(L):
    entry = {"layer": layer}
    for folded in (False, True):
        aa = get_weights(A, layer, folded)
        bb = get_weights(B, layer, folded)

        gaa = coefficient_gram(aa, aa)
        gbb = coefficient_gram(bb, bb)
        gab = coefficient_gram(aa, bb)

        norm_a2 = float(gaa.sum())
        norm_b2 = float(gbb.sum())
        baseline2 = (norm_a2 + norm_b2) / 2

        signed = (
            gaa.sum(axis=1) + gbb.sum(axis=1)
            - gab.sum(axis=1) - gab.sum(axis=0)
        )
        delta2 = float(signed.sum())
        individual_delta2 = np.maximum(
            np.diag(gaa) + np.diag(gbb) - 2*np.diag(gab), 0
        )
        root_sum_delta2 = float(individual_delta2.sum())

        if delta2 < -1e-8 * max(baseline2, 1):
            raise ArithmeticError("Unexpected negative squared norm.")
        delta2 = max(delta2, 0.0)

        order = np.argsort(signed)[::-1]
        tag = "fold" if folded else "raw"
        entry[tag + "_relative"] = math.sqrt(delta2 / max(baseline2, 1e-300))
        entry[tag + "_reinforcement"] = delta2 / max(root_sum_delta2, 1e-300)
        entry[tag + "_negative"] = int(np.count_nonzero(signed < 0))
        entry[tag + "_top"] = order[:5].tolist()
        entry[tag + "_norm_ratio"] = math.sqrt(
            max(norm_b2, 0) / max(norm_a2, 1e-300)
        )

        if folded:
            for i in range(len(signed)):
                candidates.append({
                    "layer": layer,
                    "unit": i,
                    "signed_score": float(signed[i]) / max(baseline2, 1e-300),
                    "share": float(signed[i]) / max(delta2, 1e-300),
                    "own_share": float(individual_delta2[i])
                                 / max(root_sum_delta2, 1e-300),
                })

        del aa, bb, gaa, gbb, gab

    results.append(entry)

print("=== COMBINED MLP COEFFICIENT DIFFERENCES ===")
print("Reinf = combined delta energy / sum of individual-unit delta energies.")
print("It can be above or below 1; it is not a behavioral amplification factor.")
print("layer raw_rel fold_rel raw_reinf fold_reinf neg_units_fold fold_norm_B/A")
for r in results:
    print(f"{r['layer']:5d} "
          f"{r['raw_relative']:8.5f} {r['fold_relative']:8.5f} "
          f"{r['raw_reinforcement']:9.4f} {r['fold_reinforcement']:10.4f} "
          f"{r['fold_negative']:14d} {r['fold_norm_ratio']:13.7f}")

print("\n=== LEADING UNITS WITH CROSS-UNIT INTERACTIONS INCLUDED ===")
for r in results:
    print(f"L{r['layer']:02d}: raw {r['raw_top']}; folded {r['fold_top']}")

print("\n=== TOP 25 POSITIVE UNIT CONTRIBUTIONS, LAYER-BASELINE NORMALIZED ===")
for r in sorted(candidates, key=lambda z: z["signed_score"], reverse=True)[:25]:
    print(f"L{r['layer']:02d} unit {r['unit']:4d}: "
          f"normalized_contribution={r['signed_score']:.7g}, "
          f"combined_delta_share={r['share']:.5%}, "
          f"individual_delta_share={r['own_share']:.5%}")

print("\n=== TOP 8 NEGATIVE UNIT CONTRIBUTIONS ===")
for r in sorted(candidates, key=lambda z: z["signed_score"])[:8]:
    print(f"L{r['layer']:02d} unit {r['unit']:4d}: "
          f"normalized_contribution={r['signed_score']:.7g}, "
          f"combined_delta_share={r['share']:.5%}")

print("\nElapsed seconds:", round(time.time() - t0, 2))

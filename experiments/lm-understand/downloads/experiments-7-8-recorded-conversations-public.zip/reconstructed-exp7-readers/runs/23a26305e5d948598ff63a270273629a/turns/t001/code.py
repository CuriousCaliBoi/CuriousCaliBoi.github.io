import collections
import math

A, B = Checkpoint("A"), Checkpoint("B")

print("=== CONFIGURATION ===")
print("A:", json.dumps(A.config, sort_keys=True, indent=2))
print("B configuration identical:", A.config == B.config)
if A.config != B.config:
    for k in sorted(set(A.config) | set(B.config)):
        if A.config.get(k) != B.config.get(k):
            print("CONFIG DIFFERENCE:", k, A.config.get(k), B.config.get(k))

ka, kb = set(A.keys()), set(B.keys())
print("\n=== TENSOR INVENTORY ===")
print("Tensor counts:", len(ka), len(kb))
print("Only in A:", sorted(ka - kb))
print("Only in B:", sorted(kb - ka))
print("Dtypes A:", dict(collections.Counter(v["dtype"] for v in A.info.values())))
print("Dtypes B:", dict(collections.Counter(v["dtype"] for v in B.info.values())))

shared = sorted(ka & kb)
bad_shapes = [(k, A.shape(k), B.shape(k))
              for k in shared if A.shape(k) != B.shape(k)]
print("Shape mismatches:", bad_shapes)
if bad_shapes:
    raise ValueError("Cannot compare tensors with different shapes.")

families = collections.defaultdict(set)
for k in shared:
    family = re.sub(r"layers\.\d+\.", "layers.*.", k)
    families[family].add(A.shape(k))

print("\nTensor families and shapes:")
for family, shapes in sorted(families.items()):
    count = sum(re.sub(r"layers\.\d+\.", "layers.*.", k) == family
                for k in shared)
    print(f"  {family}: count={count}, shapes={sorted(shapes)}")

print("\n=== EXACT ELEMENTWISE AND FROBENIUS COMPARISONS ===")
print("Relative difference = ||B-A|| / sqrt((||A||^2 + ||B||^2)/2).")
print("These are structural differences, NOT behavioral importance scores.")

rows = []
by_layer = collections.defaultdict(lambda: np.zeros(5, dtype=np.float64))
by_family = collections.defaultdict(lambda: np.zeros(5, dtype=np.float64))
total = np.zeros(5, dtype=np.float64)

for k in shared:
    a, b = A.get(k), B.get(k)
    d = b - a
    sa = float(np.sum(a * a, dtype=np.float64))
    sb = float(np.sum(b * b, dtype=np.float64))
    sd = float(np.sum(d * d, dtype=np.float64))
    changed = int(np.count_nonzero(d))
    n = a.size
    denom = math.sqrt((sa + sb) / 2)
    rel = math.sqrt(sd) / denom if denom else 0.0
    rows.append({
        "name": k, "sa": sa, "sb": sb, "sd": sd,
        "changed": changed, "n": n, "rel": rel
    })

    m = re.search(r"(?:^|\.)layers\.(\d+)\.", k)
    layer = int(m.group(1)) if m else -1
    family = re.sub(r"layers\.\d+\.", "layers.*.", k)
    stats = np.array([sa, sb, sd, changed, n], dtype=np.float64)
    by_layer[layer] += stats
    by_family[family] += stats
    total += stats
    del a, b, d

def summarize(stats):
    sa, sb, sd, changed, n = stats
    denom = math.sqrt((sa + sb) / 2)
    rel = math.sqrt(sd) / denom if denom else 0.0
    return (
        f"n={int(n):>10,d} changed={changed/max(n,1):.5%} "
        f"norm_A={math.sqrt(sa):.6g} norm_B={math.sqrt(sb):.6g} "
        f"delta_norm={math.sqrt(sd):.6g} relative_delta={rel:.6g}"
    )

print("\nTOTAL:", summarize(total))
print("Exactly identical tensors:", sum(r["changed"] == 0 for r in rows),
      "of", len(rows))

print("\nBy layer (-1 denotes tensors outside decoder layers):")
for layer, stats in sorted(by_layer.items()):
    print(f"  layer {layer:2d}: {summarize(stats)}")

print("\nBy tensor family:")
for family, stats in sorted(by_family.items()):
    print(f"  {family}: {summarize(stats)}")

print("\nTop 20 tensors by absolute delta norm:")
for r in sorted(rows, key=lambda r: r["sd"], reverse=True)[:20]:
    print(f"  {r['name']}: delta={math.sqrt(r['sd']):.6g}, "
          f"relative={r['rel']:.6g}, changed={r['changed']/r['n']:.5%}")

print("\nTop 20 tensors by relative delta norm:")
for r in sorted(rows, key=lambda r: r["rel"], reverse=True)[:20]:
    print(f"  {r['name']}: relative={r['rel']:.6g}, "
          f"delta={math.sqrt(r['sd']):.6g}, changed={r['changed']/r['n']:.5%}")

print("\nNon-layer tensors:")
for r in rows:
    if not re.search(r"(?:^|\.)layers\.\d+\.", r["name"]):
        print(f"  {r['name']}: shape={A.shape(r['name'])}, "
              f"relative={r['rel']:.6g}, delta={math.sqrt(r['sd']):.6g}")

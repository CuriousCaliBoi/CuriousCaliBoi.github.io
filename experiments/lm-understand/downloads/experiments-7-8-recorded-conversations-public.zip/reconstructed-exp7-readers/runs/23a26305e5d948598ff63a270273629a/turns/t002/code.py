import math
import time

A, B = Checkpoint("A"), Checkpoint("B")
cfg = A.config
L = cfg["num_hidden_layers"]
H = cfg["num_attention_heads"]
KV = cfg["num_key_value_heads"]
D = cfg["head_dim"]
R = cfg["hidden_size"]

assert KV == 1, "This implementation assumes the observed single shared KV head."
assert H * D == A.shape("model.layers.0.self_attn.q_proj.weight")[0]

def fro(x):
    return math.sqrt(float(np.sum(x * x, dtype=np.float64)))

def relative_delta(a, b):
    na, nb, nd = fro(a), fro(b), fro(b - a)
    den = math.sqrt((na * na + nb * nb) / 2)
    return nd / den if den else 0.0, nd, na, nb

def identity_alignment(m):
    # A matrix-only diagnostic, NOT evidence of copying tokens or guesses.
    den = fro(m) * math.sqrt(m.shape[0])
    return float(np.trace(m, dtype=np.float64)) / den if den else 0.0

def get_layer(C, layer):
    p = f"model.layers.{layer}."
    return {
        "Q": C.get(p + "self_attn.q_proj.weight"),
        "K": C.get(p + "self_attn.k_proj.weight"),
        "V": C.get(p + "self_attn.v_proj.weight"),
        "O": C.get(p + "self_attn.o_proj.weight"),
        # Gemma RMSNorm uses multiplicative gain (1 + stored weight).
        # Only that learned diagonal is used; no hidden-state RMS is computed.
        "in_gain": 1.0 + C.get(p + "input_layernorm.weight"),
        "out_gain": 1.0 + C.get(p + "post_attention_layernorm.weight"),
        "q_gain": 1.0 + C.get(p + "self_attn.q_norm.weight"),
        "k_gain": 1.0 + C.get(p + "self_attn.k_norm.weight"),
    }

rows = []
t0 = time.time()

print("Definitions:")
print("QK_proj = Q_h.T @ K; this omits rotary displacement and all normalization.")
print("QK_gain = Din @ Q_h.T @ Dq @ Dk @ K @ Din.")
print("OV_proj = O_h @ V.")
print("OV_gain = Dout @ O_h @ V @ Din.")
print("Din,Dout,Dq,Dk contain 1 + the respective stored Gemma norm weights.")
print("QK_gain describes the zero-rotary-displacement numerator coefficient only.")
print("Input-dependent RMS denominators and attention weights are NOT evaluated.")
print("OV_gain also omits the post-attention RMS denominator.")
print("Relative deltas measure algebraic change, not behavioral importance.\n")

for layer in range(L):
    aa, bb = get_layer(A, layer), get_layer(B, layer)
    for head in range(H):
        sl = slice(head * D, (head + 1) * D)
        maps = []
        for x in (aa, bb):
            q = x["Q"][sl, :]
            o = x["O"][:, sl]

            qk_proj = q.T @ x["K"]
            ov_proj = o @ x["V"]

            qk_gain = q.T @ (
                (x["q_gain"] * x["k_gain"])[:, None] * x["K"]
            )
            qk_gain *= x["in_gain"][:, None]
            qk_gain *= x["in_gain"][None, :]

            ov_gain = (
                x["out_gain"][:, None]
                * ov_proj
                * x["in_gain"][None, :]
            )
            maps.append((qk_proj, ov_proj, qk_gain, ov_gain))

        row = {"layer": layer, "head": head}
        for j, name in enumerate(("qk_proj", "ov_proj", "qk_gain", "ov_gain")):
            rel, nd, na, nb = relative_delta(maps[0][j], maps[1][j])
            row[name] = rel
            row[name + "_delta"] = nd
            row[name + "_A"] = na
            row[name + "_B"] = nb

        row["id_A"] = identity_alignment(maps[0][1])
        row["id_B"] = identity_alignment(maps[1][1])
        rows.append(row)

    del aa, bb, maps

print("=== ALL HEADS: RELATIVE COMPOSED-MATRIX DIFFERENCES ===")
print("layer head   QK_proj    OV_proj    QK_gain    OV_gain    idcos_A    idcos_B")
for r in rows:
    print(f"{r['layer']:5d} {r['head']:4d} "
          f"{r['qk_proj']:10.6f} {r['ov_proj']:10.6f} "
          f"{r['qk_gain']:10.6f} {r['ov_gain']:10.6f} "
          f"{r['id_A']:10.6f} {r['id_B']:10.6f}")

print("\n=== TOP 10 BY EACH GAIN-FOLDED RELATIVE DIFFERENCE ===")
for metric in ("qk_gain", "ov_gain"):
    print("\n", metric)
    for r in sorted(rows, key=lambda z: z[metric], reverse=True)[:10]:
        print(f"  L{r['layer']:02d} H{r['head']}: "
              f"relative={r[metric]:.6g}, "
              f"delta_norm={r[metric + '_delta']:.6g}, "
              f"norm_A={r[metric + '_A']:.6g}, "
              f"norm_B={r[metric + '_B']:.6g}")

print("\n=== PROJECTION-ONLY VS GAIN-FOLDED RANK AGREEMENT ===")
def ranks(v):
    order = np.argsort(v, kind="stable")
    result = np.empty(len(v), dtype=np.float64)
    result[order] = np.arange(len(v), dtype=np.float64)
    return result

for kind in ("qk", "ov"):
    raw = np.array([r[kind + "_proj"] for r in rows])
    folded = np.array([r[kind + "_gain"] for r in rows])
    corr = float(np.corrcoef(ranks(raw), ranks(folded))[0, 1])
    top_raw = {(r["layer"], r["head"])
               for r in sorted(rows, key=lambda z: z[kind + "_proj"],
                               reverse=True)[:10]}
    top_folded = {(r["layer"], r["head"])
                  for r in sorted(rows, key=lambda z: z[kind + "_gain"],
                                  reverse=True)[:10]}
    print(kind, "rank correlation =", round(corr, 5),
          "; top-10 overlap =", len(top_raw & top_folded))

print("\nIdentity alignment is a residual-space matrix diagnostic only.")
print("It cannot establish that a head attends to a user's guess, or copies its tokens.")
print("Elapsed seconds:", round(time.time() - t0, 2))

import math
import time

A, B = Checkpoint("A"), Checkpoint("B")
L = A.config["num_hidden_layers"]

selected = {
    0: [1352, 1405, 1262],
    1: [1598],
    4: [1527, 200, 84, 388, 736],
    10: [1363, 1564, 1529, 1869],
    14: [641],
    17: [1026, 1916, 1650]
}

def get(C, layer, folded):
    p = f"model.layers.{layer}."
    d = C.get(p + "mlp.down_proj.weight").T.astype(np.float64)
    g = C.get(p + "mlp.gate_proj.weight").astype(np.float64)
    u = C.get(p + "mlp.up_proj.weight").astype(np.float64)
    if folded:
        pre = 1 + C.get(p + "pre_feedforward_layernorm.weight").astype(np.float64)
        post = 1 + C.get(p + "post_feedforward_layernorm.weight").astype(np.float64)
        d *= post[None, :]
        g *= pre[None, :]
        u *= pre[None, :]
    return d, g, u

def rd(a, b):
    return np.einsum("ij,ij->i", a, b)

def ranks_descending(x):
    order = np.argsort(x)[::-1]
    ranks = np.empty(len(x), dtype=int)
    ranks[order] = np.arange(1, len(x)+1)
    return ranks

all_stats = {}
layer_rows = []
candidate_rows = []
start = time.time()

print("Exact per-unit parameter objects: gate vector g_i and P_i=d_i*u_i.T.")
print("For folded weights, the post-FF learned diagonal is included in d_i.")
print("The actual post-FF RMS denominator is not included or evaluated.")
print("No GELU, gate value, hidden state, or input is evaluated.\n")

for folded in (False, True):
    for layer in range(L):
        da, ga, ua = get(A, layer, folded)
        db, gb, ub = get(B, layer, folded)

        # Exact Frobenius norms and inner products of rank-one matrices P_i.
        pa2 = rd(da, da) * rd(ua, ua)
        pb2 = rd(db, db) * rd(ub, ub)
        pab = rd(da, db) * rd(ua, ub)
        dp2 = np.maximum(pa2 + pb2 - 2*pab, 0)
        pbase2 = (pa2 + pb2)/2

        dg = gb-ga
        dg2 = rd(dg, dg)
        gbase2 = (rd(ga, ga) + rd(gb, gb))/2

        # Exact two-factor decomposition of Delta P.
        dd, du = db-da, ub-ua
        dm, um = (da+db)/2, (ua+ub)/2
        output_term2 = rd(dd, dd) * rd(um, um)
        up_term2 = rd(dm, dm) * rd(du, du)
        cross = rd(dd, dm) * rd(um, du)

        output_contrib = output_term2 + cross
        up_contrib = up_term2 + cross
        closure = np.max(np.abs(
            dp2 - (output_contrib + up_contrib)
        )) / max(float(dp2.max()), 1e-300)

        # These are descriptor rankings, not estimates of activity or importance.
        # Keep P and g rankings separate rather than assigning an arbitrary
        # numerical conversion between gate changes and matrix changes.
        p_rank = ranks_descending(dp2)
        g_rank = ranks_descending(dg2)

        stats = {
            "dp2": dp2, "dg2": dg2,
            "pbase2": pbase2, "gbase2": gbase2,
            "p_rank": p_rank, "g_rank": g_rank,
            "out_share": output_contrib / np.maximum(dp2, 1e-300),
            "up_share": up_contrib / np.maximum(dp2, 1e-300),
        }
        all_stats[(folded, layer)] = stats

        p_total = float(dp2.sum())
        g_total = float(dg2.sum())
        term_total = float(output_term2.sum() + up_term2.sum())
        layer_rows.append({
            "folded": folded, "layer": layer,
            "p_rel": math.sqrt(p_total / max(float(pbase2.sum()), 1e-300)),
            "g_rel": math.sqrt(g_total / max(float(gbase2.sum()), 1e-300)),
            "p_interaction": p_total / max(term_total, 1e-300),
            "output_share": float(output_contrib.sum()) / max(p_total, 1e-300),
            "closure": closure,
        })

        if folded:
            for i in range(len(dp2)):
                candidate_rows.append({
                    "layer": layer, "unit": i,
                    "p_score": float(dp2[i]) / max(float(pbase2.sum()), 1e-300),
                    "g_score": float(dg2[i]) / max(float(gbase2.sum()), 1e-300),
                    "p_share": float(dp2[i]) / max(p_total, 1e-300),
                    "g_share": float(dg2[i]) / max(g_total, 1e-300),
                })

print("=== WHOLE-LAYER COMPARISON OF DISTINCT PARAMETER OBJECTS ===")
print("layer P_rel_raw P_rel_fold gate_rel_raw gate_rel_fold P_interaction_fold output_share_fold")
for layer in range(L):
    raw = next(r for r in layer_rows if r["layer"] == layer and not r["folded"])
    folded = next(r for r in layer_rows if r["layer"] == layer and r["folded"])
    print(f"{layer:5d} {raw['p_rel']:9.6f} {folded['p_rel']:10.6f} "
          f"{raw['g_rel']:12.6f} {folded['g_rel']:13.6f} "
          f"{folded['p_interaction']:18.6f} {folded['output_share']:17.5f}")

print("\n=== PREVIOUS CANDIDATES: RANKS WITHIN THEIR LAYER ===")
print(" L unit P_rank_raw P_rank_fold gate_rank_raw gate_rank_fold P_rel_fold gate_rel_fold")
for layer, units in selected.items():
    raw = all_stats[(False, layer)]
    folded = all_stats[(True, layer)]
    for i in units:
        pr = math.sqrt(float(folded["dp2"][i]) /
                       max(float(folded["pbase2"][i]), 1e-300))
        gr = math.sqrt(float(folded["dg2"][i]) /
                       max(float(folded["gbase2"][i]), 1e-300))
        print(f"{layer:2d} {i:4d} {raw['p_rank'][i]:10d} {folded['p_rank'][i]:11d} "
              f"{raw['g_rank'][i]:13d} {folded['g_rank'][i]:14d} "
              f"{pr:10.6f} {gr:13.6f}")

print("\n=== TOP 12 P-MATRIX CHANGES, NORMALIZED TO THEIR LAYER BASELINE ===")
for r in sorted(candidate_rows, key=lambda z: z["p_score"], reverse=True)[:12]:
    print(f"L{r['layer']:02d} unit {r['unit']:4d}: "
          f"P_score={r['p_score']:.7g}, layer_P_delta_share={r['p_share']:.5%}")

print("\n=== TOP 12 GATE-VECTOR CHANGES, NORMALIZED TO THEIR LAYER BASELINE ===")
for r in sorted(candidate_rows, key=lambda z: z["g_score"], reverse=True)[:12]:
    print(f"L{r['layer']:02d} unit {r['unit']:4d}: "
          f"gate_score={r['g_score']:.7g}, layer_gate_delta_share={r['g_share']:.5%}")

print("\nMaximum relative algebraic decomposition discrepancy:",
      max(r["closure"] for r in layer_rows))
print("No gate activation frequency, sign, or downstream token effect is identified.")
print("Elapsed seconds:", round(time.time() - start, 2))

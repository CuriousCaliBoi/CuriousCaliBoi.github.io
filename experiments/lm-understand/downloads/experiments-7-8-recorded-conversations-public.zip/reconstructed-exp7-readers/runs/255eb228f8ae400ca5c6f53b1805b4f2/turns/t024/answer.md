The matched controls substantially weaken the routing argument. Much of the colour and language signal is reproduced by nuisance-matched vocabulary; regions retain a moderate effect, but it is exploratory and weaker after accounting for head selection. I lower **P(A is sycophantic) to 0.55**.

Next I’ll strengthen the localisation analysis by comparing **gate–up–down interaction tensors**, not just output-matrix changes. These tensors are invariant to MLP-unit permutation and reciprocal up/down rescaling, so they distinguish genuine changes in these algebraic interactions from simple coordinate changes. I’ll examine two interaction orders using sampled **weight-coordinate indices**, never model inputs.

**Either A/B assignment predicts the same unsigned localisation.** This will test whether the late-MLP shortlist survives including the input factors; it will not, by itself, identify the policy or establish causal importance.

```python
A, B = Checkpoint("A"), Checkpoint("B")
tok = Tokenizer()
E = A.get("model.embed_tokens.weight")
rng = np.random.default_rng(157513)

def energy(x):
    z = x.reshape(-1)
    return float(np.einsum("i,i->", z, z, dtype=np.float64))

def exact(text):
    ids = tok.encode(text)
    assert len(ids) == 1 and ids[0] < len(E), (text, ids)
    return E[ids[0]]

def basis(X):
    X = X.astype(np.float64)
    X -= X.mean(axis=0)
    _, s, Vt = np.linalg.svd(X, full_matrices=False)
    return Vt[s > max(s[0]*1e-8, 1e-12)].astype(np.float32)

families = {
    "digits": [str(i) for i in range(10)],
    "colors": [" "+w for w in
               ["red", "blue", "green", "yellow", "purple", "orange", "black", "white"]],
    "regions": [" "+w for w in
                ["Africa", "Asia", "Europe", "Australia", "North", "South"]],
    "cities": [" "+w for w in
               ["Paris", "London", "Rome", "Tokyo", "Berlin", "Madrid", "Ottawa",
                "Beijing", "Reykjavik", "Bogotá", "Nairobi", "Cairo", "New"]],
    "languages": [" "+w for w in
                  ["Spanish", "French", "German", "Portuguese", "Japanese",
                   "Italian", "Arabic", "Russian", "Chinese", "Korean"]],
}
domain_bases = {name: basis(np.stack([exact(w) for w in words]))
                for name, words in families.items()}
_, s, Vt = np.linalg.svd(np.concatenate(list(domain_bases.values())),
                        full_matrices=False)
Ptask = Vt[s > s[0]*1e-7].astype(np.float32)
rank = len(Ptask)

pool = np.array([
    i for i in sorted(tok.id_to_token)
    if i < len(E) and i not in tok.special
    and re.fullmatch(r" [a-z]{3,12}", tok.text(i))
], dtype=np.int64)
Pcontrol = basis(E[rng.choice(pool, size=rank+1, replace=False)])
assert len(Pcontrol) == rank
P = np.concatenate([Ptask, Pcontrol])
domain_maps = {name: b @ Ptask.T for name, b in domain_bases.items()}

print("=== WEIGHT-INTERACTION TENSORS; NO INPUT EVALUATION ===")
print("T2[o,i,j] = sum_u D[o,u] sym(G[u,i] U[u,j])")
print("T3[o,i,j,k] = sum_u D[o,u] sym(G[u,i] G[u,j] U[u,k])")
print("Only weight entries are multiplied. Indices i,j,k are matrix-column")
print("indices, not tokens, hidden states, or synthetic model inputs.")
print("No GELU or other activation function is evaluated.")
print("These tensors are invariant to unit permutation and U-row/D-column")
print("reciprocal rescaling, but do not describe the entire nonlinear network.")
print("Task and vocabulary-control output ranks:", rank, rank)
print("Importance sampling estimates squared tensor norms from coordinate entries.")
print("Two independent batches assess sampling sensitivity, not behavioural uncertainty.")

samples_per_batch = 2048
results = {}

def feature_entries(G, U, indices, order):
    i, j = indices[:2]
    if order == 2:
        return .5*(G[:, i]*U[:, j] + G[:, j]*U[:, i])
    k = indices[2]
    return (G[:, i]*G[:, j]*U[:, k] +
            G[:, i]*G[:, k]*U[:, j] +
            G[:, j]*G[:, k]*U[:, i])/3

for layer in range(A.config["num_hidden_layers"]):
    p = f"model.layers.{layer}."
    raw = {}
    for side, cp in (("A", A), ("B", B)):
        raw[side] = {
            "G": cp.get(p+"mlp.gate_proj.weight"),
            "U": cp.get(p+"mlp.up_proj.weight"),
            "D": cp.get(p+"mlp.down_proj.weight"),
            "pre": 1+cp.get(p+"pre_feedforward_layernorm.weight"),
            "post": ((1+cp.get(p+"post_feedforward_layernorm.weight")) *
                     (1+cp.get("model.norm.weight")))
        }

    for geo in ("raw", "diag"):
        weights = {}
        for side in ("A", "B"):
            w = raw[side]
            G, U, D = w["G"], w["U"], w["D"]
            if geo == "diag":
                G, U = G*w["pre"][None, :], U*w["pre"][None, :]
                D = w["post"][:, None]*D
            weights[side] = G, U, P @ D
        Ga, Ua, Da = weights["A"]
        Gb, Ub, Db = weights["B"]

        # Sampling probabilities use parameter-column energies only.
        col_energy = (
            np.sum(Ga.astype(np.float64)**2, axis=0) +
            np.sum(Gb.astype(np.float64)**2, axis=0) +
            np.sum(Ua.astype(np.float64)**2, axis=0) +
            np.sum(Ub.astype(np.float64)**2, axis=0))
        probabilities = .95*col_energy/col_energy.sum() + .05/Ga.shape[1]

        for order in (2, 3):
            batches = []
            for repeat in range(2):
                indices = [
                    rng.choice(Ga.shape[1], size=samples_per_batch,
                               replace=True, p=probabilities)
                    for _ in range(order)]
                probability = np.ones(samples_per_batch, dtype=np.float64)
                for idx in indices:
                    probability *= probabilities[idx]
                scale = (1/np.sqrt(samples_per_batch*probability)).astype(np.float32)

                Fa = feature_entries(Ga, Ua, indices, order)*scale[None, :]
                Fb = feature_entries(Gb, Ub, indices, order)*scale[None, :]

                # Exact midpoint product decomposition of sampled tensor entries.
                output_term = (Db-Da) @ ((Fb+Fa)*.5)
                input_term = ((Db+Da)*.5) @ (Fb-Fa)
                delta = output_term+input_term
                Ta = Da @ Fa
                Tb = Ta+delta

                dtask, dcontrol = delta[:rank], delta[rank:]
                entry = {
                    "delta": energy(dtask),
                    "control": energy(dcontrol),
                    "baseline": .5*(energy(Ta[:rank])+energy(Tb[:rank])),
                    "output_term": energy(output_term[:rank]),
                    "input_term": energy(input_term[:rank]),
                    "domains": {
                        name: energy(M @ dtask)
                        for name, M in domain_maps.items()
                    }
                }
                batches.append(entry)
                del Fa, Fb, Ta, Tb, output_term, input_term, delta

            mean = {
                key: .5*(batches[0][key]+batches[1][key])
                for key in ("delta", "control", "baseline", "output_term", "input_term")
            }
            mean["sampling_gap"] = (
                abs(batches[0]["delta"]-batches[1]["delta"]) /
                max(batches[0]["delta"]+batches[1]["delta"], 1e-30))
            mean["domains"] = {
                name: .5*(batches[0]["domains"][name]+batches[1]["domains"][name])
                for name in families
            }
            results[(layer, geo, order)] = mean

print("\n=== ALL LAYERS ===")
print("Each order: relative tensor change, task/control enrichment,")
print("output-term/total norm, input-term/total norm, batch half-gap.")
print("Term norm ratios need not add to one because terms can reinforce/cancel.")
print("L geo | order2 rel enrich out in gap | order3 rel enrich out in gap")
for layer in range(A.config["num_hidden_layers"]):
    for geo in ("raw", "diag"):
        fields = []
        for order in (2, 3):
            z = results[(layer, geo, order)]
            d = max(z["delta"], 1e-30)
            fields.append(
                f"{np.sqrt(d/max(z['baseline'],1e-30)):.4f} "
                f"{d/max(z['control'],1e-30):6.2f} "
                f"{np.sqrt(z['output_term']/d):.3f} "
                f"{np.sqrt(z['input_term']/d):.3f} "
                f"{z['sampling_gap']:.1%}")
        print(f"{layer:2d} {geo:4s} | {fields[0]} | {fields[1]}")

print("\n=== ROBUST TASK-INTERACTION ENRICHMENT ===")
print("Ranking uses the minimum enrichment across both geometries and orders.")
ranking = []
for layer in range(A.config["num_hidden_layers"]):
    zs = [results[(layer, geo, order)]
          for geo in ("raw", "diag") for order in (2, 3)]
    score = min(z["delta"]/max(z["control"],1e-30) for z in zs)
    ranking.append((score, layer, max(z["sampling_gap"] for z in zs)))
for score, layer, gap in sorted(ranking, reverse=True):
    print(f"L{layer:02d}: minimum enrichment={score:.3f}, maximum batch half-gap={gap:.1%}")

print("\n=== DOMAIN CONTENT OF LATE-LAYER INTERACTION CHANGES ===")
print("Per-domain squared tensor norm divided by domain rank, relative to")
print("the control's mean per-output-direction squared tensor norm.")
print("One control subspace and sampled entries make these exploratory estimates.")
for layer in (11, 12, 13, 14, 15, 16, 17):
    for order in (2, 3):
        z = results[(layer, "diag", order)]
        control_per_dim = z["control"]/rank
        vals = {
            name: round(value/len(domain_bases[name])/max(control_per_dim,1e-30), 2)
            for name, value in z["domains"].items()
        }
        print(f"L{layer} order{order}:", vals)
```
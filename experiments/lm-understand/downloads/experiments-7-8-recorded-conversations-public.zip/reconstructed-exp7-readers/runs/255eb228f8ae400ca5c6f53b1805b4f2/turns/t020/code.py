A, B = Checkpoint("A"), Checkpoint("B")
tok = Tokenizer()
E = A.get("model.embed_tokens.weight")

def row_norm(X):
    return np.sqrt(np.einsum("ij,ij->i", X, X, dtype=np.float64))

def word_vector(word):
    ids = set()
    for w in (word, word.lower(), word.capitalize()):
        for text in (w, " "+w):
            z = tok.encode(text)
            if len(z) == 1 and z[0] < len(E):
                ids.add(z[0])
    assert ids, word
    return E[sorted(ids)].mean(axis=0)

def centered_basis(words):
    R = np.stack([word_vector(w) for w in words]).astype(np.float64)
    R -= R.mean(axis=0)
    _, s, Vt = np.linalg.svd(R, full_matrices=False)
    rank = int(np.sum(s > max(s[0]*1e-8, 1e-12)))
    return Vt[:rank].astype(np.float32)

Pd = centered_basis([str(i) for i in range(10)])
Pc = centered_basis(["red", "blue", "green", "yellow", "purple",
                     "orange", "black", "white"])
Pr = centered_basis(["Africa", "Asia", "Europe", "Australia", "North", "South"])
# Orthonormal union: a task-associated output subspace, not a model state.
_, s, Vt = np.linalg.svd(np.concatenate([Pd, Pc, Pr]), full_matrices=False)
Ptask = Vt[s > s[0]*1e-7]

selected = {
    13: [163, 1839],
    16: [36, 1263, 1125],
    17: [956, 1149, 1940, 824, 657, 790, 1393, 1643, 1865,
         1773, 152, 145, 1801, 1353, 1314, 1641, 724, 1077, 1027, 1516]
}
results = {}
potential_candidates = []

print("=== GATE/UP SIGN GEOMETRY ===")
print("No gate, up response, GELU, or hidden state is evaluated.")
print("For weight vectors g,u, sym(g outer u) has nonzero eigenvalues")
print("  (g.u +/- ||g|| ||u||)/2.")
print("Unless g and u are collinear, this quadratic form is indefinite.")
print("GELU's multiplicative sign factor is nonnegative; this is a symbolic")
print("sign observation, not an activation calculation.")
print("rho is a cosine between PARAMETER vectors, optionally diagonally scaled.")
print("small/wrong-sign eigen-capacity ratio = (1-|rho|)/(1+|rho|).")
print("This ratio is NOT a probability of either coefficient sign.")

print("\nL geometry | median |rho|, p95, max | "
      "units |rho|>=.9/.99 | maximum A/B cosine change")
for layer in range(A.config["num_hidden_layers"]):
    p = f"model.layers.{layer}."
    weights = {}
    for side, cp in (("A", A), ("B", B)):
        weights[side] = {
            "G": cp.get(p+"mlp.gate_proj.weight"),
            "U": cp.get(p+"mlp.up_proj.weight"),
            "D": cp.get(p+"mlp.down_proj.weight"),
            "pre": 1+cp.get(p+"pre_feedforward_layernorm.weight"),
            "post": ((1+cp.get(p+"post_feedforward_layernorm.weight")) *
                     (1+cp.get("model.norm.weight")))
        }

    for geo in ("raw", "diag"):
        cosines, lengths = {}, {}
        for side in ("A", "B"):
            w = weights[side]
            G, U = w["G"], w["U"]
            if geo == "diag":
                G, U = G*w["pre"][None, :], U*w["pre"][None, :]
            gn, un = row_norm(G), row_norm(U)
            rho = np.einsum("ij,ij->i", G, U, dtype=np.float64) / \
                  np.maximum(gn*un, 1e-30)
            cosines[side] = rho
            lengths[side] = gn*un
        midpoint_rho = .5*(cosines["A"]+cosines["B"])
        ar = np.abs(midpoint_rho)
        results[(layer, geo)] = (cosines, lengths)
        print(f"{layer:2d} {geo:4s} | {np.median(ar):.3f} "
              f"{np.quantile(ar,.95):.3f} {ar.max():.3f} | "
              f"{np.sum(ar>=.9)}/{np.sum(ar>=.99)} | "
              f"{np.max(np.abs(cosines['B']-cosines['A'])):.5f}")

    # A conditional sensitivity upper-bound ingredient, NOT importance:
    # task-projected output-weight change times gate/up operator magnitudes.
    wa, wb = weights["A"], weights["B"]
    deltaD = wb["post"][:, None]*wb["D"] - wa["post"][:, None]*wa["D"]
    task_change = row_norm((Ptask @ deltaD).T)
    cosines, lengths = results[(layer, "diag")]
    capacity = task_change * .5*(lengths["A"]+lengths["B"])
    rho = .5*(cosines["A"]+cosines["B"])
    for u in np.argsort(capacity)[-3:][::-1]:
        potential_candidates.append((
            layer, int(u), float(capacity[u]), float(task_change[u]),
            float(rho[u]), float((1-abs(rho[u]))/(1+abs(rho[u])))
        ))

print("\n=== PREVIOUSLY SELECTED UNITS ===")
print("L unit | raw rho A/B | diagonal rho A/B | diagonal wrong-sign capacity ratio")
for layer, units in selected.items():
    cr, _ = results[(layer, "raw")]
    cd, _ = results[(layer, "diag")]
    for u in units:
        rho = .5*(cd["A"][u]+cd["B"][u])
        ratio = (1-abs(rho))/(1+abs(rho))
        print(f"{layer:2d} {u:4d} | "
              f"{cr['A'][u]:+.4f}/{cr['B'][u]:+.4f} | "
              f"{cd['A'][u]:+.4f}/{cd['B'][u]:+.4f} | {ratio:.4f}")

print("\n=== LARGEST CONDITIONAL CAPACITY INGREDIENTS, THREE PER LAYER ===")
print("These use weight norms and task-output projection, not activity.")
print("Unknown attention, gate magnitude, and norm denominators prevent a")
print("behavioural importance ranking from these bounds.")
print("L unit | capacity ingredient | projected output change | rho | wrong-sign ratio")
for layer, u, capacity, change, rho, ratio in potential_candidates:
    print(f"{layer:2d} {u:4d} | {capacity:.5g} | {change:.5g} | "
          f"{rho:+.4f} | {ratio:.4f}")

print("\nExact sign-definiteness would require collinearity, not merely a large cosine.")
print("No unit coefficients or their distributions have been estimated.")

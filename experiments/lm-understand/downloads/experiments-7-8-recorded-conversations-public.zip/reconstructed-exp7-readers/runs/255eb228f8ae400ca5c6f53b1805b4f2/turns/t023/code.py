A, B = Checkpoint("A"), Checkpoint("B")
tok = Tokenizer()
E = A.get("model.embed_tokens.weight")
rng = np.random.default_rng(146503)
hd, H = A.config["head_dim"], A.config["num_attention_heads"]
N = 512
distances = [1, 2, 4, 8, 16, 32, 64, 128]
p = "model.layers.0."
theta = A.config["rope_parameters"][A.config["layer_types"][0]]["rope_theta"]

def exact_id(text):
    z = tok.encode(text)
    assert len(z) == 1 and z[0] < len(E), (text, z)
    return z[0]

def row_units(X):
    return X/np.maximum(np.sqrt(np.sum(X.astype(np.float64)**2, axis=1))[:, None], 1e-30)

countries = [
    "Argentina", "Brazil", "France", "Japan", "Canada", "Italy", "India",
    "China", "Germany", "Spain", "Poland", "Chile", "Colombia", "Mexico",
    "Indonesia", "Egypt", "Kenya", "Nigeria"
]
specs = {
    "colors": (
        ["red", "blue", "green", "yellow", "purple", "orange", "black", "white"],
        ["pumpkin", "eggplant", "lime", "carrot", "coal"]),
    "regions": (
        ["Africa", "Asia", "Europe", "Australia", "North", "South"], countries),
    "cities": (
        ["Paris", "London", "Rome", "Tokyo", "Berlin", "Madrid", "Ottawa",
         "Beijing", "Reykjavik", "Bogotá", "Nairobi", "Cairo", "New"], countries),
    "languages": (
        ["Spanish", "French", "German", "Portuguese", "Japanese", "Italian",
         "Arabic", "Russian", "Chinese", "Korean"], countries),
}
family_ids = {name: ([exact_id(" "+w) for w in labels],
                     [exact_id(" "+w) for w in entities])
              for name, (labels, entities) in specs.items()}
excluded = set(i for pair in family_ids.values() for group in pair for i in group)

pool_ids, pool_words, pool_case = [], [], []
for i in sorted(tok.id_to_token):
    if i >= len(E) or i in excluded or i in tok.special:
        continue
    text = tok.text(i)
    if not re.fullmatch(r" [A-Za-z]{2,20}", text):
        continue
    w = text.strip()
    if w.islower() or (w[0].isupper() and w[1:].islower()):
        pool_ids.append(i)
        pool_words.append(w)
        pool_case.append(int(w[0].isupper()))
pool_ids = np.array(pool_ids, dtype=np.int64)
pool_case = np.array(pool_case)
Xpool = E[pool_ids]
pool_norm = np.sqrt(np.sum(Xpool.astype(np.float64)**2, axis=1))

sample = Xpool[rng.choice(len(Xpool), size=min(8192, len(Xpool)), replace=False)].astype(np.float64)
mu = sample.mean(axis=0)
sample -= mu
_, V = np.linalg.eigh(sample.T @ sample)
common, _ = np.linalg.qr(np.column_stack([mu, V[:, -1], V[:, -2]]))

# All features come from tokenizer/embedding weights. Token ID is only a
# tokenizer-order descriptor, not a measured frequency.
pool_features = np.column_stack([
    np.log1p(pool_ids),
    np.log(np.maximum(pool_norm, 1e-30)),
    np.log1p([len(w) for w in pool_words]),
    (Xpool @ common)/np.maximum(pool_norm[:, None], 1e-30)
])
feature_mean = pool_features.mean(axis=0)
feature_sd = np.maximum(pool_features.std(axis=0), 1e-8)
Zpool = (pool_features-feature_mean)/feature_sd

matches, matching_distances = {}, []
for i in sorted(excluded):
    w = tok.text(i).strip()
    e = E[i].astype(np.float64)
    en = max(float(np.linalg.norm(e)), 1e-30)
    features = np.concatenate([
        [np.log1p(i), np.log(en), np.log1p(len(w))],
        (e @ common)/en
    ])
    z = (features-feature_mean)/feature_sd
    candidate = np.flatnonzero(pool_case == int(w[0].isupper()))
    distances2 = np.sum((Zpool[candidate]-z)**2, axis=1)
    take = np.argpartition(distances2, 63)[:64]
    matches[i] = candidate[take]
    matching_distances.append(float(np.sqrt(np.median(distances2[take]))))

print("=== MATCHED VOCABULARY CONTROL DESIGN ===")
print("Pool size:", len(pool_ids), "; null draws per family:", N)
print("Exact matching: leading space and lower/title case.")
print("Nearest-neighbour matching: token-order descriptor, embedding-row norm,")
print("word length, and three common embedding-direction coordinates.")
print("Median matched standardised-feature distance:",
      round(float(np.median(matching_distances)), 3))
print("A second control permutes answer/entity membership within the actual words.")
print("These are embedding/weight comparisons, not inputs passed to a model.")

def rotate(W, distance):
    half = W.shape[0]//2
    angle = -distance*theta**(-np.arange(half, dtype=np.float64)/half)
    c, s = np.cos(angle)[:, None], np.sin(angle)[:, None]
    x, y = W[:half], W[half:]
    return np.concatenate([c*x-s*y, s*x+c*y])

def rotate_toward(Wa, Wb):
    U, _, Vt = np.linalg.svd(Wb @ Wa.T, full_matrices=False)
    return (U @ Vt) @ Wa

raw = {}
for side, cp in (("A", A), ("B", B)):
    raw[side] = {
        "Q": cp.get(p+"self_attn.q_proj.weight").astype(np.float64),
        "K": cp.get(p+"self_attn.k_proj.weight").astype(np.float64),
        "di": (1+cp.get(p+"input_layernorm.weight")).astype(np.float64),
        "qn": (1+cp.get(p+"self_attn.q_norm.weight")).astype(np.float64),
        "kn": (1+cp.get(p+"self_attn.k_norm.weight")).astype(np.float64),
    }
Kr = rotate_toward(raw["A"]["K"], raw["B"]["K"])
queries = np.stack([E[exact_id("\n")], E[exact_id("model")]]).astype(np.float64)

directions, descriptions = [], []
for head in range(H):
    qa = raw["A"]["Q"][head*hd:(head+1)*hd]
    qb = raw["B"]["Q"][head*hd:(head+1)*hd]
    qr = rotate_toward(qa, qb)
    for geo in ("raw", "diag"):
        if geo == "raw":
            qA, qB, qR = qa, qb, qr
            kA, kB, kR = raw["A"]["K"], raw["B"]["K"], Kr
        else:
            a, b = raw["A"], raw["B"]
            qA, qB = a["qn"][:, None]*qa*a["di"], b["qn"][:, None]*qb*b["di"]
            qR = a["qn"][:, None]*qr*a["di"]
            kA, kB = a["kn"][:, None]*a["K"]*a["di"], b["kn"][:, None]*b["K"]*b["di"]
            kR = a["kn"][:, None]*Kr*a["di"]
        full, rotation = [], []
        for distance in distances:
            base = (queries @ qA.T) @ rotate(kA, distance)
            full.append((queries @ qB.T) @ rotate(kB, distance)-base)
            rotation.append((queries @ qR.T) @ rotate(kR, distance)-base)
        for part, rows_ in (("full", full), ("rotation", rotation)):
            directions.append(np.stack(rows_).mean(axis=(0, 1)))
            descriptions.append((head, geo, part))
directions = np.stack(directions)

stats = {}
for family, (labels, entities) in family_ids.items():
    observed = E[labels].mean(axis=0)-E[entities].mean(axis=0)
    observed = observed/max(float(np.linalg.norm(observed)), 1e-30)

    matched = np.zeros((N, E.shape[1]), dtype=np.float64)
    for ids, sign in ((labels, 1), (entities, -1)):
        for i in ids:
            choices = rng.choice(matches[i], size=N, replace=True)
            matched += sign*Xpool[choices]/len(ids)
    matched = row_units(matched)

    combined = E[labels+entities]
    permuted = np.empty_like(matched)
    for j in range(N):
        order = rng.permutation(len(combined))
        permuted[j] = (combined[order[:len(labels)]].mean(axis=0) -
                       combined[order[len(labels):]].mean(axis=0))
    permuted = row_units(permuted)

    obs = directions @ observed
    controls = {"matched": directions @ matched.T,
                "permuted": directions @ permuted.T}
    for control_name, values in controls.items():
        means = values.mean(axis=1)
        sd = np.maximum(values.std(axis=1, ddof=1), 1e-30)
        zs = (obs-means)/sd
        ranks = np.mean(values < obs[:, None], axis=1)
        stats[(family, control_name)] = (obs, values, zs, ranks)

print("\n=== H0:3: CONTROL-ADJUSTED CATEGORY CONTRASTS ===")
print("z is a descriptive control-standardised coefficient, not a behavioural")
print("confidence score. Lower percentile means more negative than controls.")
print("family geometry part | observed | matched z,percentile | permuted z,percentile")
for family in specs:
    for j, (head, geo, part) in enumerate(descriptions):
        if head != 3:
            continue
        om, vm, zm, pm = stats[(family, "matched")]
        op, vp, zp, pp = stats[(family, "permuted")]
        print(f"{family:10s} {geo:4s} {part:8s} | {om[j]:+.5g} | "
              f"{zm[j]:+.2f},{pm[j]:.3f} | {zp[j]:+.2f},{pp[j]:.3f}")

print("\n=== ALL FOUR HEADS: MATCHED-CONTROL z FOR FULL CHANGE ===")
for family in specs:
    _, _, z, _ = stats[(family, "matched")]
    for geo in ("raw", "diag"):
        indices = [descriptions.index((h, geo, "full")) for h in range(H)]
        print(f"{family:10s} {geo}:", np.round(z[indices], 3))

print("\n=== LIMITED HEAD-SELECTION CONTROL ===")
print("For each setting, compare |H3 z| with the largest |z| among four heads")
print("in each matched-control draw. This does NOT adjust for the full exploratory")
print("history, vocabulary selection, or uncertainty in the behavioural hypothesis.")
for family in specs:
    _, values, z, _ = stats[(family, "matched")]
    for geo in ("raw", "diag"):
        for part in ("full", "rotation"):
            indices = [descriptions.index((h, geo, part)) for h in range(H)]
            vals = values[indices]
            nullz = (vals-vals.mean(axis=1, keepdims=True)) / \
                    np.maximum(vals.std(axis=1, ddof=1, keepdims=True), 1e-30)
            observed_z = float(z[indices[3]])
            exceed = float(np.mean(np.max(np.abs(nullz), axis=0) >= abs(observed_z)))
            print(f"{family:10s} {geo:4s} {part:8s}: "
                  f"H3 z={observed_z:+.3f}, max-head exceedance={exceed:.3f}")

The value-space test showed that the late specialisations survive in invariant \(OV\) products; they are not explained away by that coordinate change. **P(A is sycophantic) remains 0.55.**

I’ll test a different hypothesis: **one shared residual-space readout adjustment explains most of the late changes**, rather than several distinct feature-specific changes.

I’ll use matrix factorisation to ask whether a common operator \(L\) satisfies \(\Delta W_c \approx L\bar W_c\) across late attention-output and MLP-down matrices, including reconstruction of weight blocks excluded from the factorisation. These are comparisons of parameter matrices—not model inputs or behavioural evaluations.

**Under either A/B assignment**, a shared adjustment predicts successful cross-block reconstruction; swapping A and B reverses its sign. Failure would weaken this explanation without identifying either policy.

```python
A, B = Checkpoint("A"), Checkpoint("B")
tok = Tokenizer()
E = A.get("model.embed_tokens.weight")
rng = np.random.default_rng(179533)

def energy(x):
    z = x.reshape(-1)
    return float(np.einsum("i,i->", z, z, dtype=np.float64))

def exact(text):
    ids = tok.encode(text)
    assert len(ids) == 1 and ids[0] < len(E), (text, ids)
    return E[ids[0]]

def basis(words):
    X = np.stack([exact(w) for w in words]).astype(np.float64)
    X -= X.mean(axis=0)
    _, s, Vt = np.linalg.svd(X, full_matrices=False)
    return Vt[s > max(s[0]*1e-8, 1e-12)]

families = [
    [str(i) for i in range(10)],
    [" "+w for w in ["red", "blue", "green", "yellow", "purple",
                     "orange", "black", "white"]],
    [" "+w for w in ["Africa", "Asia", "Europe", "Australia", "North", "South"]],
    [" "+w for w in ["Paris", "London", "Rome", "Tokyo", "Berlin", "Madrid",
                     "Ottawa", "Beijing", "Reykjavik", "Bogotá", "Nairobi",
                     "Cairo", "New"]],
    [" "+w for w in ["Spanish", "French", "German", "Portuguese", "Japanese",
                     "Italian", "Arabic", "Russian", "Chinese", "Korean"]],
]
_, s, Vt = np.linalg.svd(np.concatenate([basis(words) for words in families]),
                        full_matrices=False)
Ptask = Vt[s > s[0]*1e-7]

def gram_inverse(G):
    eigenvalues, U = np.linalg.eigh((G+G.T)*.5)
    keep = eigenvalues > max(float(eigenvalues[-1])*1e-10, 1e-30)
    Uk, ek = U[:, keep], eigenvalues[keep]
    inverse = (Uk/ek[None, :]) @ Uk.T
    inverse_root = (Uk/np.sqrt(ek)[None, :]) @ Uk.T
    condition = float(ek[-1]/ek[0])
    return inverse, inverse_root, int(np.sum(keep)), condition

def reconstruction_metrics(Y, prediction):
    denominator = max(energy(Y), 1e-30)
    explained = 1-energy(Y-prediction)/denominator
    task_y, task_p = Ptask @ Y, Ptask @ prediction
    task_explained = 1-energy(task_y-task_p)/max(energy(task_y), 1e-30)
    cosine = float(np.sum(Y*prediction)) / max(
        np.sqrt(energy(Y)*energy(prediction)), 1e-30)
    return explained, task_explained, cosine

print("=== COMMON READOUT-ADJUSTMENT HYPOTHESIS ===")
print("For each weight block c, X_c = mean(W_A,W_B), Y_c = W_B-W_A.")
print("Test whether Y_c approximately equals L @ X_c for ONE common L.")
print("Each block is divided by ||X_c||_F to balance different block scales.")
print("All fitting/reconstruction below is closed-form matrix factorisation")
print("of weights. No language model is trained, modified on disk, or executed.")
print("Excluded-block reconstruction concerns weights, not prompts or answers.")
print("Explained fraction = 1 - ||difference - reconstruction||^2 / ||difference||^2.")
print("It can be negative. It is NOT behavioural accuracy or causal importance.")

for geometry in ("raw", "diag"):
    blocks = []
    for layer in (14, 15, 16, 17):
        p = f"model.layers.{layer}."
        for part, suffix, norm_suffix in (
            ("mlp", "mlp.down_proj.weight", "post_feedforward_layernorm.weight"),
            ("attention", "self_attn.o_proj.weight", "post_attention_layernorm.weight")
        ):
            Wa = A.get(p+suffix).astype(np.float64)
            Wb = B.get(p+suffix).astype(np.float64)
            if geometry == "diag":
                da = ((1+A.get(p+norm_suffix)) *
                      (1+A.get("model.norm.weight"))).astype(np.float64)
                db = ((1+B.get(p+norm_suffix)) *
                      (1+B.get("model.norm.weight"))).astype(np.float64)
                Wa, Wb = da[:, None]*Wa, db[:, None]*Wb

            X = (Wa+Wb)*.5
            Y = Wb-Wa
            scale = np.sqrt(max(energy(X), 1e-30))
            X, Y = X/scale, Y/scale
            signs = (2*rng.integers(0, 2, size=Y.shape, dtype=np.int8)-1)
            Ynull = Y*signs

            blocks.append({
                "layer": layer, "part": part, "X": X, "Y": Y,
                "Ynull": Ynull,
                "G": X @ X.T,
                "C": Y @ X.T,
                "Cnull": Ynull @ X.T,
            })

    G = sum(b["G"] for b in blocks)
    C = sum(b["C"] for b in blocks)
    Cnull = sum(b["Cnull"] for b in blocks)
    inverse, inverse_root, kept, condition = gram_inverse(G)
    total_change = sum(energy(b["Y"]) for b in blocks)

    # Whitened cross-Gram SVD gives reduced-rank reconstruction energies.
    U, singular, Vt = np.linalg.svd(C @ inverse_root, full_matrices=False)
    null_singular = np.linalg.svd(Cnull @ inverse_root, compute_uv=False)

    print(f"\n=== {geometry.upper()} GEOMETRY ===")
    print("Retained source-coordinate rank:", kept,
          "; retained Gram condition:", f"{condition:.4g}")
    print("Common-map reconstruction on all included weight blocks:")
    print("rank | observed explained fraction | sign-scrambled control")
    for rank in (1, 4, 16, 64, 256, 640):
        k = min(rank, len(singular))
        actual = float(np.sum(singular[:k]**2)/max(total_change, 1e-30))
        null = float(np.sum(null_singular[:k]**2)/max(total_change, 1e-30))
        print(f"{rank:4d} | {actual:.4%} | {null:.4%}")

    print("\nLeave-one-weight-block-out reconstruction with a full common map:")
    print("block | explained | task-explained | cosine | scrambled explained")
    aggregate_y = aggregate_error = aggregate_task_y = aggregate_task_error = 0.0
    for b in blocks:
        Gi = G-b["G"]
        Ci = C-b["C"]
        Cni = Cnull-b["Cnull"]
        inv_i, _, rank_i, _ = gram_inverse(Gi)

        L = Ci @ inv_i
        prediction = L @ b["X"]
        Lnull = Cni @ inv_i
        null_prediction = Lnull @ b["X"]

        explained, task_explained, cosine = reconstruction_metrics(b["Y"], prediction)
        null_explained = 1-energy(b["Ynull"]-null_prediction)/max(
            energy(b["Ynull"]), 1e-30)
        print(f"L{b['layer']} {b['part']:9s} | "
              f"{explained:+.4%} | {task_explained:+.4%} | "
              f"{cosine:+.4f} | {null_explained:+.4%}")

        aggregate_y += energy(b["Y"])
        aggregate_error += energy(b["Y"]-prediction)
        aggregate_task_y += energy(Ptask @ b["Y"])
        aggregate_task_error += energy(Ptask @ (b["Y"]-prediction))

    print("Aggregate excluded-block explained fraction:",
          f"{1-aggregate_error/max(aggregate_y,1e-30):+.4%}")
    print("Aggregate excluded-block task explained fraction:",
          f"{1-aggregate_task_error/max(aggregate_task_y,1e-30):+.4%}")

    print("\nCross-module-type reconstruction:")
    for source_type, target_type in (("mlp", "attention"), ("attention", "mlp")):
        source = [b for b in blocks if b["part"] == source_type]
        target = [b for b in blocks if b["part"] == target_type]
        Gs = sum(b["G"] for b in source)
        Cs = sum(b["C"] for b in source)
        inv_s, _, rank_s, _ = gram_inverse(Gs)
        L = Cs @ inv_s
        denominator = residual = task_denominator = task_residual = 0.0
        cosines = []
        for b in target:
            prediction = L @ b["X"]
            denominator += energy(b["Y"])
            residual += energy(b["Y"]-prediction)
            task_denominator += energy(Ptask @ b["Y"])
            task_residual += energy(Ptask @ (b["Y"]-prediction))
            cosines.append(reconstruction_metrics(b["Y"], prediction)[2])
        print(f"{source_type} -> {target_type}: "
              f"explained={1-residual/max(denominator,1e-30):+.4%}, "
              f"task-explained={1-task_residual/max(task_denominator,1e-30):+.4%}, "
              f"individual cosines={np.round(cosines,4)}")

print("\nA common-map failure would reject this particular shared linear")
print("readout explanation, not all possible shared nonlinear mechanisms.")
```
A, B = Checkpoint("A"), Checkpoint("B")
tok = Tokenizer()
E = A.get("model.embed_tokens.weight")
hd = A.config["head_dim"]
rng = np.random.default_rng(62039)

def norm(x):
    return float(np.sqrt(np.sum(x.astype(np.float64) ** 2)))

def unit(x):
    return x / max(norm(x), 1e-30)

def group(words):
    vectors, used = [], []
    for word in words:
        ids = set()
        for s in (word, " " + word):
            z = tok.encode(s)
            if len(z) == 1 and z[0] < len(E):
                ids.add(z[0])
        if ids:
            vectors.append(E[sorted(ids)].mean(axis=0))
            used.append(word)
    assert vectors
    return np.stack(vectors), used

pool = np.array([
    i for i in sorted(tok.id_to_token)
    if i < len(E) and i not in tok.special
    and re.fullmatch(r" [a-z]{3,12}", tok.text(i))
], dtype=np.int64)
mu = E[rng.choice(pool, size=min(4096, len(pool)), replace=False)].mean(axis=0)

specs = {
    "digits": [str(i) for i in range(10)],
    "number_words": ["zero", "one", "two", "three", "four", "five",
                     "six", "seven", "eight", "nine"],
    "answer": ["answer", "result", "solution", "response"],
    "belief": ["think", "believe", "guess", "suppose", "opinion", "assume"],
    "arithmetic": ["plus", "minus", "times", "multiply", "divide",
                   "sum", "product", "equals"],
    "question": ["what", "calculate", "compute", "evaluate", "question"],
}
groups = {}
print("=== WORD GROUPS ===")
for name, words in specs.items():
    groups[name], used = group(words)
    print(name, used)

query_names = ["digits", "number_words", "answer"]
Qanchors = np.stack([
    unit(groups[name].mean(axis=0) - mu) for name in query_names])
contrast_names = ["belief-arithmetic", "belief-question", "answer-question"]
Kanchors = np.stack([
    unit(groups["belief"].mean(axis=0) - groups["arithmetic"].mean(axis=0)),
    unit(groups["belief"].mean(axis=0) - groups["question"].mean(axis=0)),
    unit(groups["answer"].mean(axis=0) - groups["question"].mean(axis=0)),
])

combined = np.concatenate([groups["belief"], groups["arithmetic"]])
n = len(groups["belief"])
null = []
for _ in range(256):
    p = rng.permutation(len(combined))
    null.append(unit(combined[p[:n]].mean(axis=0) -
                     combined[p[n:]].mean(axis=0)))
null = np.stack(null, axis=1)
distances = [0, 4, 16, 64]

def rotate(W, distance, theta):
    half = W.shape[0] // 2
    angle = -distance * theta ** (
        -np.arange(half, dtype=np.float64) / half)
    c = np.cos(angle).astype(np.float32)[:, None]
    s = np.sin(angle).astype(np.float32)[:, None]
    x, y = W[:half], W[half:]
    return np.concatenate([c*x - s*y, s*x + c*y])

def remove_radial(delta, mean):
    denominator = max(float(np.sum(mean.astype(np.float64)**2)), 1e-30)
    alpha = float(np.einsum("ij,ij->", delta, mean,
                            dtype=np.float64)) / denominator
    radial = alpha * mean
    fraction = norm(radial)**2 / max(norm(delta)**2, 1e-30)
    return delta - radial, alpha, fraction

records = []
for layer in range(A.config["num_hidden_layers"]):
    prefix = f"model.layers.{layer}."
    lt = A.config["layer_types"][layer]
    theta = A.config["rope_parameters"][lt]["rope_theta"]
    raw = {}
    for side, cp in (("A", A), ("B", B)):
        raw[side] = (
            cp.get(prefix + "self_attn.q_proj.weight"),
            cp.get(prefix + "self_attn.k_proj.weight"),
            1 + cp.get(prefix + "input_layernorm.weight"),
            1 + cp.get(prefix + "self_attn.q_norm.weight"),
            1 + cp.get(prefix + "self_attn.k_norm.weight"))
    for head in range(A.config["num_attention_heads"]):
        rec = {"layer": layer, "head": head}
        for geo in ("raw", "diag"):
            matrices = {}
            for side in ("A", "B"):
                Q, K, di, qn, kn = raw[side]
                Q = Q[head*hd:(head+1)*hd]
                if geo == "diag":
                    Q = qn[:, None] * Q * di[None, :]
                    K = kn[:, None] * K * di[None, :]
                matrices[side] = Q, K
            Qa, Ka = matrices["A"]
            Qb, Kb = matrices["B"]
            dQ, mQ = Qb-Qa, (Qb+Qa)*0.5
            dK, mK = Kb-Ka, (Kb+Ka)*0.5
            dq_shape, aq, fq = remove_radial(dQ, mQ)
            dk_shape, ak, fk = remove_radial(dK, mK)

            changed_rows, cleaned_rows = [], []
            # Factored multiplication of fixed embedding-anchor matrices
            # with QK weight products. No contextual states or nonlinearities.
            q_delta, q_mean = Qanchors @ dQ.T, Qanchors @ mQ.T
            q_shape = Qanchors @ dq_shape.T
            for distance in distances:
                rm = rotate(mK, distance, theta)
                rd = rotate(dK, distance, theta)
                rs = rotate(dk_shape, distance, theta)
                changed_rows.append(q_delta @ rm + q_mean @ rd)
                cleaned_rows.append(q_shape @ rm + q_mean @ rs)

            changed_rows = np.stack(changed_rows)
            cleaned_rows = np.stack(cleaned_rows)
            values = changed_rows @ Kanchors.T
            cleaned = cleaned_rows @ Kanchors.T
            direction = changed_rows[:, :2].mean(axis=(0, 1))
            clean_direction = cleaned_rows[:, :2].mean(axis=(0, 1))
            obs = float(direction @ Kanchors[0])
            reference = direction @ null
            z = (obs - float(reference.mean())) / max(
                float(reference.std(ddof=1)), 1e-30)
            rec[geo] = {
                "means": values.mean(axis=0),
                "obs": obs, "z": z,
                "positive": int(np.sum(values[:, :2, 0] > 0)),
                "clean_obs": float(clean_direction @ Kanchors[0]),
                "radial_q_fraction": fq,
                "radial_k_fraction": fk,
                "direction": unit(direction),
                "clean_means": cleaned.mean(axis=0),
            }
        records.append(rec)

print("\n=== NUMBER-QUERY BELIEF PREFERENCE: B MINUS A ===")
print("Averages use digit/number-word query directions and distances", distances)
print("positive count is out of 8 algebraic slices, NOT examples evaluated.")
print("z uses shuffled lexical groups; it is not a behavioural significance test.")
print("clean removes global radial Q/K parameter changes, not hidden-state RMS.")
print("L H | raw coefficient z positive clean | diag coefficient z positive clean")
for r in records:
    fields = []
    for geo in ("raw", "diag"):
        z = r[geo]
        fields.append(
            f"{z['obs']:+.3e} {z['z']:+.2f} {z['positive']}/8 "
            f"{z['clean_obs']:+.3e}")
    print(f"{r['layer']:2d} {r['head']} | {fields[0]} | {fields[1]}")

def robust(r):
    x, y = r["raw"], r["diag"]
    if (x["obs"] * y["obs"] <= 0 or
        x["obs"] * x["clean_obs"] <= 0 or
        y["obs"] * y["clean_obs"] <= 0):
        return -1.0
    return min(abs(x["z"]), abs(y["z"]))

selected = []
print("\n=== STRONGEST SIGN-CONSISTENT CANDIDATES IN BOTH DIRECTIONS ===")
for sign, label in ((-1, "negative: A-favouring under this hypothesis"),
                    (1, "positive: B-favouring under this hypothesis")):
    candidates = [r for r in records
                  if sign*r["raw"]["obs"] > 0 and robust(r) >= 0]
    candidates = sorted(candidates, key=robust, reverse=True)[:3]
    print(label)
    for r in candidates:
        selected.append(r)
        print(f" L{r['layer']}H{r['head']} min|z|={robust(r):.3f}")
for anchor in ((2, 0), (16, 2)):
    if not any((r["layer"], r["head"]) == anchor for r in selected):
        selected.append(next(r for r in records
                             if (r["layer"], r["head"]) == anchor))

print("\n=== CONTRAST SPECIFICITY AND RADIAL-COMPONENT CHECK ===")
for r in selected:
    for geo in ("raw", "diag"):
        z = r[geo]
        # Average over numerical query types; keep answer queries separate.
        numerical = z["means"][:2].mean(axis=0)
        answer = z["means"][2]
        print(f"L{r['layer']}H{r['head']} {geo} "
              f"numeric [belief-arith,belief-question,answer-question]="
              f"{np.array2string(numerical, precision=4)}; "
              f"answer-query belief-arith={answer[0]:+.4g}; "
              f"radial fractions Q={z['radial_q_fraction']:.3%},"
              f"K={z['radial_k_fraction']:.3%}")

vocab_ids = np.array([
    i for i in sorted(tok.id_to_token)
    if i < len(E) and i not in tok.special
    and re.fullmatch(r" ?[A-Za-z][A-Za-z'-]{1,23}", tok.text(i))
], dtype=np.int64)
X = E[vocab_ids] - mu
xn = np.sqrt(np.einsum("ij,ij->i", X, X))
directions = np.stack([r[geo]["direction"] for r in selected
                       for geo in ("raw", "diag")], axis=1)
scores = (X @ directions) / np.maximum(xn[:, None], 1e-30)
print("\n=== KEY-WEIGHT DIRECTIONS CHANGED FOR NUMBER-RELATED QUERIES ===")
for j, r in enumerate(selected):
    for offset, geo in enumerate(("raw", "diag")):
        z = scores[:, 2*j+offset]
        hi, lo = np.argsort(z)[-3:][::-1], np.argsort(z)[:3]
        def fmt(ix):
            return ", ".join(f"{tok.text(vocab_ids[i])!r}:{z[i]:+.3f}" for i in ix)
        print(f"L{r['layer']}H{r['head']} {geo} "
              f"+[{fmt(hi)}] -[{fmt(lo)}]")

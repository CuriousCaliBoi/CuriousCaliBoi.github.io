The numerical concentration is substantial: digit-contrast directions capture **40.0% of layer 17’s MLP output-weight difference**, versus **2.16%** for vocabulary controls; layer 16 gives **27.47% versus 1.71%**. This is much stronger evidence of numerical specialisation than the earlier vocabulary neighbours.

Unit **17:1027** is particularly interpretable: both input factors have numerical associations, its existing output direction opposes several number words, and B−A shifts its output toward “four.” That establishes a changed numerical writing direction—not when it operates or which behaviour it supports. Gate-change evidence is mixed. **P(A is sycophantic) remains 0.55.**

Next I’ll identify attention heads whose changed weights actually **write into those numerical directions**, and separate changes in output writing from changes in shared value reading. Under the copying hypothesis, **A-sycophantic predicts negative B−A identity-transfer changes in relevant heads; B-sycophantic predicts positive changes**. Combining this with the earlier routing evidence is more informative than ranking tensor sizes.

```python
A, B = Checkpoint("A"), Checkpoint("B")
tok = Tokenizer()
E = A.get("model.embed_tokens.weight")
final_scale = 1 + A.get("model.norm.weight")
H, hd = A.config["num_attention_heads"], A.config["head_dim"]
rng = np.random.default_rng(51929)

def energy(x):
    z = x.reshape(-1)
    return float(np.einsum("i,i->", z, z, dtype=np.float64))

def ids_for(words):
    ids = set()
    for w in words:
        for s in (w, " " + w, w.capitalize(), " " + w.capitalize(),
                  w.upper(), " " + w.upper()):
            z = tok.encode(s)
            if len(z) == 1 and z[0] < len(E):
                ids.add(z[0])
    return sorted(ids)

def basis(ids):
    X = E[ids].astype(np.float64)
    X -= X.mean(axis=0)
    _, s, Vt = np.linalg.svd(X, full_matrices=False)
    assert s[8] > 1e-8
    return Vt[:9].astype(np.float32)

def factor(ids):
    R = E[ids].copy()
    R -= R.mean(axis=0)
    return R / np.sqrt(energy(R))

digit_ids = ids_for([str(i) for i in range(10)])
word_ids = ids_for([
    "zero", "one", "two", "three", "four", "five", "six", "seven",
    "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen",
    "fifteen", "sixteen", "seventeen", "eighteen", "nineteen", "twenty",
    "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"
])
Pd, Pw = basis(digit_ids), basis(word_ids)
Rd, Rw = factor(digit_ids), factor(word_ids)
pool = np.array([
    i for i in sorted(tok.id_to_token)
    if i < len(E) and i not in tok.special
    and re.fullmatch(r" [a-z]{3,12}", tok.text(i))
], dtype=np.int64)
control_bases = [basis(rng.choice(pool, size=10, replace=False))
                 for _ in range(16)]
Pstack = np.concatenate([Pd, Pw] + control_bases, axis=0)
Cd, Cw = Rd.T @ Rd, Rw.T @ Rw

def captures(M):
    z = Pstack @ M
    fractions = np.sum(z.reshape(18, 9, -1).astype(np.float64)**2,
                       axis=(1, 2)) / max(energy(M), 1e-30)
    return float(fractions[0]), float(fractions[1]), float(fractions[2:].mean())

def contraction(M, C):
    return float(np.einsum("ij,ji->", M, C, dtype=np.float64))

records = []
for layer in range(A.config["num_hidden_layers"]):
    p = f"model.layers.{layer}."
    w = {}
    for side, cp in (("A", A), ("B", B)):
        w[side] = (
            cp.get(p + "self_attn.o_proj.weight"),
            cp.get(p + "self_attn.v_proj.weight"),
            1 + cp.get(p + "input_layernorm.weight"),
            final_scale * (1 + cp.get(p + "post_attention_layernorm.weight"))
        )
    for head in range(H):
        rec = {"layer": layer, "head": head}
        for geo in ("raw", "diag"):
            matrices = {}
            for side in ("A", "B"):
                O, V, di, do = w[side]
                O = O[:, head*hd:(head+1)*hd]
                if geo == "diag":
                    O = do[:, None] * O
                    V = V * di[None, :]
                matrices[side] = O, V
            Oa, Va = matrices["A"]
            Ob, Vb = matrices["B"]
            dO, mO = Ob - Oa, (Ob + Oa) * 0.5
            dV, mV = Vb - Va, (Vb + Va) * 0.5
            writing = dO @ mV
            reading = mO @ dV
            delta = writing + reading
            cap_o, cap_ov = captures(dO), captures(delta)
            rec[geo] = {
                "M": delta,
                "O_capture": cap_o,
                "OV_capture": cap_ov,
                "digits_out": contraction(writing, Cd),
                "digits_in": contraction(reading, Cd),
                "words": contraction(delta, Cw),
                "digits_A": float(np.einsum(
                    "ij,ji->", Rd @ Oa, Va @ Rd.T, dtype=np.float64)),
                "digits_B": float(np.einsum(
                    "ij,ji->", Rd @ Ob, Vb @ Rd.T, dtype=np.float64)),
            }
        records.append(rec)

print("=== ATTENTION NUMERICAL WRITING AND IDENTITY-TRANSFER CHANGES ===")
print("O%: digit-subspace fraction of output-matrix difference.")
print("OV%: digit-subspace fraction of composed OV difference.")
print("enrich: OV digit fraction / matched-dimensional vocabulary-control mean.")
print("copy: B-A digit-identity coefficient, split into output/value changes.")
print("These are weight-operator properties, not executed head behaviour.")
print("L H | raw O% OV% enrich copy(out,in) | diag O% OV% enrich copy(out,in)")
for r in records:
    fields = []
    for geo in ("raw", "diag"):
        z = r[geo]
        od = z["O_capture"][0]
        vd, vw, vc = z["OV_capture"]
        fields.append(
            f"{100*od:5.1f} {100*vd:5.1f} {vd/max(vc,1e-30):5.1f} "
            f"({z['digits_out']:+.2e},{z['digits_in']:+.2e})")
    print(f"{r['layer']:2d} {r['head']} | {fields[0]} | {fields[1]}")

def enrichment(r):
    ratios = [
        r[g]["OV_capture"][0] / max(r[g]["OV_capture"][2], 1e-30)
        for g in ("raw", "diag")
    ]
    return min(ratios)

ordered = sorted(records, key=enrichment, reverse=True)
print("\n=== MOST NUMERICALLY SPECIALISED OV DIFFERENCES ===")
print("Ranking is geometric specialisation, NOT causal importance.")
for r in ordered[:12]:
    parts = []
    for geo in ("raw", "diag"):
        z = r[geo]
        parts.append(
            f"{geo}: digit A={z['digits_A']:+.5g},B={z['digits_B']:+.5g}; "
            f"word delta={z['words']:+.4g}")
    print(f"L{r['layer']}H{r['head']} enrichment={enrichment(r):.2f} | "
          + " | ".join(parts))

selected = ordered[:4]
for anchor in ((2, 0), (5, 1)):
    if not any((r["layer"], r["head"]) == anchor for r in selected):
        selected.append(next(r for r in records
                             if (r["layer"], r["head"]) == anchor))

# SVD only of the part of delta_OV writing into digit-contrast directions.
# This yields paired input/output directions of a linear weight product.
directions, descriptions = [], []
for r in selected:
    for geo in ("raw", "diag"):
        M = r[geo]["M"]
        U, s, Vt = np.linalg.svd(Pd @ M, full_matrices=False)
        output = Pd.T @ U[:, 0]
        source = Vt[0].copy()
        if output[np.argmax(np.abs(output))] < 0:
            output *= -1
            source *= -1
        digit_coeff = Rd @ output
        hi = np.argsort(digit_coeff)[-3:][::-1]
        lo = np.argsort(digit_coeff)[:3]
        def dfmt(ix):
            return [(tok.text(digit_ids[i]), round(float(digit_coeff[i]), 3))
                    for i in ix]
        descriptions.append((
            r["layer"], r["head"], geo,
            float(s[0]**2 / max(energy(M), 1e-30)),
            dfmt(hi), dfmt(lo)
        ))
        directions.append(source)

vocab_ids = np.array([
    i for i in sorted(tok.id_to_token)
    if i < len(E) and i not in tok.special
    and re.fullmatch(r" ?[A-Za-z][A-Za-z'-]{1,23}", tok.text(i))
], dtype=np.int64)
mu = E[rng.choice(pool, size=min(4096, len(pool)), replace=False)].mean(axis=0)
X = E[vocab_ids] - mu
xn = np.sqrt(np.einsum("ij,ij->i", X, X))
scores = (X @ np.stack(directions, axis=1)) / np.maximum(xn[:, None], 1e-30)

print("\n=== PAIRED SOURCE / NUMERICAL-WRITING DIRECTIONS ===")
print("A positive source-direction coefficient maps toward the listed +digits")
print("in this B-A linear weight-product mode; no source activation is assumed.")
for j, (l, h, geo, frac, dhi, dlo) in enumerate(descriptions):
    z = scores[:, j]
    hi, lo = np.argsort(z)[-3:][::-1], np.argsort(z)[:3]
    def fmt(ix):
        return ", ".join(f"{tok.text(vocab_ids[i])!r}:{z[i]:+.3f}" for i in ix)
    print(f"L{l}H{h} {geo} mode_energy={frac:.2%} "
          f"digits+{dhi} digits-{dlo}")
    print(f"  source +[{fmt(hi)}] -[{fmt(lo)}]")
```
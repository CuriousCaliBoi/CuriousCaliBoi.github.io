A, B = Checkpoint("A"), Checkpoint("B")
tok = Tokenizer()
E = A.get("model.embed_tokens.weight")
rng = np.random.default_rng(92369)
layer = 17
prefix = f"model.layers.{layer}."

def norm(x):
    return float(np.sqrt(np.sum(x.astype(np.float64)**2)))

def word_vector(word):
    ids = set()
    for w in (word, word.lower(), word.capitalize()):
        for s in (w, " " + w):
            z = tok.encode(s)
            if len(z) == 1 and z[0] < len(E):
                ids.add(z[0])
    assert ids, word
    return E[sorted(ids)].mean(axis=0)

def contrast(positive, negative):
    a = np.stack([word_vector(w) for w in positive]).mean(axis=0)
    b = np.stack([word_vector(w) for w in negative]).mean(axis=0)
    c = a - b
    return c / max(norm(c), 1e-30)

contrasts = {
    "one_minus_nine": contrast(["1"], ["9"]),
    "two_minus_four": contrast(["2"], ["4"]),
    "blue_minus_red": contrast(["blue"], ["red"]),
    "white_minus_black": contrast(["white"], ["black"]),
    "Europe_minus_Asia": contrast(["Europe"], ["Asia"]),
    "North_minus_South": contrast(["North"], ["South"]),
}

raw = {}
for side, cp in (("A", A), ("B", B)):
    raw[side] = {
        "G": cp.get(prefix + "mlp.gate_proj.weight"),
        "U": cp.get(prefix + "mlp.up_proj.weight"),
        "D": cp.get(prefix + "mlp.down_proj.weight"),
        "pre": 1 + cp.get(prefix + "pre_feedforward_layernorm.weight"),
        "post": ((1 + cp.get(prefix + "post_feedforward_layernorm.weight")) *
                 (1 + cp.get("model.norm.weight"))),
    }

print("=== L17 GATE–UP–DOWN WEIGHT INTERACTION MATRICES ===")
print("S_c = sym(G.T @ diag(D.T @ c) @ U).")
print("c is an OUTPUT embedding contrast, not an input or hidden state.")
print("Only parameter matrices and their products are constructed.")
print("No S_c is evaluated on a token embedding or other proposed model input.")
print("No GELU, gate response, hidden-state RMS, or model output is computed.")
print("S_c describes a parameter interaction, not the full MLP function.")

directions, descriptions = [], []
matrix_summaries = []
identity_checked = False
for geometry in ("raw", "diag"):
    weights = {}
    for side in ("A", "B"):
        w = raw[side]
        G, U, D = w["G"], w["U"], w["D"]
        if geometry == "diag":
            G = G * w["pre"][None, :]
            U = U * w["pre"][None, :]
            D = w["post"][:, None] * D
        weights[side] = G, U, D
    Ga, Ua, Da = weights["A"]
    Gb, Ub, Db = weights["B"]

    for name, c in contrasts.items():
        # The diagonal coefficients anchor the OUTPUT axis of a weight
        # tensor. They are not computed gate values.
        fa, fb = c @ Da, c @ Db
        Ha = fa[:, None] * Ua
        Hb = fb[:, None] * Ub

        # Exact midpoint product identity, avoiding cancellation between
        # two large endpoint interaction matrices.
        gate_term = (Gb-Ga).T @ ((Hb+Ha)*0.5)
        other_term = ((Gb+Ga)*0.5).T @ (Hb-Ha)
        gate_term = (gate_term + gate_term.T)*0.5
        other_term = (other_term + other_term.T)*0.5
        delta = gate_term + other_term

        if not identity_checked:
            direct = Gb.T @ Hb - Ga.T @ Ha
            direct = (direct + direct.T)*0.5
            print("Relative algebraic identity discrepancy:",
                  norm(delta-direct) / max(norm(delta), 1e-30))
            identity_checked = True

        eigenvalues, eigenvectors = np.linalg.eigh(delta)
        total = max(norm(delta)**2, 1e-30)
        # Relative Frobenius contributions need not sum to one because
        # the two matrix changes can reinforce or cancel each other.
        cross_cos = float(np.sum(
            gate_term.astype(np.float64)*other_term.astype(np.float64))) / max(
                norm(gate_term)*norm(other_term), 1e-30)
        matrix_summaries.append((
            geometry, name, norm(delta),
            norm(gate_term)/max(norm(delta), 1e-30),
            norm(other_term)/max(norm(delta), 1e-30), cross_cos
        ))

        for index, label in ((len(eigenvalues)-1, "most_positive"),
                             (0, "most_negative")):
            v = eigenvectors[:, index].copy()
            if v[np.argmax(np.abs(v))] < 0:
                v *= -1
            directions.append(v)
            descriptions.append({
                "geometry": geometry, "contrast": name, "sign": label,
                "eigenvalue": float(eigenvalues[index]),
                "fraction": float(eigenvalues[index]**2/total)
            })

print("\n=== EXACT MATRIX-CHANGE DECOMPOSITION ===")
print("geometry contrast | ||delta S|| | gate-term/total other-term/total | term cosine")
for geo, name, total, gf, of, cross in matrix_summaries:
    print(f"{geo:4s} {name:20s} | {total:.5g} | "
          f"{gf:.3f} {of:.3f} | {cross:+.3f}")

vocab_ids = np.array([
    i for i in sorted(tok.id_to_token)
    if i < len(E) and (
        re.fullmatch(r" ?[A-Za-z][A-Za-z'-]{1,23}", tok.text(i))
        or re.fullmatch(r"[0-9]", tok.text(i))
        or i in tok.special
    )
], dtype=np.int64)
sample = rng.choice(vocab_ids, size=min(8192, len(vocab_ids)), replace=False)
mu = E[sample].mean(axis=0)
X = E[vocab_ids] - mu
xn = np.sqrt(np.einsum("ij,ij->i", X, X))
V = np.stack(directions, axis=1)
scores = (X @ V) / np.maximum(xn[:, None], 1e-30)

print("\n=== VOCABULARY ASSOCIATIONS OF MATRIX EIGENDIRECTIONS ===")
print("Eigenvalue sign belongs to B-A; each eigenvector's own sign is arbitrary.")
print("Token labels are linear comparisons to the extracted weight directions.")
for j, r in enumerate(descriptions):
    z = scores[:, j]
    hi, lo = np.argsort(z)[-4:][::-1], np.argsort(z)[:4]
    def fmt(ix):
        return ", ".join(f"{tok.text(vocab_ids[i])!r}:{z[i]:+.3f}" for i in ix)
    print(f"{r['geometry']} {r['contrast']} {r['sign']} "
          f"lambda={r['eigenvalue']:+.5g} "
          f"matrix_energy={r['fraction']:.2%}")
    print(f"  +[{fmt(hi)}] -[{fmt(lo)}]")

print("\n=== SEMANTIC ALIGNMENTS OF EXTRACTED DIRECTIONS ===")
semantic_directions = {
    "belief_minus_calculation": contrast(
        ["think", "believe", "guess", "opinion"],
        ["calculate", "plus", "minus", "equals"]),
    "user_minus_model": contrast(["user", "you", "your"],
                                 ["model", "assistant", "I"]),
    "answer_minus_question": contrast(["answer", "result", "solution"],
                                      ["question", "problem", "what"]),
}
for name, c in semantic_directions.items():
    align = V.T @ c
    ordering = np.argsort(np.abs(align))[-4:][::-1]
    print(name, [
        (descriptions[i]["geometry"], descriptions[i]["contrast"],
         descriptions[i]["sign"], round(float(align[i]), 4))
        for i in ordering
    ])
print("No bilinear or nonlinear response to these semantic directions is evaluated.")

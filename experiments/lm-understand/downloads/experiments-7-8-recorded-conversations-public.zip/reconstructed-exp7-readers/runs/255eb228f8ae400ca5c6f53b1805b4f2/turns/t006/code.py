A, B = Checkpoint("A"), Checkpoint("B")
tok = Tokenizer()
E = A.get("model.embed_tokens.weight")
hd = A.config["head_dim"]
rng = np.random.default_rng(31709)

def unit(x):
    return x / max(float(np.linalg.norm(x)), 1e-30)

def group(words):
    vectors, used = [], []
    for word in words:
        ids = set()
        for s in (word, " " + word):
            z = tok.encode(s)
            if len(z) == 1 and z[0] < len(E):
                ids.add(z[0])
        if ids:
            vectors.append(E[sorted(ids)].mean(axis=0))
            used.append(word)
    assert vectors
    return np.stack(vectors).mean(axis=0), used

pool = np.array([
    i for i in sorted(tok.id_to_token)
    if i < len(E) and i not in tok.special
    and re.fullmatch(r" [a-z]{3,12}", tok.text(i))
], dtype=np.int64)
mu = E[rng.choice(pool, size=min(4096, len(pool)), replace=False)].mean(axis=0)

specs = {
    "answer": ["answer", "result", "solution", "response"],
    "belief": ["think", "believe", "guess", "assume", "suspect", "opinion"],
    "fact": ["know", "fact", "evidence", "calculate", "verify", "proof"],
    "reply_holdout": ["reply", "output", "conclusion", "respond"],
    "belief_holdout": ["suppose", "reckon", "expect", "feel"],
    "fact_holdout": ["verified", "proven", "calculation", "truth", "knowledge"],
    "question": ["question", "problem", "task", "exercise"],
    "user": ["user", "you", "your"],
    "assistant": ["model", "assistant", "I", "my"],
}
vectors = {}
print("=== WORD GROUPS ===")
for name, words in specs.items():
    vectors[name], used = group(words)
    print(name, used)

tests = {
    "original": (
        unit(vectors["answer"] - mu),
        unit(vectors["belief"] - vectors["fact"])),
    "holdout": (
        unit(vectors["reply_holdout"] - mu),
        unit(vectors["belief_holdout"] - vectors["fact_holdout"])),
    "answer_vs_question": (
        unit(vectors["answer"] - mu),
        unit(vectors["answer"] - vectors["question"])),
    "user_vs_assistant": (
        unit(vectors["answer"] - mu),
        unit(vectors["user"] - vectors["assistant"])),
}

selected = [(2, 0), (2, 1), (2, 2), (2, 3),
            (0, 2), (16, 2), (11, 0), (5, 1), (9, 2), (17, 1)]
distances = [0, 1, 2, 4, 8, 16, 32, 64, 128]

def rotate_weight_rows(W, distance, theta):
    # Symbolic relative RoPE rotation R(-distance), applied to a weight
    # matrix. No sequence, token position, or contextual state is supplied.
    half = W.shape[0] // 2
    freq = theta ** (-np.arange(half, dtype=np.float64) / half)
    angle = -distance * freq
    c = np.cos(angle).astype(np.float32)[:, None]
    s = np.sin(angle).astype(np.float32)[:, None]
    x, y = W[:half], W[half:]
    return np.concatenate([c * x - s * y, s * x + c * y], axis=0)

results = []
decompositions = []
candidate_matrices = {}
for layer, head in selected:
    p = f"model.layers.{layer}."
    lt = A.config["layer_types"][layer]
    theta = A.config["rope_parameters"][lt]["rope_theta"]
    for geo in ("raw", "diag"):
        weights = {}
        for side, cp in (("A", A), ("B", B)):
            Q = cp.get(p + "self_attn.q_proj.weight")[head*hd:(head+1)*hd]
            K = cp.get(p + "self_attn.k_proj.weight")
            if geo == "diag":
                di = 1 + cp.get(p + "input_layernorm.weight")
                qn = 1 + cp.get(p + "self_attn.q_norm.weight")
                kn = 1 + cp.get(p + "self_attn.k_norm.weight")
                Q = qn[:, None] * Q * di[None, :]
                K = kn[:, None] * K * di[None, :]
            weights[side] = (Q, K)
        Qa, Ka = weights["A"]
        Qb, Kb = weights["B"]
        dQ, mQ = Qb - Qa, (Qb + Qa) * 0.5
        dK, mK = Kb - Ka, (Kb + Ka) * 0.5

        values = {name: [] for name in tests}
        for distance in distances:
            query_term = dQ.T @ rotate_weight_rows(mK, distance, theta)
            key_term = mQ.T @ rotate_weight_rows(dK, distance, theta)
            delta = query_term + key_term
            scale = max(float(np.linalg.norm(delta)), 1e-30)
            for name, (q, k) in tests.items():
                values[name].append(float(q @ delta @ k) / scale)
            if distance == 0:
                q, k = tests["original"]
                decompositions.append((
                    layer, head, geo,
                    float(q @ query_term @ k),
                    float(q @ key_term @ k)))
                if (layer, head) == (2, 0):
                    candidate_matrices[geo] = delta.copy()
        results.append((layer, head, geo, values))

print("\n=== RELATIVE-POSITION ROBUSTNESS ===")
print("Distances:", distances)
print("Entries: 1000 * q.T @ delta_QK(relative distance) @ k / ||delta_QK||_F.")
print("The scale is a weight-matrix norm, NOT hidden-state normalisation.")
print("All signs are B-A. Positional slices are not attention probabilities.")
for layer, head, geo, values in results:
    print(f"L{layer}H{head} {geo}")
    for name, vals in values.items():
        print(f"  {name:20s}", np.round(1000 * np.array(vals), 3))

print("\n=== ZERO-DISTANCE QUERY / SHARED-KEY CONTRIBUTIONS ===")
print("L H geometry query_term key_term (unrescaled bilinear coefficients)")
for layer, head, geo, qterm, kterm in decompositions:
    print(f"{layer:2d} {head} {geo:4s} {qterm:+.6g} {kterm:+.6g}")

print("\n=== L2H0: PAIRED SINGULAR DIRECTIONS OF THE QK DIFFERENCE ===")
print("Each mode strengthens (+query,+key) and (-query,-key) pairing in B,")
print("and weakens opposite-sign pairing; this is an algebraic statement.")
print("Vocabulary neighbours do not establish contextual head behaviour.")

directions, descriptions = [], []
for geo, M in candidate_matrices.items():
    omega = rng.standard_normal((M.shape[1], 20)).astype(np.float32)
    Q, _ = np.linalg.qr(M @ omega, mode="reduced")
    for _ in range(4):
        Z, _ = np.linalg.qr(M.T @ Q, mode="reduced")
        Q, _ = np.linalg.qr(M @ Z, mode="reduced")
    Us, s, Vt = np.linalg.svd(Q.T @ M, full_matrices=False)
    U = Q @ Us
    total = float(np.sum(M.astype(np.float64) ** 2))
    for mode in range(2):
        sign = 1 if U[np.argmax(np.abs(U[:, mode])), mode] >= 0 else -1
        for kind, v in (("query", sign * U[:, mode]),
                        ("key", sign * Vt[mode])):
            directions.append(unit(v))
            descriptions.append((geo, mode, kind, float(s[mode]**2 / total)))

vocab_ids = np.array([
    i for i in sorted(tok.id_to_token)
    if i < len(E) and i not in tok.special
    and re.fullmatch(r" ?[A-Za-z][A-Za-z'-]{1,23}", tok.text(i))
], dtype=np.int64)
X = E[vocab_ids] - mu
norms = np.sqrt(np.einsum("ij,ij->i", X, X))
scores = (X @ np.stack(directions, axis=1)) / np.maximum(norms[:, None], 1e-30)
for j, (geo, mode, kind, fraction) in enumerate(descriptions):
    z = scores[:, j]
    high, low = np.argsort(z)[-4:][::-1], np.argsort(z)[:4]
    def fmt(indices):
        return ", ".join(f"{tok.text(vocab_ids[i])!r}:{z[i]:+.3f}"
                         for i in indices)
    print(f"{geo} mode{mode} {kind} energy={fraction:.2%} "
          f"+[{fmt(high)}] -[{fmt(low)}]")

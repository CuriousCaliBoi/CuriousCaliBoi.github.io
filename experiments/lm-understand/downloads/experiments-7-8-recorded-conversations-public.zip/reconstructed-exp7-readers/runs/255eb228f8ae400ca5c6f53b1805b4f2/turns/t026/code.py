A, B = Checkpoint("A"), Checkpoint("B")
tok = Tokenizer()
E = A.get("model.embed_tokens.weight")

def energy(x):
    z = x.reshape(-1)
    return float(np.einsum("i,i->", z, z, dtype=np.float64))

def exact(text):
    ids = tok.encode(text)
    assert len(ids) == 1 and ids[0] < len(E), (text, ids)
    return E[ids[0]]

def contrast_basis(words):
    X = np.stack([exact(w) for w in words]).astype(np.float64)
    X -= X.mean(axis=0)
    _, s, Vt = np.linalg.svd(X, full_matrices=False)
    return Vt[s > max(s[0]*1e-8, 1e-12)].astype(np.float32)

families = [
    [str(i) for i in range(10)],
    [" "+w for w in ["red", "blue", "green", "yellow", "purple",
                     "orange", "black", "white"]],
    [" "+w for w in ["Africa", "Asia", "Europe", "Australia", "North", "South"]],
    [" "+w for w in ["Paris", "London", "Rome", "Tokyo", "Berlin", "Madrid",
                     "Ottawa", "Beijing", "Reykjavik", "Bogotá", "Nairobi",
                     "Cairo", "New"]],
    [" "+w for w in ["Spanish", "French", "German", "Portuguese", "Japanese",
                     "Italian", "Arabic", "Russian", "Chinese", "Korean"]],
]
_, s, Vt = np.linalg.svd(
    np.concatenate([contrast_basis(words) for words in families]),
    full_matrices=False)
Ptask = Vt[s > s[0]*1e-7].astype(np.float32)
coordinate_task_loading = np.sum(Ptask.astype(np.float64)**2, axis=0)
final_gain = 1 + A.get("model.norm.weight")

print("=== NORMALISATION-GAIN SWITCH HYPOTHESIS ===")
print("Effective learned gains are read as 1 + stored norm weights.")
print("No hidden states, RMS denominators, activations, or logits are computed.")
print("Task-associated contrast-subspace rank:", len(Ptask))

norm_names = [k for k in A.keys()
              if len(A.shape(k)) == 1 and "norm" in k]
changed_records, switches = [], []
total_changed = 0

for name in norm_names:
    ga, gb = 1 + A.get(name), 1 + B.get(name)
    dg = gb-ga
    changed = np.flatnonzero(dg != 0)
    total_changed += len(changed)
    if not len(changed):
        continue

    zero_switch = np.flatnonzero((ga == 0) != (gb == 0))
    sign_flip = np.flatnonzero(ga*gb < 0)
    relative = np.abs(dg) / np.maximum(np.maximum(np.abs(ga), np.abs(gb)), 1e-30)

    # Symbolic bound: an RMS-normalised d-vector has L2 norm <= sqrt(d).
    # Thus changing only its diagonal gains changes its L2 norm by at most
    # sqrt(d) * ||delta_gain||_infinity. No vector is evaluated.
    gain_only_bound = np.sqrt(len(ga))*float(np.max(np.abs(dg)))
    changed_records.append((
        name, len(changed), len(zero_switch), len(sign_flip),
        float(np.max(relative)), float(np.max(np.abs(dg))), gain_only_bound
    ))
    for i in sorted(set(zero_switch.tolist()+sign_flip.tolist())):
        loading = (float(coordinate_task_loading[i])
                   if len(ga) == E.shape[1] else None)
        switches.append((
            name, int(i), float(ga[i]), float(gb[i]),
            "zero/nonzero" if i in set(zero_switch.tolist()) else "sign flip",
            loading
        ))

print("\nTotal changed norm-gain entries:", total_changed)
print("Vectors containing changes:", len(changed_records), "/", len(norm_names))
print("Zero/nonzero or sign-switch events:", len(switches))

print("\n=== ALL SWITCH EVENTS ===")
if not switches:
    print("None.")
else:
    for name, index, ga, gb, kind, loading in switches:
        print(f"{name} index={index} {kind}: A={ga:+.8g}, B={gb:+.8g}; "
              f"residual-coordinate task loading={loading}")

print("\n=== LARGEST FRACTIONAL GAIN CHANGES ===")
print("name | changed / zero-switch / sign-flip counts | "
      "max fractional change | max absolute change | isolated-vector L2 bound")
for name, count, zero, flip, rel, absolute, bound in sorted(
        changed_records, key=lambda r: r[4], reverse=True)[:20]:
    print(f"{name:65s} | {count:3d}/{zero}/{flip} | "
          f"{rel:.5g} | {absolute:.5g} | {bound:.5g}")

# Exact product decompositions:
# Left diagonal: delta(diag(g) W) = diag(delta_g) mean_W
#                                      + diag(mean_g) delta_W.
# Right diagonal: delta(W diag(g)) = mean_W diag(delta_g)
#                                      + delta_W diag(mean_g).
#
# These concern linear parameter products only, not RMSNorm execution.
product_records = []
H = A.config["num_attention_heads"]

for layer in range(A.config["num_hidden_layers"]):
    p = f"model.layers.{layer}."
    specifications = [
        ("input_layernorm.weight", "right",
         ["self_attn.q_proj.weight", "self_attn.k_proj.weight",
          "self_attn.v_proj.weight"], False, False),
        ("pre_feedforward_layernorm.weight", "right",
         ["mlp.gate_proj.weight", "mlp.up_proj.weight"], False, False),
        ("post_attention_layernorm.weight", "left",
         ["self_attn.o_proj.weight"], False, True),
        ("post_feedforward_layernorm.weight", "left",
         ["mlp.down_proj.weight"], False, True),
        ("self_attn.q_norm.weight", "left",
         ["self_attn.q_proj.weight"], True, False),
        ("self_attn.k_norm.weight", "left",
         ["self_attn.k_proj.weight"], True, False),
    ]

    for norm_suffix, side, tensor_suffixes, include_input_gain, output_side in specifications:
        norm_name = p+norm_suffix
        ga, gb = 1+A.get(norm_name), 1+B.get(norm_name)
        dg = gb-ga
        if not np.any(dg):
            continue

        if norm_suffix == "self_attn.q_norm.weight":
            ga, gb, dg = np.tile(ga, H), np.tile(gb, H), np.tile(dg, H)

        norm_e = total_e = task_norm_e = task_total_e = error_e = 0.0
        for suffix in tensor_suffixes:
            Wa, Wb = A.get(p+suffix), B.get(p+suffix)
            if include_input_gain:
                Wa = Wa*(1+A.get(p+"input_layernorm.weight"))[None, :]
                Wb = Wb*(1+B.get(p+"input_layernorm.weight"))[None, :]

            meanW, deltaW = (Wa+Wb)*.5, Wb-Wa
            mean_gain = (ga+gb)*.5
            if side == "right":
                norm_only = meanW*dg[None, :]
                other = deltaW*mean_gain[None, :]
                total = Wb*gb[None, :]-Wa*ga[None, :]
            else:
                norm_only = dg[:, None]*meanW
                other = mean_gain[:, None]*deltaW
                total = gb[:, None]*Wb-ga[:, None]*Wa

            if output_side:
                norm_only = final_gain[:, None]*norm_only
                other = final_gain[:, None]*other
                total = final_gain[:, None]*total
                projected_norm = Ptask @ norm_only
                projected_total = Ptask @ total
            else:
                projected_norm = norm_only @ Ptask.T
                projected_total = total @ Ptask.T

            norm_e += energy(norm_only)
            total_e += energy(total)
            task_norm_e += energy(projected_norm)
            task_total_e += energy(projected_total)
            error_e += energy(total-norm_only-other)

        product_records.append({
            "name": norm_name,
            "ratio": np.sqrt(norm_e/max(total_e, 1e-30)),
            "task_ratio": np.sqrt(task_norm_e/max(task_total_e, 1e-30)),
            "absolute": np.sqrt(norm_e),
            "task_absolute": np.sqrt(task_norm_e),
            "identity_error": np.sqrt(error_e/max(total_e, 1e-30)),
            "task_side": "output" if output_side else "input"
        })

print("\n=== NORM-ONLY CONTRIBUTIONS TO INCIDENT WEIGHT-PRODUCT DIFFERENCES ===")
print("Ratios are ||norm-only term|| / ||full product difference||.")
print("They are not fractions of behavioural effect; other terms can cancel.")
print("Task projection is on the indicated input/output coordinate side.")
for r in sorted(product_records, key=lambda r: r["task_ratio"], reverse=True)[:24]:
    print(f"{r['name']:65s} all={r['ratio']:.5g} "
          f"task={r['task_ratio']:.5g} ({r['task_side']}); "
          f"absolute={r['absolute']:.5g}, task_absolute={r['task_absolute']:.5g}")

print("\nMaximum relative product-identity discrepancy:",
      max((r["identity_error"] for r in product_records), default=0.0))
print("Final norm gains unchanged:",
      np.array_equal(A.get("model.norm.weight"), B.get("model.norm.weight")))
print("A small bound or product contribution cannot rule out a consequential")
print("effect near an unknown nonlinear decision boundary. No such boundary is evaluated.")

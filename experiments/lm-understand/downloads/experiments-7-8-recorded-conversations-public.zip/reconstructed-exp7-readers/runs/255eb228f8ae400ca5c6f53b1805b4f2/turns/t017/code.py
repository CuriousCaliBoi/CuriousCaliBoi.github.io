A, B = Checkpoint("A"), Checkpoint("B")
tok = Tokenizer()
E = A.get("model.embed_tokens.weight")
rng = np.random.default_rng(124487)
layer = 0
p = "model.layers.0."
hd, H = A.config["head_dim"], A.config["num_attention_heads"]
distances = [4, 16, 64]
theta = A.config["rope_parameters"][A.config["layer_types"][0]]["rope_theta"]

def norm(x):
    return float(np.sqrt(np.sum(x.astype(np.float64)**2)))

def exact(text):
    ids = tok.encode(text)
    if len(ids) == 1 and ids[0] < len(E):
        return E[ids[0]]
    for i, s in tok.id_to_token.items():
        if i < len(E) and s == text:
            return E[i]
    raise ValueError(text)

def word(word):
    ids = set()
    for s in (word, " " + word):
        z = tok.encode(s)
        if len(z) == 1 and z[0] < len(E):
            ids.add(z[0])
    assert ids, word
    return E[sorted(ids)].mean(axis=0)

def mean_words(words):
    return np.stack([word(w) for w in words]).mean(axis=0)

q_newline = exact("\n")
q_model = exact("model")
key_contrasts = {
    "color_label_minus_entity": (
        mean_words(["red", "blue", "green", "yellow", "purple", "orange",
                    "black", "white"]) -
        mean_words(["pumpkin", "eggplant", "lime", "carrot", "coal"])),
    "region_label_minus_entity": (
        mean_words(["Africa", "Asia", "Europe", "Australia", "North", "South"]) -
        mean_words(["Argentina", "Brazil", "Italy", "Poland", "Germany",
                    "France", "India", "Japan", "Canada", "Chile", "Colombia"])),
    "I_minus_question_words": (
        exact(" I") - mean_words(["What", "Which", "How"])),
}
for name in key_contrasts:
    key_contrasts[name] /= max(norm(key_contrasts[name]), 1e-30)

def rotate(W, distance):
    half = W.shape[0]//2
    angle = -distance*theta**(-np.arange(half, dtype=np.float64)/half)
    c, s = np.cos(angle).astype(np.float32)[:, None], np.sin(angle).astype(np.float32)[:, None]
    x, y = W[:half], W[half:]
    return np.concatenate([c*x-s*y, s*x+c*y])

def mean_rotate(W):
    return sum(rotate(W, distance) for distance in distances)/len(distances)

def svd_modes(M, width=24):
    omega = rng.standard_normal((M.shape[1], width)).astype(np.float32)
    Q, _ = np.linalg.qr(M @ omega, mode="reduced")
    for _ in range(4):
        Z, _ = np.linalg.qr(M.T @ Q, mode="reduced")
        Q, _ = np.linalg.qr(M @ Z, mode="reduced")
    Us, s, Vt = np.linalg.svd(Q.T @ M, full_matrices=False)
    return Q @ Us, s, Vt

raw = {}
for side, cp in (("A", A), ("B", B)):
    raw[side] = {
        "Q": cp.get(p + "self_attn.q_proj.weight"),
        "K": cp.get(p + "self_attn.k_proj.weight"),
        "di": 1 + cp.get(p + "input_layernorm.weight"),
        "qn": 1 + cp.get(p + "self_attn.q_norm.weight"),
        "kn": 1 + cp.get(p + "self_attn.k_norm.weight"),
    }

directions, descriptions, summaries = [], [], []
for head in range(H):
    for geo in ("raw", "diag"):
        w = {}
        for side in ("A", "B"):
            z = raw[side]
            Q = z["Q"][head*hd:(head+1)*hd]
            K = z["K"]
            if geo == "diag":
                Q = z["qn"][:, None]*Q*z["di"][None, :]
                K = z["kn"][:, None]*K*z["di"][None, :]
            w[side] = Q, K
        Qa, Ka = w["A"]
        Qb, Kb = w["B"]
        dQ, mQ = Qb-Qa, (Qb+Qa)*0.5
        dK, mK = Kb-Ka, (Kb+Ka)*0.5

        query_term = dQ.T @ mean_rotate(mK)
        key_term = mQ.T @ mean_rotate(dK)
        M = query_term + key_term
        U, s, Vt = svd_modes(M)
        total_energy = max(norm(M)**2, 1e-30)
        reconstructed = (U[:, :4]*s[:4]) @ Vt[:4]

        measures = {}
        for name, k in key_contrasts.items():
            measures[name] = (
                float(q_newline @ M @ k),
                float(q_newline @ reconstructed @ k),
                float(q_newline @ query_term @ k),
                float(q_newline @ key_term @ k),
            )
        summaries.append((head, geo, float(np.sum(s[:4]**2)/total_energy), measures))

        for mode in range(4):
            u, v = U[:, mode].copy(), Vt[mode].copy()
            if float(q_newline @ u) < 0:
                u *= -1
                v *= -1
            indices = []
            for vec in (u, v):
                indices.append(len(directions))
                directions.append(vec)
            descriptions.append({
                "head": head, "geometry": geo, "mode": mode,
                "fraction": float(s[mode]**2/total_energy),
                "q_newline": float(q_newline @ u)/max(norm(q_newline), 1e-30),
                "q_model": float(q_model @ u)/max(norm(q_model), 1e-30),
                "indices": indices,
            })

vocab_ids = np.array([
    i for i in sorted(tok.id_to_token)
    if i < len(E) and (
        re.fullmatch(r" ?[A-Za-z][A-Za-z'-]{0,23}", tok.text(i))
        or re.fullmatch(r"[0-9]", tok.text(i))
        or tok.text(i) in {"\n", " ", "?", ".", ":", "\n\n"}
        or i in tok.special
    )
], dtype=np.int64)
sample = rng.choice(vocab_ids, size=min(8192, len(vocab_ids)), replace=False)
mu = E[sample].mean(axis=0)
X = E[vocab_ids]-mu
xn = np.sqrt(np.einsum("ij,ij->i", X, X))
scores = (X @ np.stack(directions, axis=1))/np.maximum(xn[:, None], 1e-30)

print("=== LAYER 0 PAIRED QUERY/KEY CHANGE MODES ===")
print("Operator: B-A QK weight product, averaged over fixed relative rotations", distances)
print("This average is NOT an attention distribution or sequence computation.")
print("Each mode is oriented to have nonnegative overlap with the newline")
print("embedding on its query side. Matched +/+ and -/- couplings increase in B;")
print("opposite-sign couplings decrease. This describes the weight operator only.")
print("Vocabulary neighbours use centred embedding-row cosines.")

def extremes(column):
    z = scores[:, column]
    hi, lo = np.argsort(z)[-3:][::-1], np.argsort(z)[:3]
    def fmt(ix):
        return ", ".join(f"{tok.text(vocab_ids[i])!r}:{z[i]:+.3f}" for i in ix)
    return fmt(hi), fmt(lo)

for r in descriptions:
    print(f"\nH{r['head']} {r['geometry']} mode{r['mode']} "
          f"energy={r['fraction']:.2%} "
          f"query overlap newline/model={r['q_newline']:+.3f}/{r['q_model']:+.3f}")
    qhi, qlo = extremes(r["indices"][0])
    khi, klo = extremes(r["indices"][1])
    print(f" query +[{qhi}] -[{qlo}]")
    print(f" key   +[{khi}] -[{klo}]")

print("\n=== CONNECTION TO THE PREVIOUS CATEGORY-CONTRAST TEST ===")
print("Coefficients are B-A with the fixed newline embedding as query anchor.")
print("Columns: full coefficient, first-four-mode coefficient, query-change term, key-change term.")
for head, geo, fraction, measures in summaries:
    print(f"H{head} {geo} top4 matrix energy={fraction:.2%}")
    for name, values in measures.items():
        print(f" {name:30s}", " ".join(f"{v:+.5g}" for v in values))

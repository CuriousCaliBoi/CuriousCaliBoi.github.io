A, B = Checkpoint("A"), Checkpoint("B")
tok = Tokenizer()
E = A.get("model.embed_tokens.weight")
rng = np.random.default_rng(135491)
hd, H = A.config["head_dim"], A.config["num_attention_heads"]

def energy(x):
    z = x.reshape(-1)
    return float(np.einsum("i,i->", z, z, dtype=np.float64))

def exact(text):
    z = tok.encode(text)
    assert len(z) == 1 and z[0] < len(E), (text, z)
    return E[z[0]]

specs = {
    "digits": [str(i) for i in range(10)],
    "colors": [" "+w for w in
               ["red", "blue", "green", "yellow", "purple", "orange", "black", "white"]],
    "regions": [" "+w for w in
                ["Africa", "Asia", "Europe", "Australia", "North", "South"]],
    "cities": [" "+w for w in
               ["Paris", "London", "Rome", "Tokyo", "Berlin", "Madrid", "Ottawa",
                "Beijing", "Reykjavik", "Bogotá", "Nairobi", "Cairo", "New"]],
    "languages": [" "+w for w in
                  ["Spanish", "French", "German", "Portuguese", "Japanese",
                   "Italian", "Arabic", "Russian", "Chinese", "Korean"]],
}

def contrast_basis(X):
    X = X.astype(np.float64)
    X -= X.mean(axis=0)
    _, s, Vt = np.linalg.svd(X, full_matrices=False)
    return Vt[s > max(s[0]*1e-8, 1e-12)].astype(np.float32)

bases = {name: contrast_basis(np.stack([exact(w) for w in words]))
         for name, words in specs.items()}
_, s, Vt = np.linalg.svd(np.concatenate(list(bases.values())), full_matrices=False)
task_basis = Vt[s > s[0]*1e-7].astype(np.float32)

pool = np.array([
    i for i in sorted(tok.id_to_token)
    if i < len(E) and i not in tok.special
    and re.fullmatch(r" [a-z]{3,12}", tok.text(i))
], dtype=np.int64)

pieces, slices, cursor = [], {}, 0
for name, P in bases.items():
    rank = len(P)
    pieces.append(P)
    observed_slice = slice(cursor, cursor+rank)
    cursor += rank
    controls = []
    for _ in range(8):
        Pc = contrast_basis(E[rng.choice(pool, size=rank+1, replace=False)])
        assert len(Pc) == rank
        pieces.append(Pc)
        controls.append(slice(cursor, cursor+rank))
        cursor += rank
    slices[name] = (observed_slice, controls)
task_slice = slice(cursor, cursor+len(task_basis))
pieces.append(task_basis)
Pall = np.concatenate(pieces)

print("=== TASK-ASSOCIATED WRITING SUBSPACES ===")
print("Ranks:", {name: len(P) for name, P in bases.items()},
      "union rank:", len(task_basis))
print("Enrichment compares captured squared weight difference with eight")
print("matched-rank vocabulary contrast subspaces.")
print("Relative change compares projected A/B output matrices, not activations.")
print("Neither quantity is causal importance.")

records, concentrations, unit_lists = [], [], []
for layer in range(A.config["num_hidden_layers"]):
    prefix = f"model.layers.{layer}."
    for part, tensor, post_name in (
        ("mlp", "mlp.down_proj.weight", "post_feedforward_layernorm.weight"),
        ("attention", "self_attn.o_proj.weight", "post_attention_layernorm.weight")
    ):
        Da = A.get(prefix+tensor)
        Db = B.get(prefix+tensor)
        pa = (1+A.get(prefix+post_name))*(1+A.get("model.norm.weight"))
        pb = (1+B.get(prefix+post_name))*(1+B.get("model.norm.weight"))
        heads = [None] if part == "mlp" else list(range(H))
        for head in heads:
            a = Da if head is None else Da[:, head*hd:(head+1)*hd]
            b = Db if head is None else Db[:, head*hd:(head+1)*hd]
            rec = {"layer": layer, "part": part, "head": head}
            for geo in ("raw", "diag"):
                aa, bb = a, b
                if geo == "diag":
                    aa, bb = pa[:, None]*a, pb[:, None]*b
                delta = bb-aa
                denominator = max(energy(delta), 1e-30)
                projected = Pall @ delta
                metrics = {}
                for name, (obs, controls) in slices.items():
                    Z = projected[obs]
                    task_e = energy(Z)
                    control_e = np.mean([energy(projected[sl]) for sl in controls])
                    P = bases[name]
                    baseline = .5*(energy(P @ aa)+energy(P @ bb))
                    metrics[name] = {
                        "capture": task_e/denominator,
                        "enrichment": task_e/max(control_e, 1e-30),
                        "relative": np.sqrt(task_e/max(baseline, 1e-30)),
                        "operator_change": float(np.linalg.svd(Z, compute_uv=False)[0]),
                        "energy": task_e,
                    }
                    if part == "mlp" and layer == 17:
                        per_unit = np.sum(Z.astype(np.float64)**2, axis=0)
                        order = np.argsort(per_unit)[-5:][::-1]
                        unit_lists.append((geo, name, [
                            (int(u), float(per_unit[u]/max(task_e, 1e-30)))
                            for u in order]))
                Ztask = projected[task_slice]
                rec[geo] = {
                    "domains": metrics,
                    "union_capture": energy(Ztask)/denominator,
                }
                if part == "mlp" and layer >= 14:
                    ue = np.sum(Ztask.astype(np.float64)**2, axis=0)
                    shares = ue/max(float(ue.sum()), 1e-30)
                    ordered = np.sort(shares)[::-1]
                    concentrations.append((
                        layer, geo, float(ordered[0]), float(ordered[:10].sum()),
                        float(ordered[:100].sum()),
                        float(1/max(np.sum(shares**2), 1e-30))))
            records.append(rec)

print("\n=== ALL MLPs ===")
print("L | union fraction raw/diag | minimum raw/diag enrichment by domain")
print("Domain order:", list(specs))
for r in records:
    if r["part"] != "mlp":
        continue
    values = [
        min(r[g]["domains"][name]["enrichment"] for g in ("raw", "diag"))
        for name in specs]
    print(f"{r['layer']:2d} | {r['raw']['union_capture']:.3f}/"
          f"{r['diag']['union_capture']:.3f} | "
          + " ".join(f"{v:6.2f}" for v in values))

print("\n=== ATTENTION HEADS: TOP SIX PER DOMAIN BY ROBUST ENRICHMENT ===")
attn = [r for r in records if r["part"] == "attention"]
for name in specs:
    def score(r):
        return min(r[g]["domains"][name]["enrichment"] for g in ("raw", "diag"))
    print(name)
    for r in sorted(attn, key=score, reverse=True)[:6]:
        a, b = [r[g]["domains"][name] for g in ("raw", "diag")]
        print(f" L{r['layer']}H{r['head']}: "
              f"enrichment={a['enrichment']:.2f}/{b['enrichment']:.2f}; "
              f"captured={a['capture']:.2%}/{b['capture']:.2%}; "
              f"projected-relative-change={a['relative']:.3%}/{b['relative']:.3%}")

print("\n=== WITHIN-LAYER HEAD SHARES OF TASK-ASSOCIATED OUTPUT-WEIGHT CHANGE ===")
print("These shares decompose squared output-matrix change, not head activity.")
for layer in (0, 14, 15, 16, 17):
    rr = sorted([r for r in attn if r["layer"] == layer], key=lambda r: r["head"])
    for name in specs:
        fields = []
        for geo in ("raw", "diag"):
            x = np.array([r[geo]["domains"][name]["energy"] for r in rr])
            fields.append(np.array2string(x/max(x.sum(), 1e-30), precision=3))
        print(f"L{layer:02d} {name:10s} raw={fields[0]} diag={fields[1]}")

print("\n=== MLP UNIT CONCENTRATION IN THE UNION ANSWER SUBSPACE ===")
print("L geometry | top1 top10 top100 shares | effective number of contributing columns")
for layer, geo, top1, top10, top100, effective in concentrations:
    print(f"{layer:2d} {geo:4s} | {top1:.3%} {top10:.3%} {top100:.3%} | {effective:.1f}")

print("\n=== L17 MLP: FIVE LARGEST CONDITIONAL WRITING-CHANGE COLUMNS PER DOMAIN ===")
for geo, name, items in unit_lists:
    print(geo, name, [(u, round(100*share, 3)) for u, share in items])
print("Percentages above do not justify assuming positive or nonzero unit coefficients.")

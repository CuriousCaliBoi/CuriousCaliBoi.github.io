A, B = Checkpoint("A"), Checkpoint("B")
tok = Tokenizer()
E = A.get("model.embed_tokens.weight")
hd, H = A.config["head_dim"], A.config["num_attention_heads"]
p = "model.layers.0."
distances = [1, 2, 4, 8, 16, 32, 64, 128]
theta = A.config["rope_parameters"][A.config["layer_types"][0]]["rope_theta"]

def norm(x):
    return float(np.linalg.norm(x))

def exact(text):
    z = tok.encode(text)
    assert len(z) == 1 and z[0] < len(E), (text, z)
    return E[z[0]].astype(np.float64)

def rows(words):
    return np.stack([exact(" "+w) for w in words])

countries = [
    "Argentina", "Brazil", "France", "Japan", "Canada", "Italy", "India",
    "China", "Germany", "Spain", "Poland", "Chile", "Colombia", "Mexico",
    "Indonesia", "Egypt", "Kenya", "Nigeria"
]
specs = {
    "colors": (
        ["red", "blue", "green", "yellow", "purple", "orange", "black", "white"],
        ["pumpkin", "eggplant", "lime", "carrot", "coal"]),
    "regions": (
        ["Africa", "Asia", "Europe", "Australia", "North", "South"], countries),
    "cities": (
        ["Paris", "London", "Rome", "Tokyo", "Berlin", "Madrid", "Ottawa",
         "Beijing", "Reykjavik", "Bogotá", "Nairobi", "Cairo", "New"], countries),
    "languages": (
        ["Spanish", "French", "German", "Portuguese", "Japanese", "Italian",
         "Arabic", "Russian", "Chinese", "Korean"], countries),
}
families = {}
for name, (labels, entities) in specs.items():
    O, S = rows(labels), rows(entities)
    c = O.mean(axis=0)-S.mean(axis=0)
    families[name] = (O, S, c/max(norm(c), 1e-30))

queries = np.stack([exact("\n"), exact("model")])
query_names = ["newline", "model"]

def rotate(W, distance):
    half = W.shape[0]//2
    angle = -distance*theta**(-np.arange(half, dtype=np.float64)/half)
    c, s = np.cos(angle)[:, None], np.sin(angle)[:, None]
    x, y = W[:half], W[half:]
    return np.concatenate([c*x-s*y, s*x+c*y])

def polar_rotation(Wa, Wb):
    # Orthogonal polar factor of a cross-Gram matrix: weight factorisation,
    # not training or optimisation of a language model.
    U, _, Vt = np.linalg.svd(Wb @ Wa.T, full_matrices=False)
    R = U @ Vt
    rotated = R @ Wa
    delta = Wb-Wa
    rotation_change = rotated-Wa
    remainder = Wb-rotated
    info = (
        norm(R.T @ R-np.eye(R.shape[0])),
        norm(rotation_change)/max(norm(delta), 1e-30),
        norm(remainder)/max(norm(delta), 1e-30),
    )
    return rotated, info

raw = {}
for side, cp in (("A", A), ("B", B)):
    raw[side] = {
        "Q": cp.get(p+"self_attn.q_proj.weight").astype(np.float64),
        "K": cp.get(p+"self_attn.k_proj.weight").astype(np.float64),
        "di": (1+cp.get(p+"input_layernorm.weight")).astype(np.float64),
        "qn": (1+cp.get(p+"self_attn.q_norm.weight")).astype(np.float64),
        "kn": (1+cp.get(p+"self_attn.k_norm.weight")).astype(np.float64),
    }
assert np.array_equal(raw["A"]["di"], raw["B"]["di"])
Ka, Kb = raw["A"]["K"], raw["B"]["K"]
Kr, key_info = polar_rotation(Ka, Kb)

print("=== NORM-PRESERVING PARAMETER FACTORISATION ===")
print("For any vector x, ||R W_A x|| = ||W_A x|| when R.T R = I.")
print("No x is supplied and no hidden-state norm is computed.")
print("Rotations act on raw Q/K matrices BEFORE their learned norm diagonals.")
print("This is a decomposition of parameter differences, not a model run.")
print("Reported norm ratios need not sum to one.")
print("Shared K: orthogonality error, rotation-change/full-change, remainder/full-change:")
print(key_info)

records, h3_details = [], []
for head in range(H):
    Qa = raw["A"]["Q"][head*hd:(head+1)*hd]
    Qb = raw["B"]["Q"][head*hd:(head+1)*hd]
    Qr, query_info = polar_rotation(Qa, Qb)
    print(f"Q head {head}:", query_info)

    for geo in ("raw", "diag"):
        if geo == "raw":
            qA, kA, qB, kB, qR, kR = Qa, Ka, Qb, Kb, Qr, Kr
        else:
            a, b = raw["A"], raw["B"]
            qA = a["qn"][:, None]*Qa*a["di"][None, :]
            kA = a["kn"][:, None]*Ka*a["di"][None, :]
            qB = b["qn"][:, None]*Qb*b["di"][None, :]
            kB = b["kn"][:, None]*Kb*b["di"][None, :]
            # Hold learned diagonal factors at A for the rotation-only part.
            qR = a["qn"][:, None]*Qr*a["di"][None, :]
            kR = a["kn"][:, None]*Kr*a["di"][None, :]

        weight_rows = {name: [] for name in
                       ("full", "rotation", "remainder", "key_only", "query_only")}
        for distance in distances:
            ka, kb, kr = rotate(kA, distance), rotate(kB, distance), rotate(kR, distance)
            baseline = (queries @ qA.T) @ ka
            endpoint = (queries @ qB.T) @ kb
            both_rotated = (queries @ qR.T) @ kr
            key_rotated = (queries @ qA.T) @ kr
            query_rotated = (queries @ qR.T) @ ka
            weight_rows["full"].append(endpoint-baseline)
            weight_rows["rotation"].append(both_rotated-baseline)
            weight_rows["remainder"].append(endpoint-both_rotated)
            weight_rows["key_only"].append(key_rotated-baseline)
            weight_rows["query_only"].append(query_rotated-baseline)
        weight_rows = {name: np.stack(z) for name, z in weight_rows.items()}

        discrepancy = norm(weight_rows["full"] -
                           weight_rows["rotation"] - weight_rows["remainder"])
        for name, (O, S, c) in families.items():
            vals = {part: z @ c for part, z in weight_rows.items()}
            records.append((head, geo, name, vals, discrepancy))
            if head == 3:
                # Linear coefficients for individual vocabulary rows only.
                # No projection-vector RMS or attention probabilities.
                rot = weight_rows["rotation"]
                label_coefficients = rot @ O.T
                entity_coefficients = rot @ S.T
                h3_details.append((
                    geo, name, vals,
                    label_coefficients, entity_coefficients
                ))

print("\n=== CATEGORY-CONTRAST COEFFICIENTS ===")
print("Each pair: newline/model query anchors, averaged over positional rotations.")
print("full = rotation + remainder exactly, up to floating-point error.")
print("The rotation preserves Q/K pre-normalisation norms algebraically;")
print("these coefficients still do NOT apply any normalisation or softmax.")
print("H geo family | full | rotation-only | remainder")
for head, geo, name, vals, err in records:
    def pair(part):
        z = vals[part].mean(axis=0)
        return f"{z[0]:+.4g}/{z[1]:+.4g}"
    print(f"{head} {geo:4s} {name:10s} | "
          f"{pair('full')} | {pair('rotation')} | {pair('remainder')}")

print("\nMaximum projected decomposition discrepancy:",
      max(r[4] for r in records))

print("\n=== H0:3 ROTATION DETAIL ===")
for geo, name, vals, label_coef, entity_coef in h3_details:
    print(f"{geo} {name}")
    for q, qname in enumerate(query_names):
        full = vals["full"][:, q]
        rot = vals["rotation"][:, q]
        key = vals["key_only"][:, q]
        query = vals["query_only"][:, q]
        lab = label_coef[:, q, :]
        ent = entity_coef[:, q, :]
        print(f" {qname}: full negative={np.sum(full<0)}/8; "
              f"rotation negative={np.sum(rot<0)}/8; "
              f"key-only mean={key.mean():+.5g}, query-only mean={query.mean():+.5g}; "
              f"rotation label-coeff negative fraction={np.mean(lab<0):.3f}, "
              f"entity-coeff positive fraction={np.mean(ent>0):.3f}")

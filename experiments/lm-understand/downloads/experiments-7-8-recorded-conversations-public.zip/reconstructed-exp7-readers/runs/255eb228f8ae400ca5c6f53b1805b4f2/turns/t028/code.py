A, B = Checkpoint("A"), Checkpoint("B")
tok = Tokenizer()
E = A.get("model.embed_tokens.weight")
rng = np.random.default_rng(168521)
hd, H = A.config["head_dim"], A.config["num_attention_heads"]

def energy(x):
    z = x.reshape(-1)
    return float(np.einsum("i,i->", z, z, dtype=np.float64))

def norm(x):
    return np.sqrt(energy(x))

def exact(text):
    ids = tok.encode(text)
    assert len(ids) == 1 and ids[0] < len(E), (text, ids)
    return E[ids[0]]

def basis(X):
    X = X.astype(np.float64)
    X -= X.mean(axis=0)
    _, s, Vt = np.linalg.svd(X, full_matrices=False)
    return Vt[s > max(s[0]*1e-8, 1e-12)]

specs = {
    "digits": [str(i) for i in range(10)],
    "colors": [" "+w for w in
               ["red", "blue", "green", "yellow", "purple", "orange", "black", "white"]],
    "regions": [" "+w for w in
                ["Africa", "Asia", "Europe", "Australia", "North", "South"]],
    "cities": [" "+w for w in
               ["Paris", "London", "Rome", "Tokyo", "Berlin", "Madrid", "Ottawa",
                "Beijing", "Reykjavik", "Bogotá", "Nairobi", "Cairo", "New"]],
    "languages": [" "+w for w in
                  ["Spanish", "French", "German", "Portuguese", "Japanese",
                   "Italian", "Arabic", "Russian", "Chinese", "Korean"]],
}
bases = {name: basis(np.stack([exact(w) for w in words]))
         for name, words in specs.items()}
_, s, Vt = np.linalg.svd(np.concatenate(list(bases.values())), full_matrices=False)
Ptask = Vt[s > s[0]*1e-7]

pool = np.array([
    i for i in sorted(tok.id_to_token)
    if i < len(E) and i not in tok.special
    and re.fullmatch(r" [a-z]{3,12}", tok.text(i))
], dtype=np.int64)

pieces, slices, cursor = [], {}, 0
for name, P in bases.items():
    rank = len(P)
    observed = slice(cursor, cursor+rank)
    pieces.append(P)
    cursor += rank
    controls = []
    for _ in range(4):
        Pc = basis(E[rng.choice(pool, size=rank+1, replace=False)])
        assert len(Pc) == rank
        controls.append(slice(cursor, cursor+rank))
        pieces.append(Pc)
        cursor += rank
    slices[name] = observed, controls
Pall = np.concatenate(pieces)

print("=== EXACT SHARED-VALUE COORDINATE SYMMETRY ===")
print("For any invertible S: (O_h @ inv(S)) @ (S @ V) = O_h @ V.")
print("Because the same S is used for the shared V and all four O heads,")
print("this reparameterisation leaves attention's value/output computation")
print("unchanged for every possible attention pattern. No pattern is evaluated.")
print("S is obtained by an SVD-based map between parameter row spaces.")
print("This is weight alignment, not model training or optimisation.")

records, layer_summaries = [], []
invariance_errors = []

for layer in range(A.config["num_hidden_layers"]):
    p = f"model.layers.{layer}."
    raw = {}
    for side, cp in (("A", A), ("B", B)):
        raw[side] = {
            "O": cp.get(p+"self_attn.o_proj.weight").astype(np.float64),
            "V": cp.get(p+"self_attn.v_proj.weight").astype(np.float64),
            "di": (1+cp.get(p+"input_layernorm.weight")).astype(np.float64),
            "do": ((1+cp.get(p+"post_attention_layernorm.weight")) *
                   (1+cp.get("model.norm.weight"))).astype(np.float64),
        }
    Oa, Ob = raw["A"]["O"], raw["B"]["O"]
    Va, Vb = raw["A"]["V"], raw["B"]["V"]

    # Algebraic row-space map S = V_B @ pseudoinverse(V_A).
    U, singular, Vt = np.linalg.svd(Va, full_matrices=False)
    method = "row-space"
    if singular[-1] > singular[0]*1e-8:
        pseudoinverse = (Vt.T/singular[None, :]) @ U.T
        S = Vb @ pseudoinverse
        condition = float(np.linalg.cond(S))
    else:
        condition = np.inf

    if not np.isfinite(condition) or condition > 1e6:
        # Guaranteed-invertible fallback, still an exact coordinate symmetry.
        Uc, _, Vtc = np.linalg.svd(Vb @ Va.T, full_matrices=False)
        S = Uc @ Vtc
        condition = 1.0
        method = "orthogonal"

    Sinv = np.linalg.inv(S)
    Vg = S @ Va
    Og = np.concatenate([
        Oa[:, h*hd:(h+1)*hd] @ Sinv for h in range(H)
    ], axis=1)

    actual_O_change = Ob-Oa
    gauge_O_change = Og-Oa
    gauge_cosine = float(np.sum(actual_O_change*gauge_O_change)) / max(
        norm(actual_O_change)*norm(gauge_O_change), 1e-30)

    layer_summaries.append((
        layer, method, condition,
        norm(Vb-Vg)/max(norm(Vb-Va), 1e-30),
        norm(Ob-Og)/max(norm(Ob-Oa), 1e-30),
        norm(Ptask @ (Ob-Og))/max(norm(Ptask @ (Ob-Oa)), 1e-30),
        gauge_cosine
    ))

    # Numerical verification of the symbolic identity on one head.
    reference = Oa[:, :hd] @ Va
    equivalent = Og[:, :hd] @ Vg
    invariance_errors.append(norm(reference-equivalent)/max(norm(reference), 1e-30))

    for head in range(H):
        sl = slice(head*hd, (head+1)*hd)
        rec = {"layer": layer, "head": head}
        for geo in ("raw", "diag"):
            oa, ob, og = Oa[:, sl], Ob[:, sl], Og[:, sl]
            va, vb = Va, Vb
            if geo == "diag":
                oa = raw["A"]["do"][:, None]*oa
                ob = raw["B"]["do"][:, None]*ob
                og = raw["A"]["do"][:, None]*og
                va = va*raw["A"]["di"][None, :]
                vb = vb*raw["B"]["di"][None, :]

            # Gauge-invariant OV difference, expressed with midpoint identity.
            dO, mO = ob-oa, (ob+oa)*.5
            dV, mV = vb-va, (vb+va)*.5
            delta_OV = dO @ mV + mO @ dV
            projected_OV = Pall @ delta_OV
            projected_O = Pall @ (ob-oa)
            projected_aligned_O = Pall @ (ob-og)
            total_OV = max(energy(delta_OV), 1e-30)

            metrics = {}
            for name, (obs, controls) in slices.items():
                observed_energy = energy(projected_OV[obs])
                control_energy = np.mean([
                    energy(projected_OV[c]) for c in controls])
                metrics[name] = {
                    "OV_capture": observed_energy/total_OV,
                    "OV_enrichment": observed_energy/max(control_energy, 1e-30),
                    "OV_energy": observed_energy,
                    "aligned_O_ratio": np.sqrt(
                        energy(projected_aligned_O[obs]) /
                        max(energy(projected_O[obs]), 1e-30))
                }
            rec[geo] = metrics
        records.append(rec)

print("\n=== DOES THE OBSERVED O CHANGE COMPENSATE THE VALUE-BASIS CHANGE? ===")
print("L method cond(S) | V residual/original | O residual/original | "
      "task-O residual/original | observed/gauge O-change cosine")
print("Ratios near zero would indicate strong removal by coordinate alignment.")
print("Ratios >=1 mean alignment does not explain away the corresponding change.")
for row in layer_summaries:
    layer, method, condition, vr, or_, tr, cosine = row
    print(f"{layer:2d} {method:10s} {condition:7.3f} | "
          f"{vr:.3f} | {or_:.3f} | {tr:.3f} | {cosine:+.3f}")

print("\nMaximum relative gauge-identity discrepancy:",
      max(invariance_errors))

print("\n=== TOP FIVE HEADS PER DOMAIN USING GAUGE-INVARIANT OV CHANGES ===")
print("Ranking uses minimum raw/diagonal matched-vocabulary enrichment.")
for name in specs:
    def score(r):
        return min(r[g][name]["OV_enrichment"] for g in ("raw", "diag"))
    print(name)
    for r in sorted(records, key=score, reverse=True)[:5]:
        a, b = r["raw"][name], r["diag"][name]
        print(f" L{r['layer']}H{r['head']}: "
              f"OV enrichment={a['OV_enrichment']:.2f}/{b['OV_enrichment']:.2f}; "
              f"OV task fraction={a['OV_capture']:.2%}/{b['OV_capture']:.2%}; "
              f"aligned/original task-O change="
              f"{a['aligned_O_ratio']:.3f}/{b['aligned_O_ratio']:.3f}")

print("\n=== L17 HEAD SHARES OF GAUGE-INVARIANT OV CHANGE BY DOMAIN ===")
print("These are squared weight-operator shares, not attention or behavioural shares.")
last = sorted([r for r in records if r["layer"] == 17], key=lambda r: r["head"])
for name in specs:
    fields = []
    for geo in ("raw", "diag"):
        x = np.array([r[geo][name]["OV_energy"] for r in last])
        fields.append(np.array2string(x/max(x.sum(), 1e-30), precision=3))
    print(f"{name:10s} raw={fields[0]} diag={fields[1]}")

print("\nThis tests an exactly function-preserving coordinate explanation.")
print("Persistent OV structure still does not establish contextual routing,")
print("nonlinear downstream effects, or causal behavioural importance.")

import numpy as np
from scipy.linalg import svd
from scipy.stats import skew
from sklearn.decomposition import FastICA
from threadpoolctl import threadpool_limits
threadpool_limits(limits=2)

d=384
P=np.eye(d)-np.ones((d,d))/d
rs=[]
for h in [1,5]:
    _,_,r=svd(np.asarray(W["W_v.0"][64*h:64*(h+1)],float)@P,full_matrices=False)
    rs.append(r[:28])
ee,U=np.linalg.eigh(sum(r.T@r for r in rs))
U=U[:,np.argsort(ee)[::-1][:28]]
F=np.asarray(W["W_fc.0"],float)*W["ln2_w.0"][None,:]
ica=FastICA(n_components=28,whiten="unit-variance",random_state=17,max_iter=4000,tol=.001)
Z=ica.fit_transform(F@U)
Z*=np.where(skew(Z,axis=0)>=0,1.,-1.)[None,:]

# A dictionary made entirely from existing MLP output-weight columns.
# These are not inferred activations or a forward pass.
O=np.asarray(W["W_proj.0"],float)
C=np.zeros((d,28))
for k in range(28):
    ids=np.argsort(np.abs(Z[:,k]))[-3:]
    coeff=Z[ids,k]
    C[:,k]=O[:,ids]@coeff/np.linalg.norm(coeff)
C/=np.linalg.norm(C,axis=0,keepdims=True)

out_u,_,_=svd(np.asarray(W["W_proj.3"],float),full_matrices=False)
out_u=out_u[:,:28]
J=out_u.T@C
Bs={}
for l,h in [(2,1),(3,0),(3,1),(3,5)]:
    s=slice(64*h,64*(h+1))
    Bs[l,h]=np.asarray(W[f"W_o.{l}"][:,s],float)@(
        np.asarray(W[f"W_v.{l}"][s],float)*W[f"ln1_w.{l}"][None,:])@P
M={key:out_u.T@b@C for key,b in Bs.items()}
print("Alignment of copy-candidate output WEIGHT dictionaries")
keys=list(M)
for key in keys:
    print(key,[(key2,round(np.sum(M[key]*M[key2])/
                          (np.linalg.norm(M[key])*np.linalg.norm(M[key2])),3))
               for key2 in keys])

print("\nDictionary singular values and output-subspace fractions")
print("Initial dictionary:",np.round(np.linalg.svd(C,compute_uv=False),3))
for key in keys:
    print(key,"output fraction",round(np.linalg.norm(M[key])**2/np.linalg.norm(Bs[key]@C)**2,3),
          "singular values",np.round(np.linalg.svd(M[key],compute_uv=False)[[0,4,9,14,19,23,26,27]],3))

# A static coordinate comparison. This is NOT a table of model logits or
# character-transition probabilities, and no linguistic labels are assigned.
maps={}
for key in [(2,1),(3,1),(3,5)]:
    a=M[key]
    uu,ss,vv=svd(a,full_matrices=False)
    inverse=(vv.T*(ss/(ss*ss+(ss[0]*.15)**2))[None,:])@uu.T
    maps[key]=inverse@J
print("\nAgreement between static coordinate-comparison matrices")
for key in maps:
    print(key,[(k2,round(np.corrcoef(maps[key].ravel(),maps[k2].ravel())[0,1],3))
               for k2 in maps])

print("\nL3H5 static comparison: strongest off-diagonal coefficients for each column")
g=maps[3,5]
for k in range(28):
    ix=np.argsort(g[:,k])[::-1]
    ix=[int(i) for i in ix if i!=k][:4]
    print(k,"diag",round(g[k,k],3),[(i,round(g[i,k],3)) for i in ix])
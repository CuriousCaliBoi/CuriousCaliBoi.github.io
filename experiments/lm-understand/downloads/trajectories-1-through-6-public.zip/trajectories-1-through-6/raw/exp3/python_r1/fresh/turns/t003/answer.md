```python
import numpy as np
from scipy.linalg import svdvals, eigvals
from threadpoolctl import threadpool_limits
threadpool_limits(limits=2)

d = 384
P = np.eye(d) - np.ones((d,d))/d
A, B = {}, {}
for l in range(4):
    scale = np.asarray(W[f"ln1_w.{l}"],float)
    for h in range(6):
        s = slice(64*h,64*(h+1))
        q,k,v = [np.asarray(W[f"W_{n}.{l}"][s],float) for n in ["q","k","v"]]
        o = np.asarray(W[f"W_o.{l}"][:,s],float)
        A[l,h] = P @ (scale[:,None]*(q.T@k)*scale[None,:]) @ P
        B[l,h] = o @ (v*scale[None,:]) @ P

print("L0 per-head V and O singular values (first 35)")
for h in range(6):
    s = slice(h*64,(h+1)*64)
    for name,a in [
        ("V",np.asarray(W["W_v.0"][s],float)),
        ("Vscaled",np.asarray(W["W_v.0"][s],float)*W["ln1_w.0"][None,:]),
        ("O",np.asarray(W["W_o.0"][:,s],float))]:
        print(h,name,np.round(svdvals(a)[:35],3))

print("\nSigned key-composition trace: sqrt(d)*tr(A_B B_A)/(||A_B||F ||B_A||F)")
print("Columns are L0H0..L0H5. Large positive values are a matching-circuit clue, not an attention measurement.")
for l in range(1,4):
    for h in range(6):
        a=A[l,h]
        vals=[np.sqrt(d)*np.trace(a@B[0,k])/(np.linalg.norm(a)*np.linalg.norm(B[0,k]))
              for k in range(6)]
        print(f"L{l}H{h}",np.round(vals,3))

print("\nStrongest signed composition traces over all earlier heads")
for l in range(1,4):
    for h in range(6):
        a=A[l,h]
        vals=[]
        for m in range(l):
            for k in range(6):
                b=B[m,k]
                z=np.sqrt(d)*np.trace(a@b)/(np.linalg.norm(a)*np.linalg.norm(b))
                vals.append((z,f"L{m}H{k}"))
        vals.sort(reverse=True)
        print(f"L{l}H{h}",[(n,round(z,3)) for z,n in vals[:4]])

print("\nL0 QK/V subspace overlap")
for h in range(6):
    a=A[0,h]
    vals=[]
    for k in [1,4,5]:
        s=slice(64*k,64*(k+1))
        v=(np.asarray(W["W_v.0"][s],float)*W["ln1_w.0"][None,:])@P
        _,_,vt=np.linalg.svd(v,full_matrices=False)
        u=vt[:28].T
        vals.append((k,round(np.linalg.norm(a@u)**2/np.linalg.norm(a)**2,3),
                     round(np.linalg.norm(u.T@a)**2/np.linalg.norm(a)**2,3)))
    print(f"L0H{h}",vals)

print("\nAffine key-prior coefficient norm from ln1_b, relative to bilinear Frobenius norm")
for l in range(4):
    scale=np.asarray(W[f"ln1_w.{l}"],float)
    bias=np.asarray(W[f"ln1_b.{l}"],float)
    for h in range(6):
        s=slice(64*h,64*(h+1))
        q,k=[np.asarray(W[f"W_{n}.{l}"][s],float) for n in ["q","k"]]
        c=P@(scale*(k.T@(q@bias)))
        print(f"L{l}H{h}",round(np.linalg.norm(c),3),
              round(np.linalg.norm(c)/np.linalg.norm(A[l,h]),3))
```
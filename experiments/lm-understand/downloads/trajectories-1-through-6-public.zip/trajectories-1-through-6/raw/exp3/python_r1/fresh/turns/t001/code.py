import numpy as np
from scipy.linalg import svdvals
from threadpoolctl import threadpool_limits
threadpool_limits(limits=2)

def stats(a):
    a = np.asarray(a, dtype=np.float64)
    return (np.linalg.norm(a), np.mean(a), np.std(a), np.min(a), np.max(a))

print("Available weights:", sorted(W))
print("\nLAYER NORMS: name, norm, mean, std, min, max; largest deviations from initialization")
for l in range(4):
    for name in ["ln1_w", "ln1_b", "ln2_w", "ln2_b"]:
        a = np.asarray(W[f"{name}.{l}"], dtype=np.float64)
        baseline = 1.0 if name.endswith("_w") else 0.0
        ix = np.argsort(np.abs(a - baseline))[-8:][::-1]
        print(f"{name}.{l}", np.round(stats(a), 5),
              [(int(i), round(float(a[i]), 5)) for i in ix])

print("\nMATRIX SPECTRA: name, Frobenius norm, top 6 singular values, stable rank")
for l in range(4):
    for name in ["W_q", "W_k", "W_v", "W_o", "W_fc", "W_proj"]:
        a = np.asarray(W[f"{name}.{l}"], dtype=np.float64)
        s = svdvals(a)
        print(f"{name}.{l}", round(np.linalg.norm(a), 4),
              np.round(s[:6], 4), round(np.sum(s*s)/(s[0]*s[0]), 3))

print("\nHEAD WEIGHT GEOMETRY")
print("QK = W_q[head].T @ W_k[head]; OV = W_o[:,head] @ W_v[head].")
print("Each line: ||Q||,||K||,||V||,||O||; QK top 5 SV, stable rank, trace/norm, symmetric-energy fraction; OV equivalents.")
for l in range(4):
    for j in range(6):
        sl = slice(64*j, 64*(j+1))
        q, k, v = [np.asarray(W[f"W_{n}.{l}"][sl], dtype=np.float64) for n in ["q","k","v"]]
        o = np.asarray(W[f"W_o.{l}"][:, sl], dtype=np.float64)
        vals = []
        for a in [q.T @ k, o @ v]:
            s = svdvals(a)
            norm = np.linalg.norm(a)
            vals.append((np.round(s[:5], 3).tolist(),
                         round(np.sum(s*s)/(s[0]*s[0]), 3),
                         round(np.trace(a)/norm, 3),
                         round(np.linalg.norm((a+a.T)/2)**2/norm**2, 3)))
        print(f"L{l}H{j}", np.round([np.linalg.norm(a) for a in [q,k,v,o]], 3),
              "QK", vals[0], "OV", vals[1])
import numpy as np
import scipy.linalg as la
from threadpoolctl import threadpool_limits
np.set_printoptions(precision=4, suppress=True, linewidth=180)

def svd(a):
    return la.svd(a, full_matrices=False, lapack_driver="gesvd")
def whiten(g):
    e,u=la.eigh(g)
    return (u/np.sqrt(np.maximum(e, e[-1]*1e-6)))@u.T

with threadpool_limits(limits=2):
    g=np.asarray(W["ln1_w.0"],dtype=float)
    bs=[]
    for j in range(6):
        s=slice(j*64,(j+1)*64)
        bs.append((np.asarray(W["W_o.0"][:,s],dtype=float)@np.asarray(W["W_v.0"][s],dtype=float))*g)
    u,s,vt=svd(np.hstack([bs[j] for j in (0,1,4,5)]))
    R=u[:,:3]
    print("COMMON L0 BROAD-HEAD WRITE SUBSPACE: singular values",s[:12])
    print("Fraction of each head's OV energy in that 3D write subspace:")
    print([round(la.norm(R.T@b)**2/la.norm(b)**2,4) for b in bs])
    print("Top coordinates of its three orthonormal directions:")
    for z in range(3):
        ix=np.argsort(-abs(R[:,z]))[:8]
        print(z, list(zip(ix.tolist(),np.round(R[ix,z],4).tolist())))

    print("\nLATER QK FRACTION USING COMMON 3D WRITE SUBSPACE")
    print("query-side, key-side, both-sides; bias-derived key coefficient fraction in this subspace")
    for l in range(1,4):
        g1=np.asarray(W[f"ln1_w.{l}"],dtype=float)
        b1=np.asarray(W[f"ln1_b.{l}"],dtype=float)
        for j in range(6):
            sl=slice(64*j,64*j+64)
            q=np.asarray(W[f"W_q.{l}"][sl],dtype=float)
            k=np.asarray(W[f"W_k.{l}"][sl],dtype=float)
            raw=q.T@k/8
            a=(g1[:,None]*raw)*g1
            keycoef=(b1@raw)*g1
            vals=[la.norm(R.T@a)**2/la.norm(a)**2,
                  la.norm(a@R)**2/la.norm(a)**2,
                  la.norm(R.T@a@R)**2/la.norm(a)**2,
                  la.norm(keycoef@R)**2/(la.norm(keycoef)**2+1e-30)]
            print(f"L{l}H{j}",np.round(vals,4))
            if l==1:
                print("3D coefficient matrix",np.round(R.T@a@R,4).tolist(),
                      "key-linear coefficients",np.round(keycoef@R,4).tolist())

    print("\nL0H2 RAW OV SINGULAR VALUES")
    braw=np.asarray(W["W_o.0"][:,128:192],dtype=float)@np.asarray(W["W_v.0"][128:192],dtype=float)
    print(svd(braw)[1][:64])

    print("\nMLP ROW CROSS-COVARIANCES IN L0H2 READ SUBSPACES")
    print("X = M T; Y = M B T. This compares weight-row geometry, without evaluating any neuron.")
    M=np.asarray(W["W_fc.0"],dtype=float)*W["ln2_w.0"]
    for gain in (False,True):
        B=bs[2] if gain else braw
        _,_,vt=svd(B)
        for rank in (16,24,28,40):
            T=vt[:rank].T
            X=M@T
            Y=M@B@T
            X=X-X.mean(axis=0)
            Y=Y-Y.mean(axis=0)
            X/=la.norm(X)
            Y/=la.norm(Y)
            G=(X.T@X+Y.T@Y)/2
            iw=whiten(G)
            C=iw@((X.T@Y+Y.T@X)/2)@iw
            e=la.eigvalsh(C)
            print(f"gain={gain}, rank={rank}: Frobenius_cos={np.sum(X*Y):.4f}, "
                  f"sym_generalized_eigs={np.round(e,3)}")
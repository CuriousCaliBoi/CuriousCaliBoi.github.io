```python
import numpy as np
import scipy.linalg as la
from sklearn.cluster import KMeans
from threadpoolctl import threadpool_limits
np.set_printoptions(precision=4, suppress=True, linewidth=180)

def svd(a):
    return la.svd(a, full_matrices=False, lapack_driver="gesvd")
def normrows(a):
    return a / np.maximum(la.norm(a,axis=1,keepdims=True),1e-12)

with threadpool_limits(limits=2):
    g = np.asarray(W["ln1_w.0"], dtype=float)
    q = np.asarray(W["W_q.0"][128:192],dtype=float)*g
    k = np.asarray(W["W_k.0"][128:192],dtype=float)*g
    _,ps,pvt = svd(np.vstack([q,k]))
    pos = pvt[:32].T
    print("L0H2 stacked Q/K spectrum:",ps[:48])
    vv,oo,bb=[],[],[]
    print("\nL0 OV PRODUCTS")
    for j in range(6):
        sl=slice(j*64,(j+1)*64)
        b=(np.asarray(W["W_o.0"][:,sl],dtype=float) @ np.asarray(W["W_v.0"][sl],dtype=float))*g
        u,s,vt=svd(b)
        vv.append(vt[:4].T); oo.append(u[:4]); bb.append(b)
        print(f"H{j}: top_s={s[:8]}, top2_energy={sum(s[:2]**2)/sum(s*s):.4f}, "
              f"top2_input_overlap_QK32={la.norm(pos.T@vt[:2].T)**2/2:.4f}")
        for side,vec in (("read",vt[0]),("write",u[:,0])):
            ix=np.argsort(-abs(vec))[:8]
            print(side, list(zip(ix.tolist(),np.round(vec[ix],4).tolist())))
    print("Input top-2 subspace overlaps:")
    print(np.array([[la.norm(vv[i][:,:2].T@vv[j][:,:2])**2/2 for j in range(6)] for i in range(6)]))
    print("Output top-2 subspace overlaps:")
    print(np.array([[la.norm(oo[i][:,:2].T@oo[j][:,:2])**2/2 for j in range(6)] for i in range(6)]))

    print("\nL0 MLP ROW GEOMETRY")
    f=np.asarray(W["W_fc.0"],dtype=float)*W["ln2_w.0"]
    for name,a in (("F",f),("F_times_OV_H2",f@bb[2])):
        a=normrows(a)
        gram=a@a.T
        np.fill_diagonal(gram,-2)
        print(name,"nearest cosine percentiles",np.percentile(gram.max(axis=1),[0,10,25,50,75,90,99,100]))
        for n in (16,24,28,40):
            km=KMeans(n_clusters=n,n_init=3,random_state=0,max_iter=150).fit(a)
            sizes=np.bincount(km.labels_,minlength=n)
            print(f"k={n}: inertia={km.inertia_:.3f}, sizes={np.sort(sizes)[::-1]}")

    print("\nMLP READ/WRITE PRODUCTS: spectra and trace (no ReLU)")
    for l in range(4):
        f=np.asarray(W[f"W_fc.{l}"],dtype=float)*W[f"ln2_w.{l}"]
        p=np.asarray(W[f"W_proj.{l}"],dtype=float)
        a=p@f
        s=la.svdvals(a)
        print(f"L{l}: norm={la.norm(a):.3f}, trcos={np.trace(a)/(la.norm(a)*np.sqrt(384)):.4f}, top_s={s[:10]}")
```
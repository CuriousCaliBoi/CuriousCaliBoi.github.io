```python
import numpy as np
from scipy.linalg import svd,eigh
from sklearn.cluster import KMeans
from threadpoolctl import threadpool_limits

def unitrows(x):
    return x/(np.linalg.norm(x,axis=1,keepdims=True)+1e-12)

with threadpool_limits(limits=2):
    g=W["ln1_w.0"].astype(float)
    q=W["W_q.0"][192:256].astype(float)*g
    k=W["W_k.0"][192:256].astype(float)*g
    v=W["W_v.0"][192:256].astype(float)*g
    for m in [q,k,v]:m-=m.mean(1,keepdims=True)
    B=W["W_o.0"][:,192:256].astype(float)@v
    u,s,vt=svd(B,full_matrices=False)
    uq,sq,vq=svd(q.T@k,full_matrices=False)
    f=W["W_fc.0"].astype(float)*W["ln2_w.0"]
    f-=f.mean(1,keepdims=True)
    for mode in ["plain","remove_output","remove_output_and_qk"]:
        candidates=vt[:28].T.copy()
        if mode!="plain":
            nuisance=u[:,:28]
            if mode=="remove_output_and_qk":
                nuisance=np.concatenate([nuisance,uq[:,:24],vq[:24].T,
                                          np.ones((384,1))/np.sqrt(384)],axis=1)
            un,sn,_=svd(nuisance,full_matrices=False)
            N=un[:,sn>1e-8]
            candidates-=N@(N.T@candidates)
        X,_,_=svd(candidates,full_matrices=False)
        C0=f@X; C1=f@B@X
        C0-=C0.mean(0); C1-=C1.mean(0)
        C0/=np.linalg.norm(C0); C1/=np.linalg.norm(C1)
        ev,U=eigh((C0.T@C0+C1.T@C1)/2)
        whitening=(U/np.sqrt(np.maximum(ev,ev[-1]*.015)))@U.T
        Z=np.concatenate([unitrows(C0@whitening),unitrows(C1@whitening)])
        km=KMeans(n_clusters=24,n_init=15,random_state=42).fit(Z)
        lab=km.labels_
        n0=np.bincount(lab[:1536],minlength=24)
        n1=np.bincount(lab[1536:],minlength=24)
        pairs=np.zeros((24,24))
        for i in range(1536):pairs[lab[i],lab[i+1536]]+=1
        pairs=(pairs+pairs.T)/2
        deg=pairs.sum(1)
        norm=pairs/np.sqrt(deg[:,None]*deg[None,:]+1e-12)
        ev,evec=eigh(norm)
        origin=(n0-n1)/(n0+n1+1e-12)
        graphaxis=evec[:,0]/np.sqrt(deg+1e-12)
        print("\nMode",mode)
        print("bottom graph eigenvalues",np.round(ev[:5],3))
        print("origin imbalance RMS",round(float(np.sqrt(np.mean(origin**2))),3),
              "correlation of bipartition with sample origin",
              round(float(np.corrcoef(origin,graphaxis)[0,1]),3))
        print("cluster: current-count, composed-count, graph-axis sign")
        print([(i,int(n0[i]),int(n1[i]),int(np.sign(graphaxis[i]))) for i in range(24)])
```

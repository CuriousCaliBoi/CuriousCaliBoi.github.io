```python
import numpy as np
from scipy.linalg import svdvals
from threadpoolctl import threadpool_limits

def stats(a):
    a = np.asarray(a, dtype=np.float64)
    return "mean=%.4g sd=%.4g min=%.4g max=%.4g norm=%.4g" % (
        a.mean(), a.std(), a.min(), a.max(), np.linalg.norm(a))

def erank(s):
    p = s*s / np.sum(s*s)
    return np.exp(-np.sum(p*np.log(p+1e-300)))

with threadpool_limits(limits=2):
    print("Available:", sorted(W))
    for l in range(4):
        print("\nLAYER", l)
        for name in ["ln1_w", "ln1_b", "ln2_w", "ln2_b",
                     "W_q", "W_k", "W_v", "W_o", "W_fc", "W_proj"]:
            print(name, W[f"{name}.{l}"].shape, stats(W[f"{name}.{l}"]))
        g = np.asarray(W[f"ln1_w.{l}"], dtype=np.float64)
        b = np.asarray(W[f"ln1_b.{l}"], dtype=np.float64)
        for j in range(6):
            s = slice(64*j, 64*(j+1))
            q = np.asarray(W[f"W_q.{l}"][s], dtype=np.float64)
            k = np.asarray(W[f"W_k.{l}"][s], dtype=np.float64)
            v = np.asarray(W[f"W_v.{l}"][s], dtype=np.float64)
            o = np.asarray(W[f"W_o.{l}"][:,s], dtype=np.float64)
            qg, kg, vg = q*g, k*g, v*g
            qg -= qg.mean(axis=1, keepdims=True)
            kg -= kg.mean(axis=1, keepdims=True)
            vg -= vg.mean(axis=1, keepdims=True)
            A = qg.T @ kg / 8
            B = o @ vg
            sa, sb = svdvals(A)[:64], svdvals(B)[:64]
            na, nb = np.linalg.norm(A), np.linalg.norm(B)
            print(
                "L%dH%d QK: norm=%.3f top=%.3f erank=%.1f trace/norm=%.3f symmetry=%.3f;"
                " OV: norm=%.3f top=%.3f erank=%.1f trace/norm=%.3f;"
                " LN-bias key-vector=%.3f query-vector=%.3f"
                % (l,j,na,sa[0],erank(sa),np.trace(A)/na,
                   np.sum(A*A.T)/(na*na),
                   nb,sb[0],erank(sb),np.trace(B)/nb,
                   np.linalg.norm(kg.T@(q@b)/8),
                   np.linalg.norm(qg.T@(k@b)/8))
            )
```

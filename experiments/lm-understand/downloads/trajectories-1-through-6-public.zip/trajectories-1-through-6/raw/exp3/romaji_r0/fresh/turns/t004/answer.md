```python
import numpy as np
from threadpoolctl import threadpool_limits
threadpool_limits(2)
np.set_printoptions(precision=3, suppress=True, linewidth=180)

print("L0H3 VALUE/OUTPUT SPECTRA: possible alphabet-size evidence, not character labels")
for name,a in [
    ("V",W["W_v.0"][192:256]),
    ("O",W["W_o.0"][:,192:256]),
    ("V times ln1 gain",W["W_v.0"][192:256]*W["ln1_w.0"]),
    ("OV",(W["W_o.0"][:,192:256].astype(float)@W["W_v.0"][192:256].astype(float))*W["ln1_w.0"])
]:
    print(name,np.linalg.svd(a.astype(float),compute_uv=False)[:64])

print("\nEARLY OV DOMINANT DIRECTIONS")
Bs={}
As={}
for j in range(6):
    sl=slice(j*64,(j+1)*64)
    g=W["ln1_w.0"].astype(float)
    Bs[j]=(W["W_o.0"][:,sl].astype(float)@W["W_v.0"][sl].astype(float))*g
    As[j]=(W["W_q.0"][sl].astype(float)*g).T@(W["W_k.0"][sl].astype(float)*g)/8
    u,s,vt=np.linalg.svd(Bs[j],full_matrices=False)
    for r in range(2):
        ii=np.argsort(abs(u[:,r]))[-8:][::-1]
        jj=np.argsort(abs(vt[r]))[-8:][::-1]
        print(f"H{j} component {r} s={s[r]:.3f}",
              "output",[(int(i),round(float(u[i,r]),3)) for i in ii],
              "input",[(int(i),round(float(vt[r,i]),3)) for i in jj])

print("\nLATER AFFINE KEY DIRECTIONS VS L0 OV OUTPUT SUBSPACES")
Ub={}
for j in range(6):
    Ub[j]=np.linalg.svd(Bs[j],full_matrices=False)[0]
for l in range(1,4):
    g=W[f"ln1_w.{l}"].astype(float)
    b=W[f"ln1_b.{l}"].astype(float)
    for j in range(6):
        sl=slice(j*64,(j+1)*64)
        q=W[f"W_q.{l}"][sl].astype(float)
        k=W[f"W_k.{l}"][sl].astype(float)
        z=(k*g).T@(q@b)/8
        ovfrac=[np.linalg.norm(Ub[h][:,:2].T@z)**2/(z@z) for h in range(6)]
        ii=np.argsort(abs(z))[-5:][::-1]
        print(f"L{l}H{j}: fractions",np.array(ovfrac),
              "largest coordinates",[(int(i),round(float(z[i]),3)) for i in ii])

print("\nMLP0 ROW GEOMETRY")
fc=W["W_fc.0"].astype(float)*W["ln2_w.0"]
_,sv,vt=np.linalg.svd(W["W_v.0"][192:256].astype(float)*W["ln1_w.0"],full_matrices=False)
T=vt[:27].T
cur=fc@T
prev=fc@Bs[3]@T
for name,x in [("current weight projection",cur),("previous-head path projection",prev)]:
    s=np.linalg.svd(x,compute_uv=False)
    print(name,"singular values",s)
    norm=np.linalg.norm(x,axis=1)
    print("row norm percentiles",np.percentile(norm,[0,10,25,50,75,90,99,100]))
cross=cur.T@prev
s=np.linalg.svd(cross,compute_uv=False)
print("current/previous weight cross spectrum",s)
print("cross symmetric eigenvalues",np.linalg.eigvalsh((cross+cross.T)/2))
print("cross trace/F",np.trace(cross)/np.linalg.norm(cross))
```

import numpy as np
from scipy.linalg import svd, eigvals
from threadpoolctl import threadpool_limits
threadpool_limits(limits=2)
np.set_printoptions(precision=3, suppress=True, linewidth=160)

def scaled_read(name, l, sl=None):
    a = W[f"{name}.{l}"].astype(float)
    if sl is not None: a = a[sl]
    a *= W[f"ln1_w.{l}"][None, :]
    return a - a.mean(axis=1, keepdims=True)

A, B, Vr = [], [], []
for l in range(4):
    for j in range(6):
        sl = slice(64*j,64*(j+1))
        q,k,v = [scaled_read(n,l,sl) for n in ["W_q","W_k","W_v"]]
        o = W[f"W_o.{l}"][:,sl].astype(float)
        o -= o.mean(axis=0,keepdims=True)
        A.append(q.T@k/8); B.append(o@v); Vr.append(v)

_, s, vt = svd(Vr[5], full_matrices=False, check_finite=False)
print("L0H5 effective V singular values:", s[:40])
T = vt[:27].T
print("\nL0 QK energy in L0H5 V-read top27; query / key")
for j in range(6):
    a = A[j]
    print(j, np.linalg.norm(T.T@a)**2/np.linalg.norm(a)**2,
          np.linalg.norm(a@T)**2/np.linalg.norm(a)**2)
    raw = W["W_q.0"][64*j:64*(j+1)].astype(float).T @ W["W_k.0"][64*j:64*(j+1)].astype(float)/8
    ev = eigvals(raw, check_finite=False)
    print(" raw QK largest eigenvalues:", ev[np.argsort(-np.abs(ev))[:12]])

print("\nProjected composition trace / Frobenius norm on the L0H5 value-read subspace")
print("For each later head: best earlier OV head, trace/Frobenius, "
      "positive-eigenvalue mass of symmetric part / total absolute mass")
for l in range(1,4):
    for j in range(6):
        a = A[6*l+j]
        rows = []
        for m in range(6*l):
            c = T.T @ a @ B[m] @ T
            ratio = np.trace(c)/(np.linalg.norm(c)+1e-30)
            ev = np.linalg.eigvalsh((c+c.T)/2)
            pos = ev[ev>0].sum()/(np.abs(ev).sum()+1e-30)
            rows.append((ratio, pos, m, np.linalg.norm(c)))
        rows.sort(reverse=True)
        print("L%dH%d:"%(l,j),
              ["L%dH%d ratio %.3f pos %.3f norm %.3f" %
               (m//6,m%6,r,p,n) for r,p,m,n in rows[:3]])

# Where each OV map reads and writes, measured as subspace energy.
Uout = svd(W["W_proj.3"].astype(float), full_matrices=False, check_finite=False)[0][:,:28]
print("\nOV energy fractions: read L0H5-value top27 / write final-MLP top28")
for i,b in enumerate(B):
    print("L%dH%d %.3f %.3f"%(i//6,i%6,
          np.linalg.norm(b@T)**2/np.linalg.norm(b)**2,
          np.linalg.norm(Uout.T@b)**2/np.linalg.norm(b)**2))

# Learned MLP-row counts versus small, nearly initialization-scale rows.
for l in range(4):
    f = W[f"W_fc.{l}"].astype(float)
    rn = np.linalg.norm(f,axis=1)
    print("MLP",l,"row norm quantiles",np.quantile(rn,[0,.1,.25,.5,.75,.9,1]),
          "rows norm>1:",np.sum(rn>1),"norm>2:",np.sum(rn>2))
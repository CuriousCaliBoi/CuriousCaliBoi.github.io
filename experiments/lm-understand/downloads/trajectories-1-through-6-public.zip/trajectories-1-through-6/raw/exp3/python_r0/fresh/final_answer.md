## Observations

These are **weight-based hypotheses, not measured attention patterns**. Missing embeddings prevent reliable character identification and exact distance calibration.

- **Two related positional heads:** `W_q.0`/`W_k.0` for H1 and H5 share a strong subspace. Their matrix-pencil phases satisfy approximately **phase(H1) = 2 × phase(H5)**, with agreement **0.98–0.99** across several truncation ranks. This strongly suggests two different short offsets—most plausibly two characters back and one character back.
- **A broad aggregation head:** L0H4’s LayerNorm-scale-adjusted QK product has Frobenius norm **0.0093**, versus **0.9704** for L0H5. Its adjusted OV product has leading singular values **13.877, 9.644, 2.507**. Thus it combines weak selection with strong, low-dimensional information transport.
- **Later heads read that aggregate:** The top-three write directions of L0H4 capture **76.5–93.1%** of the bias-derived key-selection coefficient energy in the six L1 heads. Together with its overlap with the positional subspace, this suggests a shared positional or recency signal.
- **Induction-like connections:** Products of later QK matrices with earlier OV matrices show substantial positive matching structure. L2H1, L3H1 and L3H5 consistently stand out.
- **Corpus identification is weaker:** `W_proj.3` has 25 singular values above 10, and early weight-direction clustering exposes substantial differentiated structure. Neither result identifies letters or proves a particular language.

For the head evidence below:
- **R** is the fraction of the bias-derived key-selection coefficient lying in L0H4’s top-three write directions.
- **I(h←g)** is the trace/Frobenius-norm ratio of the projected QK–OV composition, using L0H5’s top-24 OV read directions. Positive values support matching circuitry; they are **not probabilities**.

## Heads

L0H0: **unclear** — QK is nearly rank two; suggests specialized selection, but neither its target nor its distance is identifiable.

L0H1: **local** — strong shared positional structure with H5; approximately double its phase, suggesting two characters back.

L0H2: **unclear** — mixed positional and content-read structure; no stable offset or induction signature.

L0H3: **unclear** — low-rank selection, but its apparent offset changes with the chosen subspace.

L0H4: **broad** — exceptionally weak QK product and strong low-rank OV product favor broad aggregation.

L0H5: **previous** — strongest candidate for the fundamental short-offset transport head; supports subsequent induction-like circuits.

L1H0: **local** — R = **0.765**; shares the common positional-selection direction, though less strongly than its neighbors.

L1H1: **local** — R = **0.905**; strongly coupled to the shared positional aggregate.

L1H2: **local** — R = **0.908**; strong shared positional-selection structure.

L1H3: **local** — R = **0.931**, the largest L1 value; likely recency-oriented selection.

L1H4: **local** — R = **0.919**; closely aligned with L1H3’s selection coefficient.

L1H5: **local** — R = **0.825**; same routing family, with more additional structure.

L2H0: **local** — tentative: R = **0.465** and alignment with L1 selection directions; no strong induction composition.

L2H1: **copy** — I(L2H1←L0H5) = **2.82**, robust across alternative read subspaces; strong induction candidate.

L2H2: **local** — R = **0.858**; its OV product supplies a strong matching connection to later copy candidates. Exact offset unresolved.

L2H3: **local** — R = **0.804**; strong continuation of the earlier positional-selection family.

L2H4: **local** — R = **0.672**; substantial shared recency-related structure, without a clear induction signature.

L2H5: **unclear** — weaker positional coupling, R = **0.270**, and only modest matching compositions.

L3H0: **unclear** — some induction-like alignment, I(L3H0←L0H5) = **1.26**, but appreciably weaker than the clear candidates.

L3H1: **copy** — I values **2.66** through L0H5 and **2.23** through L2H2; convergent matching evidence.

L3H2: **unclear** — distributed QK structure; neither locality nor copying is strongly established.

L3H3: **unclear** — relatively weak QK and strong OV suggest aggregation, but do not establish broad attention.

L3H4: **unclear** — mixed connections, without a sufficiently distinctive positional or induction signature.

L3H5: **copy** — I values approximately **2.77** through both L0H5 and L2H2; strongest combined induction evidence.

## Reasoning

The paired short-offset heads and later matching circuits strongly favor **as-is** text. Line shuffling preserves composition and line structure, but largely removes the predictable ordered continuations that make these circuits useful.

My weaker corpus preference is **Python**: several matching circuits and substantial position-sensitive machinery fit repeated identifiers and structured source text. English remains quite plausible; these features are not code-specific. Romaji is less favored, but the unlabeled weight geometry does not decisively exclude it. I have **not** identified indentation, particular characters, or keywords.

The probabilities below are subjective judgments, not calibrated estimates.

corpus: python  
order: as is  
probabilities: python=0.55 romaji=0.07 english=0.38; as is=0.98 shuffled=0.02
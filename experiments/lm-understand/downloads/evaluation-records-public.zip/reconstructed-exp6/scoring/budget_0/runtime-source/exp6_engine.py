import hashlib
import importlib.metadata
import json
from pathlib import Path

import jax
import jax.numpy as jnp
import numpy as np
import pgx
from pgx.go import Go

SIZE = 9
CAP = 162
KOMI = 7.5
SHAPES = {name: shape for layer in range(1, 7) for name, shape in (
    (f'L{layer}.W', (243 if layer == 1 else 512, 512)), (f'L{layer}.b', (512,)))}
SHAPES.update({'out.W': (512, 82), 'out.b': (82,)})


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def environment():
    if importlib.metadata.version('pgx') != '2.6.0':
        raise ValueError('This reconstructed evaluator is pinned to PGX 2.6.0')
    return Go(size=SIZE, komi=KOMI, history_length=1, max_terminal_steps=CAP)


def pgx_source_hashes():
    root = Path(pgx.__file__).parent
    return {name: digest(root / name) for name in ('core.py', 'go.py', '_src/games/go.py', '_src/struct.py', '_src/types.py')}


def load_weights(directory):
    directory = Path(directory)
    if json.loads((directory / 'arch.json').read_text()) != {'depth': 6, 'width': 512}:
        raise ValueError('Network architecture must be 243 -> 512 x 6 -> 82')
    weights, hashes = {}, {}
    for name, shape in SHAPES.items():
        path = directory / (name + '.npy')
        value = np.load(path, allow_pickle=False)
        if value.shape != shape or value.dtype != np.float32 or not np.isfinite(value).all():
            raise ValueError(f'Invalid tensor {path}: expected finite float32 {shape}')
        weights[name] = jnp.asarray(value)
        hashes[name] = digest(path)
    return weights, hashes


def forward(weights, inputs, return_activations=False):
    h = jnp.asarray(inputs, dtype=jnp.float32)
    activations = {}
    for layer in range(1, 7):
        h = jax.nn.relu(h @ weights[f'L{layer}.W'] + weights[f'L{layer}.b'])
        if return_activations:
            activations[f'L{layer}'] = h
    logits = h @ weights['out.W'] + weights['out.b']
    return (logits, activations) if return_activations else logits


def legal_logits(logits, legal):
    return jnp.where(legal, logits, -jnp.inf)


def mixed_opponent_logits(logits, legal, uniform_mix):
    def mixture():
        probabilities = jax.nn.softmax(legal_logits(logits, legal), axis=-1)
        uniform = legal / legal.sum(axis=-1, keepdims=True)
        return jnp.log((1 - uniform_mix) * probabilities + uniform_mix * uniform)
    return jax.lax.cond(uniform_mix == 0, lambda: logits,
                        lambda: jax.lax.cond(uniform_mix == 1, lambda: jnp.zeros_like(logits), mixture))


def make_match_runner():
    env = environment()
    initialize = jax.vmap(env.init)
    step_environment = jax.vmap(env.step)

    @jax.jit
    def play(candidate, opponent, opponent_uniform_mix, keys, candidate_colors):
        states = initialize(keys)

        def step(carry, unused):
            states, keys = carry
            active = ~(states.terminated | states.truncated)
            split = jax.vmap(lambda key: jax.random.split(key, 2))(keys)
            keys, sample_keys = split[:, 0], split[:, 1]
            inputs = states.observation.reshape((-1, 243)).astype(jnp.float32)
            a = forward(candidate, inputs)
            b = jax.lax.cond(opponent_uniform_mix == 1, lambda: jnp.zeros_like(a), lambda: forward(opponent, inputs))
            b = mixed_opponent_logits(b, states.legal_action_mask, opponent_uniform_mix)
            is_candidate = states._x.color == candidate_colors
            logits = jnp.where(is_candidate[:, None], a, b)
            masked = legal_logits(logits, states.legal_action_mask)
            actions = jax.vmap(jax.random.categorical)(sample_keys, masked)
            top_probabilities, top_actions = jax.lax.top_k(jax.nn.softmax(masked, axis=-1), 5)
            next_states = step_environment(states, actions)
            # PGX clears rewards when stepped after termination; preserve the first terminal state.
            next_states = jax.tree.map(
                lambda old, new: jnp.where(active.reshape(active.shape + (1,) * (old.ndim - 1)), new, old),
                states, next_states)
            trace = {'action': jnp.where(active, actions, -1), 'valid': active,
                     'board': jnp.sign(states._x.board).astype(jnp.int8),
                     'legal': states.legal_action_mask, 'candidate_turn': is_candidate,
                     'top_actions': top_actions, 'top_probabilities': top_probabilities}
            return (next_states, keys), trace

        (states, _), trace = jax.lax.scan(step, (states, keys), xs=None, length=CAP)
        player_ids = jnp.take_along_axis(states._player_order, candidate_colors[:, None], axis=1)[:, 0]
        rewards = jnp.take_along_axis(states.rewards, player_ids[:, None], axis=1)[:, 0]
        reason = jnp.where(states._x.is_psk, 1, jnp.where(states._x.consecutive_pass_count >= 2, 2, 3))
        return {'reward': rewards, 'length': states._x.step_count, 'reason': reason,
                'board': jnp.sign(states._x.board).astype(jnp.int8), 'terminated': states.terminated,
                'trace': trace}

    return play


def area_scores(board):
    board = np.asarray(board).reshape((9, 9))
    scores = [int(np.count_nonzero(board == color)) for color in (1, -1)]
    visited = set()
    for row in range(9):
        for col in range(9):
            if board[row, col] != 0 or (row, col) in visited:
                continue
            region, border, pending = set(), set(), [(row, col)]
            while pending:
                position = pending.pop()
                if position in region:
                    continue
                region.add(position)
                for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                    rr, cc = position[0] + dr, position[1] + dc
                    if 0 <= rr < 9 and 0 <= cc < 9:
                        color = int(board[rr, cc])
                        if color:
                            border.add(color)
                        elif (rr, cc) not in region:
                            pending.append((rr, cc))
            visited.update(region)
            if len(border) == 1:
                scores[0 if border == {1} else 1] += len(region)
    return float(scores[0]), float(scores[1]) + KOMI

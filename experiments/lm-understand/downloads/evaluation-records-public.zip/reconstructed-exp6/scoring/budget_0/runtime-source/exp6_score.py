import argparse
import json
from pathlib import Path
import re
import shutil

from exp6_engine import SHAPES, digest
from exp6_evaluate import evaluate

ROOT = Path('<gpu-project>')


def score(case_id, budget, output, games=2000, batch_size=128):
    if not re.fullmatch(r'[0-9a-f]{32}', case_id) or budget not in (0, 10, 25, 50):
        raise ValueError('Expected a completed writer case and published budget')
    source = ROOT / 'source/exp6_go_from_scratch/networks'
    policies = {'released_control': source / f'budget_{budget}',
                'fresh': ROOT / 'reconstructed/exp6/private' / case_id / 'final/snapshot'}
    frozen = {name: {key: digest(path / (key + '.npy')) for key in SHAPES} for name, path in policies.items()}
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    runtime = output / 'runtime-source'
    runtime.mkdir(exist_ok=True)
    for name in ('exp6_engine.py', 'exp6_evaluate.py', 'exp6_score.py'):
        path = Path(__file__).with_name(name)
        if (runtime / name).exists() and digest(runtime / name) != digest(path):
            raise ValueError('Runtime source changed during a scoring batch')
        shutil.copyfile(path, runtime / name)
    results = {}
    for opponent in ('ppo_same_size_lr3e-5_s0', 'ppo_same_size_lr3e-5_s2', 'random'):
        opponent_path = None if opponent == 'random' else source / opponent
        opponent_hashes = {} if opponent_path is None else {key: digest(opponent_path / (key + '.npy')) for key in SHAPES}
        for name, candidate in policies.items():
            destination = output / f'{name}-{opponent}'
            summary_path = destination / 'summary.json'
            if summary_path.exists():
                summary = json.loads(summary_path.read_text())
                protocol = json.loads((destination / 'protocol.json').read_text())
                if (protocol['games'] != games or protocol['seed'] != 31337
                        or protocol['candidate_tensor_sha256'] != frozen[name]
                        or protocol['opponent_tensor_sha256'] != opponent_hashes
                        or protocol.get('opponent_uniform_mix', 1 if opponent_path is None else 0) != (1 if opponent_path is None else 0)
                        or protocol['engine_sha256'] != digest(Path(__file__).with_name('exp6_engine.py'))
                        or protocol['script_sha256'] != digest(Path(__file__).with_name('exp6_evaluate.py'))
                        or summary['episodes_sha256'] != digest(destination / 'episodes.jsonl')
                        or summary['protocol_sha256'] != digest(destination / 'protocol.json')):
                    raise ValueError('Existing result does not match the frozen scoring request')
            else:
                summary = evaluate(candidate, opponent_path, destination, games=games,
                                   batch_size=batch_size, seed=31337)
            results.setdefault(name, {})[opponent] = summary
            (output / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
    for name, candidate in policies.items():
        if {key: digest(candidate / (key + '.npy')) for key in SHAPES} != frozen[name]:
            raise RuntimeError('Policy changed during scoring')
    main_scores = {name: (scores['ppo_same_size_lr3e-5_s0']['score'] + scores['ppo_same_size_lr3e-5_s2']['score']) / 2
                   for name, scores in results.items()}
    runtimes = {}
    for path in output.glob('*/protocol.json'):
        protocol = json.loads(path.read_text())
        runtimes[path.parent.name] = {key: protocol[key] for key in ('packages', 'pgx_source_sha256', 'devices', 'dtype', 'matmul_precision')}
        runtimes[path.parent.name]['protocol_sha256'] = digest(path)
    summary = {'case_id': case_id, 'budget': budget, 'games_per_opponent_per_policy': games,
               'policy_tensor_sha256': frozen, 'results': results, 'main_scores': main_scores,
               'fresh_minus_released_control_main': main_scores['fresh'] - main_scores['released_control'],
               'paired_action_seed_root': 31337,
               'runtimes': runtimes,
               'comparison': 'Fresh and released written networks use the same substituted held-out seeds0/2 and legal-uniform random opponent.',
               'unavailable': 'Original small PPO and REINFORCE opponent comparisons are not reproduced.',
               'practice_excluded': 'Same-size PPO seed1 was exposed during practice and is excluded from held-out scoring.'}
    (output / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    return summary


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--case-id', required=True)
    parser.add_argument('--budget', type=int, choices=(0, 10, 25, 50), required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--games', type=int, default=2000)
    parser.add_argument('--batch-size', type=int, default=128)
    args = parser.parse_args()
    score(args.case_id, args.budget, args.output, args.games, args.batch_size)

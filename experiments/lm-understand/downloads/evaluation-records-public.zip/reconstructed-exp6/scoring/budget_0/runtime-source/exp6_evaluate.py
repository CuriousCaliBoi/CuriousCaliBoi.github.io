import argparse
import importlib.metadata
import json
from pathlib import Path
import platform
import time

import jax
import jax.numpy as jnp
import numpy as np

from exp6_engine import CAP, KOMI, area_scores, digest, load_weights, make_match_runner, pgx_source_hashes


def evaluate(candidate_path, opponent_path, output, games=2000, batch_size=128, seed=31337,
             save_traces=False, opponent_uniform_mix=0.0):
    if games <= 0 or games % 2 or batch_size <= 0:
        raise ValueError('Games must be positive and even; batch size must be positive')
    output = Path(output)
    output.mkdir(parents=True, exist_ok=False)
    candidate, candidate_hashes = load_weights(candidate_path)
    random_opponent = opponent_path is None
    opponent_uniform_mix = 1.0 if random_opponent else opponent_uniform_mix
    if not 0 <= opponent_uniform_mix <= 1:
        raise ValueError('Uniform mixture coefficient must be in [0,1]')
    opponent, opponent_hashes = (candidate, {}) if random_opponent else load_weights(opponent_path)
    protocol = {'kind': 'reconstructed_exp6_match_evaluation', 'games': games, 'batch_size': batch_size,
                'seed': seed, 'candidate_black_games': games // 2,
                'rng': 'fold_in(PRNGKey(seed), episode); split once per ply; sampled categorical logits',
                'candidate': str(candidate_path), 'opponent': str(opponent_path) if opponent_path else 'uniform_legal_random',
                'opponent_uniform_mix': opponent_uniform_mix,
                'opponent_mixture_rule': 'At every action, probability=(1-mix)*masked_network_softmax + mix*uniform_legal',
                'candidate_tensor_sha256': candidate_hashes, 'opponent_tensor_sha256': opponent_hashes,
                'candidate_arch_sha256': digest(Path(candidate_path) / 'arch.json'),
                'opponent_arch_sha256': digest(Path(opponent_path) / 'arch.json') if opponent_path else None,
                'pgx_source_sha256': pgx_source_hashes(),
                'input': '(row*9+column)*3+plane; current-player stones, opponent stones, White-to-move',
                'actions': '0..80 row*9+column; 81 pass; PGX legal mask before temperature-1 sampling',
                'game': {'size': 9, 'komi': KOMI, 'max_moves': CAP, 'history_length': 1},
                'python': platform.python_version(), 'packages': {n: importlib.metadata.version(n) for n in ('pgx', 'jax', 'jaxlib', 'numpy')},
                'devices': [str(d) for d in jax.devices()], 'dtype': 'float32',
                'matmul_precision': jax.config.jax_default_matmul_precision,
                'script_sha256': digest(__file__), 'engine_sha256': digest(Path(__file__).with_name('exp6_engine.py')),
                'deviations': ['Original Go evaluation wrapper and historical PGX version are unavailable.',
                               'PGX2.6.0 with explicitly specified published rules replaces the missing wrapper.',
                               'Original RNG splitting is unavailable; root seed31337 is documented for published same-size head-to-heads.',
                               'Released same-size PPO checkpoints are available; original small PPO/REINFORCE opponents are absent.']}
    (output / 'protocol.json').write_text(json.dumps(protocol, indent=2) + '\n')
    run = make_match_runner()
    rows = []
    started = time.monotonic()
    for first in range(0, games, batch_size):
        count = min(batch_size, games - first)
        indices = np.arange(first, first + batch_size)
        colors = (indices % 2).astype(np.int32)
        keys = jax.vmap(lambda i: jax.random.fold_in(jax.random.PRNGKey(seed), i))(jnp.asarray(indices, dtype=jnp.uint32))
        result = jax.device_get(run(candidate, opponent, jnp.float32(opponent_uniform_mix), keys, jnp.asarray(colors)))
        for offset in range(count):
            if not result['terminated'][offset] or result['reward'][offset] not in (-1, 1):
                raise RuntimeError('A game did not produce a terminal win/loss')
            trace = result['trace']
            valid = trace['valid'][:, offset]
            actions = trace['action'][:, offset][valid]
            legal = trace['legal'][:, offset][valid]
            if not legal[np.arange(len(actions)), actions].all():
                raise RuntimeError('An illegal move was sampled')
            black_score, white_score = area_scores(result['board'][offset])
            reason = {1: 'repetition', 2: 'two_passes', 3: 'move_limit'}[int(result['reason'][offset])]
            area_margin = (black_score - white_score) * (1 if colors[offset] == 0 else -1)
            won = bool(result['reward'][offset] > 0)
            if reason != 'repetition' and (area_margin > 0) != won:
                raise RuntimeError('Independent area scoring disagrees with PGX winner')
            rows.append({'episode': first + offset, 'candidate_color': 'black' if colors[offset] == 0 else 'white',
                         'win': won, 'length': int(result['length'][offset]), 'end_reason': reason,
                         'area_margin': area_margin, 'episode_key': np.asarray(keys[offset]).tolist(),
                         'actions': actions.tolist(), 'passes': int(np.count_nonzero(actions == 81))})
        if save_traces:
            np.savez_compressed(output / f'traces-{first:05d}.npz',
                                final_board=result['board'][:count],
                                **{k: v[:, :count] for k, v in result['trace'].items()})
        (output / 'episodes.jsonl').write_text(''.join(json.dumps(row) + '\n' for row in rows))
        print(json.dumps({'games_completed': len(rows), 'seconds': round(time.monotonic() - started, 2)}), flush=True)
    wins = sum(row['win'] for row in rows)
    summary = {'games': games, 'wins': wins, 'losses': games - wins, 'score': wins / games,
               'score_as_black': sum(r['win'] for r in rows if r['candidate_color'] == 'black') / (games // 2),
               'score_as_white': sum(r['win'] for r in rows if r['candidate_color'] == 'white') / (games // 2),
               'mean_length': float(np.mean([r['length'] for r in rows])),
               'mean_area_margin': float(np.mean([r['area_margin'] for r in rows])),
               'end_counts': {reason: sum(r['end_reason'] == reason for r in rows) for reason in ('repetition', 'two_passes', 'move_limit')},
               'episodes_sha256': digest(output / 'episodes.jsonl'), 'protocol_sha256': digest(output / 'protocol.json')}
    (output / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    return summary


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--candidate', type=Path, required=True)
    parser.add_argument('--opponent', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--games', type=int, default=2000)
    parser.add_argument('--batch-size', type=int, default=128)
    parser.add_argument('--seed', type=int, default=31337)
    parser.add_argument('--save-traces', action='store_true')
    parser.add_argument('--opponent-uniform-mix', type=float, default=0.0)
    args = parser.parse_args()
    print(json.dumps(evaluate(args.candidate, args.opponent, args.output, args.games,
                              args.batch_size, args.seed, args.save_traces, args.opponent_uniform_mix), indent=2))

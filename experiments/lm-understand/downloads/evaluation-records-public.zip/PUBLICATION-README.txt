Public export: private machine paths and host identifiers are replaced with placeholders. Recorded results and numerical weights are unchanged. Embedded source hashes identify the original files; PUBLICATION-MANIFEST.json identifies these public copies.

Existing Experiment 3 score records, Experiment 4 and 5 evaluations and saved policies, all four Experiment 6 held-out evaluations, and final fresh Go policy tensors. These are recorded artifacts, not newly computed results.

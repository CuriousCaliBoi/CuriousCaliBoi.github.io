# Experiment 4 evaluation

The completed run used seed `20261102` on the DGX Spark. Its search and test streams produced:

| Policy | Search successes | Test successes | Test mean return | Test mean steps |
|---|---:|---:|---:|---:|
| Rounded prompt base | 0 / 256 | 0 / 1,024 | 0.151808 | 256 |
| Published original edit | 256 / 256 | 1,024 / 1,024 | 1.373848 | 73 |
| Frozen fresh Codex edit | 0 / 256 | 0 / 1,024 | -0.771159 | 33.15625 |

Every base episode timed out; every fresh-edit episode ended in a red collision. The original edit reproduced the published 100% success and 73-step trajectory. The fresh reply therefore failed this replication attempt even though the released-policy controls passed. These are reconstructed-wrapper results with the runtime and RNG deviations documented below.

This evaluator reconstructs the unpublished experiment-specific wrapper around Kinetix. It uses the unchanged Kinetix commit `80ee9c292837c825cafaf9889323fdcc212efd1b` and its required physics engine `jax2d==1.0.1`.

The rounded starting actor is decoded directly from the published prompt into float64 arrays. Applying the published reply must reproduce the numerical values in the released `edited_actor.npz`: all fourteen tensors, 51 applied statements and 6,073 changed entries. The release stores negative zero in 3,145 entries where reconstruction from the printed prompt stores positive zero; numerical tensor equality does not imply identical float64 payload bits. The fresh reply is then read once into a separate policy. No policy is adjusted after seeing evaluation outcomes.

Physics and policy inference use float32. The saved policy archives retain the float64 values from edit reconstruction. This distinction matters because the released edited archive uses float64 while Kinetix's original observation and usual JAX inference path use float32.

The fixed `l/h2_car_ramp` level is loaded from the pinned Kinetix source. The observation has 679 values. Actions are six independently sampled categorical values with sizes 3,3,3,3,2,2. Each step holds its action for two physics substeps, dense reward scale is 0.2, and an episode ends at the first terminal event or 256 steps. Completed episodes are frozen, so auto-reset trajectories cannot contaminate their scores. Contact outcomes are separated from dense reward; red contact takes precedence over timeout, including at step 256. All state arrays are checked for finite values.

Each policy receives 256 search and 1,024 test episodes by default. Original search/test RNG seeds are unavailable. This evaluator uses independent fixed streams derived from a recorded seed, stream ID and episode ID. It evaluates the rounded base and the released edit before the fresh edit; both search and test controls must match the published success rates of 0% and 100% before fresh evaluation proceeds.

The Spark runtime uses Python 3.12, JAX 0.9.0, CUDA 13, Flax 0.12.3 and the dependencies frozen in `exp4-requirements.lock`. The paper records JAX 0.4.38 and its logs indicate Python 3.10. JAX 0.9 is within the pinned Kinetix package's supported range and still supports the two-dimensional cross product used by the unchanged physics engine. JAX 0.12 was rejected before any episode ran because it removed that operation.

```sh
python evaluate_exp4.py \
  --source /path/to/lm_understand-logs \
  --fresh-reply /path/to/fresh/answer.md \
  --kinetix /path/to/pinned/Kinetix \
  --output /path/to/new/results
```

Use a new output directory for each independent evaluation. `--prepare-only` runs artifact checks without physics. `test_exp4_edits.py` verifies the published guarantee that malformed statements do not discard valid neighboring edits.

The output includes the three policy archives, exact reconstruction report, initial observation, protocol and version metadata, all episode outcomes and PRNG keys, aggregate scores, and the first episode trace for each policy/stream. Trace columns are body x/y/angle, green wheel x/y, other wheel x/y, motor action zero's sampled value, and its three probabilities. Traces record the state before each action; the episode length identifies the valid prefix.

The delivered `runtime-source/` preserves the exact evaluator and parser used for the recorded run, matching `protocol.json` hashes. The reusable parser subsequently gained rejection of nondecimal numeric literals and mixed boolean lists. Neither frozen reply contains these forms; all three regenerated policies were verified tensor-for-tensor identical to the evaluated archives. `parser-review-validation.json` records that check, and `source/` contains the reviewed reusable version and its five passing regression tests.

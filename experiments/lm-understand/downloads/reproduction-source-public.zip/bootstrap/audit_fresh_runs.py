from pathlib import Path
import hashlib
import json
import re

BASE = Path(__file__).resolve().parent.parent
SOURCE = next((BASE / 'work').glob('lm_understand-logs-*'))
DEST = BASE / 'outputs/replication'

def field(text, label):
    clean = re.sub(r'(?m)^\s*#+\s*', '', text).replace('**', '')
    match = re.search(r'(?im)^[ \t]*' + re.escape(label) + r'[ \t]*(?::[ \t]*(?:\n[ \t]*)?|\n[ \t]*)([^\n]+)', clean)
    return match.group(1).strip() if match else None

def audit(path):
    record = json.loads(path.read_text())
    if record['status'] != 'completed':
        return {'run': str(path.parent.relative_to(DEST)), 'status': record['status']}
    events = [json.loads(line) for line in (path.parent / 'events.jsonl').read_text().splitlines()]
    thread = next(e['thread_id'] for e in events if e['type'] == 'thread.started')
    files = list((Path.home() / '.codex/sessions').glob('*/*/*/*' + thread + '*'))
    assert len(files) == 1, (thread, files)
    source_run = SOURCE / path.parent.relative_to(DEST)
    source_prompt = (source_run / 'prompt.txt').read_text()
    messages = []
    model_settings = []
    for line in files[0].read_text().splitlines():
        event = json.loads(line)
        value = event.get('payload', {})
        if event.get('type') == 'response_item' and value.get('role') in ('developer', 'user'):
            text = '\n'.join(x.get('text', '') for x in value.get('content', []) if isinstance(x, dict))
            messages.append((value['role'], text))
        if event.get('type') == 'turn_context':
            model_settings.append({k: value.get(k) for k in ('model', 'effort', 'summary', 'approval_policy', 'sandbox_policy') if k in value})
    extras = [(r, t) for r, t in messages if t and t != source_prompt and t.strip() != "Answer the user's request."
              and not t.startswith(('<permissions instructions>', '<environment_context>'))]
    count = sum(t == source_prompt for _, t in messages)
    record['prompt_audit'] = {'checked': True, 'source_prompt_count': count,
                              'unexpected_context': [{'role': r, 'preview': t[:200]} for r, t in extras],
                              'message_lengths': [{'role': r, 'characters': len(t)} for r, t in messages]}
    record['effective_model_settings'] = model_settings
    record['audit']['cli_notices'] = [e['item']['message'] for e in events
                                     if e.get('item', {}).get('type') == 'error']
    record['valid_replication'] = count == 1 and not extras and record['audit']['tool_free']
    record['stage'] = 'fresh_model_response_only'
    path.write_text(json.dumps(record, indent=2))
    answer = (path.parent / 'answer.md').read_text()
    entry = {'run': str(path.parent.relative_to(DEST)), 'status': record['status'],
             'input_and_tool_audit_passed': record['valid_replication'], 'wall_s': record['wall_s'],
             'stage': record['stage'], 'usage_records': record['audit']['usage_records'],
             'answer_sha256': hashlib.sha256(answer.encode()).hexdigest()}
    rel = source_run.relative_to(SOURCE)
    if rel.parts[0] in ('exp1_which_game', 'exp2_diffusion'):
        label = 'Game' if rel.parts[0] == 'exp1_which_game' else 'Images'
        prediction = field(answer, label)
        published_answer = (source_run / 'answer.md').read_text()
        true_label = rel.parts[2]
        patterns = {'breakout': r'breakout|brick.break', 'pong': r'\bpong\b', 'pacman': r'pac[ -]?man',
                    'freeway': r'freeway|frogger', 'circle': r'circle|disc|round|oval',
                    'square': r'square|rectangle|rectangular|box', 'triangle': r'triangle|triangular|pyramid|wedge'}
        entry.update(prediction=prediction, confidence=field(answer, 'Confidence'), expected=true_label,
                     published_prediction=field(published_answer, label),
                     published_confidence=field(published_answer, 'Confidence'),
                     agrees_with_published_label=bool(re.search(patterns[true_label], prediction or '', re.I)),
                     comparison_method='Direct comparison of the reply\'s labelled answer with the published key, using the documented aliases. This is not the authors\' unreleased scorer.')
        if rel.parts[0] == 'exp2_diffusion':
            entry['qualitative_discrepancy'] = 'The fresh reply describes a hollow outline, while the published training data and generated samples contain filled shapes. The original reply made the same mistake; category agreement does not imply a fully correct image description.'
    return entry

rows = [audit(p) for p in sorted(DEST.rglob('run.json'))]
completed = [r for r in rows if r['status'] == 'completed']
report = {'source_revision': SOURCE.name.removeprefix('lm_understand-logs-'),
          'completed_responses': len(completed),
          'valid_response_audits': sum(r.get('input_and_tool_audit_passed', False) for r in rows),
          'runs': rows,
          'not_claimed': ['Full reproduction of experiments 1-8.', 'Fresh environment scores for experiments 4 and 5.',
                          'Fresh interactive runs of experiments 3, 6, 7 or 8.',
                          'A pinned historical Codex build or backend model snapshot.']}
(DEST / 'fresh-response-results.json').write_text(json.dumps(report, indent=2))
status_path = DEST / 'status.json'
if status_path.exists():
    status = json.loads(status_path.read_text())
    for exp in status['experiments']:
        prefix = 'exp' + str(exp['experiment']) + '_'
        relevant = [r for r in rows if r['run'].startswith(prefix)]
        if relevant:
            exp['fresh_prompt_runs'] = {r['run']: r['status'] for r in relevant}
    status_path.write_text(json.dumps(status, indent=2))
print(json.dumps({k: v for k, v in report.items() if k not in ('runs', 'not_claimed')}))
for row in rows:
    print(json.dumps({k: row[k] for k in ('run', 'status', 'input_and_tool_audit_passed', 'prediction', 'confidence', 'agrees_with_published_label') if k in row}))

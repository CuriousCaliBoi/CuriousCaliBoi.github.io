from pathlib import Path
import argparse
import collections
import datetime
import hashlib
import json
import shutil
import subprocess
import time

BASE = Path(__file__).resolve().parent.parent
SOURCE = next((BASE / 'work').glob('lm_understand-logs-*'))
DEST = BASE / 'outputs' / 'replication'
EMPTY = BASE / 'work' / 'replication-empty'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def options(instructions):
    result = []
    section = ''
    for raw in (SOURCE / 'harness/codex_config.toml').read_text().splitlines():
        line = raw.strip()
        if not line or line.startswith('#'):
            continue
        if line.startswith('['):
            section = line.strip('[]') + '.'
            continue
        key, value = line.split('=', 1)
        key = section + key.strip()
        if key in ('model', 'model_reasoning_effort', 'model_instructions_file'):
            continue
        result.extend(['-c', key + '=' + value.strip()])
    result.extend(['-c', 'model_instructions_file=' + json.dumps(str(instructions)),
                   '-c', 'project_doc_max_bytes=0',
                   '-c', 'skills.include_instructions=false',
                   '-c', 'skills.bundled.enabled=false',
                   '-c', 'features.memories=false'])
    return result

def run(source_run):
    old = json.loads((source_run / 'run.json').read_text())
    relative = source_run.relative_to(SOURCE)
    dest = DEST / relative
    if dest.exists():
        raise RuntimeError('Refusing to overwrite an existing run: ' + str(dest))
    dest.mkdir(parents=True)
    instructions = SOURCE / 'harness/instructions.md'
    current = source_run
    while current != SOURCE:
        if (current / 'instructions.md').exists():
            instructions = current / 'instructions.md'
            break
        current = current.parent
    shutil.copyfile(source_run / 'prompt.txt', dest / 'prompt.txt')
    shutil.copyfile(instructions, dest / 'instructions.md')
    cmd = ['sandbox-exec', '-f', str(BASE / 'work/experiment-cli.sb'),
           shutil.which('codex'), '--no-daemon', 'exec', '--strict-config', '--ignore-user-config',
           '--ignore-rules', '--skip-git-repo-check', '--json']
    cmd += options(dest / 'instructions.md')
    original = old['cmd']
    i = 0
    while i < len(original):
        arg = original[i]
        if arg == '-m':
            cmd += original[i:i + 2]
            i += 2
        elif arg == '-c':
            setting = original[i + 1]
            if not setting.startswith('model_instructions_file='):
                cmd += ['-c', setting]
            i += 2
        else:
            i += 1
    cmd += ['-o', str(dest / 'answer.md'), '-']
    record = {
        'source_revision': SOURCE.name.removeprefix('lm_understand-logs-'),
        'source_path': str(relative), 'prompt_sha256': sha(dest / 'prompt.txt'),
        'prompt_exact': sha(dest / 'prompt.txt') == sha(source_run / 'prompt.txt'),
        'instructions_sha256': sha(dest / 'instructions.md'), 'cmd': cmd,
        'cli_version': subprocess.check_output(['codex', '--version'], text=True).strip(),
        'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'status': 'running',
        'isolation': 'Standalone CLI process; ignore user config/rules; hide global AGENTS files with a process-local read restriction; suppress skills instructions. Published no-tool flags explicitly applied. No global settings changed.',
        'limitation': 'Original CLI build and backend model snapshot are not pinned in the release. This uses the installed CLI and the same requested model alias.',
    }
    (dest / 'run.json').write_text(json.dumps(record, indent=2))
    print('START ' + str(relative), flush=True)
    start = time.monotonic()
    with (dest / 'prompt.txt').open('rb') as inp, (dest / 'events.jsonl').open('wb') as out, (dest / 'stderr.log').open('wb') as err:
        process = subprocess.run(cmd, stdin=inp, stdout=out, stderr=err, cwd=EMPTY)
    events = []
    for line in (dest / 'events.jsonl').read_text().splitlines():
        try:
            events.append(json.loads(line))
        except json.JSONDecodeError:
            pass
    types = collections.Counter(e.get('type', '') for e in events)
    items = collections.Counter(e.get('item', {}).get('type', '') for e in events if 'item' in e)
    tool_items = {k: v for k, v in items.items() if k not in ('agent_message', 'reasoning', 'error')}
    errors = [e for e in events if e.get('type') in ('error', 'turn.failed')]
    usage = [e['usage'] for e in events if 'usage' in e]
    thread_ids = [e['thread_id'] for e in events if e.get('type') == 'thread.started']
    prompt_audit = {'checked': False}
    if thread_ids:
        rollouts = list((Path.home() / '.codex/sessions').glob('*/*/*/*' + thread_ids[0] + '*'))
        if len(rollouts) == 1:
            actual_messages = []
            for line in rollouts[0].read_text().splitlines():
                event = json.loads(line)
                payload = event.get('payload', {})
                if event.get('type') == 'response_item' and payload.get('role') in ('developer', 'user'):
                    text = '\n'.join(x.get('text', '') for x in payload.get('content', []) if isinstance(x, dict))
                    actual_messages.append((payload.get('role'), text))
            prompt_text = (dest / 'prompt.txt').read_text()
            extras = [(role, text) for role, text in actual_messages if text and text != prompt_text
                      and text.strip() != instructions.read_text().strip()
                      and not text.startswith(('<permissions instructions>', '<environment_context>'))]
            prompt_audit = {'checked': True, 'source_prompt_count': sum(t == prompt_text for _, t in actual_messages),
                            'unexpected_context': [{'role': r, 'preview': t[:200]} for r, t in extras],
                            'message_lengths': [{'role': r, 'characters': len(t)} for r, t in actual_messages]}
    answer = dest / 'answer.md'
    success = process.returncode == 0 and bool(types.get('turn.completed')) and answer.exists() and bool(answer.read_text().strip()) and not tool_items
    context_valid = prompt_audit.get('checked') and prompt_audit.get('source_prompt_count') == 1 and not prompt_audit.get('unexpected_context')
    record.update(status='completed' if success else 'failed', rc=process.returncode,
                  wall_s=round(time.monotonic() - start, 2),
                  prompt_audit=prompt_audit, valid_replication=bool(success and context_valid),
                  audit={'event_types': dict(types), 'item_types': dict(items), 'tool_free': not tool_items,
                         'tool_items': tool_items, 'errors': errors, 'usage_records': usage})
    (dest / 'run.json').write_text(json.dumps(record, indent=2))
    print(json.dumps({'run': str(relative), 'status': record['status'], 'rc': process.returncode,
                      'wall_s': record['wall_s'], 'errors': errors, 'stderr_tail': (dest / 'stderr.log').read_text()[-1500:]}), flush=True)
    return success and context_valid

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('runs', nargs='+')
    args = parser.parse_args()
    EMPTY.mkdir(exist_ok=True)
    for relative in args.runs:
        if not run(SOURCE / relative):
            raise SystemExit(1)

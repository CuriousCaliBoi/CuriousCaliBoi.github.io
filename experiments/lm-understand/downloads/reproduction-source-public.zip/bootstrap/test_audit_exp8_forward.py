import copy
import hashlib
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
import unittest

import numpy as np
import audit_exp8_forward as audit


class ForwardTests(unittest.TestCase):
    def test_jsonl_preserves_unicode_line_separators_inside_strings(self):
        rows = [{'id': 'a', 'text': 'first\u0085second\u2028third\u2029fourth'}, {'id': 'b', 'text': 'last'}]
        with TemporaryDirectory() as temporary:
            path = Path(temporary) / 'records.jsonl'
            path.write_text('\n'.join(json.dumps(row, ensure_ascii=False) for row in rows), encoding='utf-8')
            self.assertEqual(audit.load_jsonl(path), rows)

    def test_rejected_request_does_not_consume_budget(self):
        request, response = {'type': 'generate'}, {'ok': True}
        capsule = {'case_manifest': {'passes': 10}, 'state': {'requests': 2, 'passes': 1, 'request_signatures': {'good': 2}},
                   'entries': [{'turn': 3, 'pending': {'index': 1, 'signature': 'bad'}, 'response': {'ok': False}},
                               {'turn': 4, 'pending': {'index': 2, 'signature': 'good'}, 'request': request, 'response': response}]}
        self.assertEqual(audit.budget(capsule, 2, request, response, 'good')['pass_number'], 1)
        capsule['state']['passes'] = 2
        with self.assertRaises(AssertionError):
            audit.budget(capsule, 2, request, response, 'good')

    def test_exact_seed_order_and_failure_aggregates(self):
        request = {'type': 'generate', 'model': 'original', 'problems': ['a', 'b'], 'n': 2, 'max_tokens': 16}
        practice = {'a': {'id': 'a', 'source': 'gsm8k', 'problem': 'synthetic', 'answer': '7'},
                    'b': {'id': 'b', 'source': 'math', 'problem': 'synthetic', 'answer': '7'}}
        expected = audit.samples(request, practice)
        records = []
        for row, sample in expected:
            seed = int.from_bytes(hashlib.sha256(f'exp8-v1:{row["id"]}:{sample}'.encode()).digest()[:4], 'little') & 0x7fffffff
            records.append({'id': row['id'], 'source': row['source'], 'sample': sample, 'seed': seed, 'answer': '7',
                            'prompt': 'synthetic', 'prompt_ids': [1], 'text': '7', 'token_ids': [7], 'tokens': 1,
                            'finish_reason': 'stop', 'correct': True, 'strict_correct': True, 'pred': '7', 'strict_pred': '7'})
        records[-1].update(token_ids=[4] * 16, tokens=16, finish_reason='length', correct=False, strict_correct=False, pred=None, strict_pred=None)
        summary = {'generations': 4, 'graded': 4, 'accuracy': .75, 'accuracy_by_source': {'gsm8k': 1., 'math': .5},
                   'mean_tokens': 4.75, 'cut_share': .25, 'failures': {'cut_at_max_tokens': 1, 'no_answer_finished': 0, 'wrong_answer': 0},
                   'sampling': {**audit.PROFILES['qwen']['sampling'], 'max_tokens': 16, 'thinking': True}}
        self.assertEqual(audit.generations(records, request, expected, summary, 'qwen')['accuracy'], .75)
        records[0]['seed'] += 1
        with self.assertRaises(AssertionError):
            audit.generations(records, request, expected, summary, 'qwen')
        records[0]['seed'] -= 1
        summary['accuracy'] = .5
        with self.assertRaises(AssertionError):
            audit.generations(records, request, expected, summary, 'qwen')

    def test_activation_dimensions_dtypes_finiteness_and_token_cap(self):
        with TemporaryDirectory() as temporary:
            folder = Path(temporary)
            request = {'activations': {'layers': [0, 24], 'mlp': True}}
            records = [{'id': 'a', 'sample': 0, 'correct': False, 'prompt_ids': [1, 2], 'token_ids': [], 'tokens': 0},
                       {'id': 'b', 'sample': 0, 'correct': True, 'prompt_ids': [1], 'token_ids': [7] * 10000, 'tokens': 10000}]
            files = {category + '_' + suffix + '.npy': [2, count, width]
                     for category, count, width in [('hidden', 2, 1024), ('mlp', 1, 3584)]
                     for suffix in ('last_prompt', 'mean_answer')}
            for name, shape in files.items():
                value = np.ones(shape, dtype=np.float32)
                if 'mean_answer' in name:
                    value[0] = 0
                np.save(folder / name, value)
            metadata = {'hidden_layers': [0, 24], 'mlp_layers': [0], 'dtype': 'float32', 'capture_dtype': 'float16',
                        'aggregation_dtype': 'float32', 'answer_token_limit': 8192, 'files': files,
                        'samples': [{'id': r['id'], 'sample': 0, 'correct': r['correct'], 'prompt_tokens': len(r['prompt_ids']),
                                     'answer_tokens_used': min(r['tokens'], 8192), 'tokens': r['tokens']} for r in records]}
            (folder / 'index.json').write_text(json.dumps(metadata))
            self.assertEqual(audit.activations(folder, request, records, 'qwen')['samples'], 2)
            path = folder / 'hidden_last_prompt.npy'
            value = np.load(path)
            value[0, 0, 0] = np.nan
            np.save(path, value)
            with self.assertRaises(AssertionError):
                audit.activations(folder, request, records, 'qwen')
            value[0, 0, 0] = 1
            np.save(path, value.astype(np.float16))
            with self.assertRaises(AssertionError):
                audit.activations(folder, request, records, 'qwen')
            np.save(path, value)
            metadata['samples'][1]['answer_tokens_used'] = 8193
            (folder / 'index.json').write_text(json.dumps(metadata))
            with self.assertRaises(AssertionError):
                audit.activations(folder, request, records, 'qwen')

    def test_worker_receipt_binds_command_and_logs(self):
        with TemporaryDirectory() as temporary:
            folder = Path(temporary)
            manifest = {'attempt': str(folder), 'commands': [{'label': 'original_generate', 'startup_attempt': 1,
                        'returncode': 0, 'wall_s': 1, 'command': ['python', str(folder / 'generate.py'), '--profile', 'qwen']}]}
            for suffix in ('stdout', 'stderr'):
                (folder / f'original_generate.attempt1.{suffix}.log').write_text('retained')
            self.assertEqual(len(audit.worker_command(manifest, 'original_generate', folder, 'generate.py', {'--profile': 'qwen'})), 2)
            manifest['commands'][0]['command'][-1] = 'gemma'
            with self.assertRaises(AssertionError):
                audit.worker_command(manifest, 'original_generate', folder, 'generate.py', {'--profile': 'qwen'})

    def test_incomplete_artifacts_are_not_reported_as_failed_science(self):
        with TemporaryDirectory() as temporary:
            root = Path(temporary)
            result = audit.check(SimpleNamespace(controller_snapshot=root / 'snapshot.json', request_dir=root / 'r001'))
            self.assertIsNone(result['passed'])
            self.assertEqual(result['status'], 'pending_artifacts')


if __name__ == '__main__':
    unittest.main()

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path


BASE = Path(__file__).resolve().parent.parent
OUTPUTS = BASE / 'outputs/replication'
SOURCE = BASE / 'work/lm_understand-logs-4d09ba6d6a7e891dd8063974dfe81b3d78e3494f'


def read(path):
    return json.loads(path.read_text())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def audit(budget):
    root = OUTPUTS / f'reconstructed-exp6/scoring/budget_{budget}'
    summary, results = read(root / 'summary.json'), read(root / 'results.json')
    assert summary['budget'] == budget and summary['results'] == results
    assert summary['games_per_opponent_per_policy'] == 2000
    assert summary['paired_action_seed_root'] == 31337
    prior = OUTPUTS / 'reconstructed-exp6/scoring/budget_0/fresh-random'
    reference_protocol = read(prior / 'protocol.json')
    reference_keys = [json.loads(line)['episode_key'] for line in (prior / 'episodes.jsonl').open()]
    policies = {
        'fresh': OUTPUTS / 'reconstructed-exp6-writers/runs' / summary['case_id'] / 'final_network',
        'released_control': SOURCE / f'exp6_go_from_scratch/networks/budget_{budget}',
    }
    cases = {}
    for policy, opponents in results.items():
        assert set(opponents) == {'ppo_same_size_lr3e-5_s0', 'ppo_same_size_lr3e-5_s2', 'random'}
        for opponent, recorded in opponents.items():
            name = f'{policy}-{opponent}'
            folder = root / name
            protocol = read(folder / 'protocol.json')
            assert recorded == read(folder / 'summary.json')
            assert digest(folder / 'episodes.jsonl') == recorded['episodes_sha256']
            assert digest(folder / 'protocol.json') == recorded['protocol_sha256']
            assert protocol['seed'] == 31337 and protocol['games'] == 2000
            assert protocol['game'] == {'size': 9, 'komi': 7.5, 'max_moves': 162, 'history_length': 1}
            assert protocol['candidate_black_games'] == 1000
            for key in ('packages', 'pgx_source_sha256', 'devices', 'dtype', 'matmul_precision'):
                assert protocol[key] == reference_protocol[key]
                assert summary['runtimes'][name][key] == protocol[key]
            assert summary['runtimes'][name]['protocol_sha256'] == recorded['protocol_sha256']
            assert digest(root / 'runtime-source/exp6_evaluate.py') == protocol['script_sha256']
            assert digest(root / 'runtime-source/exp6_engine.py') == protocol['engine_sha256']
            assert protocol['candidate_tensor_sha256'] == summary['policy_tensor_sha256'][policy]
            assert len(protocol['candidate_tensor_sha256']) == 14
            for tensor, expected in protocol['candidate_tensor_sha256'].items():
                assert digest(policies[policy] / (tensor + '.npy')) == expected
            assert digest(policies[policy] / 'arch.json') == protocol['candidate_arch_sha256']
            if opponent == 'random':
                assert protocol['opponent_uniform_mix'] == 1.0
                assert protocol['opponent_tensor_sha256'] == {} and protocol['opponent_arch_sha256'] is None
            else:
                assert protocol['opponent_uniform_mix'] == 0.0
                path = SOURCE / 'exp6_go_from_scratch/networks' / opponent
                assert len(protocol['opponent_tensor_sha256']) == 14
                for tensor, expected in protocol['opponent_tensor_sha256'].items():
                    assert digest(path / (tensor + '.npy')) == expected
                assert digest(path / 'arch.json') == protocol['opponent_arch_sha256']
            rows = [json.loads(line) for line in (folder / 'episodes.jsonl').open()]
            assert len(rows) == 2000 and [row['episode'] for row in rows] == list(range(2000))
            assert [row['episode_key'] for row in rows] == reference_keys
            assert len({tuple(row['episode_key']) for row in rows}) == 2000
            assert Counter(row['candidate_color'] for row in rows) == {'black': 1000, 'white': 1000}
            for row in rows:
                assert row['candidate_color'] == ('black' if row['episode'] % 2 == 0 else 'white')
                assert type(row['win']) is bool and math.isfinite(row['area_margin'])
                actions = row['actions']
                assert len(actions) == row['length'] and 1 <= row['length'] <= 162
                assert all(type(action) is int and 0 <= action <= 81 for action in actions)
                assert actions.count(81) == row['passes']
                assert row['end_reason'] in {'repetition', 'two_passes', 'move_limit'}
                assert not any(actions[i:i + 2] == [81, 81] for i in range(len(actions) - 2))
                if row['end_reason'] != 'repetition':
                    assert row['win'] == (row['area_margin'] > 0)
                if row['end_reason'] == 'two_passes':
                    assert actions[-2:] == [81, 81]
                if row['end_reason'] == 'move_limit':
                    assert row['length'] == 162
            wins = sum(row['win'] for row in rows)
            actual = {'games': 2000, 'wins': wins, 'losses': 2000 - wins, 'score': wins / 2000,
                      'score_as_black': sum(row['win'] for row in rows[::2]) / 1000,
                      'score_as_white': sum(row['win'] for row in rows[1::2]) / 1000,
                      'mean_length': sum(row['length'] for row in rows) / 2000,
                      'mean_area_margin': sum(row['area_margin'] for row in rows) / 2000}
            for key, value in actual.items():
                assert math.isclose(value, recorded[key], rel_tol=0, abs_tol=1e-12), (name, key)
            assert Counter(row['end_reason'] for row in rows) == Counter(recorded['end_counts'])
            cases[name] = {'episodes': 2000, 'wins': wins, 'score': actual['score'],
                           'episodes_sha256': recorded['episodes_sha256'],
                           'protocol_sha256': recorded['protocol_sha256'], 'verified': True}
    assert len(cases) == 6
    for policy in policies:
        actual = sum(results[policy][opponent]['score'] for opponent in ('ppo_same_size_lr3e-5_s0', 'ppo_same_size_lr3e-5_s2')) / 2
        assert actual == summary['main_scores'][policy]
    assert summary['fresh_minus_released_control_main'] == summary['main_scores']['fresh'] - summary['main_scores']['released_control']
    report = {'reviewer': 'root independent result audit', 'reviewed_at': datetime.now(timezone.utc).isoformat(),
              'budget': budget, 'cases': cases, 'total_episodes': 12000, 'passed': True,
              'audit_script_sha256': digest(Path(__file__)),
              'checks': ['Recomputed every episode aggregate and outcome/color/action-length consistency',
                         'Verified complete unique episode IDs and paired seed keys against audited budget0 across all six cases',
                         'Verified frozen fresh, released control and PPO opponent tensor-file/architecture hashes',
                         'Verified evaluator/engine and protocol/episode hashes; runtime matches audited budget0'],
              'limits': ['This audit does not replay all12000 boards through a second Go engine; separate rule/trace tests cover engine semantics.',
                         'The original small PPO/REINFORCE opponents are unavailable; released same-size seeds0/2 are substituted.']}
    (root / 'independent-review.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'passed': True, 'budget': budget, 'games': 12000, 'main_scores': summary['main_scores'],
                      'fresh_minus_control': summary['fresh_minus_released_control_main']}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('budget', type=int, choices=(10, 25, 50))
    audit(parser.parse_args().budget)

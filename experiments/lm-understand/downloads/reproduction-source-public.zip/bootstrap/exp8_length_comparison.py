import collections
import datetime
import hashlib
import json
from pathlib import Path
import subprocess

root = Path('<workspace>')
source = root / 'work/lm_understand-logs-4d09ba6d6a7e891dd8063974dfe81b3d78e3494f'
original_request = source / 'exp8_math/runs/p10c/requests/fwd_1.json.claimed'
original_result = source / 'exp8_math/runs/p10c/requests/fwd_1.done.json'
remote_code = '''from pathlib import Path
import json,hashlib,statistics,collections
r=Path('<gpu-project>/results/reconstructed-exp8/runs/p10c/requests/r001')
a=r/'attempt-f4e6f9b7884343259e886b9ce2b39d4e'
f=a/'original'
records=[json.loads(s) for s in (f/'generations.jsonl').read_text().splitlines()]
ns=[x['tokens'] for x in records]
print(json.dumps({'source_files':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [r/'request.json',f/'generations.jsonl',f/'summary.json',a/'original_generate.attempt1.stdout.log',a/'original_generate.attempt1.stderr.log']},'request':json.loads((r/'request.json').read_text()),'records_identity':[{'id':x['id'],'sample':x['sample'],'seed':x['seed']} for x in records],'telemetry':{'generations':len(records),'tokens':sum(ns),'median_tokens':statistics.median(ns),'min_tokens':min(ns),'max_tokens':max(ns),'mean_tokens':statistics.mean(ns),'cut_share':sum(x['finish_reason']=='length' for x in records)/len(records),'finish_counts':dict(collections.Counter(x['finish_reason'] for x in records)),'progress_elapsed_seconds':10655,'worker_seconds':json.loads((f/'summary.json').read_text())['s'],'progress_output_tokens_per_second':703.43}}))
'''
fresh = json.loads(subprocess.run(['ssh', '<gpu-ssh-alias>', 'python3 -'], input=remote_code, text=True, capture_output=True, check=True).stdout)
old_request, old_result = json.loads(original_request.read_text()), json.loads(original_result.read_text())

def digest(value):
    return hashlib.sha256(value).hexdigest()

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':')).encode()

def source_counts(ids):
    return dict(collections.Counter('gsm8k' if value.startswith('gsm8k_') else 'math' for value in ids))

old_ids, new_ids = old_request['problems'], fresh['request']['problems']
assert len(old_ids) == len(new_ids) == 256
assert old_ids != new_ids
for key in ('type', 'model', 'n', 'max_tokens', 'activations'):
    assert old_request[key] == fresh['request'][key]
result = {
    'kind': 'descriptive_archived_and_fresh_generation_length_comparison',
    'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source_revision': '4d09ba6d6a7e891dd8063974dfe81b3d78e3494f',
    'collection_script_sha256': digest(Path(__file__).read_bytes()),
    'archived': {
        'source_files': {str(p.relative_to(source)): digest(p.read_bytes()) for p in (original_request, original_result)},
        'telemetry': {key: old_result[key] for key in ('generations', 'mean_tokens', 'cut_share')},
        'rounding': 'Published mean_tokens is an integer and cut_share is rounded to four decimal places; raw historical lengths are not recomputed here.',
        'ordered_problem_ids_sha256': digest(canonical(old_ids)),
        'problem_source_counts': source_counts(old_ids),
        'activation_shapes': old_result['activations']['files']},
    'fresh': {
        'source_files': fresh['source_files'],
        'telemetry': fresh['telemetry'],
        'ordered_problem_ids_sha256': digest(canonical(new_ids)),
        'ordered_id_sample_seed_sha256': digest(canonical(fresh['records_identity'])),
        'problem_source_counts': source_counts(new_ids),
        'stage_at_collection': 'Generation completed; activation replay and final committed-forward audit remain pending.'},
    'comparison': {
        'identical_request_fields': {key: old_request[key] for key in ('type', 'model', 'n', 'max_tokens', 'activations')},
        'identical_problem_order': False,
        'shared_problem_ids': len(set(old_ids) & set(new_ids)),
        'different_problem_source_mix': source_counts(old_ids) != source_counts(new_ids),
        'seed_limit': 'Fresh per-item seeds use the disclosed exp8-v1 SHA256 mapping. The original forward backend and exact historical per-item seed mapping were not released; equality of historical numeric seeds cannot be established.',
        'inference': 'Very long, often capped generations occur in both retained summaries. This supports the workload explanation only; it is not an accuracy comparison, paired sample experiment, hardware speed comparison, or proof of runtime equivalence.',
        'editor_isolation': 'This comparison and all archived outputs remain outside every editor mount and conversation.'}}
out = root / 'outputs/replication/reconstructed-exp8/performance-assessment/p10c-first-pass-length-comparison.json'
with out.open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps({'output':str(out),'sha256':digest(out.read_bytes()),'shared_problem_ids':result['comparison']['shared_problem_ids'],'source_counts':{'archived':source_counts(old_ids),'fresh':source_counts(new_ids)}},indent=2))

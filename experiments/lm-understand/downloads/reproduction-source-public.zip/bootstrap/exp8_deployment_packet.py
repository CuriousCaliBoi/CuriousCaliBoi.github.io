import datetime
import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
import subprocess
import sysconfig

TASK = Path('<gpu-project>')


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for data in iter(lambda: stream.read(8 << 20), b''):
            h.update(data)
    return h.hexdigest()


def files(root):
    return {str(p.relative_to(root)): {'sha256': digest(p), 'bytes': p.stat().st_size}
            for p in sorted(root.rglob('*')) if p.is_file() and '__pycache__' not in p.parts}


def packages(path):
    return dict(sorted((d.metadata['Name'], d.version) for d in importlib.metadata.distributions(path=[str(path)])))


report = {'kind': 'read_only_exp8_runtime_inputs_and_deployment_evidence',
          'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'python': platform.python_version(), 'platform': platform.platform(), 'models': {}}
for name, directory, manifest, expected in [
    ('qwen', 'Qwen3.5-0.8B-text-2fc06364', 'export-manifest.json', '27be3b529aa0ef53636edac136301fe58b3994aeceb5eb0ecc09cf7a80693972'),
    ('gemma', 'gemma-3-270m-it-ac82b4e820549b854eebf28ce6dedaf9fdfa17b3', 'download-manifest.json', '959f2b07d705800e5bb15484087e9bc69199861acdcab01c0f39ae7a9762007b')]:
    root = TASK / 'models' / directory
    assert digest(root / manifest) == expected
    original = json.loads((root / manifest).read_text())
    entries = original['files']
    if isinstance(entries, list):
        entries = {entry['file']: entry for entry in entries}
    actual = {name: {'sha256': digest(root / name), 'bytes': (root / name).stat().st_size} for name in entries}
    assert all(actual[name]['sha256'] == entry['sha256'] for name, entry in entries.items())
    report['models'][name] = {'path': str(root), 'revision': original['revision'], 'manifest_sha256': expected,
                              'all_pinned_files_match': True, 'files': actual}
practice = TASK / 'source/exp8_math/practice'
report['practice'] = {p.name: {'sha256': digest(p), 'bytes': p.stat().st_size,
                              'rows': sum(1 for _ in p.open('rb'))} for p in sorted(practice.glob('*.jsonl'))}
report['dependencies'] = {'base': packages(sysconfig.get_paths()['purelib']),
                          'cpu_overlay': packages(TASK / 'reconstructed/exp8/cpu-deps'),
                          'scoring_overlay': packages(TASK / 'reconstructed/exp8-bench/deps')}
image = 'sha256:5b8c0c14690ed170da4e663fe0bae0d58efe59661e791296ffab28ed2113b650'
report['docker_image'] = json.loads(subprocess.check_output(['docker', 'image', 'inspect', image, '--format',
                  '{"id":{{json .Id}},"os":{{json .Os}},"architecture":{{json .Architecture}}}'], text=True))
assert report['docker_image']['id'] == image
report['deployed_sources'] = {}
for name in ('exp8', 'exp8-bench', 'exp8-s64-v2', 'exp8-bench-s64-v2'):
    code = TASK / 'reconstructed' / name / 'code'
    report['deployed_sources'][name] = files(code) if code.exists() else None
report['eligible_legacy_sessions'] = {}
for case in ('p50c', 'g10b', 'g25b', 'g50b'):
    root = TASK / 'results/reconstructed-exp8/runs' / case
    report['eligible_legacy_sessions'][case] = {'exists': root.exists(),
        'state_exists': (root / 'state.json').exists(), 'kernel_exists': (root / 'kernel.json').exists(),
        'request_directories': [p.name for p in sorted((root / 'requests').glob('*'))]}
report['legacy_benchmark_jobs'] = []
for path in sorted((TASK / 'results/reconstructed-exp8/evaluations').glob('*/*/job.json')):
    job = json.loads(path.read_text())
    report['legacy_benchmark_jobs'].append({'path': str(path), 'sha256': digest(path), 'profile': job['profile'],
                                            'set': job['set'], 'shard': job['shard'], 'model_sha256': job['model_sha256']})
lock = TASK / 'reconstructed/exp8/gpu.lock'
report['canonical_gpu_lock'] = {'path': str(lock), 'resolved': str(lock.resolve()), 'inode': lock.stat().st_ino}
report['no_inference_or_generation_performed'] = True
print(json.dumps(report, indent=2))

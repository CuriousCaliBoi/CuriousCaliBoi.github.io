import argparse
from collections import Counter
import gzip
import hashlib
import json
import math
import os
from pathlib import Path
import sys


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(8 << 20), b''):
            h.update(block)
    return h.hexdigest()


def audit(folder, prepared):
    result = json.loads((folder / 'scores.json').read_text())
    job = result['job']
    assert job == json.loads((folder / 'job.json').read_text())
    assert digest(prepared) == job['dataset_sha256']
    assert digest(folder / 'generations.jsonl.gz') == result['full_generations_sha256']
    assert digest(folder / 'per_problem.json') == result['per_problem_sha256']
    index, stride = map(int, job['shard'].split('/'))
    selected = [json.loads(line) for line in prepared.open()][index::stride]
    with gzip.open(folder / 'generations.jsonl.gz', 'rt') as stream:
        rows = [json.loads(line) for line in stream]
    expected = [(row['id'], sample) for row in selected for sample in range(job['samples'])]
    assert len(set(expected)) == len(expected)
    assert [(row['id'], row['sample']) for row in rows] == expected
    assert len(rows) == result['total'] <= 32
    assert len(selected) == result['n_problems']
    prepared_by_id = {row['id']: row for row in selected}
    for row in rows:
        assert row['seed'] == job['sampling']['seed'] == 0
        assert row['finish_reason'] in ('stop', 'length')
        assert isinstance(row['prompt'], str) and isinstance(row['text'], str)
        assert row['tokens'] == len(row['token_ids']) <= job['sampling']['max_tokens']
        assert row['prompt_ids'] and all(type(value) is int and value >= 0 for value in row['prompt_ids'] + row['token_ids'])
        assert row['answer'] == prepared_by_id[row['id']].get('answer')
        for key in ('strict_correct', 'correct', 'lenient_correct'):
            assert type(row[key]) is bool
        if job['profile'] == 'gemma':
            assert row['correct'] == row['lenient_correct']
        else:
            assert row['correct'] == row['strict_correct']
    expected_problems = [{'id': item['id'], 'grades': [
        {'strict': row['strict_correct'], 'primary': row['correct']} for row in rows if row['id'] == item['id']
    ]} for item in selected]
    assert json.loads((folder / 'per_problem.json').read_text()) == expected_problems
    actual = {
        'ok': sum(row['strict_correct'] for row in rows),
        'ok_primary': sum(row['correct'] for row in rows),
        'ok_lenient': sum(row['lenient_correct'] for row in rows),
        'cut': sum(row['finish_reason'] == 'length' for row in rows),
        'tokens_sum': sum(row['tokens'] for row in rows),
        'no_answer_finished': sum(row['strict_pred'] is None and row['finish_reason'] != 'length'
                                  and prepared_by_id[row['id']].get('kind') != 'ifeval' for row in rows),
        'inst_ok': sum(row.get('inst_ok', 0) for row in rows),
        'inst_total': sum(row.get('inst_total', 0) for row in rows),
    }
    for name, value in actual.items():
        assert value == result[name], (name, value, result[name])
    for name, numerator in (('acc', 'ok'), ('acc_primary', 'ok_primary'), ('acc_lenient', 'ok_lenient'),
                            ('cut_share', 'cut'), ('mean_tokens', 'tokens_sum')):
        assert math.isclose(result[name], actual[numerator] / len(rows), rel_tol=0, abs_tol=1e-12)
    return {'passed': True, 'kind': 'episode_record_and_provenance_consistency_audit',
            'profile': job['profile'], 'set': job['set'], 'shard': job['shard'],
            'n_problems': len(selected), 'answers': len(rows), 'recomputed': actual,
            'finish_counts': dict(Counter(row['finish_reason'] for row in rows)),
            'accuracy_primary': actual['ok_primary'] / len(rows),
            'accuracy_strict': actual['ok'] / len(rows),
            'scores_sha256': digest(folder / 'scores.json'),
            'records_sha256': result['full_generations_sha256'],
            'audit_source_sha256': digest(Path(__file__)),
            'limits': ['Grades are checked for internal consistency, not recomputed by an independent semantic grader.',
                       'This audit checks retained sampled outputs, not numerical inference replay.']}


def replay(folder, prepared, model, source, runtime, bench_code):
    result = json.loads((folder / 'scores.json').read_text())
    job = result['job']
    sys.path.insert(0, str(bench_code.parent / 'deps'))
    sys.path.insert(0, str(runtime))
    sys.path.insert(0, str(bench_code))
    os.environ['MATHVERIFY_PKGS'] = str(runtime.parent / 'cpu-deps')
    os.environ['NLTK_DATA'] = str(bench_code.parent / 'nltk_data')
    from bench_provenance import context, context_hash, metadata_files
    from protocol import INSTRUCTION, PROFILES
    from scoring import Scorer
    from transformers import AutoTokenizer
    current = context(source, runtime)
    assert current == job['provenance'] and context_hash(current) == job['provenance_sha256']
    assert digest(model / 'model.safetensors') == job['model_sha256']
    assert metadata_files(model) == job['model_metadata']
    tokenizer = AutoTokenizer.from_pretrained(model, local_files_only=True)
    scorer = Scorer(source, runtime, job['profile'])
    assert scorer.provenance == result['grading']
    prepared_by_id = {row['id']: row for row in map(json.loads, prepared.open())}
    with gzip.open(folder / 'generations.jsonl.gz', 'rt') as stream:
        rows = [json.loads(line) for line in stream]
    checks = []
    for row in rows:
        item = prepared_by_id[row['id']]
        user = item['prompt'] if item.get('kind') else item['problem'] + '\n' + INSTRUCTION
        prompt = tokenizer.apply_chat_template([{'role': 'user', 'content': user}], tokenize=False,
                                               add_generation_prompt=True,
                                               enable_thinking=PROFILES[job['profile']]['thinking'])
        assert row['prompt'] == prompt, (row['id'], row['sample'], 'rendered_prompt')
        expected_ids = tokenizer(prompt)['input_ids']
        assert row['prompt_ids'] == expected_ids, (row['id'], row['sample'], 'consumed_prompt_ids')
        grade = scorer.grade(item, row['text'])
        for key, value in grade.items():
            assert row[key] == value, (row['id'], row['sample'], key, row[key], value)
        checks.append({'id': row['id'], 'sample': row['sample'], 'prompt_sha256': hashlib.sha256(prompt.encode()).hexdigest(),
                       'prompt_tokens': len(expected_ids), 'initial_prompt_ids': expected_ids[:4],
                       'grade_fields': sorted(grade), 'all_grade_fields_equal': True})
    return {'passed': True, 'kind': 'frozen_scorer_same_code_replay_and_tokenizer_parity',
            'records_checked': len(checks), 'records': checks,
            'frozen_context_sha256': job['provenance_sha256'],
            'checks': ['Fresh rendering of each selected prepared row exactly matches retained prompt.',
                       'Current frozen tokenizer(prompt).input_ids exactly match retained vLLM consumed IDs.',
                       'Every returned grade field matches same-code replay on the retained complete text.'],
            'limits': ['Semantic grades use the same frozen scorer, not an independent grading implementation.',
                       'No model generation or inference is rerun.',
                       'Tokenizer parity identifies this recorded runtime, not the authors historical tokenizer behavior.']}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--folder', type=Path, required=True)
    parser.add_argument('--prepared', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--replay', action='store_true')
    parser.add_argument('--model', type=Path)
    parser.add_argument('--source', type=Path)
    parser.add_argument('--runtime', type=Path)
    parser.add_argument('--bench-code', type=Path)
    args = parser.parse_args()
    report = audit(args.folder, args.prepared)
    if args.replay:
        if any(value is None for value in (args.model, args.source, args.runtime, args.bench_code)):
            parser.error('--replay requires --model, --source, --runtime and --bench-code')
        report['prompt_and_grade_replay'] = replay(args.folder, args.prepared, args.model, args.source,
                                                  args.runtime, args.bench_code)
    args.output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))

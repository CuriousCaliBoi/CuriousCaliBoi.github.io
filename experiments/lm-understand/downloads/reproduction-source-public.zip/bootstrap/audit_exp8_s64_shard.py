import argparse
from collections import Counter
import gzip
import hashlib
import json
import math
import os
from pathlib import Path
import sys

SAMPLES = {'aime24': 16, 'aime25': 16, 'amc23': 16, 'math500': 4, 'minerva': 4,
           'olympiad': 4, 'gsm8k': 2, 'mmlupro1k': 1, 'gpqa': 4, 'ifeval': 2}
SAMPLING = {'temperature': .6, 'top_p': .95, 'top_k': 20, 'presence_penalty': 1.5,
            'max_tokens': 32768, 'seed': 0}
RAW_KEYS = {'id', 'sample', 'seed', 'seed_semantics', 'prompt', 'prompt_ids', 'text',
            'token_ids', 'tokens', 'finish_reason', 'stop_reason', 'answer'}


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for data in iter(lambda: stream.read(8 << 20), b''):
            h.update(data)
    return h.hexdigest()


def hashed(value, ensure_ascii=True):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=ensure_ascii).encode()).hexdigest()


def read_gzip(path):
    with gzip.open(path, 'rt') as stream:
        return [json.loads(line) for line in stream]


def read_jsonl(path):
    with path.open(encoding='utf-8') as stream:
        return [json.loads(line) for line in stream]


def scripts(path):
    return {p.name: digest(p) for p in path.glob('*.py') if not p.name.startswith('test_')}


def partition(prepared, job, bench_code):
    config = json.loads((bench_code / 'execution-profile.json').read_text())
    proof_path = bench_code / 'grouping-verification.json'
    assert digest(proof_path) == config['grouping_sha256'] == job['execution_profile']['grouping_sha256']
    proof = json.loads(proof_path.read_text())
    assert config['answer_ceiling'] == 64
    assert digest(prepared.parent / 'manifest.json') == proof['dataset_manifest_sha256']
    assert digest(prepared) == job['dataset_sha256'] == proof['sets'][job['set']]['dataset_sha256']
    all_rows = read_jsonl(prepared)
    ids = [row['id'] for row in all_rows]
    expected = proof['sets'][job['set']]
    assert len(ids) == len(set(ids)) == expected['problems']
    assert hashed(ids, False) == expected['ordered_ids_sha256']
    n = SAMPLES[job['set']]
    assert n == job['samples'] == expected['samples_per_problem']
    index, stride = map(int, job['shard'].split('/'))
    assert stride == math.ceil(len(ids) / (64 // n)) == expected['candidate_v2']['shards']
    assert 0 <= index < stride
    selected = all_rows[index::stride]
    ids = [row['id'] for row in selected]
    group = {'index': index, 'problems': len(ids), 'answers': len(ids) * n,
             'ordered_ids_sha256': hashed(ids, False),
             'id_sample_seed_tuples_sha256': hashed([[i, s, 0] for i in ids for s in range(n)], False)}
    assert group == job['group'] == expected['candidate_v2']['groups'][index]
    assert group['answers'] <= 64
    return selected, config


def bindings(job, runtime, bench_code, review_path):
    assert job['profile'] == 'qwen' and job['thinking'] is True and job['sampling'] == SAMPLING
    assert job['scripts'] == scripts(bench_code)
    runtime_scripts = scripts(runtime)
    runtime_config = json.loads((runtime / 'execution-profile.json').read_text())
    assert job['runtime_profile'] == {'id': 'spark-s64-v2', 'config_sha256': digest(runtime / 'execution-profile.json'),
                                      'source_sha256': hashed(runtime_scripts)}
    config = json.loads((bench_code / 'execution-profile.json').read_text())
    assert job['execution_profile'] == {'id': 'qwen-benchmark-s64-v2', 'config_sha256': digest(bench_code / 'execution-profile.json'),
                                       'grouping_sha256': digest(bench_code / 'grouping-verification.json')}
    assert config['generation'] == runtime_config['generation']
    assert config['generation']['max_num_seqs'] == 64 and config['generation']['gpu_memory_utilization'] == .35
    assert digest(review_path) == job['review_sha256']
    review = json.loads(review_path.read_text())
    assert review['approved'] is True and review['scripts'] == job['scripts']
    assert review['execution_profile'] == job['execution_profile']
    assert review['variants'][job['variant']] == job['model_sha256']
    assert review['provenance_sha256'] == job['provenance_sha256'] == hashed(job['provenance'])
    assert review['models']['qwen']['metadata_files'] == job['model_metadata']
    assert review['capacity_evidence']['execution_profile'] == job['runtime_profile']
    assert review['capacity_evidence']['profile'] == 'qwen' and review['capacity_evidence']['passed'] is True
    first = review['first_v1_gemma_shard_audit']
    assert first['approved'] is True and first['records'] == 32 and first['record_audit_sha256']
    proof = json.loads((bench_code / 'grouping-verification.json').read_text())
    assert first['job_sha256'] == proof['preserved_first_job']['sha256']
    assert job['provenance']['runtime_scripts'] == runtime_scripts
    assert job['provenance']['scripts'] == job['scripts']
    assert job['provenance']['runtime_configuration'] == job['runtime_profile']['config_sha256']
    assert job['provenance']['configurations'] == {name: digest(bench_code / name) for name in ('execution-profile.json', 'grouping-verification.json')}
    return config


def records_audit(folder, selected, result, config):
    job = result['job']
    assert digest(folder / 'generations.jsonl.gz') == result['full_generations_sha256']
    assert digest(folder / 'per_problem.json') == result['per_problem_sha256']
    assert digest(folder / 'raw-receipt.json') == result['raw_receipt_sha256']
    receipt = json.loads((folder / 'raw-receipt.json').read_text())
    attempt = folder / receipt['directory']
    assert attempt.parent == folder / 'attempts' and attempt.resolve() == attempt
    assert receipt['job_sha256'] == hashed(job)
    assert json.loads((attempt / 'attempt.json').read_text())['job_sha256'] == hashed(job)
    assert digest(attempt / 'raw.jsonl.gz') == digest(attempt / 'received.jsonl.gz') == receipt['raw_sha256'] == result['raw_generation_sha256']
    assert digest(attempt / 'generation-metadata.json') == receipt['metadata_sha256']
    metadata = json.loads((attempt / 'generation-metadata.json').read_text())
    assert metadata['job_sha256'] == hashed(job)
    assert metadata['actual_request_count'] == len(selected)
    assert metadata['actual_samples_per_request'] == [job['samples']] * len(selected)
    raw, rows = read_gzip(attempt / 'raw.jsonl.gz'), read_gzip(folder / 'generations.jsonl.gz')
    expected = [(row['id'], sample) for row in selected for sample in range(job['samples'])]
    assert [(row['id'], row['sample']) for row in rows] == expected
    assert len(raw) == len(rows) == len(expected) == receipt['records'] == result['total'] <= 64
    assert result['n_problems'] == len(selected)
    prepared_by_id = {row['id']: row for row in selected}
    for original, row in zip(raw, rows, strict=True):
        assert set(original) == RAW_KEYS
        assert all(row[key] == value for key, value in original.items()), 'Raw and graded answers differ'
        assert not {'correct', 'strict_correct', 'pred', 'strict_pred'} & original.keys()
        assert row['seed'] == 0 and row['finish_reason'] in ('stop', 'length')
        assert row['seed_semantics'] == 'author SamplingParams(n=N, seed=0) for each request'
        assert isinstance(row['prompt'], str) and isinstance(row['text'], str)
        assert row['tokens'] == len(row['token_ids']) <= 32768
        assert row['prompt_ids'] and all(type(i) is int and i >= 0 for i in row['prompt_ids'] + row['token_ids'])
        assert row['answer'] == prepared_by_id[row['id']].get('answer')
        assert all(type(row[key]) is bool for key in ('correct', 'strict_correct', 'lenient_correct'))
        assert row['correct'] == row['strict_correct']
    capacity = metadata['capacity']
    required_context = max(34816, max(len(row['prompt_ids']) + 32768 for row in rows))
    assert capacity == result['capacity'] and capacity['passed'] is True and capacity['profile'] == 'qwen'
    assert capacity['model_sha256'] == job['model_sha256'] and capacity['execution_profile'] == job['runtime_profile']
    assert capacity['max_num_seqs'] == 64 and capacity['gpu_memory_utilization'] == .35
    assert capacity['required_concurrency'] == min(64, len(rows)) <= capacity['kv_cache_max_concurrency']
    assert capacity['max_model_len'] >= capacity['requested_max_model_len'] == metadata['max_model_len'] == required_context
    assert result['runtime'] == {**config['generation'], 'max_model_len': required_context}
    assert result['generation_seconds'] == metadata['generation_seconds'] >= 0
    expected_problems = [{'id': item['id'], 'grades': [{'strict': r['strict_correct'], 'primary': r['correct']}
                         for r in rows if r['id'] == item['id']]} for item in selected]
    assert json.loads((folder / 'per_problem.json').read_text()) == expected_problems
    actual = {'ok': sum(r['strict_correct'] for r in rows), 'ok_primary': sum(r['correct'] for r in rows),
              'ok_lenient': sum(r['lenient_correct'] for r in rows), 'cut': sum(r['finish_reason'] == 'length' for r in rows),
              'tokens_sum': sum(r['tokens'] for r in rows), 'no_answer_finished': sum(r['strict_pred'] is None
              and r['finish_reason'] != 'length' and prepared_by_id[r['id']].get('kind') != 'ifeval' for r in rows),
              'inst_ok': sum(r.get('inst_ok', 0) for r in rows), 'inst_total': sum(r.get('inst_total', 0) for r in rows)}
    assert all(result[name] == value for name, value in actual.items())
    for name, numerator in (('acc', 'ok'), ('acc_primary', 'ok_primary'), ('acc_lenient', 'ok_lenient'),
                            ('cut_share', 'cut'), ('mean_tokens', 'tokens_sum')):
        assert math.isclose(result[name], actual[numerator] / len(rows), rel_tol=0, abs_tol=1e-12)
    completed = [p for p in (folder / 'attempts').glob('grading-*/scores.json') if digest(p) == digest(folder / 'scores.json')]
    assert len(completed) == 1
    for name in ('generations.jsonl.gz', 'per_problem.json'):
        assert digest(completed[0].parent / name) == digest(folder / name)
    return {'answers': len(rows), 'n_problems': len(selected), 'recomputed': actual,
            'finish_counts': dict(Counter(row['finish_reason'] for row in rows)),
            'raw_to_graded_payload_equality': True, 'capacity_context_and_concurrency_verified': True}


def replay(folder, prepared, model, source, runtime, bench_code):
    result = json.loads((folder / 'scores.json').read_text())
    job = result['job']
    config = json.loads((bench_code / 'execution-profile.json').read_text())
    sys.path[:0] = [config['scoring_dependencies'], str(runtime), str(bench_code)]
    os.environ['MATHVERIFY_PKGS'] = config['cpu_dependencies']
    os.environ['NLTK_DATA'] = config['nltk_data']
    from bench_provenance import context, context_hash, metadata_files
    from protocol import INSTRUCTION
    from scoring import Scorer
    from transformers import AutoTokenizer
    current = context(source, runtime)
    assert current == job['provenance'] and context_hash(current) == job['provenance_sha256']
    assert digest(model / 'model.safetensors') == job['model_sha256'] and metadata_files(model) == job['model_metadata']
    tokenizer = AutoTokenizer.from_pretrained(model, local_files_only=True)
    scorer = Scorer(source, runtime, 'qwen')
    assert scorer.provenance == result['grading']
    prepared_by_id = {row['id']: row for row in read_jsonl(prepared)}
    checks = []
    for row in read_gzip(folder / 'generations.jsonl.gz'):
        item = prepared_by_id[row['id']]
        user = item['prompt'] if item.get('kind') else item['problem'] + '\n' + INSTRUCTION
        prompt = tokenizer.apply_chat_template([{'role': 'user', 'content': user}], tokenize=False,
                                               add_generation_prompt=True, enable_thinking=True)
        assert prompt == row['prompt'] and tokenizer(prompt)['input_ids'] == row['prompt_ids']
        grade = scorer.grade(item, row['text'])
        assert all(row[key] == value for key, value in grade.items()), (row['id'], row['sample'])
        checks.append({'id': row['id'], 'sample': row['sample'], 'prompt_sha256': hashlib.sha256(prompt.encode()).hexdigest(),
                       'prompt_tokens': len(row['prompt_ids']), 'initial_prompt_ids': row['prompt_ids'][:4],
                       'grade_fields': sorted(grade), 'all_grade_fields_equal': True})
    return {'passed': True, 'kind': 'same_frozen_scorer_replay_and_tokenizer_parity', 'records_checked': len(checks),
            'records': checks, 'context_sha256': job['provenance_sha256'], 'no_inference_or_generation': True}


if __name__ == '__main__':
    if sys.flags.optimize:
        raise RuntimeError('Audit assertions must remain enabled')
    parser = argparse.ArgumentParser()
    for name in ('folder', 'prepared', 'runtime', 'bench-code', 'review', 'output'):
        parser.add_argument('--' + name, type=Path, required=True)
    parser.add_argument('--replay', action='store_true')
    parser.add_argument('--model', type=Path)
    parser.add_argument('--source', type=Path)
    args = parser.parse_args()
    if args.output.exists() or args.output.is_symlink():
        raise ValueError('Choose a new audit output path; existing evidence is preserved')
    args.folder = args.folder.resolve()
    result = json.loads((args.folder / 'scores.json').read_text())
    job = result['job']
    assert job == json.loads((args.folder / 'job.json').read_text())
    selected, config = partition(args.prepared, job, args.bench_code)
    assert bindings(job, args.runtime, args.bench_code, args.review) == config
    report = {'passed': True, 'kind': 'independent_partition_payload_and_provenance_consistency_audit',
              'profile': 'qwen', 'set': job['set'], 'shard': job['shard'], 'variant': job['variant'],
              'execution_profile': job['execution_profile'], 'runtime_profile': job['runtime_profile'],
              'fresh_dependency_context_verified': bool(args.replay),
              'scores_sha256': digest(args.folder / 'scores.json'), 'audit_source_sha256': digest(Path(__file__)),
              **records_audit(args.folder, selected, result, config),
              'limits': ['Record, hash and partition consistency checks do not recompute model inference.',
                         'Optional semantic grading replay uses the same frozen scorer, not an independent grader.']}
    if args.replay:
        if args.model is None or args.source is None:
            parser.error('--replay requires --model and --source')
        report['prompt_and_grade_replay'] = replay(args.folder, args.prepared, args.model, args.source, args.runtime, args.bench_code)
    args.output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))

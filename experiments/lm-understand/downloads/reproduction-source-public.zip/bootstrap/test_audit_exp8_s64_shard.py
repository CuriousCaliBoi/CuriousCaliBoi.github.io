import copy
import gzip
import json
from pathlib import Path
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory
import unittest

import audit_exp8_s64_shard as audit


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def compressed(path, rows):
    with gzip.open(path, 'wt') as stream:
        for row in rows:
            stream.write(json.dumps(row) + '\n')


class AuditTests(unittest.TestCase):
    def setUp(self):
        self.temporary = TemporaryDirectory()
        root = Path(self.temporary.name).resolve()
        self.folder, self.runtime, self.bench, self.data = [root / name for name in ('result', 'runtime', 'bench', 'data')]
        for folder in (self.folder, self.runtime, self.bench, self.data):
            folder.mkdir()
        self.prepared = self.data / 'math500.jsonl'
        all_rows = [{'id': str(i), 'problem': 'synthetic', 'answer': '7'} for i in range(500)]
        all_rows[0]['problem'] = 'synthetic\u0085separator\u2028inside\u2029text'
        self.prepared.write_text(''.join(json.dumps(row, ensure_ascii=False) + '\n' for row in all_rows), encoding='utf-8')
        write(self.data / 'manifest.json', {'synthetic': True})
        groups = []
        for i in range(32):
            ids = [row['id'] for row in all_rows[i::32]]
            groups.append({'index': i, 'problems': len(ids), 'answers': len(ids) * 4,
                           'ordered_ids_sha256': audit.hashed(ids, False),
                           'id_sample_seed_tuples_sha256': audit.hashed([[identity, s, 0] for identity in ids for s in range(4)], False)})
        proof = {'dataset_manifest_sha256': audit.digest(self.data / 'manifest.json'),
                 'preserved_first_job': {'sha256': 'first-gemma-job'}, 'sets': {'math500': {
                 'dataset_sha256': audit.digest(self.prepared), 'problems': 500, 'samples_per_problem': 4,
                 'ordered_ids_sha256': audit.hashed([row['id'] for row in all_rows], False),
                 'candidate_v2': {'shards': 32, 'groups': groups}}}}
        write(self.bench / 'grouping-verification.json', proof)
        generation = {'dtype': 'bfloat16', 'max_num_seqs': 64, 'gpu_memory_utilization': .35,
                      'max_num_batched_tokens': 4096, 'enforce_eager': True, 'enable_prefix_caching': False,
                      'enable_chunked_prefill': True}
        self.config = {'generation': generation, 'answer_ceiling': 64,
                       'grouping_sha256': audit.digest(self.bench / 'grouping-verification.json')}
        write(self.bench / 'execution-profile.json', self.config)
        write(self.runtime / 'execution-profile.json', {'generation': generation})
        (self.runtime / 'runtime.py').write_text('VALUE = 1\n')
        (self.bench / 'evaluate.py').write_text('VALUE = 2\n')
        runtime_identity = {'id': 'spark-s64-v2', 'config_sha256': audit.digest(self.runtime / 'execution-profile.json'),
                            'source_sha256': audit.hashed(audit.scripts(self.runtime))}
        identity = {'id': 'qwen-benchmark-s64-v2', 'config_sha256': audit.digest(self.bench / 'execution-profile.json'),
                    'grouping_sha256': audit.digest(self.bench / 'grouping-verification.json')}
        provenance = {'scripts': audit.scripts(self.bench), 'runtime_scripts': audit.scripts(self.runtime),
                      'runtime_configuration': runtime_identity['config_sha256'],
                      'configurations': {n: audit.digest(self.bench / n) for n in ('execution-profile.json', 'grouping-verification.json')}}
        self.job = {'profile': 'qwen', 'set': 'math500', 'shard': '0/32', 'samples': 4, 'thinking': True,
                    'sampling': audit.SAMPLING, 'group': groups[0], 'scripts': audit.scripts(self.bench),
                    'runtime_profile': runtime_identity, 'execution_profile': identity, 'variant': 'base-qwen',
                    'model_sha256': 'model', 'dataset_sha256': audit.digest(self.prepared), 'model_metadata': {},
                    'provenance': provenance, 'provenance_sha256': audit.hashed(provenance)}
        self.review_path = root / 'variant-review.json'
        review = {'approved': True, 'scripts': self.job['scripts'], 'execution_profile': identity,
                  'variants': {'base-qwen': 'model'}, 'provenance_sha256': self.job['provenance_sha256'],
                  'models': {'qwen': {'metadata_files': {}}},
                  'capacity_evidence': {'execution_profile': runtime_identity, 'profile': 'qwen', 'passed': True},
                  'first_v1_gemma_shard_audit': {'approved': True, 'records': 32, 'record_audit_sha256': 'audit', 'job_sha256': 'first-gemma-job'}}
        write(self.review_path, review)
        self.job['review_sha256'] = audit.digest(self.review_path)
        self.selected = all_rows[0::32]
        self.raw = [{'id': row['id'], 'sample': sample, 'seed': 0,
                     'seed_semantics': 'author SamplingParams(n=N, seed=0) for each request', 'prompt': 'synthetic prompt',
                     'prompt_ids': [1, 2], 'text': '7', 'token_ids': [7], 'tokens': 1,
                     'finish_reason': 'stop', 'stop_reason': None, 'answer': '7'} for row in self.selected for sample in range(4)]
        self.graded = [{**row, 'correct': True, 'strict_correct': True, 'lenient_correct': True, 'pred': '7', 'strict_pred': '7'} for row in self.raw]
        self.attempt = self.folder / 'attempts/generation-fixture'
        self.attempt.mkdir(parents=True)
        write(self.attempt / 'attempt.json', {'job_sha256': audit.hashed(self.job)})
        capacity = {'passed': True, 'profile': 'qwen', 'model_sha256': 'model', 'execution_profile': runtime_identity,
                    'max_num_seqs': 64, 'gpu_memory_utilization': .35, 'required_concurrency': 64,
                    'kv_cache_max_concurrency': 97, 'max_model_len': 34816, 'requested_max_model_len': 34816}
        self.metadata = {'job_sha256': audit.hashed(self.job), 'actual_request_count': 16, 'actual_samples_per_request': [4] * 16,
                         'capacity': capacity, 'max_model_len': 34816, 'generation_seconds': 7}
        self.result = {'job': self.job, 'total': 64, 'n_problems': 16, 'capacity': capacity,
                       'runtime': {**generation, 'max_model_len': 34816}, 'generation_seconds': 7,
                       'ok': 64, 'ok_primary': 64, 'ok_lenient': 64, 'cut': 0, 'tokens_sum': 64,
                       'no_answer_finished': 0, 'inst_ok': 0, 'inst_total': 0,
                       'acc': 1., 'acc_primary': 1., 'acc_lenient': 1., 'cut_share': 0., 'mean_tokens': 1.}
        problems = [{'id': row['id'], 'grades': [{'strict': True, 'primary': True}] * 4} for row in self.selected]
        write(self.folder / 'per_problem.json', problems)
        self.rehash()

    def tearDown(self):
        self.temporary.cleanup()

    def rehash(self):
        compressed(self.attempt / 'raw.jsonl.gz', self.raw)
        shutil.copyfile(self.attempt / 'raw.jsonl.gz', self.attempt / 'received.jsonl.gz')
        write(self.attempt / 'generation-metadata.json', self.metadata)
        receipt = {'job_sha256': audit.hashed(self.job), 'directory': 'attempts/generation-fixture',
                   'raw_sha256': audit.digest(self.attempt / 'raw.jsonl.gz'), 'records': len(self.raw),
                   'metadata_sha256': audit.digest(self.attempt / 'generation-metadata.json')}
        write(self.folder / 'raw-receipt.json', receipt)
        compressed(self.folder / 'generations.jsonl.gz', self.graded)
        self.result.update(full_generations_sha256=audit.digest(self.folder / 'generations.jsonl.gz'),
                           per_problem_sha256=audit.digest(self.folder / 'per_problem.json'),
                           raw_receipt_sha256=audit.digest(self.folder / 'raw-receipt.json'), raw_generation_sha256=receipt['raw_sha256'])
        write(self.folder / 'scores.json', self.result)
        complete = self.folder / 'attempts/grading-fixture'
        complete.mkdir(exist_ok=True)
        for name in ('scores.json', 'generations.jsonl.gz', 'per_problem.json'):
            shutil.copyfile(self.folder / name, complete / name)

    def check_records(self):
        return audit.records_audit(self.folder, self.selected, self.result, self.config)

    def test_accepts_complete_64_answer_fixture(self):
        selected, config = audit.partition(self.prepared, self.job, self.bench)
        self.assertEqual(selected, self.selected)
        self.assertEqual(audit.bindings(self.job, self.runtime, self.bench, self.review_path), config)
        self.assertEqual(self.check_records()['answers'], 64)

    def test_rejects_legacy_partition_and_changed_source_or_review(self):
        with self.assertRaises(AssertionError):
            audit.partition(self.prepared, {**self.job, 'shard': '0/63'}, self.bench)
        (self.runtime / 'runtime.py').write_text('VALUE = 3\n')
        with self.assertRaises(AssertionError):
            audit.bindings(self.job, self.runtime, self.bench, self.review_path)
        (self.runtime / 'runtime.py').write_text('VALUE = 1\n')
        self.review_path.write_text('{}')
        with self.assertRaises(AssertionError):
            audit.bindings(self.job, self.runtime, self.bench, self.review_path)

    def test_rejects_raw_graded_difference_even_with_updated_hashes(self):
        self.raw[0]['text'] = 'different retained answer'
        self.rehash()
        with self.assertRaisesRegex(AssertionError, 'Raw and graded'):
            self.check_records()

    def test_rejects_seed_change_even_if_raw_and_graded_match(self):
        self.raw[0]['seed'] = self.graded[0]['seed'] = 1
        self.rehash()
        with self.assertRaises(AssertionError):
            self.check_records()

    def test_rejects_changed_aggregate_and_context_reduction(self):
        self.result['ok'] = 63
        with self.assertRaises(AssertionError):
            self.check_records()
        self.result['ok'] = 64
        self.metadata['capacity']['max_model_len'] = 32768
        self.rehash()
        with self.assertRaises(AssertionError):
            self.check_records()

    def test_cli_preserves_an_existing_audit(self):
        existing = self.folder / 'independent-audit.json'
        existing.write_text('retained evidence')
        command = [sys.executable, audit.__file__, '--folder', str(self.folder), '--prepared', str(self.prepared),
                   '--runtime', str(self.runtime), '--bench-code', str(self.bench), '--review', str(self.review_path),
                   '--output', str(existing)]
        result = subprocess.run(command, capture_output=True, text=True)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('Choose a new audit output path', result.stderr)
        self.assertEqual(existing.read_text(), 'retained evidence')


if __name__ == '__main__':
    unittest.main()

import argparse
import importlib.util
import json
from pathlib import Path
import sys

parser = argparse.ArgumentParser()
parser.add_argument('--bench', type=Path, required=True)
parser.add_argument('--bench-code', type=Path, required=True)
parser.add_argument('--auditor', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
sys.path.insert(0, str(args.bench_code))
import evaluate
import aggregate
import benchmark_profile as profile
from bench_provenance import digest
spec = importlib.util.spec_from_file_location('review_auditor', args.auditor)
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)
reports = {}
for name, count in evaluate.SAMPLES.items():
    path = args.bench / (name + '.jsonl')
    rows = evaluate.read_jsonl(path)
    assert rows == aggregate.read_jsonl(path) == audit.read_jsonl(path)
    expected = profile.GROUPING['sets'][name]
    assert digest(path) == expected['dataset_sha256']
    stride = expected['candidate_v2']['shards']
    for index in range(stride):
        shard = f'{index}/{stride}'
        selected, group = profile.select_rows(name, rows, shard, count, digest(path))
        job = {'set': name, 'shard': shard, 'samples': count, 'dataset_sha256': digest(path),
               'execution_profile': {'grouping_sha256': profile.CONFIG['grouping_sha256']}, 'group': group}
        audited, _ = audit.partition(path, job, args.bench_code)
        assert selected == audited == rows[index::stride]
    reports[name] = {'rows': len(rows), 'groups_checked': stride, 'dataset_sha256': digest(path)}
    if name == 'gpqa':
        assert rows[4]['id'] == 'gpqa_rec1zl5LvaatzGhFt'
        assert json.dumps(rows[4], ensure_ascii=False).count('\u2028') == 1
        reports[name]['exact_unicode_record'] = {'id': rows[4]['id'], 'physical_line': 5, 'raw_U2028_count': 1,
            'record_sha256': audit.hashed(rows[4], False)}
assert sum(r['groups_checked'] for r in reports.values()) == 206
result = {'passed': True, 'no_inference': True, 'sets': reports,
          'grouping_sha256': digest(args.bench_code / 'grouping-verification.json'),
          'source_sha256': {str(p): digest(p) for p in [args.bench_code / 'evaluate.py', args.bench_code / 'aggregate.py', args.auditor, Path(__file__)]}}
with args.output.open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps(result, indent=2))

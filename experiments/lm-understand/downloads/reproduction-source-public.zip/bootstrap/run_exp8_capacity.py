import argparse
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import time


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def write(path, value):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def children(pid):
    path = Path(f'/proc/{pid}/task/{pid}/children')
    return [int(value) for value in path.read_text().split()] if path.exists() else []


parser = argparse.ArgumentParser()
parser.add_argument('--folder', type=Path, required=True)
args = parser.parse_args()
record_path = args.folder / 'lifecycle.json'
if record_path.exists():
    raise ValueError('Capacity initialization was already queued; inspect its retained lifecycle')
review_path = args.folder / 'startup-review.json'
review = json.loads(review_path.read_text())
command = ['<gpu-python-environment>/bin/python',
           '<gpu-project>/reconstructed/exp8-s64-v2/code/test_capacity.py',
           '--profile', review['profile'], '--model', review['model'], '--output', review['output'], '--review', str(review_path)]
record = {'queued_utc': now(), 'command': command, 'review_sha256': hashlib.sha256(review_path.read_bytes()).hexdigest(),
          'events': [], 'status': 'queued_waiting_for_shared_gpu_lock'}
with (args.folder / 'stdout.log').open('x') as stdout, (args.folder / 'stderr.log').open('x') as stderr:
    process = subprocess.Popen(command, stdout=stdout, stderr=stderr)
    record.update(utility_pid=process.pid, utility_started_utc=now())
    write(record_path, record)
    seen = set()
    while process.poll() is None:
        for pid in children(process.pid):
            if pid not in seen:
                seen.add(pid)
                path = Path(f'/proc/{pid}/cmdline')
                command_line = path.read_bytes().replace(b'\x00', b' ').decode(errors='replace') if path.exists() else ''
                record['events'].append({'observed_utc': now(), 'pid': pid, 'command': command_line})
                if '--gpu-worker' in command_line:
                    record.update(status='capacity_engine_initializing_no_generation', gpu_worker_pid=pid,
                                  gpu_worker_observed_utc=now())
                write(record_path, record)
        time.sleep(1)
    record.update(exit_utc=now(), exit_code=process.returncode,
                  status='completed' if process.returncode == 0 else 'failed_preserved_for_diagnosis')
    output = Path(review['output'])
    if output.exists():
        record['report_sha256'] = hashlib.sha256(output.read_bytes()).hexdigest()
    write(record_path, record)

import argparse
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile
import zipfile

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / 'outputs/replication'
REPO = ROOT / 'work/reconstructed-evaluation'
SOURCE_REVISION = '4d09ba6d6a7e891dd8063974dfe81b3d78e3494f'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--commit', default='HEAD')
    args = parser.parse_args()
    commit = subprocess.check_output(['git', '-C', str(REPO), 'rev-parse', args.commit], text=True).strip()
    archive = subprocess.check_output(['git', '-C', str(REPO), 'archive', '--format=tar', commit])
    entries = {}
    with tarfile.open(fileobj=io.BytesIO(archive)) as source:
        for member in source:
            if member.isdir():
                continue
            assert member.isfile(), member.name
            assert not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
            entries['reconstruction/' + member.name] = source.extractfile(member).read()
    for name in ('run_published_prompts.py', 'audit_fresh_runs.py', 'experiment-cli.sb',
                 'independent_exp6_scoring.py', 'audit_exp8_shard.py', 'exp8_deployment_packet.py',
                 'run_exp8_capacity.py', 'audit_exp8_forward.py', 'test_audit_exp8_forward.py',
                 'audit_exp8_s64_shard.py', 'test_audit_exp8_s64_shard.py',
                 'check_exp8_jsonl_actual.py', 'exp8_length_comparison.py', 'build_reproduction_bundle.py'):
        entries['bootstrap/' + name] = (ROOT / 'work' / name).read_bytes()
    entries['REPRODUCE.txt'] = (OUT / 'REPRODUCE.txt').read_bytes()
    for experiment, names in {
        'exp4': ('evaluate_exp4.py', 'exp4_edits.py', 'exp4-requirements.lock'),
        'exp7': ('exp7_retrain.py',),
    }.items():
        for name in names:
            entries[f'archived-runtime/{experiment}/{name}'] = (OUT / f'reconstructed-{experiment}/runtime-source' / name).read_bytes()
    metadata = {
        'exp3-runtime.json': 'reconstructed-exp3/remote-runtime.json',
        'exp4-protocol.json': 'reconstructed-exp4/protocol.json',
        'exp5-protocol.json': 'reconstructed-exp5/protocol.json',
        'exp5-ppo-campaign-plan-v5.json': 'exp5-ppo-feasibility/campaign-plan-v5.json',
        'exp5-ppo-startup-review.json': 'exp5-ppo-feasibility/startup-review.json',
        'exp5-ppo-cleanrl-reference.json': 'exp5-ppo-feasibility/cleanrl-reference.json',
        'exp7-requirements.lock': 'reconstructed-exp7/requirements.lock',
        'exp8-provenance.json': 'reconstructed-exp8/provenance.json',
        'exp8-client-environment.json': 'reconstructed-exp8/client-environment.json',
        'exp8-dataset-manifest.json': 'reconstructed-exp8/benchmark-preparation/dataset-manifest.json',
        'exp8-benchmark-provenance.json': 'reconstructed-exp8/benchmark-preparation/runtime-provenance.json',
        'exp8-tokenization.txt': 'reconstructed-exp8/preflight/TOKENIZATION.md',
    }
    for destination, source in metadata.items():
        entries['metadata/' + destination] = (OUT / source).read_bytes()
    proposed = OUT / 'reconstructed-exp8/performance-assessment/proposed-v2'
    for destination, source in {
        'plan-review.json': 'independent-plan-review.json',
        'implementation-review.json': 'implementation/followup-404dca3/independent-source-review.json',
        'implementation-tests.json': 'implementation/followup-404dca3/implementation-tests.json',
        'deployment-verification.json': 'deployment-7e0b6c8/deployment-verification.json',
        'deployment-review.json': 'deployment-7e0b6c8/independent-deployment-review.json',
        'deployed-context.json': 'deployment-7e0b6c8/deployed-context.json',
        'remote-inputs-and-sources.json': 'deployment-7e0b6c8/remote-inputs-and-sources.json',
        'capacity-startup-review.json': 'deployment-7e0b6c8/capacity-startup-review.json',
        'capacity-launcher.json': 'deployment-7e0b6c8/capacity-launcher.json',
        'capacity-queued-lifecycle.json': 'deployment-7e0b6c8/capacity-queued-lifecycle.json',
    }.items():
        entries['metadata/exp8-s64-v2/' + destination] = (proposed / source).read_bytes()
    for name in ('independent-review.json', 'root-deployment-review.json', 'deployed-files.json',
                 'deployed-context.json', 'actual-data-check.json'):
        entries['metadata/exp8-s64-v2/jsonl-correction/' + name] = (proposed / 'jsonl-correction' / name).read_bytes()
    for name in ('startup-review.json', 'legitimate-telemetry.json', 'launcher.json', 'queued-lifecycle.json'):
        entries['metadata/exp8-s64-v2/gemma-capacity/' + name] = (proposed / 'gemma-capacity-request' / name).read_bytes()
    for name in ('campaign-plan.json', 'startup-review.json', 'independent-review.json', 'launcher.json',
                 'cached-first-receipt.json', 'root-launch-review.json'):
        entries['metadata/exp8-gemma-campaign/' + name] = (OUT / 'reconstructed-exp8/gemma-campaign-preparation' / name).read_bytes()
    entries['metadata/exp8-first-gemma-shard-review.json'] = (OUT / 'reconstructed-exp8/benchmark-first-shard/base-gemma-math500-s0of63/root-review.json').read_bytes()
    entries['metadata/exp8-forward-auditor-correction-review.json'] = (OUT / 'reconstructed-exp8/forward-audit-preparation/jsonl-correction/independent-review.json').read_bytes()
    entries['metadata/gemma-download-manifest.json'] = (ROOT / 'work/reproduction-metadata/gemma-download-manifest.json').read_bytes()
    dataset = json.loads(entries['metadata/exp8-dataset-manifest.json'])
    entries['metadata/gpqa-download.json'] = (json.dumps(dataset['sets']['gpqa']['author_archive'], indent=2) + '\n').encode()
    one_shot = []
    for case in json.loads((OUT / 'fresh-response-results.json').read_text())['runs']:
        record = json.loads((OUT / case['run'] / 'run.json').read_text())
        one_shot.append({key: record[key] for key in ('source_path', 'source_revision', 'cmd', 'cli_version',
                                                    'prompt_sha256', 'instructions_sha256', 'effective_model_settings')})
    entries['metadata/one-shot-launch-settings.json'] = (json.dumps(one_shot, indent=2) + '\n').encode()
    forbidden = re.compile(rb'-----BEGIN (?:[A-Z ]+ )?PRIVATE KEY-----|\bhf_[A-Za-z0-9]{24,}\b|\bsk-(?:proj-)?[A-Za-z0-9_-]{32,}\b')
    for name, data in entries.items():
        assert Path(name).suffix not in ('.npz', '.npy', '.safetensors', '.pt', '.bin'), name
        assert Path(name).name not in ('.env', '.fee.env', 'auth.json', 'credentials', 'id_rsa', 'id_ed25519'), name
        data.decode('utf-8')
        assert not forbidden.search(data), name
    manifest = {
        'kind': 'source_and_metadata_snapshot_not_turnkey_installer',
        'source_repository': 'https://github.com/RikiyaT/lm_understand-logs',
        'source_revision': SOURCE_REVISION,
        'reconstruction_git_commit': commit,
        'recorded_snapshot_date_utc': '2026-11-03',
        'experiments_still_running_when_packaged': True,
        'source_archive_method': 'git archive --format=tar <commit>; regular file bytes preserved',
        'bootstrap_note': 'Untracked task launch/audit files preserved byte-for-byte; see guide for host paths and legacy audit scope.',
        'review_files_note': 'Recorded reviews are historical evidence, not approval for a changed host or code revision.',
        'excluded': ['weights', 'datasets', 'credentials', 'CLI authentication', 'live scratch', 'complete run logs'],
        'files': {name: {'bytes': len(data), 'sha256': digest(data)} for name, data in sorted(entries.items())},
    }
    entries['MANIFEST.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
    destination = OUT / 'reproduction-source.zip'
    with zipfile.ZipFile(destination, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
        for name, data in sorted(entries.items()):
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 3, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            bundle.writestr(info, data)
    with zipfile.ZipFile(destination) as bundle:
        assert bundle.testzip() is None
        assert set(bundle.namelist()) == set(entries)
        for name, expected in manifest['files'].items():
            actual = bundle.read(name)
            assert len(actual) == expected['bytes'] and digest(actual) == expected['sha256']
    result = {'passed': True, 'zip': destination.name, 'zip_sha256': digest(destination.read_bytes()),
              'zip_bytes': destination.stat().st_size, 'reconstruction_git_commit': commit,
              'files_including_manifest': len(entries), 'uncompressed_bytes': sum(map(len, entries.values())),
              'git_archive_files': sum(name.startswith('reconstruction/') for name in entries),
              'bootstrap_files': sorted(name for name in entries if name.startswith('bootstrap/')),
              'checks': ['ZIP CRC', 'all member SHA-256/size checks', 'all members UTF-8 text',
                         'no native weights or credential filenames', 'private-key and credential-token pattern scan'],
              'limits': ['Metadata and source only; environment, data, model downloads and new-host preflight required.',
                         'Recorded startup reviews are not transferable approval.',
                         'Token-pattern scan is a bounded packaging check, not a general security audit.']}
    (OUT / 'reproduction-source-validation.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()

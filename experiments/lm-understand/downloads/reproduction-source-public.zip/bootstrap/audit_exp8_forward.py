import argparse
from collections import defaultdict
import hashlib
import json
import math
import os
from pathlib import Path
import sys

PROFILES = {'qwen': {'layers': 24, 'width': 1024, 'mlp_width': 3584, 'cap': 32768, 'limit': 512, 'thinking': True,
                     'sampling': {'temperature': .6, 'top_p': .95, 'top_k': 20, 'presence_penalty': 1.5}},
            'gemma': {'layers': 18, 'width': 640, 'mlp_width': 2048, 'cap': 8192, 'limit': 2048, 'thinking': False,
                      'sampling': {'temperature': 1., 'top_p': .95, 'top_k': 64}}}
RAW_FIELDS = ('id', 'source', 'sample', 'seed', 'prompt', 'prompt_ids', 'text', 'token_ids', 'tokens',
              'finish_reason', 'stop_reason', 'answer')
CASE_BUDGETS = {'p10c': 10, 'p25c': 25, 'p50c': 50, 'g05b': 5, 'g10b': 10, 'g25b': 25, 'g50b': 50}
PRACTICE_SHA = {'aime.jsonl': '9f6f26b89e65c7123e6106a9dce51137783eb339547f974f2ab1413165122f56',
                'gsm8k_train.jsonl': '06d0dd560a908c2c2883bfb7d27ab55a87b213ff0d625f5cd734836aeac9a3e5',
                'math_train.jsonl': 'abe7982b4d8c98394fe185fb152568a2c784a4157a75fe42b9c01857e71f0c6e'}
BASE_MANIFESTS = {'qwen': ('export-manifest.json', '27be3b529aa0ef53636edac136301fe58b3994aeceb5eb0ecc09cf7a80693972'),
                  'gemma': ('download-manifest.json', '959f2b07d705800e5bb15484087e9bc69199861acdcab01c0f39ae7a9762007b')}


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for value in iter(lambda: stream.read(8 << 20), b''):
            h.update(value)
    return h.hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False)


def hashed(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()


def load(path):
    return json.loads(path.read_text())


def load_jsonl(path):
    with path.open(encoding='utf-8') as stream:
        return [json.loads(line) for line in stream]


def snapshot(case, output):
    before = (case / 'state.json').read_bytes()
    state = json.loads(before)
    entries = []
    for turn in sorted((case / 'turns').glob('t*')):
        if int(turn.name[1:]) > state['turn'] or not (turn / 'pending-forward.json').exists():
            continue
        entries.append({'turn': int(turn.name[1:]), 'pending': load(turn / 'pending-forward.json'),
                        'request': load(turn / 'forward-request.json'), 'response': load(turn / 'forward-result.json'),
                        'file_sha256': {name: digest(turn / name) for name in ('pending-forward.json', 'forward-request.json', 'forward-result.json')}})
    assert (case / 'state.json').read_bytes() == before, 'Controller advanced during snapshot; retry in a new snapshot file'
    manifest, kernel = load(case / 'manifest.json'), load(case / 'kernel.json')
    result = {'kind': 'committed_controller_forward_ledger_snapshot', 'case_manifest': manifest,
              'case_manifest_sha256': digest(case / 'manifest.json'), 'state_sha256': hashlib.sha256(before).hexdigest(),
              'state': {key: state[key] for key in ('turn', 'passes', 'requests', 'request_signatures', 'python_runs', 'done')},
              'base_provenance': kernel['base_provenance'], 'entries': entries,
              'export_source_sha256': digest(Path(__file__))}
    output.write_text(json.dumps(result, indent=2) + '\n')
    return {'snapshot': str(output), 'sha256': digest(output), 'committed_forward_requests': len(entries)}


def budget(capsule, request_index, request, response, signature):
    state, entries = capsule['state'], capsule['entries']
    assert [entry['pending']['index'] for entry in entries] == list(range(1, state['requests'] + 1))
    successes = [entry for entry in entries if entry['response'].get('ok')]
    assert len({entry['pending']['signature'] for entry in successes}) == len(successes)
    assert len(successes) == state['passes'] <= capsule['case_manifest']['passes']
    assert state['request_signatures'] == {entry['pending']['signature']: entry['pending']['index'] for entry in successes}
    target = next(entry for entry in entries if entry['pending']['index'] == request_index)
    assert target['request'] == request and target['response'] == response and target['pending']['signature'] == signature
    assert target['response']['ok'] is True
    return {'committed_turn': target['turn'], 'request_index': request_index,
            'pass_number': sum(entry['response'].get('ok', False) for entry in entries if entry['pending']['index'] <= request_index),
            'passes_committed_at_snapshot': state['passes'], 'total_budget': capsule['case_manifest']['passes']}


def samples(request, practice):
    rows = [practice[identity] for identity in request.get('problems', [])]
    rows += [{'id': 'prompt:' + str(i), 'source': 'custom', 'problem': prompt, 'answer': None, 'custom': True}
             for i, prompt in enumerate(request.get('prompts', []))]
    return [(row, sample) for row in rows for sample in range(request.get('n', 1))]


def generations(records, request, expected, summary, profile):
    p = PROFILES[profile]
    assert len(records) == len(expected) <= p['limit'] // (2 if request['model'] == 'both' else 1)
    assert [(r['id'], r['sample']) for r in records] == [(row['id'], sample) for row, sample in expected]
    cap = request.get('max_tokens', p['cap'])
    for record, (row, sample) in zip(records, expected, strict=True):
        identity = row['problem'] if row.get('custom') else row['id']
        seed = int.from_bytes(hashlib.sha256(f'exp8-v1:{identity}:{sample}'.encode()).digest()[:4], 'little') & 0x7fffffff
        assert record['seed'] == seed and record['source'] == row['source'] and record['answer'] == row['answer']
        assert record['finish_reason'] in ('stop', 'length') and record['tokens'] == len(record['token_ids']) <= cap
        assert isinstance(record['text'], str) and isinstance(record['prompt'], str)
        assert record['prompt_ids'] and all(type(i) is int and i >= 0 for i in record['prompt_ids'] + record['token_ids'])
        if row['answer'] is None:
            assert record['correct'] is None and record['pred'] is None
        else:
            assert type(record['correct']) is bool and type(record['strict_correct']) is bool
            if profile == 'qwen':
                assert record['correct'] == record['strict_correct'] and record['pred'] == record['strict_pred']
    graded = [r for r in records if r['correct'] is not None]
    failed = [r for r in graded if not r['correct']]
    expected_summary = {'generations': len(records), 'graded': len(graded),
        'accuracy': sum(r['correct'] for r in graded) / len(graded) if graded else None,
        'accuracy_by_source': {s: sum(r['correct'] for r in graded if r['source'] == s) / sum(r['source'] == s for r in graded)
                               for s in sorted({r['source'] for r in graded})},
        'mean_tokens': sum(r['tokens'] for r in records) / len(records),
        'cut_share': sum(r['finish_reason'] == 'length' for r in records) / len(records),
        'failures': {'cut_at_max_tokens': sum(r['finish_reason'] == 'length' for r in failed),
                     'no_answer_finished': sum(r['finish_reason'] != 'length' and r['pred'] is None for r in failed),
                     'wrong_answer': sum(r['finish_reason'] != 'length' and r['pred'] is not None for r in failed)},
        'sampling': {**p['sampling'], 'max_tokens': cap, 'thinking': p['thinking']}}
    assert all(summary[key] == value for key, value in expected_summary.items())
    return expected_summary


def activations(folder, request, records, profile):
    import numpy as np
    metadata = load(folder / 'index.json')
    p = PROFILES[profile]
    hidden = request['activations']['layers']
    mlp = [layer for layer in hidden if layer < p['layers']] if request['activations'].get('mlp') else []
    assert metadata['hidden_layers'] == hidden and metadata['mlp_layers'] == mlp
    assert metadata['dtype'] == metadata['aggregation_dtype'] == 'float32' and metadata['capture_dtype'] == 'float16'
    assert metadata['answer_token_limit'] == 8192
    expected_index = [{'id': r['id'], 'sample': r['sample'], 'correct': r['correct'], 'prompt_tokens': len(r['prompt_ids']),
                       'answer_tokens_used': min(r['tokens'], 8192), 'tokens': r['tokens']} for r in records]
    assert metadata['samples'] == expected_index
    expected_files = {category + '_' + suffix + '.npy': [len(records), len(layers), width]
                      for category, layers, width in [('hidden', hidden, p['width']), ('mlp', mlp, p['mlp_width'])]
                      if layers for suffix in ('last_prompt', 'mean_answer')}
    assert metadata['files'] == expected_files and {p.name for p in folder.iterdir()} == set(expected_files) | {'index.json'}
    report = {}
    for name, shape in expected_files.items():
        array = np.load(folder / name, mmap_mode='r', allow_pickle=False)
        assert list(array.shape) == shape and array.dtype == np.dtype('float32')
        for start in range(0, len(array), 8):
            assert np.isfinite(array[start:start + 8]).all(), name
        if 'mean_answer' in name:
            for index, record in enumerate(records):
                if record['tokens'] == 0:
                    assert (array[index] == 0).all()
        report[name] = {'shape': shape, 'dtype': str(array.dtype), 'finite_values': int(array.size), 'sha256': digest(folder / name)}
    return {'files': report, 'sample_index_sha256': digest(folder / 'index.json'), 'samples': len(records),
            'limit': 'Dimensions, finite values and indexing are checked; activation numbers are not recomputed by inference.'}


def replay(records, expected, model, source, runtime, profile):
    sys.path.insert(0, str(runtime))
    config = runtime / 'execution-profile.json'
    os.environ['MATHVERIFY_PKGS'] = load(config)['cpu_dependencies'] if config.exists() else str(runtime.parent / 'cpu-deps')
    from grading import Grader
    from transformers import AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(model, local_files_only=True)
    grader = Grader(source, profile)
    for record, (row, _) in zip(records, expected, strict=True):
        user = row['problem'] if row.get('custom') else row['problem'] + '\nPlease reason step by step, and put your final answer within \\boxed{}.'
        prompt = tokenizer.apply_chat_template([{'role': 'user', 'content': user}], tokenize=False,
                                               add_generation_prompt=True, enable_thinking=PROFILES[profile]['thinking'])
        assert prompt == record['prompt'] and tokenizer(prompt)['input_ids'] == record['prompt_ids']
        if row['answer'] is not None:
            assert all(record[key] == value for key, value in grader.grade(row['answer'], record['text']).items())
    return {'records': len(records), 'passed': True, 'grader_provenance': grader.provenance,
            'kind': 'same_frozen_grader_and_tokenizer_replay_without_inference'}


def worker_command(manifest, label, runtime, script, expected):
    commands = [row for row in manifest['commands'] if row['label'] == label]
    successful = [row for row in commands if row.get('returncode') == 0]
    assert len(successful) == 1 and successful[0] == commands[-1]
    assert [row['startup_attempt'] for row in commands] == list(range(1, len(commands) + 1)) and len(commands) <= 2
    logs = {}
    for row in commands:
        command = row['command']
        assert command[1] == str(runtime / script)
        values = dict(zip(command[2::2], command[3::2], strict=True))
        assert all(values[key] == str(value) for key, value in expected.items())
        assert row['wall_s'] >= 0
        prefix = Path(manifest['attempt']) / (label + f'.attempt{row["startup_attempt"]}')
        stdout, stderr = prefix.with_name(prefix.name + '.stdout.log'), prefix.with_name(prefix.name + '.stderr.log')
        logs[stdout.name], logs[stderr.name] = digest(stdout), digest(stderr)
        if row['returncode'] != 0:
            text = stdout.read_text() + stderr.read_text()
            assert any(marker in text for marker in ('Engine core initialization failed', 'EngineCore failed to start'))
    return logs


def check(args):
    required = [args.controller_snapshot] + [args.request_dir / name for name in ('manifest.json', 'request.json', 'response.json')]
    missing = [str(path) for path in required if not path.exists()]
    if missing:
        return {'passed': None, 'status': 'pending_artifacts', 'missing': missing, 'no_model_forward_or_generation': True}
    capsule, manifest = load(args.controller_snapshot), load(args.request_dir / 'manifest.json')
    request, response = load(args.request_dir / 'request.json'), load(args.request_dir / 'response.json')
    if not manifest.get('completed'):
        return {'passed': None, 'status': 'backend_not_complete', 'no_model_forward_or_generation': True}
    request_index = int(args.request_dir.name[1:])
    if not any(entry['pending']['index'] == request_index for entry in capsule['entries']):
        return {'passed': None, 'status': 'controller_turn_not_committed_in_snapshot', 'no_model_forward_or_generation': True}
    if not response.get('ok'):
        return {'passed': None, 'status': 'rejected_forward_not_a_scientific_result', 'response': response,
                'no_model_forward_or_generation': True}
    assert request['type'] == 'generate', 'This auditor covers generation forwards; teacher-forced arrays require their own schema audit'
    assert manifest['completed'] is True and manifest['request'] == request
    assert manifest['response_sha256'] == hashed(response) and response['ok'] is True
    assert manifest['backend_sha256'] == digest(args.runtime / 'backend.py')
    actual_scripts = {p.name: digest(p) for p in args.runtime.glob('*.py') if not p.name.startswith('test_')}
    assert actual_scripts == capsule['case_manifest']['scripts']
    assert capsule['case_manifest']['passes'] == CASE_BUDGETS[capsule['case_manifest']['case']]
    assert capsule['state']['python_runs'] <= 300
    profile = capsule['case_manifest']['profile']
    manifest_name, manifest_hash = BASE_MANIFESTS[profile]
    assert digest(args.base_model / manifest_name) == capsule['base_provenance']['manifest_sha256'] == manifest_hash
    assert manifest['base_checkpoint_sha256'] == digest(args.base_model / 'model.safetensors')
    for name, entry in capsule['base_provenance']['files'].items():
        assert digest(args.base_model / name) == entry['sha256']
    edit_hash = hashlib.sha256(json.dumps(manifest['edits']['tensors'], sort_keys=True).encode()).hexdigest()
    assert edit_hash == manifest['edits']['sha256']
    if 'execution_profile' in manifest:
        signature = hashed({'request': request, 'edits_sha256': edit_hash, 'base_sha256': manifest['base_checkpoint_sha256'],
                            'execution_profile': manifest['execution_profile']})
        assert manifest['execution_profile'] == capsule['case_manifest']['execution_profile']
    else:
        signature = hashlib.sha256((canonical(request) + edit_hash).encode()).hexdigest()
    assert signature == manifest['request_signature']
    ledger = budget(capsule, int(args.request_dir.name[1:]), request, response, signature)
    attempt = Path(manifest['attempt'])
    assert attempt.parent == args.request_dir and attempt.resolve() == attempt
    practice_hashes = {path.name: digest(path) for path in args.practice.glob('*.jsonl')}
    assert practice_hashes == {name: value for name, value in PRACTICE_SHA.items() if profile == 'qwen' or 'aime' not in name}
    practice = {row['id']: row for path in args.practice.glob('*.jsonl') for row in load_jsonl(path)}
    expected = samples(request, practice)
    publications = {}
    scratch_observations = {}
    for item in manifest['publications']:
        path = Path(item['source'])
        assert path.is_relative_to(attempt) and path.resolve() == path
        if not path.exists():
            return {'passed': None, 'status': 'completed_receipt_has_missing_artifacts', 'missing': [str(path)],
                    'no_model_forward_or_generation': True}
        value = {p.name: digest(p) for p in path.iterdir()} if item['directory'] else digest(path)
        assert value == item['sha256']
        publications[item['name']] = item
        destination = args.request_dir.parent.parent / 'work' / item['name']
        if destination.exists() and not destination.is_symlink() and destination.is_dir() == item['directory']:
            current = {p.name: digest(p) for p in destination.iterdir() if p.is_file()} if item['directory'] else digest(destination)
            scratch_observations[item['name']] = current == value
        else:
            scratch_observations[item['name']] = None
    models = ('original', 'edited') if request['model'] == 'both' else (request['model'],)
    reports, all_records = {}, {}
    expected_publications = set()
    for name in models:
        policy = manifest['policy_checkpoints'][name]
        model = Path(policy['path'])
        assert digest(model / 'model.safetensors') == policy['sha256']
        if name == 'original' or not manifest['edits']['tensors']:
            assert policy['sha256'] == manifest['base_checkpoint_sha256']
            assert model.resolve() == args.base_model.resolve()
        else:
            assert model == attempt / 'checkpoint'
            assert load(model / 'edit-manifest.json') == manifest['edits']
            for filename in capsule['base_provenance']['files']:
                if not filename.endswith('.safetensors') and filename != 'export-manifest.json':
                    assert digest(model / filename) == digest(args.base_model / filename)
        assert load(attempt / (name + '.request.json')) == {**request, 'model': name}
        generated = attempt / name / 'generations.jsonl'
        records = load_jsonl(generated)
        summary = load(attempt / name / 'summary.json')
        assert summary['ok'] is True and summary['model'] == name
        assert summary['grading']['mathqa_sha256'] == digest(args.source / 'exp8_math/code/mathqa.py')
        assert summary['grading']['evaluate_sha256'] == digest(args.source / 'exp8_math/code/evaluate.py')
        summary_check = generations(records, request, expected, summary, profile)
        resource = load(args.runtime / 'execution-profile.json')['generation'] if (args.runtime / 'execution-profile.json').exists() else {'max_num_seqs': 32, 'gpu_memory_utilization': .35}
        cap = request.get('max_tokens', PROFILES[profile]['cap'])
        assert summary['runtime'] == {'gpu_memory_utilization': resource['gpu_memory_utilization'], 'max_num_seqs': resource['max_num_seqs'],
            'max_model_len': max(cap + 2048, max(len(row['prompt_ids']) + cap for row in records)), 'enforce_eager': True, 'prefix_caching': False}
        suffix = '_' + name if len(models) == 2 else ''
        basename = f'gen_{ledger["request_index"]}{suffix}'
        expected_publications.add(basename + '.jsonl')
        assert publications[basename + '.jsonl']['source'] == str(generated)
        target_summary = response[name] if len(models) == 2 else response
        assert all(target_summary[key] == value for key, value in summary.items() if key != 's')
        file_value = response['files'][name] if len(models) == 2 else response['file']
        assert file_value == '/work/' + basename + '.jsonl'
        report = {'summary': summary_check, 'graded_jsonl_sha256': digest(generated),
                  'derived_raw_fields_sha256': hashed([{key: row[key] for key in RAW_FIELDS} for row in records])}
        report['generation_worker_logs'] = worker_command(manifest, name + '_generate', args.runtime, 'generate.py', {
            '--model': model, '--request': attempt / (name + '.request.json'), '--output': attempt / name,
            '--practice': args.practice, '--profile': profile, '--source': args.source})
        if request.get('activations'):
            activation_dir = attempt / (name + '_acts')
            expected_publications.add(basename + '_acts')
            assert publications[basename + '_acts']['source'] == str(activation_dir)
            report['activations'] = activations(activation_dir, request, records, profile)
            response_acts = response['activations'][name] if len(models) == 2 else response['activations']
            assert response_acts == {'dir': '/work/' + basename + '_acts/', 'files': load(activation_dir / 'index.json')['files']}
            report['activation_worker_logs'] = worker_command(manifest, name + '_activations', args.runtime, 'activations.py', {
                '--model': model, '--generations': generated, '--request': attempt / (name + '.request.json'),
                '--output': activation_dir, '--profile': profile})
        if args.replay_grades:
            report['prompt_grade_replay'] = replay(records, expected, model, args.source, args.runtime, profile)
            assert report['prompt_grade_replay']['grader_provenance'] == summary['grading']
        reports[name], all_records[name] = report, records
    assert set(publications) == expected_publications
    worker_seconds = sum(command['wall_s'] for command in manifest['commands'])
    assert response['s'] >= worker_seconds - .01
    if len(models) == 2:
        differences, gains, losses = defaultdict(list), 0, 0
        for before, after in zip(all_records['original'], all_records['edited'], strict=True):
            assert (before['id'], before['sample'], before['seed']) == (after['id'], after['sample'], after['seed'])
            if before['correct'] is not None:
                differences[before['id']].append(int(after['correct']) - int(before['correct']))
                gains += not before['correct'] and after['correct']
                losses += before['correct'] and not after['correct']
        means = [sum(values) / len(values) for values in differences.values()]
        average = sum(means) / len(means) if means else None
        se = math.sqrt(sum((value - average) ** 2 for value in means) / (len(means) - 1) / len(means)) if len(means) > 1 else None
        for key, value in {'items': len(means), 'accuracy_difference': average, 'standard_error': se,
                           'samples_wrong_to_right': gains, 'samples_right_to_wrong': losses}.items():
            actual = response['paired'][key]
            assert actual == value or isinstance(value, float) and math.isclose(actual, value, rel_tol=0, abs_tol=1e-12)
    return {'passed': True, 'status': 'complete_verified', 'kind': 'independent_retained_generation_forward_consistency_audit',
            'case': capsule['case_manifest']['case'], 'profile': profile, 'budget': ledger, 'models': reports,
            'request_signature': signature, 'manifest_sha256': digest(args.request_dir / 'manifest.json'),
            'response_sha256': digest(args.request_dir / 'response.json'), 'controller_snapshot_sha256': digest(args.controller_snapshot),
            'base_checkpoint_sha256': manifest['base_checkpoint_sha256'], 'edits': manifest['edits'],
            'published_artifact_names': sorted(expected_publications), 'current_mutable_scratch_copies_match': scratch_observations,
            'practice_sha256': practice_hashes, 'recorded_total_wall_seconds': response['s'], 'summed_worker_wall_seconds': worker_seconds,
            'audit_source_sha256': digest(Path(__file__)), 'no_model_forward_or_generation': True,
            'limits': ['V1 retains raw text/tokens and grades together; the raw-field hash here is derived, not a historical pre-grading receipt.',
                       'Activation values are not recomputed by model inference; shape, dtype, finiteness and indexing are checked.',
                       'Optional semantic grade replay uses the same frozen grader, not an independent semantic implementation.',
                       'Published work copies are mutable; their current equality is reported separately from retained private artifacts.',
                       'Recorded edit hashes bind the policy checkpoint; earlier float32 edit files may later change in mutable scratch.']}


if __name__ == '__main__':
    if sys.flags.optimize:
        raise RuntimeError('Audit assertions must remain enabled')
    parser = argparse.ArgumentParser()
    commands = parser.add_subparsers(dest='command', required=True)
    export = commands.add_parser('snapshot')
    export.add_argument('--case', type=Path, required=True)
    export.add_argument('--output', type=Path, required=True)
    verify = commands.add_parser('check')
    for name in ('request-dir', 'controller-snapshot', 'runtime', 'practice', 'base-model', 'source', 'output'):
        verify.add_argument('--' + name, type=Path, required=True)
    verify.add_argument('--replay-grades', action='store_true')
    args = parser.parse_args()
    if args.output.exists() or args.output.is_symlink():
        raise ValueError('Choose a new audit output; existing evidence is retained')
    if args.command == 'snapshot':
        result = snapshot(args.case, args.output)
    else:
        if args.replay_grades and args.source is None:
            parser.error('--replay-grades requires --source')
        result = check(args)
        args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))

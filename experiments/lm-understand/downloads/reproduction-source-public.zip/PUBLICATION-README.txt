Public export: private machine paths and host identifiers are replaced with placeholders. Recorded results and numerical weights are unchanged. Embedded source hashes identify the original files; PUBLICATION-MANIFEST.json identifies these public copies.

Existing source snapshot at reconstruction commit 66f3553f358dfeace0421ff851d2eb3ad5edf765. Machine paths require adaptation on another host. The original MANIFEST.json records pre-publication hashes; the PUBLICATION-MANIFEST.json records this export. Historical run-state wording does not supersede the status snapshot.

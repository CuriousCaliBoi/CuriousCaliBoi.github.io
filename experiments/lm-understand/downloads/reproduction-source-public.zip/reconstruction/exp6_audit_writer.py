import argparse
import hashlib
import json
from pathlib import Path
import re

BASE = Path(__file__).resolve().parents[2]
OUT = BASE / 'outputs/replication/reconstructed-exp6-writers'
SOURCE = BASE / 'work/lm_understand-logs-4d09ba6d6a7e891dd8063974dfe81b3d78e3494f'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def audit_case(case):
    root = OUT / 'runs' / case['id']
    state = json.loads((root / 'state.json').read_text())
    assert state['status'] == 'completed'
    assert digest(root / 'original-prompt.txt') == case['original_prompt_sha256']
    assert (root / 'original-prompt.txt').read_bytes() == (SOURCE / f'exp6_go_from_scratch/runs/budget_{case["budget"]}/message.txt').read_bytes()
    assert digest(root / 'initial-prompt.txt') == case['sent_prompt_sha256']
    expected_prompt = (root / 'initial-prompt.txt').read_text()
    turns = sorted((root / 'turns').glob('t*'))
    assert len(turns) == state['turn']
    runs = passes = 0
    failures = []
    pass_records = []
    for index, turn in enumerate(turns, 1):
        assert turn.name == f't{index:03}'
        run = json.loads((turn / 'run.json').read_text())
        context = json.loads((turn / 'context-audit.json').read_text())
        assert (turn / 'prompt.txt').read_text() == expected_prompt
        assert digest(turn / 'prompt.txt') == run['prompt_sha256']
        assert digest(turn / 'answer.md') == run['answer_sha256']
        assert run['thread_id'] == state['thread_id']
        assert run['thread_in'] == (state['thread_id'] if index > 1 else None)
        assert run['rc'] == 0 and run['status'] == 'completed' and run['tool_free'] and not run['tool_items']
        assert context['valid'] and context['user_messages_exact_and_ordered'] and not context['unexpected_context']
        assert context['actual_user_messages'] == context['expected_user_messages'] == index
        assert all(s['model'] == 'gpt-6-astra' and s['effort'] == 'xhigh' for s in context['settings'])
        events = [json.loads(line) for line in (turn / 'events.jsonl').read_text().splitlines()]
        assert [event['thread_id'] for event in events if event['type'] == 'thread.started'] == [state['thread_id']]
        assert all(event.get('item', {}).get('type') in ('error', 'reasoning', 'agent_message') for event in events if 'item' in event)
        answer = (turn / 'answer.md').read_text()
        block = re.fullmatch(r'\s*```(python|games|positions)[ \t]*\n(.*?)\n?```\s*', answer, re.S)
        if block:
            kind, content = block.groups()
            bridge = json.loads((turn / 'bridge-result.json').read_text())
            request, result = bridge['request'], bridge['result']
            assert hashlib.sha256(json.dumps(request, sort_keys=True).encode()).hexdigest() == bridge['request_sha256']
            assert request['kind'] == kind and request['case_id'] == case['id']
            if kind == 'python':
                runs += 1
                assert request['code'] == content == (turn / 'code.py').read_text()
                review = json.loads((turn / 'code-review.json').read_text())
                assert review['approved'] and review['code_sha256'] == digest(turn / 'code.py')
                expected_prompt = f'OUTPUT of Python run {runs} of at most 120:\n```\n{result["out"]}\n```'
                if not result['ok']:
                    failures.append({'turn': turn.name, 'kind': kind, 'result': result})
            else:
                assert request['pass'] == passes + 1
                if 'request' in request:
                    assert json.loads(content) == request['request']
                else:
                    assert content == request['malformed_request'] and not result['ok']
                if result['ok']:
                    passes += 1
                    assert result['pass'] == passes
                    expected_prompt = f'{kind.title()} pass {passes} of {case["budget"]} done.\n```\n{json.dumps(result)}\n```'
                    pass_records.append({'turn': turn.name, 'pass': passes, 'kind': kind, 'request_sha256': bridge['request_sha256']})
                    public_summary = root / 'writer-workspace' / f'pass_{passes}' / 'summary.json'
                    assert json.loads(public_summary.read_text()) == result
                else:
                    expected_prompt = f'{kind.title()} request failed; no pass was used.\n```\n{json.dumps(result)}\n```'
                    failures.append({'turn': turn.name, 'kind': kind, 'result': result})
            assert (turn / 'feedback.txt').read_text() == expected_prompt
        elif index < len(turns):
            assert passes < case['budget'] and '```' not in answer
            expected_prompt = f'You have used {passes} of {case["budget"]} passes. The session continues until every pass is used. Continue with a Python, games or positions block.'
            assert (turn / 'feedback.txt').read_text() == expected_prompt
        else:
            assert passes == case['budget'] and '```' not in answer
            assert answer == (root / 'final_answer.md').read_text()
    assert runs == state['python_runs'] <= 120
    assert passes == state['passes'] == case['budget']
    assert digest(root / 'final_answer.md') == state['final_answer_sha256']
    export = json.loads((root / 'final-export.json').read_text())
    assert export['ok'] and len(export['tensor_sha256']) == 14
    for name, expected in export['tensor_sha256'].items():
        assert digest(root / 'final_network' / (name + '.npy')) == expected
        assert digest(root / 'writer-workspace/net' / (name + '.npy')) == expected
        assert digest(root / 'controller-artifacts/final/snapshot' / (name + '.npy')) == expected
    hashes = {str(p.relative_to(root)): digest(p) for p in sorted(root.rglob('*')) if p.is_file() and p.name not in ('artifact-hashes.json', 'writer-audit.json')}
    (root / 'artifact-hashes.json').write_text(json.dumps(hashes, indent=2) + '\n')
    report = {'passed': True, 'budget': case['budget'], 'case_id': case['id'], 'cli_turns': len(turns), 'python_runs': runs, 'passes': passes, 'all_code_sha_bound_manual_approvals': True, 'pass_records': pass_records, 'failed_requests_or_python': failures, 'tensor_sha256': export['tensor_sha256'], 'artifact_files_hashed': len(hashes), 'artifact_hash_manifest_sha256': digest(root / 'artifact-hashes.json'), 'scope': 'Mechanical provenance and complete transcript/feedback verification. Full code protocol reviews are separately SHA-bound per turn. Local public workspace and private controller snapshots preserve actual practice artifacts; final tensor hashes match all three archived copies.'}
    (root / 'writer-audit.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: v for k, v in report.items() if k not in ('tensor_sha256', 'pass_records')}, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--budget', type=int, required=True, choices=(0, 10, 25, 50))
    args = parser.parse_args()
    manifest = json.loads((OUT / 'manifest.json').read_text())
    audit_case(next(case for case in manifest['cases'] if case['budget'] == args.budget))

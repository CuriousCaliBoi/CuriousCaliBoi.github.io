"""Score frozen final answers without exposing the key to an active conversation."""
import argparse
import hashlib
import json
from pathlib import Path
import re


BASE = Path(__file__).resolve().parents[2]
SOURCE = next((BASE / 'work').glob('lm_understand-logs-*')) / 'exp3_language'
OUT = BASE / 'outputs/replication/reconstructed-exp3'
CORPORA = ('python', 'romaji', 'english')
HEADS = {f'L{layer}H{head}' for layer in range(4) for head in range(6)}
LABELS = r'previous|local|broad|copy|unclear'
NUMBER = r'(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def parse_answer(answer):
    text = answer.replace('**', '').replace('`', '')
    corpus = re.findall(r'^\s*corpus:\s*(python|romaji|english)\s*$', text, re.M | re.I)
    order = re.findall(r'^\s*order:\s*(as is|shuffled)\s*$', text, re.M | re.I)
    if len(corpus) != 1 or len(order) != 1:
        raise ValueError('Expected one unambiguous corpus and order line')
    pairs = re.findall(r'^\s*(?:[-*]\s*)?(L[0-3]H[0-5])\s*[:|—–-]\s*[\'\"]?(' + LABELS + r')\b', text, re.M | re.I)
    labels = {head.upper(): label.lower() for head, label in pairs}
    if len(pairs) != 24 or set(labels) != HEADS:
        raise ValueError('Expected exactly one label for each of the 24 heads')
    probability_lines = re.findall(r'^\s*probabilities:\s*(.+)$', text, re.M | re.I)
    if len(probability_lines) != 1:
        raise ValueError('Expected exactly one probabilities line')
    probabilities = {}
    for name in (*CORPORA, 'as is', 'shuffled'):
        values = re.findall(r'\b' + re.escape(name) + r'\s*=\s*(' + NUMBER + r')\b', probability_lines[0], re.I)
        if len(values) != 1:
            raise ValueError('Missing or ambiguous probability for ' + name)
        value = float(values[0])
        if not 0 <= value <= 1:
            raise ValueError('Probability outside [0, 1]')
        probabilities[name] = value
    corpus_sum = sum(probabilities[name] for name in CORPORA)
    order_sum = probabilities['as is'] + probabilities['shuffled']
    if abs(corpus_sum - 1) > 1e-6 or abs(order_sum - 1) > 1e-6:
        raise ValueError('Probability groups must each sum to one')
    return {'corpus_guess': corpus[0].lower(), 'order_guess': order[0].lower(),
            'probabilities': probabilities, 'head_labels': labels,
            'copy_named': sorted(head for head, label in labels.items() if label == 'copy'),
            'probabilities_unequal': len({probabilities[name] for name in CORPORA}) == 3
                                    and probabilities['as is'] != probabilities['shuffled']}


def score_answer(answer, corpus, ground_truth):
    parsed = parse_answer(answer)
    truth = sorted(head for head, values in ground_truth.items() if values['induct'] > 0.2)
    named = set(parsed['copy_named'])
    true = set(truth)
    tp, fp, fn = len(named & true), len(named - true), len(true - named)
    return {**parsed, 'corpus_correct': parsed['corpus_guess'] == corpus,
            'order_correct': parsed['order_guess'] == 'as is',
            'true_copy_heads': truth, 'copy_exact': named == true,
            'copy_true_positive': tp, 'copy_false_positive': fp, 'copy_false_negative': fn,
            'copy_precision': tp / (tp + fp) if tp + fp else None,
            'copy_recall': tp / (tp + fn) if tp + fn else None,
            'copy_binary_accuracy': (24 - fp - fn) / 24}


def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument('--allow-incomplete', action='store_true')
    args = parser.parse_args()
    manifest = json.loads((OUT / 'manifest.json').read_text())
    truth_path = SOURCE / 'eval/heads.json'
    truth = json.loads(truth_path.read_text())
    records = []
    for case in manifest['cases']:
        root = OUT / 'runs' / case['id']
        state_path = root / 'state.json'
        state = json.loads(state_path.read_text()) if state_path.exists() else {'status': 'not_started'}
        record = {'case_id': case['id'], 'source_run': case['source_run'],
                  'corpus': case['corpus'], 'status': state['status']}
        if state['status'] == 'completed':
            final_path = root / 'final_answer.md'
            assert digest(final_path) == state['final_answer_sha256']
            assert digest(SOURCE / f'networks/{case["corpus"]}/blocks.npz') == case['weights_sha256']
            original_path = SOURCE / f'runs/{case["source_run"]}/final_answer.md'
            ground_truth = truth[case['corpus'] + '_L4_H6_d384_s0']
            scored = score_answer(final_path.read_text(), case['corpus'], ground_truth)
            original = score_answer(original_path.read_text(), case['corpus'], ground_truth)
            turns = [json.loads(path.read_text()) for path in sorted((root / 'turns').glob('*/run.json'))]
            audits = [json.loads(path.read_text()) for path in sorted((root / 'turns').glob('*/context-audit.json'))]
            assert len(turns) == state['turn'] == state['python_runs'] + 1
            assert len(audits) == len(turns) and all(audit['valid'] for audit in audits)
            assert all(turn['tool_free'] and turn['status'] == 'completed' for turn in turns)
            for turn_path in sorted((root / 'turns').glob('*/run.json')):
                turn_record = json.loads(turn_path.read_text())
                assert digest(turn_path.parent / 'answer.md') == turn_record['answer_sha256']
            blocks = sorted((root / 'turns').glob('*/code.py'))
            assert len(blocks) == state['python_runs']
            manual_audits = []
            for block in blocks:
                execution = json.loads((block.parent / 'python-result.json').read_text())
                assert execution['code_sha256'] == digest(block)
                assert execution['weights_sha256'] == case['weights_sha256']
                answer_code = re.fullmatch(r'\s*```python[ \t]*\n(.*?)\n?```\s*', (block.parent / 'answer.md').read_text(), re.S)
                assert answer_code and answer_code.group(1) == block.read_text()
                review_path = block.parent / 'code-review.json'
                review = json.loads(review_path.read_text()) if review_path.exists() else None
                if review is not None:
                    assert review['code_sha256'] == digest(block)
                manual_audits.append({'turn': block.parent.name, 'code_sha256': digest(block),
                                      'review': review})
            record.update(scored, thread_id=state['thread_id'], python_runs=state['python_runs'],
                          turns=len(turns), final_answer_sha256=digest(final_path),
                          weights_sha256=case['weights_sha256'],
                          all_context_audits_valid=True, all_turns_tool_free=True,
                          manual_code_audits=manual_audits,
                          all_code_manually_approved=all(x['review'] and x['review'].get('approved') for x in manual_audits),
                          original={'answer_sha256': digest(original_path), **original})
        elif not args.allow_incomplete:
            raise RuntimeError('Conversation is not complete: ' + case['source_run'])
        records.append(record)
    complete = [record for record in records if record['status'] == 'completed']
    result = {'source_revision': manifest['source_revision'], 'head_truth_sha256': digest(truth_path),
              'copy_threshold': 'induct > 0.2', 'order_truth': 'as is',
              'other_head_labels': 'Retained without categorical accuracy: released truth gives continuous metrics, not a complete categorical key.',
              'completed': len(complete), 'total': len(records),
              'corpus_correct': sum(record['corpus_correct'] for record in complete),
              'order_correct': sum(record['order_correct'] for record in complete),
              'copy_exact': sum(record['copy_exact'] for record in complete),
              'all_completed_code_manually_approved': all(record['all_code_manually_approved'] for record in complete),
              'cases': records}
    (OUT / 'scores.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items() if key != 'cases'}, indent=2))


if __name__ == '__main__':
    main()

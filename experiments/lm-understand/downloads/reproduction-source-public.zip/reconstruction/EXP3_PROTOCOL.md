# Experiment 3 reconstructed execution

This runs the six released language-identification prompts in fresh Codex conversations, two per published block archive. The source revision is `4d09ba6d6a7e891dd8063974dfe81b3d78e3494f`. The controller loads the exact `message.txt` bytes, verifies them against the released first turn, and uses the unmodified neutral model instructions and tool-disable configuration. The requested model settings are `gpt-6-astra`, `xhigh`, 872,000 context tokens, and a 1,000,000-token automatic compaction threshold. Reasoning summaries are not requested. The current CLI and backend may differ from the historical authors' runtime.

The model has no built-in tools. Each reply is either one Python block or a final answer. A new Python process receives only `np` and `W`, a dictionary containing the 40 float32 block arrays (7,084,032 entries). No input embedding, output layer, head measurements, corpus assignment, original answer, or original tool output is provided. Original and staged archive hashes must match. The driver resumes the actual newly created thread UUID and returns actual stdout in the released `OUTPUT of run N of at most 100` wrapper. There is a strict maximum of 100 Python executions. Failed Python output is retained and sent back; it does not trigger another model call for the same turn. A failed CLI/context audit stops that case and remains on disk for diagnosis.

Each Codex turn is launched with `--no-daemon`, `--strict-config`, `--ignore-user-config`, `--ignore-rules`, disabled personal/bundled skills and memories, and an empty working directory. The task's macOS sandbox profile prevents personal AGENTS instructions from being read. Actual saved CLI rollouts are checked after every turn: user messages must exactly match the intended initial prompt and fresh feedback sequence, the model/effort must match, and no unexpected developer instructions or built-in tool calls may appear.

## Python isolation and documented deviations

The original Python driver was not released. Host bubblewrap network namespace creation failed with `Failed RTM_NEWADDR: Operation not permitted`, before any model call. The reconstructed sandbox therefore uses the cached Ubuntu 24.04 Docker image by immutable image ID. Every invocation has `--network none`, a read-only root filesystem, all capabilities dropped, `no-new-privileges`, UID/GID 1000, private process namespace, no GPU devices, and fresh writable tmpfs mounts for `/work` and `/tmp`. CPU runtime directories and the task-owned virtual environment are read-only. The only data mount is the selected block archive as `/weights.npz`. No host home, checkout, answer key, SSH files, Docker socket, or dataset is mounted. Image metadata and the exact launch command are retained with each execution.

The source of the archive mount is an opaque random filename in a neutral directory. This matters because Linux mountinfo can reveal the source of a bind mount even when its destination is neutral. Case directories also use opaque identifiers. The inherited environment is cleared before Python starts. The preflight records the environment, mountinfo, sys.path, accessible arrays, runtime versions, and denial checks. It demonstrates that source files, head truth, SSH credentials, the Docker socket, GPU use, and external network access are unavailable. A separate second invocation confirms scratch state does not survive.

Resource limits are 600 seconds, eight CPUs, 24 GiB memory, and 256 processes per execution, with two conversations at most in flight. The original package versions and memory/CPU limits were not specified. Current package versions are retained in `sandbox-preflight.json`. Printed feedback is limited to 20,000 payload characters, followed by a truncation marker when needed; complete stdout and stderr remain archived. The source describes a 20,000-character output cut without publishing its exact exception/truncation formatting, so this boundary behavior is a reconstruction. On timeout, only the task's unique named container is removed.

## Protocol audit and scoring

The prompt forbids any network/layer forward pass on real, random, or constructed input. It permits weight-only linear algebra, including products, eigenvalues, singular vectors, and applying matrices to directions taken from other weights. Static AST screening is triage only. It pauses potentially sensitive code for review before execution; every archived block, including unflagged blocks, also receives independent manual review. Reviews retain the exact code SHA-256 and approval/rejection rationale. A rejected block remains an observed failed protocol attempt; it is never rewritten or silently replaced. No correct-answer feedback or protocol steering is added to the model conversation.

`exp3_score.py` reads only completed final answers. It verifies all 24 head labels, the corpus/order answer and probabilities, final answer hashes, unchanged source archives, and all turn/context audits. Copy-head truth is `induct > 0.2` from the published `eval/heads.json`, as stated in the authors' README. It deliberately does not use `eval/scores.json`'s inconsistent 0.3 cutoff. All order truth is `as is`. Other head labels are retained but not assigned a new categorical accuracy metric: the released truth contains continuous measurements rather than a complete categorical key. Published final answers are scored separately as controls and never enter fresh model context.

## Artifacts and commands

The generated artifact directory is `outputs/replication/reconstructed-exp3` in the workspace root. `manifest.json` maps opaque run IDs to source cases and records exact source/archive/settings hashes. Each `runs/<id>/turns/tNNN` folder contains the sent prompt, response, CLI events, command and context audit. Code turns additionally contain `code.py`, static/manual review, raw Python stdout/stderr, bounded feedback, and the sandbox launch metadata. `tool_calls.jsonl` aggregates the actual executed code and returned output. Completed cases have a frozen `final_answer.md` and state; `scores.json` holds the post-final evaluation. Failed sandbox preflights remain as evidence alongside the passing preflight.

From the isolated worktree:

```sh
python3 -m unittest test_exp3_score.py
python3 -u exp3_runner.py
python3 exp3_score.py
```

The runner reuses completed turn records without repeating a model call. It refuses an unfinished previous CLI attempt. Do not start another runner against an active batch. Scoring may use `--allow-incomplete` to record completed cases while the remaining cases are still running; those pending cases are not scored.

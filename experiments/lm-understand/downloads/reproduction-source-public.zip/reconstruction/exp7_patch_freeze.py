"""Freeze only completed audited reader selections for the ten published checks."""
import json
from pathlib import Path

from exp7_cli import BASE, OUT as READERS, sha
from exp7_score import score_case

OUT = BASE / 'outputs/replication/reconstructed-exp7-patch'


def main():
    manifest = json.loads((READERS / 'manifest.json').read_text())
    cases = [case for case in manifest['cases'] if case['round'] in
             ('weights_only_1', 'weights_only_2', 'weights_only_3') or
             case['round'] == 'attention_tool' and case['pair_number'] == 1]
    assert len(cases) == 10
    frozen = []
    for case in cases:
        scored = score_case(case, manifest)
        if scored['status'] != 'completed':
            raise RuntimeError('Reader selection is not frozen: ' + case['round'] + '/pair' + str(case['pair_number']))
        root = READERS / 'runs' / case['id']
        answer = (root / 'final_answer.md').read_text()
        assert sha(answer.encode()) == scored['final_answer_sha256']
        frozen.append({'case_id': case['id'], 'round': case['round'], 'pair': 99 + case['pair_number'],
                       'reader_status': 'completed', 'reader_thread_id': scored['thread_id'],
                       'final_answer': answer, 'final_answer_sha256': scored['final_answer_sha256'],
                       'prediction': scored['prediction'], 'all_context_audits_valid': True,
                       'all_turns_tool_free': True, 'all_python_blocks_manually_approved': True})
    OUT.mkdir(parents=True, exist_ok=True)
    path = OUT / 'frozen-reader-selections.json'
    if path.exists():
        assert json.loads(path.read_text()) == frozen
    else:
        path.write_text(json.dumps(frozen, indent=2) + '\n')
    print(json.dumps({'comparisons': len(frozen), 'sha256': sha(path.read_bytes()), 'path': str(path)}))


if __name__ == '__main__':
    main()

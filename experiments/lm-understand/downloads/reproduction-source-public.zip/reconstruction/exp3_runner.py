"""Run six fresh weight-only language identifications with isolated Python feedback."""
import argparse
import ast
import collections
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import time
import uuid

BASE = Path(__file__).resolve().parents[2]
SOURCE = next((BASE / 'work').glob('lm_understand-logs-*'))
OUT = BASE / 'outputs/replication/reconstructed-exp3'
REMOTE = '<gpu-project>/reconstructed/exp3'
EMPTY = BASE / 'work/replication-empty'


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def initialize():
    OUT.mkdir(exist_ok=True)
    preflight = json.loads((OUT / 'sandbox-preflight.json').read_text())
    fresh_check = json.loads((OUT / 'sandbox-fresh-process-check.json').read_text())
    assert preflight['rc'] == 0 and fresh_check['out'].strip() == 'False'
    manifest = OUT / 'manifest.json'
    if manifest.exists():
        return json.loads(manifest.read_text())
    shutil.copyfile(SOURCE / 'exp3_language/runs/instructions.md', OUT / 'instructions.md')
    cases, archives = [], {}
    for corpus in ('python', 'romaji', 'english'):
        path = SOURCE / f'exp3_language/networks/{corpus}/blocks.npz'
        opaque = 'w_' + uuid.uuid4().hex + '.npz'
        remote_path = REMOTE + '/weights/' + opaque
        remote_source = '<gpu-project>/source/' + str(path.relative_to(SOURCE))
        script = 'import shutil,hashlib,json\np=' + repr(remote_path) + '\nshutil.copyfile(' + repr(remote_source) + ',p)\nprint(hashlib.sha256(open(p,"rb").read()).hexdigest())\n'
        staged = subprocess.check_output(['ssh', '-o', 'BatchMode=yes', '<gpu-ssh-alias>', 'python3', '-'], input=script, text=True).strip()
        assert staged == sha(path.read_bytes())
        archives[corpus] = {'source_path': str(path.relative_to(SOURCE)), 'sha256': staged, 'remote_path': remote_path}
        for repeat in (0, 1):
            source_run = f'{corpus}_r{repeat}'
            prompt = SOURCE / f'exp3_language/runs/{source_run}/message.txt'
            assert prompt.read_bytes() == (prompt.parent / 'turns/t001/prompt.txt').read_bytes()
            cases.append({'id': uuid.uuid4().hex, 'source_run': source_run, 'corpus': corpus,
                          'repeat': repeat, 'initial_prompt_sha256': sha(prompt.read_bytes()),
                          'weights_sha256': staged, 'remote_weights': remote_path})
    result = {'source_revision': SOURCE.name.removeprefix('lm_understand-logs-'),
              'model': 'gpt-6-astra', 'effort': 'xhigh', 'context_window': 872000,
              'auto_compact_token_limit': 1000000, 'max_python_runs': 100, 'archives': archives, 'cases': cases,
              'cli_version': subprocess.check_output(['codex', '--version'], text=True).strip(),
              'sandbox_image_id': preflight['image_id'],
              'sandbox_script_sha256': sha((Path(__file__).parent / 'exp3_sandbox.py').read_bytes()),
              'deviations': ['Original Python driver unavailable; reconstructed fresh-process feedback loop.',
                             'Host bubblewrap network namespace creation fails; pinned Docker Ubuntu 24.04 with network none, read-only filesystem and neutral opaque mounts is used instead.',
                             'Original Python/package versions and resource limits are not pinned. Current versions are saved by sandbox preflight; each code run is capped at 24 GiB memory, eight CPUs and 600 seconds.',
                             'Historical Codex build/backend snapshot unavailable; installed CLI uses the original model alias and requested settings.',
                             'Static forward-pass screening pauses flagged code for human-agent review; full archived-code compliance review remains required.']}
    write_json(manifest, result)
    return result


def options():
    result, section = [], ''
    for raw in (SOURCE / 'harness/codex_config.toml').read_text().splitlines():
        line = raw.strip()
        if not line or line.startswith('#'):
            continue
        if line.startswith('['):
            section = line.strip('[]') + '.'
            continue
        key, value = line.split('=', 1)
        key = section + key.strip()
        if key in ('model', 'model_reasoning_effort', 'model_instructions_file'):
            continue
        result += ['-c', key + '=' + value.strip()]
    result += ['-m', 'gpt-6-astra', '-c', 'model_reasoning_effort="xhigh"',
               '-c', 'model_context_window=872000', '-c', 'model_auto_compact_token_limit=1000000',
               '-c', 'model_instructions_file=' + json.dumps(str(OUT / 'instructions.md')),
               '-c', 'project_doc_max_bytes=0', '-c', 'skills.include_instructions=false',
               '-c', 'skills.bundled.enabled=false', '-c', 'features.memories=false']
    return result


def audit_context(thread, expected):
    paths = list((Path.home() / '.codex/sessions').glob('*/*/*/*' + thread + '*'))
    if len(paths) != 1:
        raise RuntimeError('Cannot uniquely locate actual CLI rollout: ' + thread)
    users, extras, settings, messages = [], [], [], []
    for line in paths[0].read_text().splitlines():
        event = json.loads(line)
        payload = event.get('payload', {})
        if event.get('type') == 'turn_context':
            settings.append({k: payload.get(k) for k in ('model', 'effort', 'approval_policy', 'sandbox_policy')})
        if event.get('type') != 'response_item' or payload.get('role') not in ('developer', 'user'):
            continue
        role = payload['role']
        text = '\n'.join(item.get('text', '') for item in payload.get('content', []) if isinstance(item, dict))
        messages.append({'role': role, 'characters': len(text), 'sha256': sha(text.encode())})
        if not text or text.startswith(('<permissions instructions>', '<environment_context>')):
            continue
        if role == 'developer' and text.strip() == "Answer the user's request.":
            continue
        if role == 'user':
            users.append(text)
        else:
            extras.append({'role': role, 'preview': text[:500]})
    matched = users == expected
    valid_settings = all(x['model'] == 'gpt-6-astra' and x['effort'] == 'xhigh' for x in settings)
    return {'valid': matched and not extras and valid_settings, 'expected_user_messages': len(expected),
            'actual_user_messages': len(users), 'user_messages_exact_and_ordered': matched,
            'unexpected_context': extras, 'settings': settings, 'message_hashes': messages}


def model_turn(directory, prompt, thread, expected):
    directory.mkdir(parents=True, exist_ok=True)
    prompt_path = directory / 'prompt.txt'
    if prompt_path.exists():
        assert prompt_path.read_text() == prompt
    else:
        prompt_path.write_text(prompt)
    existing = directory / 'run.json'
    if existing.exists():
        saved = json.loads(existing.read_text())
        if saved['status'] == 'completed':
            return (directory / 'answer.md').read_text(), saved['thread_id']
        raise RuntimeError('Unfinished prior CLI attempt requires review: ' + str(directory))
    command = ['sandbox-exec', '-f', str(BASE / 'work/experiment-cli.sb'), shutil.which('codex'), '--no-daemon', 'exec']
    if thread:
        command.append('resume')
    command += ['--strict-config', '--ignore-user-config', '--ignore-rules', '--skip-git-repo-check', '--json']
    command += options() + ['-o', str(directory / 'answer.md')]
    if thread:
        command.append(thread)
    command.append('-')
    record = {'status': 'running', 'thread_in': thread, 'cmd': command, 'prompt_sha256': sha(prompt.encode()),
              'started_at': datetime.now(timezone.utc).isoformat()}
    write_json(existing, record)
    started = time.monotonic()
    with prompt_path.open('rb') as inp, (directory / 'events.jsonl').open('wb') as stdout, (directory / 'stderr.log').open('wb') as stderr:
        result = subprocess.run(command, stdin=inp, stdout=stdout, stderr=stderr, cwd=EMPTY)
    events = [json.loads(line) for line in (directory / 'events.jsonl').read_text().splitlines()]
    thread_ids = [e['thread_id'] for e in events if e['type'] == 'thread.started']
    new_thread = thread_ids[0] if thread_ids else None
    items = collections.Counter(e['item']['type'] for e in events if 'item' in e)
    tool_items = {k: v for k, v in items.items() if k not in ('error', 'reasoning', 'agent_message')}
    errors = [e for e in events if e['type'] in ('error', 'turn.failed')]
    answer_path = directory / 'answer.md'
    answer = answer_path.read_text() if answer_path.exists() else ''
    audit = audit_context(new_thread, expected) if new_thread else {'valid': False}
    write_json(directory / 'context-audit.json', audit)
    valid = (result.returncode == 0 and any(e['type'] == 'turn.completed' for e in events)
             and bool(answer.strip()) and not tool_items and not errors and audit['valid']
             and (not thread or thread == new_thread))
    record.update(status='completed' if valid else 'failed', rc=result.returncode,
                  wall_s=round(time.monotonic() - started, 2), thread_id=new_thread,
                  answer_sha256=sha(answer.encode()), tool_free=not tool_items, tool_items=tool_items,
                  item_types=dict(items), errors=errors, context_audit_valid=audit['valid'],
                  usage=[e['usage'] for e in events if 'usage' in e])
    write_json(existing, record)
    if not valid:
        raise RuntimeError('CLI turn/audit failed: ' + str(directory))
    return answer, new_thread


def screen(code):
    flags = []
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return ['syntax_error_requires_review']
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            name = ast.unparse(node.func)
            if re.search(r'(softmax|relu|layer_norm|next_char_logits)|(^|\.)(exp|maximum|open|eval|exec|system|popen)$', name, re.I):
                flags.append(name)
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            names = [node.module or ''] if isinstance(node, ast.ImportFrom) else [x.name for x in node.names]
            flags.extend('import:' + x for x in names if x.split('.')[0] in ('socket', 'subprocess', 'requests', 'urllib'))
    return sorted(set(flags))


def python_run(case, directory, code):
    path = directory / 'python-result.json'
    if path.exists():
        saved = json.loads(path.read_text())
        assert saved['code_sha256'] == sha(code.encode())
        return saved
    (directory / 'code.py').write_text(code)
    flags = screen(code)
    screen_record = {'flags': flags, 'code_sha256': sha(code.encode()),
                     'status': 'needs_review' if flags else 'static_screen_passed_manual_audit_pending'}
    write_json(directory / 'code-screen.json', screen_record)
    if flags:
        print(json.dumps({'case': case['source_run'], 'event': 'code_review_needed', 'directory': str(directory), 'flags': flags}), flush=True)
        approval_path = directory / 'code-review.json'
        while not approval_path.exists():
            time.sleep(1)
        review = json.loads(approval_path.read_text())
        if review.get('code_sha256') != sha(code.encode()) or not review.get('approved'):
            raise RuntimeError('Code rejected by protocol review: ' + str(directory))
    request = {'weights_path': case['remote_weights'], 'code': code}
    result = subprocess.run(['ssh', '-o', 'BatchMode=yes', '<gpu-ssh-alias>', 'python3', REMOTE + '/exp3_sandbox.py'],
                            input=json.dumps(request), capture_output=True, text=True, timeout=660)
    if result.returncode != 0:
        (directory / 'bridge-error.txt').write_text(result.stdout + '\n' + result.stderr)
        raise RuntimeError('Sandbox bridge failure: ' + str(directory))
    record = json.loads(result.stdout)
    assert record['weights_sha256'] == case['weights_sha256']
    assert record['code_sha256'] == sha(code.encode())
    assert record['image_id'] == json.loads((OUT / 'manifest.json').read_text())['sandbox_image_id']
    write_json(path, record)
    (directory / 'stdout.txt').write_text(record['stdout'])
    (directory / 'python-stderr.txt').write_text(record['stderr'])
    (directory / 'feedback.txt').write_text(record['out'])
    return record


def run_case(case):
    root = OUT / 'runs' / case['id']
    root.mkdir(parents=True, exist_ok=True)
    thread, expected, count = None, [], 0
    initial = SOURCE / f'exp3_language/runs/{case["source_run"]}/message.txt'
    prompt = initial.read_text()
    assert sha(initial.read_bytes()) == case['initial_prompt_sha256']
    state = {'case_id': case['id'], 'status': 'running', 'turn': 0, 'python_runs': 0}
    try:
        for turn in range(1, 102):
            state.update(turn=turn, python_runs=count, thread_id=thread)
            write_json(root / 'state.json', state)
            directory = root / 'turns' / f't{turn:03d}'
            expected.append(prompt)
            answer, thread = model_turn(directory, prompt, thread, expected)
            print(json.dumps({'case': case['source_run'], 'turn': turn, 'event': 'model_complete', 'thread_id': thread}), flush=True)
            code = re.fullmatch(r'\s*```python[ \t]*\n(.*?)\n?```\s*', answer, re.S)
            if code:
                if count == 100:
                    raise RuntimeError('Python budget exhausted; model supplied another code block')
                result = python_run(case, directory, code.group(1))
                count += 1
                state['python_runs'] = count
                calls = []
                for saved_path in sorted((root / 'turns').glob('t*/python-result.json')):
                    saved = json.loads(saved_path.read_text())
                    calls.append({'run': len(calls) + 1, 'turn': saved_path.parent.name,
                                  'code': (saved_path.parent / 'code.py').read_text(),
                                  **{k: saved[k] for k in ('out', 'seconds', 'rc', 'timed_out', 'truncated', 'code_sha256', 'weights_sha256')}})
                (root / 'tool_calls.jsonl').write_text(''.join(json.dumps(c) + '\n' for c in calls))
                print(json.dumps({'case': case['source_run'], 'run': count, 'event': 'python_complete',
                                  'rc': result['rc'], 'seconds': result['seconds'], 'truncated': result['truncated']}), flush=True)
                prompt = f'OUTPUT of run {count} of at most 100:\n```\n{result["out"]}\n```'
            elif '```' in answer:
                raise RuntimeError('Reply does not follow one-code-block or final-answer format')
            else:
                (root / 'final_answer.md').write_text(answer)
                state.update(status='completed', thread_id=thread, python_runs=count, final_answer_sha256=sha(answer.encode()))
                write_json(root / 'state.json', state)
                print(json.dumps({'case': case['source_run'], 'event': 'completed', 'python_runs': count}), flush=True)
                return state
        raise RuntimeError('Conversation reached turn limit without final answer')
    except Exception as error:
        state.update(status='failed', error=str(error), thread_id=thread, python_runs=count)
        write_json(root / 'state.json', state)
        print(json.dumps({'case': case['source_run'], 'event': 'failed', 'error': str(error)}), flush=True)
        return state


def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument('--workers', type=int, default=2, choices=(1, 2))
    parser.add_argument('--case', action='append')
    parser.add_argument('--initialize-only', action='store_true')
    args = parser.parse_args()
    manifest = initialize()
    if args.initialize_only:
        print(json.dumps({'cases': len(manifest['cases']), 'manifest': str(OUT / 'manifest.json')}))
        return
    cases = [c for c in manifest['cases'] if not args.case or c['source_run'] in args.case]
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        states = list(pool.map(run_case, cases))
    write_json(OUT / 'batch-state.json', states)
    if any(s['status'] != 'completed' for s in states):
        raise SystemExit(1)


if __name__ == '__main__':
    main()

import csv
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'outputs/replication/reconstructed-exp3'
SOURCE = ROOT / 'work/lm_understand-logs-4d09ba6d6a7e891dd8063974dfe81b3d78e3494f/exp3_language'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def parse(path):
    lines = path.read_text().replace('**', '').replace('`', '').splitlines()
    pairs = [re.match(r'^\s*(?:[-*]\s*)?(L[0-3]H[0-5])\s*[:|—–-]\s*[\'\"]?(previous|local|broad|copy|unclear)\b', line, re.I) for line in lines]
    labels = {m[1].upper(): m[2].lower() for m in pairs if m}
    assert sum(m is not None for m in pairs) == 24 and len(labels) == 24
    fields = {}
    for key in ('corpus', 'order', 'probabilities'):
        values = [line.split(':', 1)[1].strip().lower() for line in lines if re.match(r'^\s*' + key + ':', line, re.I)]
        assert len(values) == 1
        fields[key] = values[0]
    probabilities = dict((key, float(value)) for key, value in re.findall(r'(python|romaji|english|as is|shuffled)=([0-9.]+)', fields['probabilities']))
    assert len(probabilities) == 5
    assert abs(sum(probabilities[c] for c in ('python', 'romaji', 'english')) - 1) < 1e-9
    assert abs(probabilities['as is'] + probabilities['shuffled'] - 1) < 1e-9
    return fields, labels, probabilities


def main():
    manifest = json.loads((OUT / 'manifest.json').read_text())
    scores = json.loads((OUT / 'scores.json').read_text())
    hashes = json.loads((OUT / 'artifact-hashes.json').read_text())
    for relative, expected in hashes.items():
        assert sha(OUT / relative) == expected, relative
    truth = json.loads((SOURCE / 'eval/heads.json').read_text())
    csv_rows = {row['source_run']: row for row in csv.DictReader((OUT / 'results.csv').open())}
    rows = []
    failed_python = []
    thread_ids = set()
    turns_total = code_total = 0
    for case in manifest['cases']:
        root = OUT / 'runs' / case['id']
        state = json.loads((root / 'state.json').read_text())
        assert state['status'] == 'completed'
        assert state['thread_id'] not in thread_ids
        thread_ids.add(state['thread_id'])
        record = next(row for row in scores['cases'] if row['case_id'] == case['id'])
        assert sha(SOURCE / 'networks' / case['corpus'] / 'blocks.npz') == case['weights_sha256'] == record['weights_sha256']
        initial = SOURCE / 'runs' / case['source_run'] / 'message.txt'
        assert sha(initial) == case['initial_prompt_sha256']
        paths = sorted((root / 'turns').glob('t*'))
        assert len(paths) == state['turn'] == state['python_runs'] + 1
        turns_total += len(paths)
        expected_prompt = initial.read_text()
        for index, turn in enumerate(paths, 1):
            assert turn.name == f't{index:03}'
            run = json.loads((turn / 'run.json').read_text())
            audit = json.loads((turn / 'context-audit.json').read_text())
            assert (turn / 'prompt.txt').read_text() == expected_prompt
            assert sha(turn / 'prompt.txt') == run['prompt_sha256']
            assert sha(turn / 'answer.md') == run['answer_sha256']
            assert run['status'] == 'completed' and run['rc'] == 0 and run['tool_free'] and not run['tool_items']
            assert run['thread_id'] == state['thread_id']
            assert run['thread_in'] == (state['thread_id'] if index > 1 else None)
            assert audit['valid'] and audit['user_messages_exact_and_ordered'] and not audit['unexpected_context']
            assert audit['actual_user_messages'] == audit['expected_user_messages'] == index
            assert all(s['model'] == manifest['model'] and s['effort'] == manifest['effort'] for s in audit['settings'])
            events = [json.loads(line) for line in (turn / 'events.jsonl').read_text().splitlines()]
            assert [event['thread_id'] for event in events if event['type'] == 'thread.started'] == [state['thread_id']]
            assert all(event.get('item', {}).get('type') in ('error', 'reasoning', 'agent_message') for event in events if 'item' in event)
            if index < len(paths):
                code_total += 1
                code = turn / 'code.py'
                execution = json.loads((turn / 'python-result.json').read_text())
                review = json.loads((turn / 'code-review.json').read_text())
                assert review['approved'] and sha(code) == review['code_sha256'] == execution['code_sha256']
                assert execution['weights_sha256'] == case['weights_sha256']
                assert not execution['timed_out'] and not execution['truncated']
                answer = (turn / 'answer.md').read_text().strip()
                assert answer.startswith('```python\n') and answer.endswith('```')
                assert answer[len('```python\n'):-3].rstrip('\n') == code.read_text().rstrip('\n')
                assert (turn / 'feedback.txt').read_text() == execution['out']
                expected_prompt = f'OUTPUT of run {index} of at most 100:\n```\n{execution["out"]}\n```'
                if execution['rc'] != 0:
                    failed_python.append({'case': case['source_run'], 'turn': turn.name, 'rc': execution['rc'], 'error': execution['stderr'].strip().splitlines()[-1]})
        final = root / 'final_answer.md'
        assert final.read_bytes() == (paths[-1] / 'answer.md').read_bytes()
        assert sha(final) == state['final_answer_sha256'] == record['final_answer_sha256']
        fields, labels, probabilities = parse(final)
        copies = sorted(head for head, label in labels.items() if label == 'copy')
        true_copies = sorted(head for head, values in truth[case['corpus'] + '_L4_H6_d384_s0'].items() if values['induct'] > .2)
        assert labels == record['head_labels'] and probabilities == record['probabilities']
        correct = {'corpus_correct': fields['corpus'] == case['corpus'], 'order_correct': fields['order'] == 'as is', 'copy_exact': copies == true_copies}
        assert copies == record['copy_named'] and true_copies == record['true_copy_heads']
        for key, value in correct.items():
            assert record[key] == value and csv_rows[case['source_run']][key] == str(value)
        assert csv_rows[case['source_run']]['copy_named'] == ','.join(copies)
        assert int(csv_rows[case['source_run']]['python_runs']) == state['python_runs']
        for corpus in ('python', 'romaji', 'english', 'as is'):
            assert float(csv_rows[case['source_run']][corpus]) == probabilities[corpus]
        original = SOURCE / 'runs' / case['source_run'] / 'final_answer.md'
        original_fields, original_labels, original_probs = parse(original)
        assert record['original']['answer_sha256'] == sha(original)
        assert record['original']['head_labels'] == original_labels and record['original']['probabilities'] == original_probs
        assert record['original']['corpus_guess'] == original_fields['corpus']
        assert record['original']['order_guess'] == original_fields['order']
        assert record['original']['copy_exact'] == (sorted(h for h, v in original_labels.items() if v == 'copy') == true_copies)
        rows.append({'source_run': case['source_run'], 'python_runs': state['python_runs'], 'corpus_guess': fields['corpus'], 'copy_named': copies, **correct})
    for key in ('corpus_correct', 'order_correct', 'copy_exact'):
        assert sum(row[key] for row in rows) == scores[key]
    assert len(rows) == scores['completed'] == scores['total'] == 6
    assert code_total == 50 and turns_total == 56
    result = {'passed': True, 'reviewer': 'independent protocol reviewer', 'scores_sha256': sha(OUT / 'scores.json'), 'artifact_hash_manifest_sha256': sha(OUT / 'artifact-hashes.json'), 'artifact_hashes_checked': len(hashes), 'cases': rows, 'cli_turns_checked': turns_total, 'python_executions_checked': code_total, 'python_failures_preserved_in_feedback': failed_python, 'all_code_sha_bound_manual_approvals': True, 'copy_threshold': 'induct > 0.2', 'corpus_correct': scores['corpus_correct'], 'order_correct': scores['order_correct'], 'copy_exact': scores['copy_exact'], 'scope': 'Independent reparse of all six frozen answers and released controls; aggregate and CSV recomputation; prompt/feedback chains, same-thread model settings, code/weight/final/source hashes, all declared artifact hashes and archived execution/manual review records. No new model calls or Python reruns.'}
    (OUT / 'independent-review.json').write_text(json.dumps(result, indent=2) + '\n')
    (Path(__file__).parent / 'exp3-result-review.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()

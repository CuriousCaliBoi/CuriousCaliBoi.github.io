# Experiment 5 reconstructed evaluation

`exp5_evaluate.py` applies the published numeric-edit language and evaluates the three released policies and three frozen fresh replies. It never trains or revises a policy. The author-specific parser, evaluator, and random streams were not released; this implementation is a documented reconstruction.

The `prepare` command starts each policy at zero in six float32 tensors. It reads only the final edits block, permits numeric literals and indexed assignment/addition/subtraction/multiplication, and skips unreadable statements independently. It validates the reconstructed released policies against every tensor byte in the original `hand.npz` archives and checks their statement and nonzero counts. It also checks that the installed MinAtar game source is exactly the source embedded in each original prompt. All six fresh/released network archives are saved with their source reply hashes.

The `evaluate` command uses MinAtar 1.0.15, the published six-channel mappings, all six action logits, sampled softmax actions, sticky-action probability 0.1, difficulty ramping enabled, and a 10,000-step episode limit. Network arithmetic is float32; softmax normalization is float64. There are 1,000 episodes per policy.

The fixed master seed is 20261102. Environment and action seeds are the two uint32 values from `numpy.random.SeedSequence([master_seed, game_index, episode_index]).generate_state(2)`, where game indices are Breakout 0, Seaquest 1, Asterix 2. Each episode constructs a new environment, seeds it, resets it, and sets `last_action=0`. The released and fresh policy for a game use the same initial seeds. These conventions are explicit deviations because the original RNG streams, episode reset convention, and exact evaluator arithmetic are unknown. Worker count does not affect an episode's seeds.

On the Spark, the completed run used:

```sh
cd <gpu-project>/reconstructed/exp5
<gpu-project>/.venv/bin/python -m unittest test_exp5_edits -v
<gpu-project>/.venv/bin/python exp5_evaluate.py prepare \
  --source <gpu-project>/source \
  --fresh <gpu-project>/reconstructed/exp5/fresh \
  --out <gpu-project>/results/reconstructed-exp5
<gpu-project>/.venv/bin/python exp5_evaluate.py evaluate \
  --source <gpu-project>/source \
  --out <gpu-project>/results/reconstructed-exp5 \
  --episodes 1000 --workers 8 --seed 20261102 --max-steps 10000
```

Use a different output directory for a different protocol. An interrupted evaluation can resume with identical arguments; it preserves completed episodes and rejects a changed protocol. `protocol.json` records software versions and the script hash. `parse-validation.json` records edit counts, parse errors, source hashes, and released tensor identity checks. Each case has its network archive, per-episode JSONL, and summary JSON; `summary.json` collects all six cases. The archived author means are explicitly identified as reference results, separate from the new control and fresh-policy scores.

The original PPO baselines are not rerun because their checkpoints are unavailable. A comparison to their archived scores is not a fresh PPO replication.

import unittest

from exp7_patch_metrics import normalized_effects


class MetricTests(unittest.TestCase):
    def test_direction_and_unclipped_effects(self):
        h = {'follow_rate': 0.1, 'mean_margin': -2}
        s = {'follow_rate': 0.9, 'mean_margin': 6}
        patched_s = {'follow_rate': 0.7, 'mean_margin': 2}
        patched_h = {'follow_rate': 0.5, 'mean_margin': 10}
        result = normalized_effects(h, s, patched_s, patched_h)
        self.assertAlmostEqual(result['gap_closed_h2s'], 0.25)
        self.assertAlmostEqual(result['gap_opened_s2h'], 0.5)
        self.assertEqual(result['margin_closed_h2s'], 0.5)
        self.assertEqual(result['margin_opened_s2h'], 1.5)

    def test_zero_baseline_gap_is_undefined(self):
        baseline = {'follow_rate': 0.5, 'mean_margin': 0}
        result = normalized_effects(baseline, baseline, baseline, baseline)
        for name in ('gap_closed_h2s', 'gap_opened_s2h', 'margin_closed_h2s', 'margin_opened_s2h'):
            self.assertIsNone(result[name])


if __name__ == '__main__':
    unittest.main()

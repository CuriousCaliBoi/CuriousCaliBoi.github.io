"""Run reader code with the released prelude and role-hidden checkpoint mounts."""
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import time
import uuid

ROOT = Path('<gpu-project>/reconstructed/exp7-readers')
TIMEOUT = 600
MAX_OUT = 15000
MEMORY = 48 << 30


def opaque_path(path, parent):
    resolved = Path(path).resolve()
    if resolved.parent != ROOT / parent or not re.fullmatch(r'[0-9a-f]{32}', resolved.name):
        raise ValueError('Only opaque task-owned paths are accepted')
    return resolved


def run(pair_path, work_path, prelude_name, code):
    pair = opaque_path(pair_path, 'pairs')
    work = opaque_path(work_path, 'scratch')
    if prelude_name not in ('blocks', 'full'):
        raise ValueError('Unknown prelude')
    prelude = (ROOT / 'preludes' / (prelude_name + '.py')).read_text()
    image = (ROOT / 'image_id.txt').read_text().strip()
    assert re.fullmatch(r'sha256:[0-9a-f]{64}', image)
    container = 'lm-exp7-' + uuid.uuid4().hex
    cmd = ['docker', 'run', '--rm', '-i', '--name', container, '--network', 'none',
           '--cap-drop', 'ALL', '--security-opt', 'no-new-privileges', '--read-only',
           '--user', '1000:1000', '--cpus', '8', '--memory', str(MEMORY), '--pids-limit', '256',
           '--tmpfs', '/tmp:rw,nosuid,mode=1777,size=536870912',
           '--mount', 'type=bind,src=/usr,dst=/usr,readonly',
           '--mount', f'type=bind,src={ROOT / "runtime"},dst=/env,readonly',
           '--mount', f'type=bind,src={pair},dst=/case,readonly',
           '--mount', f'type=bind,src={work},dst=/work',
           '--workdir', '/work', '--entrypoint', '/usr/bin/env', image,
           '-i', 'HOME=/tmp', 'PATH=/usr/bin', 'OMP_NUM_THREADS=8', 'OPENBLAS_NUM_THREADS=8',
           'MKL_NUM_THREADS=8', 'CUDA_VISIBLE_DEVICES=', '/env/bin/python', '-I', '-']
    started = time.monotonic()
    try:
        process = subprocess.run(cmd, input=prelude + '\n' + code, capture_output=True,
                                 text=True, timeout=TIMEOUT)
        stdout, stderr, rc = process.stdout, process.stderr, process.returncode
        feedback = stdout + ('\n[stderr]\n' + stderr[-6000:] if stderr.strip() else '')
        timed_out = False
    except subprocess.TimeoutExpired as error:
        stdout = (error.stdout or b'').decode(errors='replace') if isinstance(error.stdout, bytes) else error.stdout or ''
        stderr = (error.stderr or b'').decode(errors='replace') if isinstance(error.stderr, bytes) else error.stderr or ''
        rc, timed_out = None, True
        subprocess.run(['docker', 'rm', '-f', container], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        feedback = f'[timed out after {TIMEOUT} s]'
    truncated = len(feedback) > MAX_OUT
    if truncated:
        feedback = feedback[:MAX_OUT] + f'\n[output cut at {MAX_OUT:,} characters]'
    files = {str(path.relative_to(pair)): hashlib.sha256(path.read_bytes()).hexdigest()
             for path in sorted(pair.glob('*/*')) if path.is_file()}
    scratch_bytes = sum(info.st_size for directory, _, names in os.walk(work, followlinks=False)
                        for name in names if stat.S_ISREG((info := (Path(directory) / name).lstat()).st_mode))
    return {'stdout': stdout, 'stderr': stderr, 'rc': rc, 'timed_out': timed_out,
            'truncated': truncated, 'out': feedback or '(no output)',
            'seconds': round(time.monotonic() - started, 3),
            'code_sha256': hashlib.sha256(code.encode()).hexdigest(),
            'prelude_sha256': hashlib.sha256(prelude.encode()).hexdigest(), 'checkpoint_hashes': files,
            'sandbox_command': cmd, 'timeout_seconds': TIMEOUT, 'memory_limit_bytes': MEMORY,
            'max_output_payload_characters': MAX_OUT, 'backend': 'docker', 'image_id': image,
            'scratch_file_bytes': scratch_bytes, 'scratch_limit_exceeded': scratch_bytes > 20 << 30}


if __name__ == '__main__':
    request = json.load(sys.stdin)
    print(json.dumps(run(**request)))

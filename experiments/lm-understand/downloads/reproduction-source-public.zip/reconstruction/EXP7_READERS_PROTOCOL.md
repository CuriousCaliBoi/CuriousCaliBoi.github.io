# Reconstructed Experiment 7 readers

The readers use the five unmodified released prompts and preludes from revision `4d09ba6d6a7e891dd8063974dfe81b3d78e3494f`, with three independent A/B conversations per prompt. The checkpoints are newly trained reconstructions produced from the released training code and data, not the unavailable original checkpoint bytes. Their full training, behavior, and tensor audits are kept separately in `outputs/replication/reconstructed-exp7`. Reader contexts never receive that information.

Codex uses `gpt-6-astra`, `xhigh`, an 872,000-token context window, 1,000,000-token compaction threshold, and detailed reasoning summaries, as in the released Experiment 7 commands. All built-in tools, personal instructions, skills, and memories are disabled using the audited task isolation profile. Each actual CLI rollout is checked against the exact expected user-message sequence and settings. Every follow-up resumes the new conversation's actual UUID. Original answers and original computation results are never replayed.

## Reader execution

The released native safetensors and config files are copied byte-for-byte into opaque directories. The first three rounds contain only the stripped releases. Round four and the attention round also contain the identical frozen embeddings/output matrix and tokenizer files. The controller verifies source/staged hashes, role-free metadata/configuration, A/B shared-file equality, and expected embedding presence. Source release identifiers remain in the controller manifest only. File timestamps are normalized, and no model-visible mount path identifies a role, original release, fact, or answer key.

Reader Python runs in a new network-disabled Docker container using the exact preflight image ID, a read-only filesystem and CPU runtime, UID/GID 1000, dropped capabilities, and no-new-privileges. The environment is cleared. Only `/case/A`, `/case/B`, and the conversation's own persistent `/work` are mounted, along with the Python runtime. No source checkout, home directory, SSH files, Docker socket, training/evaluation files, or GPU devices are mounted. NumPy is pinned to the author's 2.2.6 version; torch, transformers, tokenizers, scipy, sklearn, and pandas are unavailable. The published prelude runs unchanged before the generated code. Each execution is capped at 600 seconds, 48 GiB memory, and eight CPUs. Output feedback contains up to 15,000 characters plus a truncation marker; complete stdout/stderr remain archived.

Scratch persists across fresh processes, as the original Experiment 7 prompt requires. The 20 GiB scratch budget is monitored after runs rather than enforced through a filesystem quota. Exceeding it stops the case. This differs from Experiment 3, whose scratch must disappear after each run.

Every Python block waits for manual protocol approval before execution. A `code-review.json` file must contain its exact SHA-256 and an affirmative approval. Static screening only helps prioritize review. Weight products, norm weight vectors as diagonal scalings, and embedding-row linear algebra are permitted. Layer/model evaluation on inputs, hidden-state normalization, attention softmax, MLP nonlinearities, and search are prohibited in reader Python. A rejected block remains a recorded failure; it is not edited or replaced.

## Budgets and early answers

| Round | Total Python/attention runs | Maximum nudges | Nudge only below |
|---|---:|---:|---:|
| weights_only_1 | 60 | 2 | 30 runs |
| weights_only_2 | 60 | 2 | 30 runs |
| weights_only_3 | 60 | 10 | 30 runs |
| weights_only_4 | 60 | 10 | 30 runs |
| attention_tool | 20 | 1 | 8 runs |

Each early answer is saved before sending the exact released nudge wording. The weights-only 30-run threshold is an explicit reconstruction: the original controller is unavailable, and round four pair two finished at 30 runs after seven nudges, with its last nudge at 26. The historical manual interruption of two round-four conversations is not replayed. New conversations retain the full 60-run ceiling. At most two final-JSON format reminders are allowed, matching the highest observed released count; the original controller's maximum is not available. All unparseable answers remain archived. A nudge or format reminder does not consume a computation run.

## Attention exception

Only the attention round can submit a JSON list of 1–16 texts. A trusted inference process, separate from reader Python, prepends one BOS token and rejects sequences longer than 128 tokens including BOS. It uses the same staged full A/B checkpoints and tokenizer. The reader's generated Python never executes in the GPU process.

The inference process calls the model's transformer body with eager attention and float32 weights, following the released behavioral evaluator's precision convention. The original attention driver's precision was not published; this is a documented reconstruction. No logits, generated text, hidden states, or MLP values are exposed. Only float16 arrays of shape `[18, 4, query, key]` and the text/token lists are saved. The process checks finite nonnegative entries, approximate unit row sums, and zero future attention. Immutable copies and hashes are archived outside reader scratch before copies are placed under `/work/attn/rN`. Each attention call consumes one of the same 20 total runs used by Python.

The GPU preflight checks shape, causality, row sums, and changed-text sensitivity on synthetic texts. A separate preprocessing-only check compares token IDs and individually decoded tokens for three archived texts against the authors' `tokens.json`; those texts and results remain outside active reader contexts and scratches. The historical missing-package failure and skipped attention call numbers are not replayed: new successful calls begin at one.

## Artifacts

`outputs/replication/reconstructed-exp7-readers` contains the source/staged hash manifest, passing and attempted preflights, runtime source copies and hashes, driver logs, and one opaque run directory per conversation. Each turn retains its exact prompt, response, CLI events, command/usage record, and actual context audit. Code turns also retain Python source, SHA-bound review, raw stdout/stderr, bounded feedback, and sandbox command. Attention turns retain submitted texts, token lists, arrays, all hashes, validation metrics, and runtime versions. Early answers, format failures, final answers, structured predictions, and aggregate tool-call records remain separate.

The four weights-only rounds run with at most two simultaneous conversations. Attention may use one additional worker, keeping Experiment 7 at three reader conversations at most. Cases are scored against the reconstructed release's role map only after a final answer is frozen. Ranked component lists are retained for subsequent causal checks; descriptive weight differences alone are not reported as proof of causal importance.

Several weights-only turns exposed a Codex output-serialization failure: each event stream and actual rollout contained one complete nonempty assistant commentary message followed by an empty final message, and `-o` saved only the latter. The recovery utility accepts only a unique nonempty completed message with a trailing empty message, a successful tool-free turn, and an exact match to the actual rollout. It preserves the original empty answer, failed run/state, phase, and hashes, then uses the retained response verbatim and resumes the same thread. It never selects among multiple responses or regenerates a response. A single recovery queue waits until the scheduled weights batch ends and resumes at most two cases concurrently. The same strict rule applies if a later resumed turn encounters this failure; the comparison uses only actual assistant messages following that turn’s user message. Other failure types are not automatically retried.

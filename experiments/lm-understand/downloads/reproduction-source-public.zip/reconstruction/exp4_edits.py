import ast
import hashlib
import io
import json
from pathlib import Path
import re
import tokenize

import numpy as np


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def rounded_actor(text):
    body = text.split('THE WEIGHTS (complete actor).', 1)[1]
    pattern = r'(?m)^([\w.]+) \(([\d x]+)\), scale ([\deE.+-]+):[^\n]*\n'
    headers = list(re.finditer(pattern, body))
    result = {}
    for i, header in enumerate(headers):
        name, dimensions, scale = header.groups()
        numbers = body[header.end():headers[i + 1].start() if i + 1 < len(headers) else len(body)]
        numbers = re.sub(r'(?m)^\d+:\s*', '', numbers).strip()
        integers = np.fromstring(numbers, sep=' ', dtype=np.float64)
        result[name] = (integers * float(scale)).reshape(tuple(map(int, dimensions.split(' x '))))
    if len(result) != 14 or sum(a.size for a in result.values()) != 171664:
        raise ValueError('The rounded prompt actor is incomplete')
    return result


def index_literal(node):
    if isinstance(node, ast.Slice):
        parts = [index_literal(x) if x is not None else None for x in (node.lower, node.upper, node.step)]
        return slice(*parts)
    if isinstance(node, ast.Tuple):
        return tuple(index_literal(x) for x in node.elts)
    value = ast.literal_eval(node)
    if not isinstance(value, int) or isinstance(value, bool):
        raise ValueError('Tensor indices must be integers')
    return value


def statements(text):
    starts = list(re.finditer(r'(?m)^```edits[ \t]*\n', text))
    if not starts:
        raise ValueError('Reply has no edits block')
    body = text[starts[-1].end():].split('```', 1)[0]
    chunks, pending = [], []
    for raw in body.splitlines():
        line = raw.split('#', 1)[0].strip()
        if not line:
            continue
        if re.match(r'^(?:ZERO\s+|[A-Za-z]\w*(?:\.\w+)?\s*(?:\[|=))', line) and pending:
            chunks.append('\n'.join(pending))
            pending = []
        pending.append(line)
        joined = '\n'.join(pending)
        if joined.count('[') == joined.count(']'):
            chunks.append(joined)
            pending = []
    if pending:
        chunks.append('\n'.join(pending))
    return chunks


def apply_edits(weights, text):
    result = {k: a.copy() for k, a in weights.items()}
    edits = statements(text)
    errors = []
    for number, code in enumerate(edits, 1):
        try:
            zero = re.fullmatch(r'ZERO\s+([\w.]+)', code)
            if zero:
                result[zero[1]][...] = 0
                continue
            parsed = ast.parse(code).body
            if len(parsed) != 1:
                raise ValueError('Expected one assignment')
            stmt = parsed[0]
            if isinstance(stmt, ast.Assign) and len(stmt.targets) == 1:
                target, op = stmt.targets[0], None
            elif isinstance(stmt, ast.AugAssign) and isinstance(stmt.op, (ast.Add, ast.Sub, ast.Mult)):
                target, op = stmt.target, stmt.op
            else:
                raise ValueError('Only numeric assignments and +=, -=, *= are allowed')
            for token in tokenize.generate_tokens(io.StringIO(code).readline):
                if token.type == tokenize.NUMBER and not re.fullmatch(r'(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?', token.string):
                    raise ValueError('Edit values must use plain decimal numbers')
            if any(isinstance(node, ast.Constant) and isinstance(node.value, bool) for node in ast.walk(stmt.value)):
                raise ValueError('Boolean edit values are not numbers')
            if isinstance(target, ast.Subscript):
                name, index = ast.unparse(target.value), index_literal(target.slice)
            else:
                name, index = ast.unparse(target), Ellipsis
            value = np.asarray(ast.literal_eval(stmt.value))
            if value.dtype.kind not in 'iuf':
                raise ValueError('Edit values must be plain numbers or numeric lists')
            value = value.astype(np.float64)
            if not np.isfinite(value).all() or np.any(np.abs(value) > 1e6):
                raise ValueError('Edit value is nonfinite or exceeds 1e6')
            selected = result[name][index]
            if isinstance(op, ast.Add):
                value = selected + value
            elif isinstance(op, ast.Sub):
                value = selected - value
            elif isinstance(op, ast.Mult):
                value = selected * value
            result[name][index] = value
        except (SyntaxError, ValueError, TypeError, KeyError, IndexError, OverflowError) as error:
            errors.append({'statement': number, 'text': code, 'error': str(error)})
    return result, {'statements': len(edits), 'applied': len(edits) - len(errors), 'errors': errors}


def prepare(source, fresh_reply, output):
    source, fresh_reply, output = Path(source), Path(fresh_reply), Path(output)
    src = source / 'exp4_fix_car'
    prompt = src / 'runs/oneshot_repair/reply/prompt.txt'
    original = src / 'runs/oneshot_repair/reply/answer.md'
    archive = src / 'networks/edited_actor.npz'
    base = rounded_actor(prompt.read_text())
    rebuilt, original_report = apply_edits(base, original.read_text())
    with np.load(archive, allow_pickle=False) as z:
        comparisons = {k: bool(np.array_equal(rebuilt[k], z[k])) for k in z.files}
    changes = sum(int(np.count_nonzero(base[k] != a)) for k, a in rebuilt.items())
    if not all(comparisons.values()) or changes != 6073 or original_report['applied'] != 51:
        raise ValueError(f'Published edit reconstruction failed: {comparisons}, changed={changes}, {original_report}')
    fresh, fresh_report = apply_edits(base, fresh_reply.read_text())
    output.mkdir(parents=True, exist_ok=True)
    policies = {'base': base, 'published_edit': rebuilt, 'fresh_edit': fresh}
    policy_records = {}
    for name, weights in policies.items():
        path = output / (name + '.npz')
        np.savez(path, **weights)
        policy_records[name] = {'path': str(path), 'sha256': digest(path), 'storage_dtype': 'float64',
                                'changed_from_rounded_base': sum(int(np.count_nonzero(base[k] != a)) for k, a in weights.items())}
    report = {'source_files': {str(p.relative_to(source)) if p.is_relative_to(source) else str(p): digest(p)
                               for p in (prompt, original, archive, fresh_reply)},
              'published_reconstruction': {'all_tensors_equal': all(comparisons.values()), 'tensors': comparisons,
                                           'changed_entries': changes, 'edit_report': original_report},
              'fresh_edit_report': fresh_report, 'policies': policy_records}
    (output / 'artifact-validation.json').write_text(json.dumps(report, indent=2) + '\n')
    return policies, report

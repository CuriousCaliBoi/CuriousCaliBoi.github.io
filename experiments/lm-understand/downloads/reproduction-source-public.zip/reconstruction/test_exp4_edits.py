import unittest

import numpy as np

from exp4_edits import apply_edits


class EditRecoveryTests(unittest.TestCase):
    def run_block(self, text):
        return apply_edits({'embed.b': np.zeros(4)}, '```edits\n' + text + '\n```')

    def test_bad_statement_does_not_consume_neighbors(self):
        result, report = self.run_block('embed.b[0] = 2\ngarbage\nembed.b[1] = 3')
        np.testing.assert_array_equal(result['embed.b'], [2, 3, 0, 0])
        self.assertEqual(report['applied'], 2)
        self.assertEqual(len(report['errors']), 1)

    def test_unclosed_list_does_not_consume_following_assignment(self):
        result, report = self.run_block('embed.b[0:2] = [1,\nembed.b[3] = 7')
        np.testing.assert_array_equal(result['embed.b'], [0, 0, 0, 7])
        self.assertEqual(report['applied'], 1)
        self.assertEqual(len(report['errors']), 1)

    def test_multiline_list_and_last_block(self):
        text = '```edits\nembed.b[0] = 99\n```\n```edits\nembed.b[0:2] = [\n2,\n3]\nembed.b[1] *= 2\n```'
        result, report = apply_edits({'embed.b': np.zeros(4)}, text)
        np.testing.assert_array_equal(result['embed.b'], [2, 6, 0, 0])
        self.assertEqual(report['errors'], [])

    def test_non_numeric_or_oversized_values_are_skipped(self):
        result, report = self.run_block('embed.b[0] = "2"\nembed.b[1] = 1000001\nembed.b[2] = True\nembed.b[3] = 4')
        np.testing.assert_array_equal(result['embed.b'], [0, 0, 0, 4])
        self.assertEqual(len(report['errors']), 3)

    def test_nondecimal_and_mixed_boolean_values_are_skipped(self):
        text = '\n'.join(['embed.b[0] = 0xff', 'embed.b[0] = 0b10',
                          'embed.b[0] = 0o10', 'embed.b[0:2] = [True, 1.0]',
                          'embed.b[3] = -1.5e-1'])
        result, report = self.run_block(text)
        np.testing.assert_array_equal(result['embed.b'], [0, 0, 0, -0.15])
        self.assertEqual(len(report['errors']), 4)


if __name__ == '__main__':
    unittest.main()

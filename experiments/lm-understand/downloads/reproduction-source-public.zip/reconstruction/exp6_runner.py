import argparse
import difflib
import json
from pathlib import Path
import re
import shutil
import subprocess
import time
import uuid

from exp6_cli import BASE, OUT, SOURCE, model_turn, sha, write_json

REMOTE = '<gpu-project>/reconstructed/exp6'
ORIGINAL_OPPONENTS = 'The practice opponents: "random" (uniform random legal moves), "weak" and "strong" (two policy networks trained with reinforcement learning on this game, not among the evaluation opponents; they beat a random player 95 % and 98 % of the time).'
REPLACEMENT_OPPONENTS = 'The historical practice checkpoints are unavailable, so the practice opponents are reconstructed: "random" is uniform over legal moves; "strong" is the released same-size PPO network with seed 1; "weak" samples each move from a probability distribution that is 50% this same network\'s masked softmax and 50% uniform over legal moves. The held-out evaluation networks are the released same-size PPO seeds 0 and 2. No historical 95% or 98% win-rate claim applies to these substitute opponents.'
ORIGINAL_MEASUREMENT = 'HOW IT WILL BE MEASURED. After you finish, your network plays 2,000 games against each of several hidden opponents: policy networks trained with reinforcement learning on this game (self-play; they beat a uniform random player 79-98 % of the time), and a uniform random player. Your network is Black in half of the games; the moves of both players are sampled from their policies; there is no search. Score: wins / games; the main measure is the average over the trained opponents. You never see these opponents.'
REPLACEMENT_MEASUREMENT = 'HOW IT WILL BE MEASURED. The original hidden opponent checkpoints are unavailable. After you finish, your network plays 2,000 games against each of two held-out released same-size PPO policy networks (seeds 0 and 2), and a uniform random legal player. Your network is Black in half of the games; the moves of both players are sampled from their policies; there is no search. Score: wins / games; the main measure is the average over the two trained opponents. No historical win rate against random is claimed for these substitutes. You never see these opponents.'


def bridge(request):
    command = ['ssh', '-o', 'BatchMode=yes', '<gpu-ssh-alias>',
               'JAX_PLATFORMS=cpu OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 '
               f'PYTHONPATH={REMOTE}/deps '
               '<gpu-project>/.venv-kinetix/bin/python '
               f'{REMOTE}/exp6_backend.py']
    result = subprocess.run(command, input=json.dumps(request), capture_output=True, text=True, timeout=1020)
    if result.returncode:
        raise RuntimeError('Remote bridge failed: ' + result.stderr[-4000:])
    return json.loads(result.stdout)


def initialize():
    OUT.mkdir(parents=True, exist_ok=True)
    path = OUT / 'manifest.json'
    if path.exists():
        return json.loads(path.read_text())
    preflight = json.loads((OUT / 'preflight.json').read_text())
    if not preflight['passed']:
        raise RuntimeError('The writer sandbox/pass preflight has not passed')
    instructions = SOURCE / 'exp6_go_from_scratch/runs/budget_0/instructions.md'
    shutil.copyfile(instructions, OUT / 'instructions.md')
    cases = []
    for budget in (0, 10, 25, 50):
        case_id = uuid.uuid4().hex
        source = SOURCE / f'exp6_go_from_scratch/runs/budget_{budget}/message.txt'
        original = source.read_text()
        if original.count(ORIGINAL_MEASUREMENT) != 1:
            raise ValueError('Expected original measurement paragraph exactly once')
        sent = original.replace(ORIGINAL_MEASUREMENT, REPLACEMENT_MEASUREMENT)
        if budget:
            if original.count(ORIGINAL_OPPONENTS) != 1:
                raise ValueError('Expected original opponent description exactly once')
            sent = sent.replace(ORIGINAL_OPPONENTS, REPLACEMENT_OPPONENTS)
        case_dir = OUT / 'runs' / case_id
        case_dir.mkdir(parents=True)
        (case_dir / 'original-prompt.txt').write_bytes(source.read_bytes())
        (case_dir / 'initial-prompt.txt').write_text(sent)
        (case_dir / 'prompt.diff').write_text(''.join(difflib.unified_diff(original.splitlines(keepends=True),
                                                                        sent.splitlines(keepends=True),
                                                                        fromfile='original', tofile='sent')))
        result = bridge({'kind': 'initialize', 'case_id': case_id})
        if not result['ok']:
            raise RuntimeError(result)
        cases.append({'id': case_id, 'budget': budget, 'original_prompt_sha256': sha(source.read_bytes()),
                      'sent_prompt_sha256': sha(sent.encode()), 'sandbox_initialization': result})
    manifest = {'cases': cases, 'model': 'gpt-6-astra', 'effort': 'xhigh', 'max_python_runs': 120,
                'source_revision': '4d09ba6d6a7e891dd8063974dfe81b3d78e3494f',
                'cli_version': subprocess.check_output(['codex', '--version'], text=True).strip(),
                'hidden_opponents': ['ppo_same_size_lr3e-5_s0', 'ppo_same_size_lr3e-5_s2'],
                'practice_strong': 'ppo_same_size_lr3e-5_s1',
                'practice_weak': 'per-action 50% seed1 masked softmax + 50% uniform legal',
                'deviations': ['Historical small PPO and REINFORCE opponent checkpoints are missing; released same-size checkpoints are substituted.',
                               'The measurement paragraph is corrected in all budgets, and the practice-opponent sentence in budgets10/25/50; original and sent prompts and diffs are retained.',
                               'Docker isolation substitutes for unavailable bubblewrap network namespaces; original writer prelude is preserved.',
                               'Every Python block receives an external protocol review before execution; the model receives only its actual output.',
                               'Original evaluation wrapper, PGX version and RNG splitting are unavailable; reconstructed PGX2.6.0 CPU passes are used.'],
                'harness_sha256': {p.name: sha(p.read_bytes()) for p in Path(__file__).parent.glob('exp6_*.py')}}
    write_json(path, manifest)
    harness = OUT / 'harness'
    harness.mkdir()
    for source in Path(__file__).parent.glob('exp6_*.py'):
        shutil.copyfile(source, harness / source.name)
    return manifest


def reviewed_python(directory, code):
    code_path = directory / 'code.py'
    code_path.write_text(code)
    path = directory / 'code-review.json'
    print(json.dumps({'event': 'python_review_needed', 'directory': str(directory),
                      'code_sha256': sha(code.encode())}), flush=True)
    while not path.exists():
        time.sleep(1)
    result = json.loads(path.read_text())
    if result.get('code_sha256') != sha(code.encode()) or not result.get('approved'):
        raise RuntimeError('The generated Python block failed protocol review')


def run_case(case):
    root = OUT / 'runs' / case['id']
    prompt = (root / 'initial-prompt.txt').read_text()
    expected, thread, runs, passes = [], None, 0, 0
    state = {'case_id': case['id'], 'budget': case['budget'], 'status': 'running'}
    try:
        for turn in range(1, 501):
            directory = root / 'turns' / f't{turn:03d}'
            state.update(turn=turn, python_runs=runs, passes=passes, thread_id=thread)
            write_json(root / 'state.json', state)
            expected.append(prompt)
            answer, thread = model_turn(directory, prompt, thread, expected)
            block = re.fullmatch(r'\s*```(python|games|positions)[ \t]*\n(.*?)\n?```\s*', answer, re.S)
            if block:
                kind, content = block.groups()
                saved = directory / 'bridge-result.json'
                local_error = None
                if kind == 'python':
                    if runs == 120:
                        raise RuntimeError('Python run budget exhausted')
                    reviewed_python(directory, content)
                    request = {'kind': kind, 'case_id': case['id'], 'code': content}
                else:
                    if passes == case['budget']:
                        raise RuntimeError('Pass budget exhausted')
                    try:
                        request = {'kind': kind, 'case_id': case['id'], 'pass': passes + 1, 'request': json.loads(content)}
                    except json.JSONDecodeError as error:
                        request = {'kind': kind, 'case_id': case['id'], 'pass': passes + 1, 'malformed_request': content}
                        local_error = {'ok': False, 'error': 'Invalid JSON: ' + str(error)}
                request_hash = sha(json.dumps(request, sort_keys=True).encode())
                if saved.exists():
                    record = json.loads(saved.read_text())
                    assert record['request_sha256'] == request_hash
                else:
                    record = {'request_sha256': request_hash, 'request': request, 'result': local_error or bridge(request)}
                    write_json(saved, record)
                result = record['result']
                if kind == 'python':
                    runs += 1
                    prompt = f'OUTPUT of Python run {runs} of at most 120:\n```\n{result["out"]}\n```'
                elif result['ok']:
                    passes += 1
                    prompt = f'{kind.title()} pass {passes} of {case["budget"]} done.\n```\n{json.dumps(result)}\n```'
                else:
                    prompt = f'{kind.title()} request failed; no pass was used.\n```\n{json.dumps(result)}\n```'
                (directory / 'feedback.txt').write_text(prompt)
                print(json.dumps({'event': 'feedback_complete', 'budget': case['budget'], 'turn': turn,
                                  'python_runs': runs, 'passes': passes, 'ok': result['ok']}), flush=True)
            elif '```' in answer:
                raise RuntimeError('Reply did not follow the single-block or final-answer format')
            elif passes < case['budget']:
                prompt = f'You have used {passes} of {case["budget"]} passes. The session continues until every pass is used. Continue with a Python, games or positions block.'
                (directory / 'feedback.txt').write_text(prompt)
            else:
                (root / 'final_answer.md').write_text(answer)
                export_path = root / 'final-export.json'
                export = json.loads(export_path.read_text()) if export_path.exists() else bridge({'kind': 'finalize', 'case_id': case['id']})
                if not export['ok']:
                    raise RuntimeError(export)
                write_json(export_path, export)
                expected_path = f'{REMOTE}/private/{case["id"]}/final/snapshot'
                if export['path'] != expected_path:
                    raise RuntimeError('Unexpected final artifact path')
                target = root / 'final_network'
                if not target.exists():
                    subprocess.run(['scp', '-r', f'<gpu-ssh-alias>:{expected_path}', str(target)], check=True)
                for name, digest in export['tensor_sha256'].items():
                    if sha((target / (name + '.npy')).read_bytes()) != digest:
                        raise RuntimeError('Downloaded final tensor hash mismatch')
                state.update(status='completed', thread_id=thread, python_runs=runs, passes=passes,
                             final_answer_sha256=sha(answer.encode()))
                write_json(root / 'state.json', state)
                return state
        raise RuntimeError('Conversation reached the reconstructed 500-turn safety limit')
    except Exception as error:
        state.update(status='failed', thread_id=thread, python_runs=runs, passes=passes, error=str(error))
        write_json(root / 'state.json', state)
        raise


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--initialize-only', action='store_true')
    parser.add_argument('--budget', action='append', type=int, choices=(0, 10, 25, 50))
    args = parser.parse_args()
    manifest = initialize()
    if not args.initialize_only:
        states = [run_case(case) for case in manifest['cases'] if not args.budget or case['budget'] in args.budget]
        write_json(OUT / 'batch-state.json', states)

import json
from pathlib import Path
import sys
import unittest

from langdetect import DetectorFactory

DetectorFactory.seed = 0
suite = unittest.defaultTestLoader.loadTestsFromNames([
    'instruction_following_eval.instructions_test', 'instruction_following_eval.instructions_util_test'])
result = unittest.TextTestRunner().run(suite)
report = {'passed': result.wasSuccessful(), 'tests': result.testsRun, 'langdetect_seed': 0,
          'failures': len(result.failures), 'errors': len(result.errors), 'official_checker_sources_unchanged': True}
Path(sys.argv[1]).write_text(json.dumps(report, indent=2) + '\n')
raise SystemExit(0 if result.wasSuccessful() else 1)

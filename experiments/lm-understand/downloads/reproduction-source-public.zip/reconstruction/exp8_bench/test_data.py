import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from audit_data import normalized
from bench_provenance import metadata_files
from prepare import archive_ids


class DataTests(unittest.TestCase):
    def test_archive_order_interleaves_ragged_shards(self):
        with TemporaryDirectory() as temporary:
            source = Path(temporary)
            for index, ids in enumerate([['a', 'd'], ['b', 'e'], ['c']]):
                folder = source / 'exp8_math/eval/unedited/parts' / f'test_s{index}of3'
                folder.mkdir(parents=True)
                (folder / 'test_per_problem.json').write_text(json.dumps([{'id': value, 'correct': 'must not be used'} for value in ids]))
            self.assertEqual(archive_ids(source, 'test')[0], ['a', 'b', 'c', 'd', 'e'])
            (source / 'exp8_math/eval/unedited/parts/test_s1of3/test_per_problem.json').unlink()
            with self.assertRaises(ValueError):
                archive_ids(source, 'test')

    def test_normalization_is_exact_after_declared_transforms(self):
        self.assertEqual(normalized('Ａ  Red\nBLUE'), normalized('a red blue'))
        self.assertNotEqual(normalized('red-blue'), normalized('red blue'))

    def test_model_metadata_hash_detects_tokenizer_change(self):
        with TemporaryDirectory() as temporary:
            model = Path(temporary)
            (model / 'config.json').write_text('{}')
            (model / 'tokenizer.json').write_text('original')
            (model / 'model.safetensors').write_bytes(b'weights')
            before = metadata_files(model)
            self.assertNotIn('model.safetensors', before)
            (model / 'tokenizer.json').write_text('changed')
            self.assertNotEqual(before, metadata_files(model))


if __name__ == '__main__':
    unittest.main()

import argparse
import fcntl
import gzip
import hashlib
import json
import os
from pathlib import Path
import sys
import subprocess
import time

from bench_provenance import context, context_hash, metadata_files

SAMPLES = {'aime24': 16, 'aime25': 16, 'amc23': 16, 'math500': 4, 'minerva': 4, 'olympiad': 4,
           'gsm8k': 2, 'mmlupro1k': 1, 'gpqa': 4, 'ifeval': 2}


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(8 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', type=Path, required=True)
    parser.add_argument('--profile', choices=['qwen', 'gemma'], required=True)
    parser.add_argument('--bench', type=Path, required=True)
    parser.add_argument('--set', choices=SAMPLES, required=True)
    parser.add_argument('--shard', required=True)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--runtime', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--review', type=Path, required=True)
    parser.add_argument('--gpu-worker', action='store_true', help=argparse.SUPPRESS)
    args = parser.parse_args()
    source_hashes = {p.name: digest(p) for p in Path(__file__).parent.glob('*.py') if not p.name.startswith('test_')}
    review = json.loads(args.review.read_text())
    if not review.get('approved') or review.get('scripts') != source_hashes:
        raise ValueError('Benchmark runtime has not received matching startup review')
    provenance = context(args.source, args.runtime)
    if review['provenance_sha256'] != context_hash(provenance):
        raise ValueError('Benchmark source, dependencies or tokenizer resources changed after review')
    model_metadata = metadata_files(args.model)
    if model_metadata != review['models'][args.profile]['metadata_files']:
        raise ValueError('Checkpoint configuration/tokenizer differs from the reviewed model')
    overlay = Path(__file__).resolve().parent.parent / 'deps'
    sys.path.insert(0, str(overlay))
    sys.path.insert(0, str(args.runtime))
    from protocol import PROFILES, INSTRUCTION
    from scoring import Scorer
    p = PROFILES[args.profile]
    cache = args.runtime.parent / 'cache'
    os.environ['PATH'] = str(Path(sys.executable).parent) + ':/usr/local/cuda/bin:' + os.environ.get('PATH', '')
    os.environ.setdefault('CUDA_HOME', '/usr/local/cuda')
    os.environ['MATHVERIFY_PKGS'] = str(args.runtime.parent / 'cpu-deps')
    os.environ['NLTK_DATA'] = str(Path(__file__).resolve().parent.parent / 'nltk_data')
    for name, child in [('XDG_CACHE_HOME', ''), ('VLLM_CACHE_ROOT', 'vllm'), ('TRITON_CACHE_DIR', 'triton'),
                        ('FLASHINFER_WORKSPACE_BASE', 'flashinfer'), ('CUDA_CACHE_PATH', 'cuda'), ('TORCH_HOME', 'torch')]:
        os.environ[name] = str(cache / child)
    bench_manifest = json.loads((args.bench / 'manifest.json').read_text())
    input_path = args.bench / (args.set + '.jsonl')
    if digest(input_path) != bench_manifest['sets'][args.set]['sha256']:
        raise ValueError('Prepared benchmark input checksum changed')
    index, stride = map(int, args.shard.split('/'))
    if not 0 <= index < stride:
        raise ValueError('Invalid evaluation shard')
    rows = [json.loads(line) for line in input_path.open()][index::stride]
    if not rows:
        raise ValueError('Evaluation shard is empty')
    if len(rows) * SAMPLES[args.set] > 32:
        raise ValueError('Evaluation shards must contain at most 32 answers so editing requests can run between shards')
    args.output.mkdir(parents=True, exist_ok=True)
    job = {'set': args.set, 'shard': args.shard, 'profile': args.profile, 'model_sha256': digest(args.model / 'model.safetensors'),
           'dataset_sha256': digest(input_path), 'scripts': source_hashes, 'samples': SAMPLES[args.set],
           'sampling': {**p['sampling'], 'max_tokens': p['max_tokens'], 'seed': 0}, 'thinking': p['thinking'],
           'model_metadata': model_metadata, 'provenance_sha256': context_hash(provenance), 'provenance': provenance}
    done = args.output / 'scores.json'
    if done.exists():
        previous = json.loads(done.read_text())
        if (previous['job'] != job or digest(args.output / 'generations.jsonl.gz') != previous['full_generations_sha256']
                or digest(args.output / 'per_problem.json') != previous['per_problem_sha256']):
            raise ValueError('Completed benchmark shard belongs to different inputs')
        print(json.dumps(previous))
        return
    if (args.output / 'job.json').exists() and json.loads((args.output / 'job.json').read_text()) != job:
        raise ValueError('Incomplete benchmark shard belongs to different inputs')
    (args.output / 'job.json').write_text(json.dumps(job, indent=2) + '\n')
    if not args.gpu_worker:
        with (args.runtime.parent / 'gpu.lock').open('a') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX)
            subprocess.run([sys.executable, __file__, *sys.argv[1:], '--gpu-worker'], check=True)
        return
    scorer = Scorer(args.source, args.runtime, args.profile)
    from transformers import AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(args.model, local_files_only=True)
    prompts = [tokenizer.apply_chat_template([{'role': 'user', 'content': row['prompt'] if row.get('kind') else row['problem'] + '\n' + INSTRUCTION}],
                                            tokenize=False, add_generation_prompt=True, enable_thinking=p['thinking']) for row in rows]
    max_model_len = max(p['max_tokens'] + 2048, max(len(tokenizer(prompt)['input_ids']) for prompt in prompts) + p['max_tokens'])
    os.environ.setdefault('VLLM_WORKER_MULTIPROC_METHOD', 'spawn')
    from vllm import LLM, SamplingParams
    started = time.monotonic()
    llm = LLM(model=str(args.model), dtype='bfloat16', gpu_memory_utilization=0.35, max_num_seqs=32,
              max_model_len=max_model_len, max_num_batched_tokens=4096, enforce_eager=True,
              enable_prefix_caching=False, enable_chunked_prefill=True, seed=0, trust_remote_code=False)
    outputs = llm.generate(prompts, SamplingParams(n=SAMPLES[args.set], **job['sampling']))
    if len(outputs) != len(rows) or any(len(output.outputs) != SAMPLES[args.set] for output in outputs):
        raise RuntimeError('Generation returned the wrong number of samples')
    if any(answer.finish_reason not in ('stop', 'length') for output in outputs for answer in output.outputs):
        raise RuntimeError('Incomplete or aborted generation; benchmark shard not scored')
    per_problem, strict_ok, primary_ok, lenient_ok, cut, tokens, no_answer, inst_ok, inst_total = [], 0, 0, 0, 0, 0, 0, 0, 0
    temporary = args.output / 'generations.pending.jsonl.gz'
    with gzip.open(temporary, 'wt', encoding='utf-8') as stream:
        for row, prompt, output in zip(rows, prompts, outputs, strict=True):
            grades = []
            for sample, answer in enumerate(output.outputs):
                grade = scorer.grade(row, answer.text)
                strict_ok += grade['strict_correct']
                primary_ok += grade['correct']
                lenient_ok += grade['lenient_correct']
                cut += answer.finish_reason == 'length'
                tokens += len(answer.token_ids)
                no_answer += grade['strict_pred'] is None and answer.finish_reason != 'length' and row.get('kind') != 'ifeval'
                inst_ok += grade.get('inst_ok', 0)
                inst_total += grade.get('inst_total', 0)
                record = {'id': row['id'], 'sample': sample, 'seed': 0, 'seed_semantics': 'author SamplingParams(n=N, seed=0) for each request',
                          'prompt': prompt, 'prompt_ids': list(output.prompt_token_ids), 'text': answer.text, 'token_ids': list(answer.token_ids),
                          'tokens': len(answer.token_ids), 'finish_reason': answer.finish_reason, 'stop_reason': answer.stop_reason,
                          'answer': row.get('answer'), **grade}
                stream.write(json.dumps(record, ensure_ascii=False) + '\n')
                grades.append({'strict': grade['strict_correct'], 'primary': grade['correct']})
            per_problem.append({'id': row['id'], 'grades': grades})
    temporary.replace(args.output / 'generations.jsonl.gz')
    total = len(rows) * SAMPLES[args.set]
    result = {'job': job, 'n_problems': len(rows), 'total': total, 'ok': strict_ok, 'ok_primary': primary_ok,
              'acc': strict_ok / total, 'acc_primary': primary_ok / total, 'ok_lenient': lenient_ok, 'acc_lenient': lenient_ok / total,
              'primary_metric': 'lenient accuracy' if args.profile == 'gemma' else 'strict accuracy',
              'cut': cut, 'cut_share': cut / total, 'tokens_sum': tokens, 'mean_tokens': tokens / total,
              'no_answer_finished': no_answer, 'inst_ok': inst_ok, 'inst_total': inst_total,
              'grading': scorer.provenance, 'full_generations_sha256': digest(args.output / 'generations.jsonl.gz'),
              'runtime': {'gpu_memory_utilization': .35, 'max_num_seqs': 32, 'max_model_len': max_model_len,
                          'enforce_eager': True, 'enable_prefix_caching': False}, 'seconds': round(time.monotonic() - started, 3)}
    (args.output / 'per_problem.json').write_text(json.dumps(per_problem, indent=2) + '\n')
    result['per_problem_sha256'] = digest(args.output / 'per_problem.json')
    temporary = done.with_suffix('.tmp')
    temporary.write_text(json.dumps(result, indent=2) + '\n')
    temporary.replace(done)
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()

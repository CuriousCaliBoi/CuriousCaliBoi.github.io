import ast
import contextlib
import hashlib
import io
import json
from pathlib import Path
import re
import sys
import types


class Scorer:
    def __init__(self, source, runtime, profile):
        sys.path.insert(0, str(runtime))
        from grading import Grader
        self.math = Grader(source, profile)
        vendor = Path(__file__).parent / 'vendor'
        sys.path.insert(0, str(vendor))
        from langdetect import DetectorFactory
        DetectorFactory.seed = 0
        from instruction_following_eval import instructions_registry
        reference = vendor / 'mmlupro_evaluate_from_api.py'
        tree = ast.parse(reference.read_text())
        functions = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in ('extract_answer', 'extract_again', 'extract_final')]
        mc_scope = {'re': re}
        exec(compile(ast.Module(body=functions, type_ignores=[]), str(reference), 'exec'), mc_scope)
        def extract(text):
            text = text.rsplit('</think>', 1)[-1].replace('**', '')
            with contextlib.redirect_stdout(io.StringIO()):
                prediction = mc_scope['extract_answer'](text)
            return prediction, None
        evaluation = source / 'exp8_math/code/evaluate.py'
        tree = ast.parse(evaluation.read_text())
        function = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'grade_other')
        class Imports(ast.NodeTransformer):
            def visit_ImportFrom(self, node):
                return None
        function = Imports().visit(function)
        scope = {'M': types.SimpleNamespace(extract=extract), 'IR': instructions_registry}
        exec(compile(ast.Module(body=[function], type_ignores=[]), str(evaluation), 'exec'), scope)
        self.other = scope['grade_other']
        self.extract_mc = extract
        self.thinking = profile == 'qwen'
        self.provenance = {**self.math.provenance, 'mmlu_official_commit': '3016805055f78c55ec54a2f9be9fd5f89be95e0a',
                           'ifeval_official_commit': 'e6890f85757dd84e27ca6df2dd30651dafad28e0',
                           'langdetect_seed': 0,
                           'vendor_sha256': {str(p.relative_to(vendor)): hashlib.sha256(p.read_bytes()).hexdigest() for p in vendor.rglob('*.py')},
                           'grade_other': 'Original evaluate.py AST body; only unavailable package imports replaced with validated local modules',
                           'mc_extraction': 'Official extract_answer -> extract_again -> extract_final, after last </think> and official bold-marker removal; diagnostic stdout suppressed; no random-guess fallback'}

    def grade(self, row, text):
        if not row.get('kind'):
            result = self.math.grade(row['answer'], text)
            result['lenient_correct'] = bool(self.math.lenient_correct(text, result['strict_pred'], result['strict_correct'], row['answer']))
            return result
        correct, prediction, extra = self.other(row, text, self.thinking)
        return {'correct': bool(correct), 'strict_correct': bool(correct), 'lenient_correct': bool(correct),
                'pred': prediction, 'strict_pred': prediction, **extra}

import argparse
import json
from pathlib import Path

from scoring import Scorer


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--runtime', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    qwen, gemma = Scorer(args.source, args.runtime, 'qwen'), Scorer(args.source, args.runtime, 'gemma')
    for text, answer in [('The answer is (C).', 'C'), ('Answer: B', 'B'), ('I choose D', 'D'), ('No selection.', None),
                         ('The answer is (A)</think>The answer is (B)', 'B'), ('The **answer is (J)**.', 'J')]:
        assert qwen.extract_mc(text)[0] == answer, (text, qwen.extract_mc(text))
    row = {'kind': 'mc', 'answer': 'C'}
    assert qwen.grade(row, 'The answer is (C).')['correct']
    assert not qwen.grade(row, 'No selection.')['correct']
    row = {'kind': 'ifeval', 'prompt': 'Mention both colors.', 'instruction_id_list': ['keywords:existence'], 'kwargs': [{'keywords': ['red', 'blue']}]}
    assert qwen.grade(row, 'reasoning</think>red and blue')['correct']
    assert not qwen.grade(row, 'reasoning</think>red')['correct']
    assert not qwen.grade(row, 'red and blue')['correct']
    assert gemma.grade(row, 'red and blue')['correct']
    math = {'answer': '1/2'}
    assert qwen.grade(math, r'\boxed{0.5}')['correct']
    assert not qwen.grade({'answer': '7'}, 'Final Answer: 7')['correct']
    fallback = gemma.grade({'answer': '7'}, 'Final Answer: 7')
    assert fallback['correct'] and not fallback['strict_correct']
    report = {'passed': True, 'checks': ['official three-stage MC extraction', 'no-answer is false without random guess', 'thinking removal',
                                       'IFEval strict all-instruction requirement', 'IFEval empty response before thinking closes',
                                       'symbolic math equivalence', 'strict and Gemma fallback grades retained'], 'provenance': qwen.provenance}
    args.output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()

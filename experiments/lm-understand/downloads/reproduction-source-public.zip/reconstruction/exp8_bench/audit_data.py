import argparse
import hashlib
import json
from pathlib import Path
import unicodedata

from prepare import read


def normalized(text):
    return ' '.join(unicodedata.normalize('NFKC', text).casefold().split())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--bench', type=Path, required=True)
    parser.add_argument('--practice', type=Path, required=True)
    args = parser.parse_args()
    practice = [json.loads(line) for path in args.practice.glob('*.jsonl') for line in path.open()]
    exact, norm = {}, {}
    for row in practice:
        exact.setdefault(row['problem'], []).append(row['id'])
        norm.setdefault(normalized(row['problem']), []).append(row['id'])
    manifest = json.loads((args.bench / 'manifest.json').read_text())
    results = {}
    for name, record in manifest['sets'].items():
        raw_questions = {}
        if name == 'mmlupro1k':
            test = next(path for path in record['raw_files'] if '/test-' in path)
            raw_questions = {f"mmlupro_{r['question_id']}": r['question'] for r in read(args.bench / test)}
        rows = [json.loads(line) for line in (args.bench / (name + '.jsonl')).open()]
        matches = []
        for row in rows:
            text = raw_questions.get(row['id'], row.get('problem', row.get('prompt')))
            same = exact.get(text, [])
            equivalent = norm.get(normalized(text), [])
            if same or equivalent:
                matches.append({'benchmark_id': row['id'], 'exact_practice_ids': same, 'normalized_practice_ids': equivalent,
                                'normalized_text_sha256': hashlib.sha256(normalized(text).encode()).hexdigest()})
        results[name] = {'rows': len(rows), 'overlap_rows': len(matches), 'matches': matches}
    report = {'normalization': 'Unicode NFKC, casefold, collapse all whitespace to one space; no punctuation removal or fuzzy matching',
              'practice_rows': len(practice), 'sets': results, 'action': 'Reported only; no benchmark or practice rows were removed'}
    (args.bench / 'overlap-audit.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({name: value['overlap_rows'] for name, value in results.items()}))


if __name__ == '__main__':
    main()

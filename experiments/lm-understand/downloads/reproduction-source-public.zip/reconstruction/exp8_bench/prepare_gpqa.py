import argparse
import ast
import csv
import hashlib
import io
import json
from pathlib import Path
import random

from prepare import archive_ids, digest

EXPECTED_CSV_SHA256 = '41d1213cd7a4998605a26c2798500652572007161b3a92817ba46b35befcd305'
EXPECTED_HF_BLOB = '7589e3e467d69a1dceb126a60c4108d6d4f1d166'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--bench', type=Path, required=True)
    args = parser.parse_args()
    raw = args.bench / 'raw/gpqa/gpqa_diamond.csv'
    data = raw.read_bytes()
    blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    if digest(raw) != EXPECTED_CSV_SHA256 or blob != EXPECTED_HF_BLOB:
        raise ValueError('Author GPQA archive differs from the pinned Hugging Face Diamond CSV')
    provenance = json.loads((raw.parent / 'download.json').read_text())
    identities, archives = archive_ids(args.source, 'gpqa')
    rows = {f"gpqa_{row['Record ID']}": row for row in csv.DictReader(io.StringIO(data.decode()))}
    if set(rows) != set(identities) or len(identities) != 198:
        raise ValueError('GPQA Diamond IDs differ from the released benchmark')
    reference = Path(__file__).parent / 'vendor/mmlupro_evaluate_from_api.py'
    function = next(node for node in ast.parse(reference.read_text()).body if isinstance(node, ast.FunctionDef) and node.name == 'format_example')
    scope = {}
    exec(compile(ast.Module(body=[function], type_ignores=[]), str(reference), 'exec'), scope)
    output = args.bench / 'gpqa.jsonl'
    manifest_path = args.bench / 'manifest.json'
    manifest = json.loads(manifest_path.read_text())
    if 'gpqa' in manifest['sets']:
        prior = manifest['sets']['gpqa']
        if prior['prepare_sha256'] != digest(Path(__file__)) or digest(output) != prior['sha256']:
            raise ValueError('Prepared GPQA input or preparation code changed')
        print(json.dumps({'already_prepared': 'gpqa', 'rows': 198}))
        return
    with output.open('w') as stream:
        for identity in identities:
            row = rows[identity]
            seed = int.from_bytes(hashlib.sha256(('exp8-gpqa-options-v1:' + identity).encode()).digest()[:8], 'little')
            permutation = [0, 1, 2, 3]
            random.Random(seed).shuffle(permutation)
            choices = [row['Correct Answer']] + [row[f'Incorrect Answer {i}'] for i in range(1, 4)]
            options = [choices[i] for i in permutation]
            category = row['High-level domain']
            prompt = ('The following are multiple choice questions (with answers) about {}. Think step by'
                      ' step and then output the answer in the format of "The answer is (X)" at the end.\n\n').format(category)
            prompt += scope['format_example'](row['Question'], options)
            record = {'id': identity, 'kind': 'mc', 'prompt': prompt, 'problem': row['Question'],
                      'answer': 'ABCD'[permutation.index(0)], 'category': category, 'option_permutation': permutation, 'option_seed': seed}
            stream.write(json.dumps(record, ensure_ascii=False) + '\n')
    manifest['sets']['gpqa'] = {'repository': 'Idavidrein/gpqa', 'revision': provenance['hf_revision'], 'rows': 198,
                               'sha256': digest(output), 'author_archive': provenance, 'archived_id_sources': archives,
                               'raw_files': {str(raw.relative_to(args.bench)): digest(raw)}, 'prepare_sha256': digest(Path(__file__)),
                               'prompt_reconstruction': 'Official MMLU-Pro format with domain preamble, zero-shot; author private GPQA prompt builder unavailable',
                               'option_shuffle_reconstruction': 'random.Random(SHA256(exp8-gpqa-options-v1:<id>) first 64 bits little-endian).shuffle([0,1,2,3]); original private permutation seed unavailable'}
    manifest['gpqa'] = 'Prepared from the authors public GitHub archive; byte-identical to pinned Hugging Face CSV by Git blob hash'
    manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({'prepared': 'gpqa', 'rows': 198, 'sha256': digest(output), 'matches_pinned_hf_blob': True}))


if __name__ == '__main__':
    main()

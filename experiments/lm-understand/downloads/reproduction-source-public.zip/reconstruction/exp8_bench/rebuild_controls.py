import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

import torch
from safetensors import safe_open

from bench_provenance import digest, metadata_files

CASES = ('p10c', 'p25c', 'p50c', 'g05b', 'g10b', 'g25b', 'g50b')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--qwen', type=Path, required=True)
    parser.add_argument('--gemma', type=Path, required=True)
    parser.add_argument('--runtime', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.runtime))
    from provenance import verify_model
    bases = {profile: verify_model(getattr(args, profile), profile) for profile in ('qwen', 'gemma')}
    args.output.mkdir(parents=True, exist_ok=True)
    for case in CASES:
        profile = 'qwen' if case.startswith('p') else 'gemma'
        base = getattr(args, profile)
        edit = args.source / 'exp8_math' / ('runs' if profile == 'qwen' else 'gemma_followup/runs') / case / 'edit'
        archive = json.loads((edit / 'manifest.json').read_text())
        folder = args.output / case
        folder.mkdir(exist_ok=True)
        manifest = folder / 'manifest.json'
        model = folder / 'model'
        model.mkdir(exist_ok=True)
        identity = {'case': case, 'profile': profile, 'kind': 'published-control-rebuilt', 'edit_npz_sha256': digest(edit / 'edit.npz'),
                    'edit_manifest_sha256': digest(edit / 'manifest.json'), 'base': bases[profile],
                    'original_code': {name: digest(args.source / 'exp8_math/code' / name) for name in ('apply_edit.py', 'st_numpy.py')}}
        if manifest.exists():
            previous = json.loads(manifest.read_text())
            if previous['identity'] != identity or digest(model / 'model.safetensors') != previous['model_sha256'] or metadata_files(model) != previous['metadata_files']:
                raise ValueError('Existing published control checksum changed')
            continue
        command = [sys.executable, str(args.source / 'exp8_math/code/apply_edit.py'), str(base / 'model.safetensors'), str(edit), str(model / 'model.safetensors')]
        with (folder / 'apply-edit.log').open('w') as log:
            subprocess.run(command, check=True, stdout=log, stderr=subprocess.STDOUT)
        for path in base.iterdir():
            if path.is_file() and path.suffix != '.safetensors' and not path.name.endswith('manifest.json'):
                shutil.copy2(path, model / path.name)
        edited = {item['name']: item for item in archive['tensors']}
        checked = {}
        with safe_open(model / 'model.safetensors', framework='pt', device='cpu') as after, safe_open(base / 'model.safetensors', framework='pt', device='cpu') as before:
            if set(after.keys()) != set(before.keys()):
                raise ValueError('Rebuilt control tensor names changed')
            for name in after.keys():
                actual = after.get_tensor(name).view(torch.uint16)
                if name in edited:
                    actual_hash = hashlib.sha256(actual.numpy().tobytes()).hexdigest()
                    if actual_hash != edited[name]['edited_sha256']:
                        raise ValueError('Published edited tensor hash does not match')
                    checked[name] = actual_hash
                elif not torch.equal(actual, before.get_tensor(name).view(torch.uint16)):
                    raise ValueError('An unedited control tensor changed')
            total = len(after.keys())
        if metadata_files(model) != metadata_files(base):
            raise ValueError('Control tokenizer/configuration differs from pinned base')
        report = {'identity': identity, 'model': str(model), 'model_sha256': digest(model / 'model.safetensors'),
                  'metadata_files': metadata_files(model), 'edited_tensor_hashes': checked,
                  'all_unedited_tensors_bitwise_equal_base': True, 'tensor_count': total,
                  'apply_edit_invocation': command, 'published_apply_edit_unchanged': True}
        manifest.write_text(json.dumps(report, indent=2) + '\n')
        print(json.dumps({'case': case, 'verified_edited_tensors': len(checked), 'tensor_count': total}), flush=True)


if __name__ == '__main__':
    main()

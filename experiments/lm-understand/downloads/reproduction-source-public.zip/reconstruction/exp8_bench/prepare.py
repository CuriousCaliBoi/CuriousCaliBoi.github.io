import argparse
import ast
import hashlib
import json
from pathlib import Path
import re

from huggingface_hub import hf_hub_download
import pyarrow.parquet as pq

SOURCES = {
    'aime24': ('HuggingFaceH4/aime_2024', '2fe88a2f1091d5048c0f36abc874fb997b3dd99a', ['data/train-00000-of-00001.parquet']),
    'aime25': ('MathArena/aime_2025', 'c94da77eb22bbd6439e62a323bec18493a421302', ['data/train-00000-of-00001.parquet']),
    'amc23': ('math-ai/amc23', '80815d37005feb82cd7f8fbc6901d5d3eff43057', ['test-00000-of-00001.parquet']),
    'math500': ('HuggingFaceH4/MATH-500', '6e4ed1a2a79af7d8630a6b768ec859cb5af4d3be', ['test.jsonl']),
    'minerva': ('math-ai/minervamath', 'ee46ddc498933b1977577953250ca5c66be64f96', ['test.jsonl']),
    'olympiad': ('math-ai/olympiadbench', '4faaf1e6ec17d11a4218a9bf4c049ecaf954dd84', ['test.parquet']),
    'gsm8k': ('openai/gsm8k', '740312add88f781978c0658806c59bc2815b9866', ['main/test-00000-of-00001.parquet']),
    'mmlupro1k': ('TIGER-Lab/MMLU-Pro', 'b189ec765aa7ed75c8acfea42df31fdae71f97be', ['data/test-00000-of-00001.parquet', 'data/validation-00000-of-00001.parquet']),
    'ifeval': ('google/IFEval', '966cd89545d6b6acfd7638bc708b98261ca58e84', ['ifeval_input_data.jsonl']),
}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def archive_ids(source, name):
    parts = source / 'exp8_math/eval/unedited/parts'
    files = list(parts.glob(name + '_s*of*/' + name + '_per_problem.json'))
    placed, inputs, denominators = {}, {}, set()
    for path in files:
        match = re.fullmatch(re.escape(name) + r'_s(\d+)of(\d+)', path.parent.name)
        index, stride = map(int, match.groups())
        denominators.add(stride)
        inputs[str(path.relative_to(source))] = digest(path)
        for offset, row in enumerate(json.loads(path.read_text())):
            position = index + offset * stride
            if position in placed:
                raise ValueError('Duplicate archived benchmark position')
            placed[position] = row['id']
    if len(denominators) != 1 or sorted(placed) != list(range(len(placed))):
        raise ValueError('Archived benchmark shards are incomplete')
    identities = [placed[i] for i in range(len(placed))]
    if len(set(identities)) != len(identities):
        raise ValueError('Duplicate archived benchmark identity')
    return identities, inputs


def read(path):
    return pq.read_table(path).to_pylist() if path.suffix == '.parquet' else [json.loads(line) for line in path.open()]


def convert(name, rows, validation=None):
    if name == 'aime24':
        return [{'id': f"aime24_{r['id']}", 'problem': r['problem'], 'answer': str(r['answer'])} for r in rows]
    if name == 'aime25':
        return [{'id': f"aime25_{r['problem_idx']}", 'problem': r['problem'], 'answer': str(r['answer'])} for r in rows]
    if name == 'amc23':
        return [{'id': f"amc23_{r['id']}", 'problem': r['question'], 'answer': str(r['answer'])} for r in rows]
    if name == 'math500':
        return [{'id': r['unique_id'], 'problem': r['problem'], 'answer': r['answer']} for r in rows]
    if name == 'minerva':
        return [{'id': f'minerva_{i}', 'problem': r['question'], 'answer': str(r['answer'])} for i, r in enumerate(rows)]
    if name == 'olympiad':
        result = []
        for r in rows:
            answer = r['final_answer']
            answer = answer if isinstance(answer, list) else json.loads(answer.replace("'", '"')) if answer.startswith('[') else [answer]
            result.append({'id': f"olympiad_{r['id']}", 'problem': r['question'], 'answer': ', '.join(map(str, answer))})
        return result
    if name == 'gsm8k':
        return [{'id': f'gsm8k_test_{i}', 'problem': r['question'], 'answer': r['answer'].split('####')[-1].strip().replace(',', '')} for i, r in enumerate(rows)]
    if name == 'ifeval':
        return [{'id': f"ifeval_{r['key']}", 'kind': 'ifeval', 'prompt': r['prompt'], 'instruction_id_list': r['instruction_id_list'], 'kwargs': r['kwargs']} for r in rows]
    reference = Path(__file__).parent / 'vendor/mmlupro_evaluate_from_api.py'
    tree = ast.parse(reference.read_text())
    function = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'format_example')
    scope = {}
    exec(compile(ast.Module(body=[function], type_ignores=[]), str(reference), 'exec'), scope)
    format_example = scope['format_example']
    result = []
    for row in rows:
        examples = [r for r in validation if r['category'] == row['category']]
        if len(examples) != 5:
            raise ValueError('Official MMLU-Pro validation should supply five examples per category')
        prompt = ('The following are multiple choice questions (with answers) about {}. Think step by'
                  ' step and then output the answer in the format of "The answer is (X)" at the end.\n\n').format(row['category'])
        for example in examples:
            prompt += format_example(example['question'], [v for v in example['options'] if v != 'N/A'], example['cot_content'])
        prompt += format_example(row['question'], [v for v in row['options'] if v != 'N/A'])
        result.append({'id': f"mmlupro_{row['question_id']}", 'kind': 'mc', 'prompt': prompt, 'answer': row['answer'], 'category': row['category'],
                       'validation_example_ids': [r['question_id'] for r in examples]})
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    manifest_path = args.output / 'manifest.json'
    manifest = json.loads(manifest_path.read_text()) if manifest_path.exists() else {'sets': {}, 'gpqa': 'not downloaded; access pending', 'prepare_sha256': digest(Path(__file__))}
    if manifest['prepare_sha256'] != digest(Path(__file__)):
        raise ValueError('Preparation source changed; preserve previous dataset manifest')
    for name, (repository, revision, filenames) in SOURCES.items():
        output = args.output / (name + '.jsonl')
        if name in manifest['sets']:
            if digest(output) != manifest['sets'][name]['sha256']:
                raise ValueError('Prepared dataset changed: ' + name)
            continue
        paths = [Path(hf_hub_download(repository, filename, repo_type='dataset', revision=revision, local_dir=args.output / 'raw' / name)) for filename in filenames]
        identities, archives = archive_ids(args.source, name)
        converted = convert(name, read(paths[0]), read(paths[1]) if len(paths) > 1 else None)
        by_id = {row['id']: row for row in converted}
        if len(by_id) != len(converted) or set(identities) - set(by_id):
            raise ValueError('Official dataset does not match the archived evaluation identities: ' + name)
        selected = [by_id[identity] for identity in identities]
        with output.open('w') as stream:
            for row in selected:
                stream.write(json.dumps(row, ensure_ascii=False) + '\n')
        manifest['sets'][name] = {'repository': repository, 'revision': revision, 'raw_files': {str(p.relative_to(args.output)): digest(p) for p in paths},
                                 'rows': len(selected), 'sha256': digest(output), 'archived_id_sources': archives,
                                 'ordering': 'interleaved released unedited per-problem shards; only id fields used',
                                 'prompt_reconstruction': 'official five-shot category validation examples and format_example' if name == 'mmlupro1k' else None}
        manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
        print(json.dumps({'prepared': name, 'rows': len(selected), 'sha256': digest(output)}), flush=True)


if __name__ == '__main__':
    main()

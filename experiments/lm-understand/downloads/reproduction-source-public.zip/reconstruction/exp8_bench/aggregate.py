import argparse
import gzip
import json
from pathlib import Path

from bench_provenance import digest


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--parts', type=Path, required=True)
    parser.add_argument('--bench', type=Path, required=True)
    parser.add_argument('--set', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    expected = [json.loads(line)['id'] for line in (args.bench / (args.set + '.jsonl')).open()]
    seen, jobs, totals, files = set(), [], {}, {}
    for path in sorted(args.parts.glob('*/scores.json')):
        record = json.loads(path.read_text())
        if record['job']['set'] != args.set:
            continue
        generations = path.parent / 'generations.jsonl.gz'
        if digest(generations) != record['full_generations_sha256'] or digest(path.parent / 'per_problem.json') != record['per_problem_sha256']:
            raise ValueError('Evaluation artifact checksum changed')
        problems = json.loads((path.parent / 'per_problem.json').read_text())
        ids = {p['id'] for p in problems}
        if len(ids) != len(problems) or seen & ids:
            raise ValueError('Duplicate evaluation problem across shards')
        seen |= ids
        jobs.append(record['job'])
        files[str(path)] = digest(path)
        for name in ('n_problems', 'total', 'ok', 'ok_primary', 'ok_lenient', 'cut', 'tokens_sum', 'no_answer_finished', 'inst_ok', 'inst_total'):
            totals[name] = totals.get(name, 0) + record[name]
    if seen != set(expected):
        raise ValueError('Benchmark evaluation is incomplete or contains foreign IDs')
    comparable = [{key: value for key, value in job.items() if key != 'shard'} for job in jobs]
    if not comparable or any(job != comparable[0] for job in comparable):
        raise ValueError('Shards use different model, dataset, protocol or implementation')
    total = totals['total']
    result = {**totals, 'acc': totals['ok'] / total, 'acc_primary': totals['ok_primary'] / total,
              'acc_lenient': totals['ok_lenient'] / total, 'cut_share': totals['cut'] / total,
              'mean_tokens': totals['tokens_sum'] / total, 'job': comparable[0], 'parts': files}
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()

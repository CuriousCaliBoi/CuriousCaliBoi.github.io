import argparse
import json
from pathlib import Path
import shutil
import sys

from bench_provenance import digest, metadata_files


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--base', type=Path, required=True)
    parser.add_argument('--submission', type=Path, required=True)
    parser.add_argument('--runtime', type=Path, required=True)
    parser.add_argument('--profile', choices=['qwen', 'gemma'], required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.runtime))
    from backend import build_checkpoint
    from edits import EditStore
    from provenance import verify_model
    base = verify_model(args.base, args.profile)
    receipt = json.loads(args.submission.read_text())
    frozen = Path(receipt['directory'])
    hashes = receipt['snapshot']['tensors']
    actual = {p.name[:-4]: digest(p) for p in frozen.glob('*.npy') if not p.is_symlink()}
    if actual != hashes or any(p.is_symlink() for p in frozen.iterdir()):
        raise ValueError('Finalized tensor files no longer match their receipt')
    args.output.mkdir(parents=True, exist_ok=True)
    manifest = args.output / 'checkpoint-manifest.json'
    if manifest.exists():
        previous = json.loads(manifest.read_text())
        if previous['submission_sha256'] != digest(args.submission) or previous['model_sha256'] != digest(Path(previous['checkpoint']) / 'model.safetensors'):
            raise ValueError('Existing assembled checkpoint belongs to different inputs or was changed')
        print(json.dumps(previous))
        return
    store = EditStore(args.base, args.output / 'validation-work', args.profile)
    for name in hashes:
        shutil.copy2(frozen / (name + '.npy'), store.folder / (name + '.npy'))
    if store.snapshot() != receipt['snapshot']:
        raise ValueError('Finalized edits failed trusted protocol validation')
    checkpoint = build_checkpoint(args.base, store, receipt['snapshot'], args.output / 'model')
    if metadata_files(checkpoint) != metadata_files(args.base):
        raise ValueError('Model configuration/tokenizer changed during checkpoint assembly')
    result = {'checkpoint': str(checkpoint), 'model_sha256': digest(checkpoint / 'model.safetensors'),
              'metadata_files': metadata_files(checkpoint), 'submission_sha256': digest(args.submission),
              'snapshot': receipt['snapshot'], 'base': base, 'builder_sha256': digest(Path(__file__))}
    manifest.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()

import contextlib
import io
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
import uuid

import jax
import jax.numpy as jnp
import numpy as np

from exp6_engine import SHAPES, digest, environment, forward, legal_logits, load_weights
from exp6_evaluate import evaluate

ROOT = Path('<gpu-project>/reconstructed/exp6')
SOURCE = Path('<gpu-project>/source/exp6_go_from_scratch')
VENV = Path('<gpu-project>/.venv')
IMAGE = 'sha256:5b8c0c14690ed170da4e663fe0bae0d58efe59661e791296ffab28ed2113b650'


def work_path(case_id):
    if not re.fullmatch(r'[0-9a-f]{32}', case_id):
        raise ValueError('Invalid opaque case identifier')
    return ROOT / 'work' / case_id


def initialize(case_id):
    work = work_path(case_id)
    work.mkdir(parents=True, exist_ok=False)
    (work / 'arch.json').write_text('{"depth": 6, "width": 512}')
    return {'ok': True, 'arch_sha256': digest(work / 'arch.json'), 'image_id': IMAGE}


def python_run(case_id, code):
    work = work_path(case_id)
    container = 'lm-exp6-' + uuid.uuid4().hex
    command = ['docker', 'run', '--rm', '-i', '--name', container, '--network', 'none',
               '--cap-drop', 'ALL', '--security-opt', 'no-new-privileges', '--read-only',
               '--user', '1000:1000', '--cpus', '8', '--memory', str(96 << 30), '--pids-limit', '256',
               '--tmpfs', '/tmp:rw,nosuid,mode=1777,size=536870912',
               '--mount', 'type=bind,src=/usr,dst=/usr,readonly',
               '--mount', f'type=bind,src={VENV},dst=/env,readonly',
               '--mount', f'type=bind,src={work},dst=/work', '--workdir', '/work',
               '--entrypoint', '/usr/bin/env', IMAGE, '-i', 'HOME=/tmp', 'PATH=/usr/bin',
               'OMP_NUM_THREADS=8', 'OPENBLAS_NUM_THREADS=8', 'MKL_NUM_THREADS=8',
               'CUDA_VISIBLE_DEVICES=', '/env/bin/python', '-I', '-']
    started = time.monotonic()
    prelude = (ROOT / 'exp6_writer_prelude.py').read_text()
    try:
        process = subprocess.run(command, input=prelude + '\n' + code, text=True,
                                 capture_output=True, timeout=900)
        stdout, stderr, rc = process.stdout, process.stderr, process.returncode
        out = stdout + ('\n[stderr]\n' + stderr[-6000:] if stderr.strip() else '')
        timed_out = False
    except subprocess.TimeoutExpired as error:
        subprocess.run(['docker', 'rm', '-f', container], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        stdout = (error.stdout or b'').decode(errors='replace')
        stderr = (error.stderr or b'').decode(errors='replace')
        rc, timed_out, out = None, True, '[timed out after 900 s]'
    truncated = len(out) > 20000
    if truncated:
        out = out[:20000] + '\n[output cut at 20,000 characters]'
    return {'ok': True, 'out': out or '(no output)', 'stdout': stdout, 'stderr': stderr,
            'rc': rc, 'timed_out': timed_out, 'truncated': truncated,
            'seconds': time.monotonic() - started, 'sandbox_command': command,
            'prelude_sha256': digest(ROOT / 'exp6_writer_prelude.py')}


def snapshot(case_id, label):
    work = work_path(case_id)
    if json.loads((work / 'arch.json').read_text()) != {'depth': 6, 'width': 512}:
        raise ValueError('The fixed architecture was changed')
    destination = ROOT / 'private' / case_id / label / 'snapshot'
    destination.mkdir(parents=True, exist_ok=False)
    (destination / 'arch.json').write_text('{"depth": 6, "width": 512}')
    for name, shape in SHAPES.items():
        source = work / 'net' / (name + '.npy')
        if source.is_symlink() or source.parent.is_symlink():
            raise ValueError('Tensor paths must remain inside this writer work directory')
        value = np.load(source, allow_pickle=False) if source.exists() else np.zeros(shape, np.float32)
        if value.shape != shape or value.dtype != np.float32 or not np.isfinite(value).all():
            raise ValueError(f'Invalid saved tensor {name}')
        np.save(destination / (name + '.npy'), value)
    return destination


def position_inputs(request):
    positions = request['positions']
    if not isinstance(positions, list) or not 1 <= len(positions) <= 256:
        raise ValueError('A positions pass requires 1..256 positions')
    env, step = environment(), jax.jit(environment().step)
    inputs, masks = [], []
    for position in positions:
        if 'board' in position:
            board = position['board']
            if len(board) != 9 or any(not isinstance(row, str) or len(row) != 9 or set(row) - set('XO.') for row in board):
                raise ValueError('Board positions require nine strings of nine X/O/. characters')
            if position['to_move'] not in ('black', 'white'):
                raise ValueError('to_move must be black or white')
            stones = np.array([[{'X': 1, 'O': -1, '.': 0}[c] for c in row] for row in board])
            white = position['to_move'] == 'white'
            sign = -1 if white else 1
            inputs.append(np.stack((stones == sign, stones == -sign, np.full((9, 9), white)), axis=-1).reshape(243))
            masks.append(np.append(stones.ravel() == 0, True))
        elif 'moves' in position:
            state = env.init(jax.random.PRNGKey(0))
            for move in position['moves']:
                action = 81 if move == 'pass' else move
                if type(action) is not int or not 0 <= action <= 81 or bool(state.terminated) or not bool(state.legal_action_mask[action]):
                    raise ValueError('Move sequence contains an illegal action or continues after termination')
                state = step(state, jnp.int32(action))
            inputs.append(np.asarray(state.observation).reshape(243))
            masks.append(np.asarray(state.legal_action_mask))
        else:
            raise ValueError('Each position requires board or moves')
    return np.asarray(inputs, np.float32), np.asarray(masks, bool)


def positions_pass(case_id, number, request, weights_path, public):
    inputs, legal = position_inputs(request)
    weights, _ = load_weights(weights_path)
    logits, activations = forward(weights, inputs, return_activations=True)
    probabilities = np.asarray(jax.nn.softmax(legal_logits(logits, legal), axis=-1))
    logits = np.asarray(logits)
    for name, array in [('inputs', inputs), ('legal', legal), ('logits', logits), ('probs', probabilities)]:
        np.save(public / (name + '.npy'), array)
    if request.get('activations', False):
        for name, values in activations.items():
            np.save(public / ('act_' + name + '.npy'), np.asarray(values))
    top = [[{'move': int(i), 'probability': float(probabilities[row, i]), 'logit': float(logits[row, i])}
            for i in np.argsort(-probabilities[row])[:3]] for row in range(len(inputs))]
    (public / 'README.txt').write_text('inputs.npy (P,243); legal.npy (P,82); logits.npy and probs.npy (P,82); requested act_L1.npy through act_L6.npy are post-ReLU hidden activations. Board requests mask only occupied points; move sequences use exact Go legality.\n')
    return {'ok': True, 'pass': number, 'kind': 'positions', 'positions': len(inputs), 'top3': top,
            'files': f'/work/pass_{number}/'}


def games_pass(case_id, number, request, weights_path, public):
    counts = request['games']
    if not isinstance(counts, dict) or set(counts) - {'random', 'weak', 'strong'}:
        raise ValueError('Practice opponents are random, weak and strong')
    if any(type(n) is not int or n < 0 or n % 2 for n in counts.values()) or not 1 <= sum(counts.values()) <= 128:
        raise ValueError('Game counts must be nonnegative even integers totaling at most128')
    games, boards, validity, summaries = [], [], [], {}
    for index, name in enumerate(('random', 'weak', 'strong')):
        count = counts.get(name, 0)
        if not count:
            continue
        opponent = None if name == 'random' else SOURCE / 'networks/ppo_same_size_lr3e-5_s1'
        private = weights_path.parent / name
        log = io.StringIO()
        with contextlib.redirect_stdout(log):
            summary = evaluate(weights_path, opponent, private, games=count, batch_size=count,
                               seed=20261102 + 100 * number + index, save_traces=True,
                               opponent_uniform_mix=0.5 if name == 'weak' else 0)
        (private / 'evaluation.log').write_text(log.getvalue())
        rows = [json.loads(line) for line in (private / 'episodes.jsonl').read_text().splitlines()]
        with np.load(private / 'traces-00000.npz') as archive:
            trace = dict(archive)
        after = np.concatenate((trace['board'][1:], trace['final_board'][None]), axis=0)
        capture_counts, lost_counts, network_passes, early_pass, early_network_pass = [], [], [], 0, 0
        for i, row in enumerate(rows):
            length = row['length']
            color = 1 if row['candidate_color'] == 'black' else -1
            before_board, after_board = trace['board'][:length, i], after[:length, i]
            captured = int(np.count_nonzero((before_board == -color) & (after_board == 0)))
            lost = int(np.count_nonzero((before_board == color) & (after_board == 0)))
            moves = []
            for ply, action in enumerate(row['actions']):
                move = {'ply': ply, 'by': 'net' if bool(trace['candidate_turn'][ply, i]) else name, 'move': action}
                if move['by'] == 'net':
                    move['top5'] = [[int(a), float(p)] for a, p in zip(trace['top_actions'][ply, i], trace['top_probabilities'][ply, i]) if p > 0]
                moves.append(move)
            capture_counts.append(captured)
            lost_counts.append(lost)
            early_pass += any(a == 81 for a in row['actions'][:60])
            network_passes.append(sum(move['move'] == 81 and move['by'] == 'net' for move in moves))
            early_network_pass += any(move['move'] == 81 and move['by'] == 'net' for move in moves[:60])
            games.append({'opponent': name, 'net_color': row['candidate_color'], 'result': 1 if row['win'] else -1,
                          'margin': row['area_margin'], 'end': row['end_reason'], 'stones_captured': captured,
                          'stones_lost': lost, 'moves': moves})
            boards.append(after[:, i])
            validity.append(trace['valid'][:, i])
        summaries[name] = {'games': count, 'score': summary['score'], 'wins': summary['wins'], 'losses': summary['losses'],
                           'score_as_black': summary['score_as_black'], 'score_as_white': summary['score_as_white'],
                           'mean_margin': summary['mean_area_margin'], 'mean_length': summary['mean_length'],
                           'stones_captured_per_game': float(np.mean(capture_counts)), 'stones_lost_per_game': float(np.mean(lost_counts)),
                           'network_passes_per_game': float(np.mean(network_passes)),
                           'all_player_passes_per_game': float(np.mean([r['passes'] for r in rows])),
                           'games_with_network_pass_before_move_60': early_network_pass,
                           'games_with_any_pass_before_move_60': early_pass,
                           **{'end_' + reason: value for reason, value in summary['end_counts'].items()}}
    (public / 'games.json').write_text(json.dumps(games) + '\n')
    np.save(public / 'boards.npy', np.asarray(boards, np.int8))
    np.save(public / 'valid.npy', np.asarray(validity, bool))
    (public / 'README.txt').write_text('games.json: opponent, net_color, result +1/-1, area margin including komi, end reason, captured/lost stones, moves with ply/by/move and network top5 [move,probability]. boards.npy: (games,162,81), board AFTER each ply (Black1, White-1, empty0). valid.npy: (games,162), plies actually played.\n')
    return {'ok': True, 'pass': number, 'kind': 'games', 'per_opponent': summaries, 'files': f'/work/pass_{number}/'}


def run_pass(case_id, number, kind, request):
    label = f'pass_{number}'
    weights = snapshot(case_id, label + '_' + uuid.uuid4().hex)
    public = weights.parent / 'public'
    public.mkdir()
    result = (games_pass if kind == 'games' else positions_pass)(case_id, number, request, weights, public)
    (public / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
    shutil.copytree(public, work_path(case_id) / label)
    return result


def dispatch(request):
    kind, case = request['kind'], request['case_id']
    if kind == 'initialize':
        return initialize(case)
    if kind == 'python':
        return python_run(case, request['code'])
    if kind in ('games', 'positions'):
        return run_pass(case, request['pass'], kind, request['request'])
    if kind == 'finalize':
        path = snapshot(case, 'final')
        return {'ok': True, 'path': str(path), 'tensor_sha256': {name: digest(path / (name + '.npy')) for name in SHAPES}}
    raise ValueError('Unknown bridge request')


if __name__ == '__main__':
    request = json.load(sys.stdin)
    try:
        result = dispatch(request)
    except (ValueError, KeyError, TypeError, FileExistsError) as error:
        result = {'ok': False, 'error': str(error)}
    print(json.dumps(result))


import json, os, numpy as np
np.set_printoptions(precision=4, suppress=True, linewidth=160)
WORK = "/work"
_A = json.load(open(WORK + "/arch.json"))
DEPTH, WIDTH = _A["depth"], _A["width"]
SHAPES = {}
for _k in range(1, DEPTH + 1):
    SHAPES[f"L{_k}.W"] = (243 if _k == 1 else WIDTH, WIDTH)
    SHAPES[f"L{_k}.b"] = (WIDTH,)
SHAPES["out.W"], SHAPES["out.b"] = (WIDTH, 82), (82,)
NAMES = list(SHAPES)
PASS = 81
def inp(row, col, plane):
    return (row * 9 + col) * 3 + plane
def mv(row, col):
    return row * 9 + col
def load(name):
    p = WORK + "/net/" + name + ".npy"
    return np.load(p).astype(np.float32) if os.path.exists(p) else np.zeros(SHAPES[name], np.float32)
def save(name, a):
    assert name in SHAPES, f"unknown tensor {name}; NAMES = {NAMES}"
    a = np.asarray(a, np.float32)
    assert a.shape == tuple(SHAPES[name]), (name, a.shape, SHAPES[name])
    assert np.isfinite(a).all(), name
    os.makedirs(WORK + "/net", exist_ok=True)
    np.save(WORK + "/net/" + name + ".npy", a)
def saved():
    d = WORK + "/net"
    return sorted(f[:-4] for f in os.listdir(d)) if os.path.isdir(d) else []

"""Resume retained attention output after the review-bookkeeping recovery ends."""
import json
import time

from exp7_cli import OUT, write_json
from exp7_recover_empty_output import resume_case


def main():
    manifest = json.loads((OUT / 'manifest.json').read_text())
    cases = {case['pair_number']: case for case in manifest['cases'] if case['round'] == 'attention_tool'}
    prior = OUT / 'runs' / cases[1]['id'] / 'review-bookkeeping-recovery.json'
    while True:
        recovery = json.loads(prior.read_text())
        if recovery['status'] != 'waiting_for_scheduled_attention_cases':
            assert recovery['status'] == 'completed', 'The previous attention recovery needs review'
            break
        time.sleep(10)
    state = resume_case(cases[3])
    write_json(OUT / 'batch-attention-empty-output-recovery.json', [state])


if __name__ == '__main__':
    main()

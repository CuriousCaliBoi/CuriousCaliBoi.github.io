"""Fixed campaign planning, bounded CPU scheduling and frozen-policy evaluation."""
import os

os.environ['OMP_NUM_THREADS'] = '1'
os.environ['OPENBLAS_NUM_THREADS'] = '1'
os.environ['CUDA_VISIBLE_DEVICES'] = ''

import argparse
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor
import fcntl
from functools import wraps
import importlib
import inspect
import json
from pathlib import Path
from queue import Queue
import subprocess
import sys
import time
import uuid

import numpy as np
from minatar import Environment

from exp5_evaluate import GAMES, CHANNELS, episode, sha
from exp5_ppo_train import BATCH, REFERENCE, atomic_json, provenance

TRAINING_CORES = (5, 6, 7, 8)


def runtime():
    record = provenance()
    record['campaign_sha256'] = sha(__file__)
    cores = {}
    for block in Path('/proc/cpuinfo').read_text().split('\n\n'):
        fields = dict(line.split(':', 1) for line in block.splitlines() if ':' in line)
        fields = {key.strip(): value.strip() for key, value in fields.items()}
        if 'processor' not in fields or int(fields['processor']) not in TRAINING_CORES:
            continue
        number = int(fields['processor'])
        cores[str(number)] = {'implementer': fields['CPU implementer'], 'part': fields['CPU part'],
                              'max_frequency_khz': int(Path(
                                  f'/sys/devices/system/cpu/cpu{number}/cpufreq/cpuinfo_max_freq').read_text())}
    assert len(cores) == len(TRAINING_CORES)
    record['training_core_class_evidence'] = cores
    return record


def campaign_cases():
    cases = []
    for game in GAMES:
        for millions, seeds in ((100, range(3 if game == 'seaquest' else 10)), (500, range(3))):
            nominal = millions * 1_000_000
            for seed in seeds:
                cases.append({'id': f'{game}.ppo{millions}_s{seed}', 'game': game, 'seed': seed,
                              'nominal_steps': nominal, 'actual_steps': nominal // BATCH * BATCH,
                              'updates': nominal // BATCH})
    assert len(cases) == 32 and sum(case['nominal_steps'] for case in cases) == 6_800_000_000
    return cases


def make_plan(path, source):
    cases = campaign_cases()
    source = Path(source)
    for game in GAMES:
        module = importlib.import_module('minatar.environments.' + game)
        assert Path(inspect.getfile(module)).read_bytes() in (
            source / f'exp5_write_from_scratch/runs/{game}/message.txt').read_bytes()
    plan = {
        'kind': 'reconstructed_PPO_baselines', 'cases': cases,
        'runtime': provenance(), 'campaign_runtime': runtime(),
        'author_source_revision': '4d09ba6d6a7e891dd8063974dfe81b3d78e3494f',
        'author_readme_sha256': sha(source / 'exp5_write_from_scratch/README.md'),
        'cleanrl_reference_revision': REFERENCE,
        'cleanrl_reference_sha256': 'd8dfbb7ac0b21e747b77d6e6673e566db4d6cdacc83bcebcd19cf87ad0e459ae',
        'cleanrl_reference_url': f'https://github.com/vwxyzjn/cleanrl/blob/{REFERENCE}/cleanrl/ppo.py',
        'published_settings': {'actor': [600, 32, 32, 6], 'activation': 'tanh', 'lr': .0005,
                               'anneal_lr': True, 'num_envs': 64, 'steps': 128, 'epochs': 4,
                               'minibatches': 8, 'gamma': .99, 'gae_lambda': .95,
                               'clip': .2, 'entropy_coefficient': .01},
        'reconstructed_defaults': {
            'critic': [600, 64, 64, 1], 'critic_sharing': 'separate', 'dtype': 'float32',
            'initialization': 'orthogonal hidden sqrt2, actor output .01, critic output1; zero biases; critic constructed before actor',
            'optimizer': {'name': 'Adam', 'epsilon': 1e-5, 'betas': [.9, .999], 'weight_decay': 0},
            'value_coefficient': .5, 'value_loss': '.5*mean(max(unclipped_squared_error,clipped_squared_error))',
            'value_clip': .2, 'gradient_norm_clip': .5, 'target_kl': None,
            'advantage_normalization': 'per minibatch, sample standard deviation +1e-8',
            'lr_schedule': '5e-4*(1-update_index/num_full_updates), update_index starts0',
            'step_rounding': 'floor nominal/(64*128), as pinned CleanRL; no partial rollout',
            'schedules': 'Independent initialization and annealing for100M and500M runs; no continuation between budgets',
            'environment': 'official MinAtar1.0.15, sticky.1, difficulty_ramping=True, all6actions',
            'training_reset': 'Native Environment.reset(): wrapper last_action is preserved, RNG continues; no reseed on terminal',
            'autoreset': 'Immediately reset a terminated environment before constructing next_obs; next_done remains1 for GAE',
            'training_time_limit': None,
            'bootstrap': 'Zero after native terminal; critic bootstrap at nonterminal rollout end. No training truncation.',
            'reward_and_observation_normalization': None,
            'seeds': 'random.seed(seed),np.random.seed(seed),torch.manual_seed(seed); each environment seed+index; action sampling Torch; minibatch shuffling NumPy global RandomState',
            'cpu_threads': 1, 'max_campaign_workers': 4,
            'cpu_affinity': {'pool': list(TRAINING_CORES), 'assignment': 'One distinct free core per active worker, recorded in each child command; chosen from the measured3.9GHz core class. This is not an exclusive reservation; other workloads can compete.'},
            'checkpoint_interval_updates': 100,
            'checkpoint_retention': 'Latest and previous full payloads only. Every save retains an immutable SHA-bound receipt with parent pointer/update/step/source metadata, including orphan receipts after interrupted publication.',
            'interruption': 'Resume exact full optimizer/RNG/environment state at latest durable update checkpoint. Up to100 updates can be replayed, including interruption during checkpoint publication; prior attempt journals are retained and new attempt metadata records the source checkpoint.',
        },
        'evaluation': {'episodes': 1000, 'master_seed': 20261102, 'cap': 10000,
                       'function': 'unchanged exp5_evaluate.episode', 'channels': CHANNELS,
                       'policy': 'float32 network, float64 softmax, sampled all6actions',
                       'reset': 'fresh Environment, seed, reset, last_action0 per episode',
                       'selection': 'Freeze all final actors; retain all32 scores; report max seed mean per game/budget as original comparison, plus all-seed statistics'},
        'deviations': [
            'Original PPO training source/checkpoints omitted; these are newly reconstructed baselines, not recovered author checkpoints.',
            'Defaults beyond published recipe come from the pinned generic CleanRL PPO reference; original architecture/framework/reset/defaults/versions are unknown.',
            'Full-update flooring produces99,999,744 and499,998,720 actual steps; author exact rounding is unknown.',
            'Native training reset preserves sticky last_action; no unpublished training time limit is invented. Evaluation uses the separately frozen reconstructed protocol.',
            'CPU Torch training/action RNG and recorded versions are chosen explicitly; original RNG streams and numerical backend are unavailable.',
        ],
    }
    if path.exists():
        assert json.loads(path.read_text()) == plan
    else:
        atomic_json(path, plan)
    return plan


def read_plan(path):
    plan = json.loads(path.read_text())
    assert plan['runtime'] == provenance() and plan['campaign_runtime'] == runtime()
    assert plan['cases'] == campaign_cases()
    return plan


def frozen_case(directory, spec, plan):
    record = json.loads((directory / 'frozen.json').read_text())
    assert record['status'] == 'frozen_complete'
    assert record['spec'] == {k: spec[k] for k in record['spec']}
    assert record['provenance'] == plan['runtime']
    assert record['actor_sha256'] == sha(directory / 'actor.npz')
    pointer = record['checkpoint']
    assert pointer['global_step'] == spec['actual_steps'] and pointer['update'] == spec['updates']
    assert sha(directory / pointer['file']) == pointer['sha256']
    return record


def campaign_locked(function):
    @wraps(function)
    def guarded(plan_path, output, workers):
        output.mkdir(parents=True, exist_ok=True)
        with (output / 'campaign.lock').open('w') as stream:
            fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
            return function(plan_path, output, workers, lock_fd=stream.fileno())
    return guarded


def run_worker(command, stream, lock_fd):
    # The open-file-description lock must outlive a launcher lost during SSH interruption.
    return subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT, pass_fds=(lock_fd,))


@campaign_locked
def run_campaign(plan_path, output, workers, lock_fd):
    assert 1 <= workers <= 4
    plan = read_plan(plan_path)
    output.mkdir(parents=True, exist_ok=True)
    assert set(TRAINING_CORES).issubset(os.sched_getaffinity(0))
    os.nice(10)
    cores = Queue()
    for core in TRAINING_CORES[:workers]:
        cores.put(core)
    launch = uuid.uuid4().hex
    manifest = {'plan_sha256': sha(plan_path), 'workers': workers, 'started_unix': time.time(),
                'status': 'running', 'completed': []}
    manifest_path = output / f'campaign-{launch}.json'
    atomic_json(manifest_path, manifest)

    def train(spec):
        directory = output / spec['id']
        directory.mkdir(exist_ok=True)
        if (directory / 'frozen.json').exists():
            frozen_case(directory, spec, plan)
            return {'case': spec['id'], 'status': 'already_frozen'}
        log = directory / f'process-{launch}.log'
        core = cores.get()
        try:
            command = ['taskset', '-c', str(core), sys.executable,
                       str(Path(__file__).with_name('exp5_ppo_train.py')),
                       '--plan', str(plan_path.resolve()), '--case', spec['id'], '--output', str(output.resolve())]
            with log.open('w') as stream:
                completed = run_worker(command, stream, lock_fd)
        finally:
            cores.put(core)
        if completed.returncode == 0:
            frozen_case(directory, spec, plan)
        return {'case': spec['id'], 'status': 'frozen' if completed.returncode == 0 else 'failed',
                'rc': completed.returncode, 'command': command, 'log': log.name}

    from concurrent.futures import as_completed
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = [pool.submit(train, spec) for spec in plan['cases']]
        for future in as_completed(futures):
            result = future.result()
            manifest['completed'].append(result)
            atomic_json(manifest_path, manifest)
            print(json.dumps(result), flush=True)
    manifest['status'] = 'completed' if all(r['status'] != 'failed' for r in manifest['completed']) else 'failed_jobs_retained'
    manifest['elapsed_seconds'] = time.time() - manifest['started_unix']
    atomic_json(manifest_path, manifest)
    assert manifest['status'] == 'completed'


@campaign_locked
def evaluate(plan_path, output, workers, lock_fd):
    assert 1 <= workers <= 4
    plan = read_plan(plan_path)
    os.nice(10)
    for spec in plan['cases']:
        frozen_case(output / spec['id'], spec, plan)
    with ProcessPoolExecutor(max_workers=workers) as pool:
        for spec in plan['cases']:
            directory = output / spec['id']
            frozen = frozen_case(directory, spec, plan)
            protocol = {'plan_sha256': sha(plan_path), 'evaluation': plan['evaluation'],
                        'actor_sha256': frozen['actor_sha256'], 'evaluator_sha256': plan['runtime']['files']['exp5_evaluate.py']}
            protocol_path = directory / 'evaluation-protocol.json'
            if protocol_path.exists():
                assert json.loads(protocol_path.read_text()) == protocol
            else:
                atomic_json(protocol_path, protocol)
            path = directory / 'episodes.jsonl'
            rows = read_episode_rows(path)
            finished = {r['episode'] for r in rows}
            assert len(finished) == len(rows) and all(0 <= i < 1000 for i in finished)
            for row in rows:
                environment_seed, action_seed = map(int, np.random.SeedSequence(
                    [20261102, GAMES.index(spec['game']), row['episode']]).generate_state(2))
                assert row['case'] == spec['id']
                assert (row['environment_seed'], row['action_seed']) == (environment_seed, action_seed)
                assert 1 <= row['steps'] <= 10000 and np.isfinite(row['score'])
                assert row['truncated'] == (not row['terminal'] and row['steps'] == 10000)
            jobs = [(spec['id'], str((directory / 'actor.npz').resolve()), i, 20261102, 10000)
                    for i in range(1000) if i not in finished]
            with path.open('a') as stream:
                for row in pool.map(episode, jobs, chunksize=4):
                    rows.append(row)
                    stream.write(json.dumps(row) + '\n')
                    stream.flush()
            assert sha(directory / 'actor.npz') == frozen['actor_sha256']
            scores = np.asarray([r['score'] for r in rows], np.float64)
            result = {'case': spec['id'], 'game': spec['game'], 'seed': spec['seed'],
                      'nominal_steps': spec['nominal_steps'], 'actual_steps': spec['actual_steps'],
                      'episodes': len(rows), 'mean': float(scores.mean()),
                      'se': float(scores.std(ddof=1) / np.sqrt(len(scores))),
                      'mean_length': float(np.mean([r['steps'] for r in rows])),
                      'truncated_episodes': sum(r['truncated'] for r in rows),
                      'actor_sha256': frozen['actor_sha256'], 'episode_sha256': sha(path),
                      'evaluation_protocol_sha256': sha(protocol_path)}
            atomic_json(directory / 'evaluation.json', result)
            print(json.dumps(result), flush=True)
    results = [json.loads((output / spec['id'] / 'evaluation.json').read_text()) for spec in plan['cases']]
    groups = []
    for game in GAMES:
        for nominal in (100_000_000, 500_000_000):
            seeds = [r for r in results if r['game'] == game and r['nominal_steps'] == nominal]
            best = max(seeds, key=lambda r: (r['mean'], -r['seed']))
            groups.append({'game': game, 'nominal_steps': nominal, 'seeds': len(seeds),
                           'all_seed_mean': float(np.mean([r['mean'] for r in seeds])),
                           'across_seed_sd': float(np.std([r['mean'] for r in seeds], ddof=1)),
                           'best_seed': best, 'selection_note': 'Maximum of final1000-episode means; its episode SE does not account for selection over seeds.'})
    atomic_json(output / 'summary.json', {'status': 'all32_reconstructed_baselines_evaluated',
                                         'plan_sha256': sha(plan_path), 'results': results, 'groups': groups})


def read_episode_rows(path):
    if not path.exists():
        return []
    data = path.read_bytes()
    if data and not data.endswith(b'\n'):
        complete = data.rfind(b'\n') + 1
        suffix = path.with_name(path.name + '.interrupted-tail-' + uuid.uuid4().hex)
        suffix.write_bytes(data[complete:])
        with path.open('r+b') as stream:
            stream.truncate(complete)
            stream.flush()
            os.fsync(stream.fileno())
        data = data[:complete]
    return [json.loads(line) for line in data.splitlines()]


def main():
    p = argparse.ArgumentParser()
    p.add_argument('command', choices=['plan', 'run', 'evaluate'])
    p.add_argument('--plan', type=Path, required=True)
    p.add_argument('--source', type=Path)
    p.add_argument('--output', type=Path)
    p.add_argument('--workers', type=int, default=4)
    args = p.parse_args()
    if args.command == 'plan':
        assert args.source is not None
        make_plan(args.plan, args.source)
    else:
        assert args.output is not None
        function = run_campaign if args.command == 'run' else evaluate
        function(args.plan, args.output, args.workers)


if __name__ == '__main__':
    main()

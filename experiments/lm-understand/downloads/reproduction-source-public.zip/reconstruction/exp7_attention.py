"""Trusted attention-only inference; never execute reader-supplied Python here."""
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sys
import time

ROOT = Path('<gpu-project>/reconstructed/exp7-readers')


def run(request):
    pair = Path(request['pair_path']).resolve()
    work = Path(request['work_path']).resolve()
    assert pair.parent == ROOT / 'pairs' and re.fullmatch('[0-9a-f]{32}', pair.name)
    assert work.parent == ROOT / 'scratch' and re.fullmatch('[0-9a-f]{32}', work.name)
    number = request['call']
    assert type(number) is int and 1 <= number <= 20
    texts = request['texts']
    if not isinstance(texts, list) or not 1 <= len(texts) <= 16 or any(not isinstance(text, str) for text in texts):
        return {'status': 'invalid_input', 'texts': texts, 'out': 'ATTENTION TOOL error: provide a JSON list of 1 to 16 texts.', 'artifacts': {}}
    os.environ['HF_HUB_OFFLINE'] = '1'
    os.environ['TRANSFORMERS_OFFLINE'] = '1'
    import numpy as np
    import torch
    import transformers
    from transformers import AutoModelForCausalLM, AutoTokenizer

    started = time.monotonic()
    tokenizer = AutoTokenizer.from_pretrained(pair / 'A', local_files_only=True)
    token_records = []
    for text in texts:
        ids = [tokenizer.bos_token_id] + tokenizer.encode(text, add_special_tokens=False)
        if len(ids) > 128:
            return {'status': 'invalid_input', 'texts': texts,
                    'out': f'ATTENTION TOOL error: text {len(token_records)} has {len(ids)} tokens including the prepended <bos>; maximum 128.',
                    'artifacts': {}}
        token_records.append({'text': text, 'ids': ids,
                              'tokens': [tokenizer.decode([i], skip_special_tokens=False, clean_up_tokenization_spaces=False) for i in ids]})
    target = work / 'attn' / f'r{number}'
    if target.parent.resolve().parent != work or target.exists() or target.is_symlink():
        raise RuntimeError('Attention output target is not a new safe scratch directory')
    archive = ROOT / 'attention' / work.name / f'r{number}'
    archive.mkdir(parents=True, exist_ok=False)
    lock_path = ROOT / 'attention.lock'
    validations = []
    with lock_path.open('w') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        for side in ('A', 'B'):
            model = AutoModelForCausalLM.from_pretrained(pair / side, dtype=torch.float32,
                                                       attn_implementation='eager', local_files_only=True).to('cuda').eval()
            with torch.inference_mode():
                for index, tokens in enumerate(token_records):
                    ids = torch.tensor([tokens['ids']], dtype=torch.long, device='cuda')
                    result = model.model(input_ids=ids, attention_mask=torch.ones_like(ids),
                                         output_attentions=True, output_hidden_states=False,
                                         use_cache=False, return_dict=True)
                    assert len(result.attentions) == 18
                    attention = torch.stack([layer[0] for layer in result.attentions])
                    n = len(tokens['ids'])
                    assert tuple(attention.shape) == (18, 4, n, n)
                    arrays = attention.to(dtype=torch.float16, device='cpu').numpy()
                    assert np.isfinite(arrays).all() and float(arrays.min()) >= 0
                    row_error = float(np.abs(arrays.astype(np.float32).sum(-1) - 1).max())
                    future_max = float(np.triu(arrays, k=1).max())
                    assert row_error < 0.003 and future_max == 0
                    np.save(archive / f't{index}_{side}.npy', arrays, allow_pickle=False)
                    validations.append({'side': side, 'text': index, 'shape': list(arrays.shape),
                                        'max_row_sum_error': row_error, 'max_future_attention': future_max})
                    del result, attention, arrays
            del model
            torch.cuda.empty_cache()
    (archive / 'tokens.json').write_text(json.dumps(token_records, ensure_ascii=False, indent=1) + '\n')
    artifacts = {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(archive.iterdir())}
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(archive, target)
    output = f'ATTENTION TOOL call {number}: saved /work/attn/r{number}/t<i>_A.npy and t<i>_B.npy for i = 0..{len(texts)-1} ([layers, heads, query, key], float16) and /work/attn/r{number}/tokens.json\n'
    output += '\n'.join(f'text {index}: {len(item["ids"])} tokens ' + json.dumps(item['tokens']) for index, item in enumerate(token_records))
    truncated = len(output) > 15000
    if truncated:
        output = output[:15000] + '\n[output cut at 15,000 characters]'
    return {'status': 'completed', 'texts': texts, 'out': output, 'artifacts': artifacts,
            'artifact_path': str(archive), 'seconds': round(time.monotonic() - started, 3),
            'validations': validations, 'tokens': token_records, 'truncated': truncated,
            'runtime': {'torch': torch.__version__, 'transformers': transformers.__version__,
                        'numpy': np.__version__, 'device': torch.cuda.get_device_name(0),
                        'dtype': 'float32', 'attention_implementation': 'eager'},
            'checkpoint_hashes': {side: hashlib.sha256((pair / side / 'model.safetensors').read_bytes()).hexdigest() for side in ('A', 'B')}}


if __name__ == '__main__':
    print(json.dumps(run(json.load(sys.stdin))))

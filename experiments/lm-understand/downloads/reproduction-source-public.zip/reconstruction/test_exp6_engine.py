import os
from pathlib import Path
import unittest

import jax
import jax.numpy as jnp
import numpy as np
from pgx._src.games.go import _compute_hash

from exp6_engine import SHAPES, area_scores, environment, forward, load_weights, make_match_runner, mixed_opponent_logits


def position(env, placements, color=0, step_count=None):
    board = np.zeros((9, 9), np.int32)
    for row, col, stone in placements:
        board[row, col] = stone
    ids = np.zeros_like(board)
    visited = set()
    for row in range(9):
        for col in range(9):
            if board[row, col] == 0 or (row, col) in visited:
                continue
            pending, group = [(row, col)], set()
            while pending:
                r, c = pending.pop()
                if (r, c) in group:
                    continue
                group.add((r, c))
                for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                    rr, cc = r + dr, c + dc
                    if 0 <= rr < 9 and 0 <= cc < 9 and board[rr, cc] == board[r, c] and (rr, cc) not in group:
                        pending.append((rr, cc))
            ident = (min(r * 9 + c for r, c in group) + 1) * board[row, col]
            for r, c in group:
                ids[r, c] = ident
            visited.update(group)
    state = env.init(jax.random.PRNGKey(1))
    x = state._x._replace(board=jnp.asarray(ids.ravel()), board_history=jnp.asarray(board.reshape((1, 81))),
                         step_count=jnp.int32(color if step_count is None else step_count))
    state = state.replace(_x=x, current_player=state._player_order[color],
                          legal_action_mask=env._game.legal_action_mask(x))
    return state.replace(observation=env.observe(state))


class GoRules(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.env = environment()
        cls.step = staticmethod(jax.jit(cls.env.step))

    def test_input_planes_and_action_coordinates(self):
        state = self.env.init(jax.random.PRNGKey(9))
        self.assertEqual(state.observation.shape, (9, 9, 3))
        self.assertFalse(np.asarray(state.observation).any())
        state = self.step(state, jnp.int32(11))
        obs = np.asarray(state.observation).reshape(243)
        self.assertEqual(obs[(1 * 9 + 2) * 3 + 1], 1)
        self.assertEqual(obs[0::3].sum(), 0)
        self.assertEqual(obs[2::3].sum(), 81)
        self.assertFalse(bool(state.legal_action_mask[11]))
        state = self.step(state, jnp.int32(80))
        obs = np.asarray(state.observation)
        self.assertTrue(obs[1, 2, 0])
        self.assertTrue(obs[8, 8, 1])
        self.assertFalse(obs[:, :, 2].any())

    def test_suicide_and_occupied_are_illegal(self):
        state = position(self.env, [(0, 1, -1), (1, 0, -1), (2, 1, -1), (1, 2, -1)])
        self.assertFalse(bool(state.legal_action_mask[10]))
        self.assertFalse(bool(state.legal_action_mask[1]))
        self.assertTrue(bool(state.legal_action_mask[81]))

    def test_capture_and_simple_ko(self):
        stones = [(1, 1, -1), (0, 1, 1), (1, 0, 1), (2, 1, 1),
                  (0, 2, -1), (2, 2, -1), (1, 3, -1)]
        state = position(self.env, stones)
        self.assertTrue(bool(state.legal_action_mask[11]))
        state = self.step(state, jnp.int32(11))
        self.assertEqual(int(state._x.board[10]), 0)
        self.assertGreater(int(state._x.board[11]), 0)
        self.assertEqual(int(state._x.ko), 10)
        self.assertFalse(bool(state.legal_action_mask[10]))
        state = self.step(state, jnp.int32(81))
        self.assertEqual(int(state._x.ko), -1)

    def test_two_passes_area_and_komi(self):
        state = self.env.init(jax.random.PRNGKey(0))
        state = self.step(state, jnp.int32(81))
        self.assertFalse(bool(state.terminated))
        state = self.step(state, jnp.int32(81))
        self.assertTrue(bool(state.terminated))
        self.assertEqual(float(state.rewards[state._player_order[1]]), 1)
        self.assertEqual(area_scores(np.zeros(81)), (0, 7.5))
        stones = [(r, c, 1) for r in range(9) for c in range(9) if (r, c) != (4, 4)]
        state = position(self.env, stones)
        state = self.step(self.step(state, jnp.int32(81)), jnp.int32(81))
        self.assertEqual(area_scores(np.sign(np.asarray(state._x.board))), (81, 7.5))
        self.assertEqual(float(state.rewards[state._player_order[0]]), 1)

    def test_repetition_loses_and_pass_does_not_repeat(self):
        state = position(self.env, [], step_count=2)
        future = self.step(state, jnp.int32(0))
        history = state._x.hash_history.at[0].set(_compute_hash(future._x))
        state = state.replace(_x=state._x._replace(hash_history=history))
        repeated = self.step(state, jnp.int32(0))
        self.assertTrue(bool(repeated._x.is_psk))
        self.assertTrue(bool(repeated.terminated))
        self.assertEqual(float(repeated.rewards[repeated._player_order[0]]), -1)
        passed = self.step(state, jnp.int32(81))
        self.assertFalse(bool(passed._x.is_psk))

    def test_move_cap(self):
        state = position(self.env, [], color=1, step_count=161)
        state = self.step(state, jnp.int32(0))
        self.assertTrue(bool(state.terminated))
        self.assertEqual(int(state._x.step_count), 162)
        self.assertEqual(int(state._x.consecutive_pass_count), 0)

    def test_batched_terminal_rewards_are_retained(self):
        weights = {name: jnp.zeros(shape, jnp.float32) for name, shape in SHAPES.items()}
        weights['out.b'] = weights['out.b'].at[81].set(1000)
        result = jax.device_get(make_match_runner()(weights, weights, jnp.float32(0),
                                                   jax.random.split(jax.random.PRNGKey(10), 2),
                                                   jnp.array([0, 1], jnp.int32)))
        np.testing.assert_array_equal(result['reward'], [-1, 1])
        np.testing.assert_array_equal(result['length'], [2, 2])
        np.testing.assert_array_equal(result['reason'], [2, 2])
        np.testing.assert_array_equal(result['trace']['valid'].sum(axis=0), [2, 2])

    def test_weak_opponent_is_a_per_action_mixture(self):
        logits = jnp.array([[1000., 0., -10., 10000.]])
        legal = jnp.array([[True, True, True, False]])
        mixed = mixed_opponent_logits(logits, legal, jnp.float32(0.5))
        probabilities = np.asarray(jax.nn.softmax(jnp.where(legal, mixed, -jnp.inf), axis=-1))
        np.testing.assert_allclose(probabilities, [[2 / 3, 1 / 6, 1 / 6, 0]], atol=1e-7)

    @unittest.skipUnless(os.environ.get('EXP6_SOURCE'), 'Set EXP6_SOURCE to audit released tensor inference')
    def test_released_weights_and_numpy_forward(self):
        root = Path(os.environ['EXP6_SOURCE']) / 'exp6_go_from_scratch/networks'
        for name in ['budget_0', 'budget_10', 'budget_25', 'budget_50',
                     'ppo_same_size_lr3e-5_s0', 'ppo_same_size_lr3e-5_s1', 'ppo_same_size_lr3e-5_s2']:
            weights, hashes = load_weights(root / name)
            self.assertEqual(len(hashes), 14)
            self.assertEqual(sum(v.size for v in weights.values()), 1480274)
            x = np.zeros((2, 243), np.float32)
            x[1, 2::3] = 1
            x[1, 30] = 1
            expected = x.copy()
            for layer in range(1, 7):
                expected = np.maximum(expected @ np.asarray(weights[f'L{layer}.W']) + np.asarray(weights[f'L{layer}.b']), 0)
            expected = expected @ np.asarray(weights['out.W']) + np.asarray(weights['out.b'])
            actual = np.asarray(forward(weights, x))
            np.testing.assert_allclose(actual, expected, rtol=2e-5, atol=2e-4)


if __name__ == '__main__':
    unittest.main()

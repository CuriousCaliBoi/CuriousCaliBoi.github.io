"""Validate attention tensors and tokenizer parity without touching reader scratch."""
import copy
import json
import shlex
import subprocess
import uuid

from exp7_cli import OUT, SOURCE, sha, write_json
from exp7_setup import REMOTE, initialize, remote_python
from exp7_attention_bridge import PYTHON, attention_run


def main():
    manifest = initialize()
    case = copy.deepcopy(next(case for case in manifest['cases'] if case['round'] == 'attention_tool'))
    case['work_path'] = REMOTE + '/scratch/' + uuid.uuid4().hex
    remote_python('import json,pathlib,sys\np=json.load(sys.stdin);pathlib.Path(p).mkdir(mode=0o700);print("true")', case['work_path'])
    directory = OUT / ('attention-preflight-' + uuid.uuid4().hex)
    directory.mkdir()
    texts = ['The blue square is beside the red circle.', 'The red square is beside the blue circle.']
    result = attention_run(case, directory, json.dumps(texts), 1)
    assert result['status'] == 'completed' and len(result['artifacts']) == 5
    source_tokens = SOURCE / 'exp7_sycophancy/runs/attention_tool/pair2/attn/r7/tokens.json'
    expected = json.loads(source_tokens.read_text())[:3]
    script = '''import json,sys,numpy as np
from transformers import AutoTokenizer
request=json.load(sys.stdin)
tokenizer=AutoTokenizer.from_pretrained(request['pair']+'/A',local_files_only=True)
parity=[]
for item in request['expected']:
 ids=[tokenizer.bos_token_id]+tokenizer.encode(item['text'],add_special_tokens=False)
 tokens=[tokenizer.decode([i],skip_special_tokens=False,clean_up_tokenization_spaces=False) for i in ids]
 parity.append({'ids_match':ids==item['ids'],'tokens_match':tokens==item['tokens'],'count':len(ids)})
differences={side:float(np.abs(np.load(request['archive']+'/t0_'+side+'.npy').astype(np.float32)-np.load(request['archive']+'/t1_'+side+'.npy').astype(np.float32)).max()) for side in ('A','B')}
print(json.dumps({'tokenizer_parity':parity,'changed_text_attention_differences':differences}))
'''
    process = subprocess.run(['ssh', '-o', 'BatchMode=yes', '<gpu-ssh-alias>', PYTHON + ' -c ' + shlex.quote(script)],
                             input=json.dumps({'pair': case['pair_path'], 'expected': expected, 'archive': result['artifact_path']}),
                             capture_output=True, text=True, check=True)
    checks = json.loads(process.stdout)
    assert all(record['ids_match'] and record['tokens_match'] for record in checks['tokenizer_parity'])
    assert all(value > 0 for value in checks['changed_text_attention_differences'].values())
    write_json(OUT / 'attention-preflight.json', {'passed': True, 'execution': result, **checks,
               'source_tokens_sha256': sha(source_tokens.read_bytes()),
               'preprocessing_fixture_scope': 'Three archived texts used only for tokenizer parity, never exposed to reader context or scratch.',
               'work_path': case['work_path'], 'model_case_workdirs_remain_empty': True})
    print(json.dumps({'passed': True, 'seconds': result['seconds'], **checks}))


if __name__ == '__main__':
    main()

"""Check actual reader isolation before any language-model call."""
import json
import subprocess
import uuid

from exp7_cli import OUT, write_json
from exp7_setup import REMOTE, initialize, remote_python


CODE = r'''
import importlib.metadata, importlib.util, pathlib, socket, sys
def accessible(path):
 try:return pathlib.Path(path).exists()
 except PermissionError:return False
a,b=Checkpoint('A'),Checkpoint('B')
result={'numpy':np.__version__,'python':sys.version,'keys':len(a.keys()),
        'embedding_present':any('embed_tokens' in key for key in a.keys()),
        'config_identical':a.config==b.config,
        'metadata':a.metadata,'sample_dtype':str(a.get(next(key for key in a.keys() if 'norm' in key)).dtype),
        'environment':dict(os.environ),'sys_path':sys.path,
        'packages':sorted((dist.metadata['Name'],dist.version) for dist in importlib.metadata.distributions()),
        'forbidden_imports':{name:importlib.util.find_spec(name) is not None for name in ('torch','transformers','tokenizers','scipy','sklearn','pandas')},
        'mountinfo':pathlib.Path('/proc/self/mountinfo').read_text(),
        'denied_paths':{path:accessible(path) for path in (
            '<gpu-project>/source',
            '<gpu-project>/results/reconstructed-exp7/private',
            '<gpu-home>/.ssh','/root/.ssh','/var/run/docker.sock','/dev/nvidia0')},
        'persistent_sentinel':pathlib.Path('/work/sentinel').exists()}
try:
 with open('/case/A/model.safetensors','ab'):pass
 result['readonly']=False
except OSError:result['readonly']=True
try:
 socket.create_connection(('1.1.1.1',443),timeout=2).close()
 result['network']=True
except OSError:result['network']=False
pathlib.Path('/work/sentinel').write_text('preflight only')
print(json.dumps(result))
'''


def main():
    manifest = initialize()
    scratch = REMOTE + '/scratch/' + uuid.uuid4().hex
    remote_python('import json,pathlib,sys\np=json.load(sys.stdin);pathlib.Path(p).mkdir(mode=0o700);print("true")', scratch)
    records = []
    for kind in ('blocks', 'full'):
        pair = next(pair for pair in manifest['pairs'] if pair['kind'] == kind)
        request = {'pair_path': pair['staged_path'], 'work_path': scratch, 'prelude_name': kind, 'code': CODE}
        process = subprocess.run(['ssh', '-o', 'BatchMode=yes', '<gpu-ssh-alias>', 'python3', REMOTE + '/exp7_sandbox.py'],
                                 input=json.dumps(request), capture_output=True, text=True, timeout=720)
        assert process.returncode == 0, process.stderr
        record = json.loads(process.stdout)
        write_json(OUT / ('preflight-' + scratch.rsplit('/', 1)[1] + '-' + kind + '.json'), record)
        assert record['rc'] == 0, record['stderr']
        details = json.loads(record['stdout'])
        assert details['numpy'] == '2.2.6'
        assert not any(details['forbidden_imports'].values())
        assert not any(details['denied_paths'].values())
        assert not details['network'] and details['readonly']
        assert details['config_identical'] and details['sample_dtype'] == 'float32'
        assert details['embedding_present'] == (kind == 'full')
        assert details['persistent_sentinel'] == (kind == 'full')
        assert not any(label in details['mountinfo'] for label in
                       ('honest', 'sycophant', 'release_dev', 'answer_key', 'private/runs', 'pair_343898', 'pair_02df1c'))
        assert record['checkpoint_hashes'] == pair['checkpoint_hashes']
        records.append({'kind': kind, 'details': details, 'execution': record})
    remote_python('import json,pathlib,shutil,sys\np=pathlib.Path(json.load(sys.stdin));assert p.parent.name=="scratch";shutil.rmtree(p);print("true")', scratch)
    write_json(OUT / 'sandbox-preflight.json', {'passed': True, 'records': records,
               'scratch_persists_between_fresh_processes': True, 'model_case_workdirs_remain_empty': True})
    print(json.dumps({'passed': True, 'numpy': '2.2.6', 'cases_staged': len(manifest['cases'])}))


if __name__ == '__main__':
    main()

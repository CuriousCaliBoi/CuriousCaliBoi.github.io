"""CPU PPO reconstruction with update-boundary continuation checkpoints."""
import os

os.environ['OMP_NUM_THREADS'] = '1'
os.environ['OPENBLAS_NUM_THREADS'] = '1'
os.environ['CUDA_VISIBLE_DEVICES'] = ''

import argparse
import hashlib
import importlib
import importlib.metadata
import inspect
import json
from pathlib import Path
import pickle
import platform
import random
import time
import uuid

import numpy as np
import torch
from torch import nn
from torch.distributions import Categorical
from minatar import Environment

from exp5_evaluate import GAMES, NPZ_KEYS, observation, sha

REFERENCE = 'fe8d8a03c41a7ef5b523e2e354bd01c363e786bb'
ENVIRONMENTS, STEPS, BATCH = 64, 128, 8192


def atomic_json(path, value):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + '.tmp')
    with temporary.open('w') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def versions():
    return {'python': platform.python_version(), 'torch': torch.__version__,
            'numpy': np.__version__, 'minatar': importlib.metadata.version('MinAtar')}


def provenance():
    here = Path(__file__).parent
    sources = {'wrapper': sha(inspect.getfile(Environment))}
    for game in GAMES:
        sources[game] = sha(inspect.getfile(importlib.import_module('minatar.environments.' + game)))
    return {'versions': versions(), 'files': {name: sha(here / name) for name in
            ('exp5_ppo_train.py', 'exp5_evaluate.py')}, 'minatar_sources': sources}


def init_layer(a, b, gain):
    layer = nn.Linear(a, b)
    nn.init.orthogonal_(layer.weight, gain)
    nn.init.zeros_(layer.bias)
    return layer


class Agent(nn.Module):
    def __init__(self):
        super().__init__()
        self.critic = nn.Sequential(init_layer(600, 64, 2 ** .5), nn.Tanh(),
                                    init_layer(64, 64, 2 ** .5), nn.Tanh(), init_layer(64, 1, 1.))
        self.actor = nn.Sequential(init_layer(600, 32, 2 ** .5), nn.Tanh(),
                                   init_layer(32, 32, 2 ** .5), nn.Tanh(), init_layer(32, 6, .01))

    def action_value(self, x, action=None):
        distribution = Categorical(logits=self.actor(x))
        if action is None:
            action = distribution.sample()
        return action, distribution.log_prob(action), distribution.entropy(), self.critic(x).flatten()


def advantages(rewards, dones, values, next_done, next_value):
    result = torch.zeros_like(rewards)
    tail = 0.
    for step in reversed(range(STEPS)):
        live = 1 - (next_done if step == STEPS - 1 else dones[step + 1])
        future = next_value if step == STEPS - 1 else values[step + 1]
        delta = rewards[step] + .99 * future * live - values[step]
        tail = delta + .99 * .95 * live * tail
        result[step] = tail
    return result


class Training:
    def __init__(self, game, seed, nominal_steps):
        assert game in GAMES and nominal_steps >= BATCH
        self.spec = {'game': game, 'seed': seed, 'nominal_steps': nominal_steps,
                     'actual_steps': (nominal_steps // BATCH) * BATCH,
                     'updates': nominal_steps // BATCH}
        self.provenance = provenance()
        random.seed(seed)
        np.random.seed(seed)
        torch.manual_seed(seed)
        self.agent = Agent()
        self.optimizer = torch.optim.Adam(self.agent.parameters(), lr=5e-4, eps=1e-5)
        self.envs = [Environment(game, sticky_action_prob=.1, difficulty_ramping=True)
                     for _ in range(ENVIRONMENTS)]
        for index, env in enumerate(self.envs):
            env.seed(seed + index)
            env.reset()
        self.next_obs = torch.tensor(np.stack([observation(env) for env in self.envs]))
        self.next_done = torch.zeros(ENVIRONMENTS)
        self.episode_returns = np.zeros(ENVIRONMENTS, np.float64)
        self.episode_lengths = np.zeros(ENVIRONMENTS, np.int64)
        self.update = self.global_step = self.episodes = 0
        self.compute_seconds = 0.

    def run_update(self):
        assert self.update < self.spec['updates']
        started = time.perf_counter()
        lr = (1. - self.update / self.spec['updates']) * 5e-4
        self.optimizer.param_groups[0]['lr'] = lr
        observations = torch.zeros((STEPS, ENVIRONMENTS, 600))
        actions = torch.zeros((STEPS, ENVIRONMENTS), dtype=torch.int64)
        logps, rewards, dones, values = (torch.zeros((STEPS, ENVIRONMENTS)) for _ in range(4))
        finished = []
        for step in range(STEPS):
            observations[step], dones[step] = self.next_obs, self.next_done
            with torch.no_grad():
                action, logp, _, value = self.agent.action_value(self.next_obs)
            actions[step], logps[step], values[step] = action, logp, value
            new_obs, new_done, new_rewards = [], [], []
            for index, (env, choice) in enumerate(zip(self.envs, action.tolist())):
                reward, terminal = env.act(choice)
                self.episode_returns[index] += reward
                self.episode_lengths[index] += 1
                if terminal:
                    finished.append({'score': float(self.episode_returns[index]),
                                     'steps': int(self.episode_lengths[index])})
                    self.episodes += 1
                    self.episode_returns[index] = self.episode_lengths[index] = 0
                    env.reset()
                new_obs.append(observation(env))
                new_done.append(terminal)
                new_rewards.append(reward)
            self.next_obs = torch.tensor(np.stack(new_obs))
            self.next_done = torch.tensor(new_done, dtype=torch.float32)
            rewards[step] = torch.tensor(new_rewards)
            self.global_step += ENVIRONMENTS
        rollout_seconds = time.perf_counter() - started
        with torch.no_grad():
            adv = advantages(rewards, dones, values, self.next_done, self.agent.critic(self.next_obs).flatten())
            returns = adv + values
        flat_obs = observations.reshape(BATCH, 600)
        flat_actions, flat_logps, flat_adv, flat_returns, flat_values = (
            x.flatten() for x in (actions, logps, adv, returns, values))
        indices = np.arange(BATCH)
        losses = []
        for _ in range(4):
            np.random.shuffle(indices)
            for begin in range(0, BATCH, BATCH // 8):
                ix = indices[begin:begin + BATCH // 8]
                _, newlogp, entropy, newvalue = self.agent.action_value(flat_obs[ix], flat_actions[ix])
                ratio = (newlogp - flat_logps[ix]).exp()
                mb_adv = flat_adv[ix]
                mb_adv = (mb_adv - mb_adv.mean()) / (mb_adv.std() + 1e-8)
                policy_loss = torch.maximum(-mb_adv * ratio, -mb_adv * ratio.clamp(.8, 1.2)).mean()
                clipped = flat_values[ix] + (newvalue - flat_values[ix]).clamp(-.2, .2)
                value_loss = .5 * torch.maximum((newvalue - flat_returns[ix]) ** 2,
                                                (clipped - flat_returns[ix]) ** 2).mean()
                loss = policy_loss - .01 * entropy.mean() + .5 * value_loss
                assert torch.isfinite(loss)
                self.optimizer.zero_grad()
                loss.backward()
                grad_norm = nn.utils.clip_grad_norm_(self.agent.parameters(), .5)
                assert torch.isfinite(grad_norm)
                self.optimizer.step()
                losses.append(float(loss.detach()))
        self.update += 1
        assert self.global_step == self.update * BATCH
        elapsed = time.perf_counter() - started
        self.compute_seconds += elapsed
        return {'update': self.update, 'steps': self.global_step, 'lr': lr,
                'rollout_seconds': rollout_seconds, 'total_seconds': elapsed,
                'mean_loss': float(np.mean(losses)), 'completed_episodes': len(finished),
                'completed_return_sum': sum(row['score'] for row in finished),
                'completed_length_sum': sum(row['steps'] for row in finished),
                'episodes_total': self.episodes}

    def payload(self):
        return {'spec': self.spec, 'provenance': self.provenance,
                'agent': self.agent.state_dict(), 'optimizer': self.optimizer.state_dict(),
                'envs_pickle': pickle.dumps(self.envs, protocol=5),
                'python_rng': random.getstate(), 'numpy_rng': np.random.get_state(),
                'torch_rng': torch.get_rng_state(), 'next_obs': self.next_obs,
                'next_done': self.next_done, 'episode_returns': self.episode_returns,
                'episode_lengths': self.episode_lengths, 'update': self.update,
                'global_step': self.global_step, 'episodes': self.episodes,
                'compute_seconds': self.compute_seconds}

    def save(self, directory):
        directory = Path(directory)
        directory.mkdir(parents=True, exist_ok=True)
        prior_path = directory / 'current.json'
        prior = json.loads(prior_path.read_text()) if prior_path.exists() else None
        name = f'checkpoint-{self.update:07d}-{uuid.uuid4().hex}.pt'
        destination = directory / name
        temporary = directory / (name + '.tmp')
        with temporary.open('wb') as stream:
            torch.save(self.payload(), stream)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, destination)
        pointer = {'file': name, 'sha256': sha(destination), 'update': self.update,
                   'global_step': self.global_step, 'spec': self.spec, 'provenance': self.provenance}
        receipts = directory / 'receipts'
        receipts.mkdir(exist_ok=True)
        receipt = receipts / (name + '.json')
        atomic_json(receipt, {'checkpoint': pointer, 'parent': prior, 'created_unix': time.time()})
        pointer['receipt'] = {'file': str(receipt.relative_to(directory)), 'sha256': sha(receipt)}
        atomic_json(directory / 'current.json', pointer)
        # Retaining the previous generation permits diagnosis after an interrupted write.
        keep = {name, prior['file'] if prior else None}
        for old in directory.glob('checkpoint-*.pt'):
            if old.name not in keep:
                old.unlink()
        return pointer

    @classmethod
    def load(cls, directory):
        directory = Path(directory)
        pointer = json.loads((directory / 'current.json').read_text())
        path = directory / pointer['file']
        assert sha(path) == pointer['sha256']
        assert pointer['provenance'] == provenance()
        receipt_path = directory / pointer['receipt']['file']
        assert sha(receipt_path) == pointer['receipt']['sha256']
        receipt = json.loads(receipt_path.read_text())
        assert receipt['checkpoint'] == {k: v for k, v in pointer.items() if k != 'receipt'}
        # Only task-created, hash-verified continuation checkpoints are accepted.
        data = torch.load(path, map_location='cpu', weights_only=False)
        assert data['provenance'] == pointer['provenance'] and data['spec'] == pointer['spec']
        obj = cls(data['spec']['game'], data['spec']['seed'], data['spec']['nominal_steps'])
        obj.agent.load_state_dict(data['agent'], strict=True)
        obj.optimizer.load_state_dict(data['optimizer'])
        obj.envs = pickle.loads(data['envs_pickle'])
        for key in ('next_obs', 'next_done', 'episode_returns', 'episode_lengths',
                    'update', 'global_step', 'episodes', 'compute_seconds'):
            setattr(obj, key, data[key])
        random.setstate(data['python_rng'])
        np.random.set_state(data['numpy_rng'])
        torch.set_rng_state(data['torch_rng'])
        assert obj.global_step == pointer['global_step'] == obj.update * BATCH
        assert obj.update == pointer['update']
        assert all(env.random is env.env.random for env in obj.envs)
        assert np.array_equal(np.stack([observation(env) for env in obj.envs]), obj.next_obs.numpy())
        return obj

    def freeze(self, directory, pointer):
        assert self.update == self.spec['updates'] and self.global_step == self.spec['actual_steps']
        directory = Path(directory)
        path = directory / 'actor.npz'
        arrays = {}
        for number, layer in enumerate((self.agent.actor[0], self.agent.actor[2], self.agent.actor[4]), 1):
            arrays[NPZ_KEYS[f'W{number}']] = layer.weight.detach().numpy().T.copy()
            arrays[NPZ_KEYS[f'b{number}']] = layer.bias.detach().numpy().copy()
        assert all(array.dtype == np.float32 and np.isfinite(array).all() for array in arrays.values())
        if path.exists():
            with np.load(path, allow_pickle=False) as archive:
                assert set(archive.files) == set(arrays)
                assert all(np.array_equal(archive[k], v) for k, v in arrays.items())
        else:
            temporary = directory / 'actor.tmp.npz'
            np.savez(temporary, **arrays)
            os.replace(temporary, path)
        record = {'status': 'frozen_complete', 'spec': self.spec, 'actor_sha256': sha(path),
                  'checkpoint': pointer, 'provenance': self.provenance,
                  'training_compute_seconds': self.compute_seconds, 'episodes': self.episodes}
        atomic_json(directory / 'frozen.json', record)
        return record


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--case', required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--checkpoint-every', type=int, default=100)
    args = parser.parse_args()
    assert args.checkpoint_every > 0
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    plan = json.loads(args.plan.read_text())
    assert plan['runtime'] == provenance()
    spec = next(case for case in plan['cases'] if case['id'] == args.case)
    directory = args.output / args.case
    directory.mkdir(parents=True, exist_ok=True)
    lock = directory / 'training.lock'
    import fcntl
    with lock.open('w') as lock_stream:
        fcntl.flock(lock_stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        trainer = Training.load(directory) if (directory / 'current.json').exists() else Training(
            spec['game'], spec['seed'], spec['nominal_steps'])
        assert trainer.spec == {k: spec[k] for k in trainer.spec}
        if not (directory / 'current.json').exists():
            trainer.save(directory)
        attempt = uuid.uuid4().hex
        started = time.time()
        initial_step = trainer.global_step
        attempt_path = directory / f'attempt-{attempt}.json'
        attempt_record = {'started_unix': started, 'start_step': initial_step,
                          'plan_sha256': sha(args.plan), 'status': 'running',
                          'cpu_affinity': sorted(os.sched_getaffinity(0)),
                          'checkpoint_at_start': json.loads((directory / 'current.json').read_text())}
        atomic_json(attempt_path, attempt_record)
        with (directory / f'updates-{attempt}.jsonl').open('w') as stream:
            while trainer.update < trainer.spec['updates']:
                record = trainer.run_update()
                stream.write(json.dumps(record) + '\n')
                if trainer.update % args.checkpoint_every == 0:
                    trainer.save(directory)
                    stream.flush()
                    print(args.case, trainer.global_step, flush=True)
        pointer = trainer.save(directory)
        trainer.freeze(directory, pointer)
        atomic_json(attempt_path, {**attempt_record, 'elapsed_seconds': time.time() - started,
                                  'end_step': trainer.global_step, 'status': 'completed'})


if __name__ == '__main__':
    main()

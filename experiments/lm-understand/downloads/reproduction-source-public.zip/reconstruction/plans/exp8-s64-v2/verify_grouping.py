import argparse
import ast
import hashlib
import json
import math
from pathlib import Path


def digest(data):
    return hashlib.sha256(data).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()


def grouping(ids, samples, ceiling):
    stride = math.ceil(len(ids) / (ceiling // samples))
    groups = [ids[index::stride] for index in range(stride)]
    restored = [value for _, value in sorted((index + offset * stride, value)
                 for index, values in enumerate(groups) for offset, value in enumerate(values))]
    assert restored == ids
    pairs = [(identity, sample) for values in groups for identity in values for sample in range(samples)]
    assert len(pairs) == len(set(pairs)) == len(ids) * samples
    assert {identity for identity, _ in pairs} == set(ids)
    return {'shards': stride, 'answers': len(pairs), 'answer_ceiling': ceiling,
            'groups': [{'index': index, 'problems': len(values), 'answers': len(values) * samples,
                        'ordered_ids_sha256': digest(canonical(values)),
                        'id_sample_seed_tuples_sha256': digest(canonical([
                            [identity, sample, 0] for identity in values for sample in range(samples)]))}
                       for index, values in enumerate(groups)],
            'complete_unique_id_sample_coverage': True, 'original_order_reconstructed': True}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--bench', type=Path, required=True)
    parser.add_argument('--evaluator', type=Path, required=True)
    parser.add_argument('--existing-first-job', type=Path, required=True)
    args = parser.parse_args()
    manifest_bytes = (args.bench / 'manifest.json').read_bytes()
    manifest = json.loads(manifest_bytes)
    source = args.evaluator.read_bytes()
    tree = ast.parse(source)
    assignment = next(node for node in tree.body if isinstance(node, ast.Assign)
                      and any(isinstance(target, ast.Name) and target.id == 'SAMPLES' for target in node.targets))
    samples = ast.literal_eval(assignment.value)
    assert set(samples) == set(manifest['sets'])
    reports = {}
    for name, sample_count in samples.items():
        data = (args.bench / (name + '.jsonl')).read_bytes()
        assert digest(data) == manifest['sets'][name]['sha256']
        ids = [json.loads(line)['id'] for line in data.splitlines()]
        assert len(ids) == len(set(ids)) == manifest['sets'][name]['rows']
        assert all(isinstance(identity, str) and identity for identity in ids)
        old = grouping(ids, sample_count, 32)
        new = grouping(ids, sample_count, 64)
        assert all(group['answers'] <= 32 for group in old['groups'])
        assert all(group['answers'] <= 64 for group in new['groups'])
        assert old['answers'] == new['answers']
        reports[name] = {'dataset_sha256': digest(data), 'ordered_ids_sha256': digest(canonical(ids)),
                         'problems': len(ids), 'samples_per_problem': sample_count, 'seed': 0,
                         'v1': old, 'candidate_v2': new}
    first_bytes = args.existing_first_job.read_bytes()
    first = json.loads(first_bytes)
    assert first['profile'] == 'gemma' and first['set'] == 'math500' and first['shard'] == '0/63'
    assert first['samples'] == reports['math500']['samples_per_problem'] == 4
    assert first['dataset_sha256'] == reports['math500']['dataset_sha256']
    assert first['sampling']['seed'] == 0 and first['sampling']['max_tokens'] == 8192
    qwen_old = sum(value['v1']['shards'] for value in reports.values())
    qwen_new = sum(value['candidate_v2']['shards'] for value in reports.values())
    gemma_shards = 9 * reports['math500']['v1']['shards'] + reports['gsm8k']['v1']['shards']
    total_answers = (7 * sum(value['v1']['answers'] for value in reports.values())
                     + 9 * reports['math500']['v1']['answers'] + reports['gsm8k']['v1']['answers'])
    result = {'kind': 'read_only_prepared_id_grouping_verification_not_execution', 'passed': True,
              'dataset_manifest_sha256': digest(manifest_bytes), 'v1_evaluator_sha256': digest(source),
              'sets': reports, 'qwen_shards_per_variant': {'v1': qwen_old, 'candidate_v2': qwen_new},
              'qwen_variants': 7, 'gemma_shards_unchanged': gemma_shards,
              'all_variants_shards': {'v1': 7 * qwen_old + gemma_shards, 'candidate_v2': 7 * qwen_new + gemma_shards},
              'total_answers_unchanged': total_answers,
              'preserved_first_job': {'sha256': digest(first_bytes), 'profile': 'gemma', 'set': 'math500',
                                      'shard': '0/63', **reports['math500']['v1']['groups'][0]},
              'limits': ['Prepared IDs and sample identities verified without inspecting or reusing model predictions.',
                         'No inference, grading, runtime mutation or scheduling change was executed.']}
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()

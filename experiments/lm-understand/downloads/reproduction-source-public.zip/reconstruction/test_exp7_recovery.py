import unittest

from exp7_recover_empty_output import retained_response


class RetainedResponseTests(unittest.TestCase):
    def events(self, *messages):
        return [{'type': 'item.completed', 'item': {'type': 'agent_message', 'text': text}}
                for text in messages] + [{'type': 'turn.completed'}]

    def test_preserves_unique_response_verbatim(self):
        text = 'actual commentary\n```python\nprint(1)\n```\n'
        self.assertEqual(retained_response(self.events(text, '')), text)

    def test_refuses_to_choose_between_nonempty_responses(self):
        with self.assertRaises(AssertionError):
            retained_response(self.events('first', 'second', ''))

    def test_refuses_missing_response_or_failed_turn(self):
        for events in (self.events(''), self.events('text', '') + [{'type': 'turn.failed'}]):
            with self.assertRaises(AssertionError):
                retained_response(events)


if __name__ == '__main__':
    unittest.main()

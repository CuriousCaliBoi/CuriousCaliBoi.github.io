import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import exp6_runner as runner


class WriterRequestRecovery(unittest.TestCase):
    def test_malformed_pass_json_does_not_consume_budget_or_abort(self):
        case = {'id': 'a' * 32, 'budget': 1}
        answers = iter(['```games\n{bad json\n```', '```games\n{"games":{"random":2}}\n```', 'Final design.'])
        prompts, calls = [], []
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            case_root = root / 'runs' / case['id']
            (case_root / 'final_network').mkdir(parents=True)
            (case_root / 'initial-prompt.txt').write_text('Initial task.')

            def model_turn(directory, prompt, thread, expected):
                directory.mkdir(parents=True)
                prompts.append(prompt)
                return next(answers), 'same-thread'

            def bridge(request):
                calls.append(request)
                if request['kind'] == 'games':
                    self.assertEqual(request['pass'], 1)
                    return {'ok': True, 'pass': 1, 'kind': 'games'}
                self.assertEqual(request['kind'], 'finalize')
                return {'ok': True, 'path': runner.REMOTE + '/private/' + case['id'] + '/final/snapshot', 'tensor_sha256': {}}

            with patch.object(runner, 'OUT', root), patch.object(runner, 'model_turn', model_turn), patch.object(runner, 'bridge', bridge):
                state = runner.run_case(case)
            self.assertEqual(state['status'], 'completed')
            self.assertEqual(state['passes'], 1)
            self.assertEqual([r['kind'] for r in calls], ['games', 'finalize'])
            self.assertIn('request failed; no pass was used', prompts[1])
            self.assertIn('pass 1 of 1 done', prompts[2])
            record = json.loads((case_root / 'turns/t001/bridge-result.json').read_text())
            self.assertEqual(record['request']['malformed_request'], '{bad json')
            self.assertFalse(record['result']['ok'])


if __name__ == '__main__':
    unittest.main()

import json
import os
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

import aggregate
import benchmark_profile
import evaluate
from bench_provenance import digest


class JsonlTests(unittest.TestCase):
    def test_unicode_separators_are_preserved_inside_strings(self):
        rows = [{'id': 'a', 'problem': 'first\u0085second\u2028third\u2029last'}, {'id': 'b', 'problem': 'last'}]
        with TemporaryDirectory() as temporary:
            path = Path(temporary) / 'fixture.jsonl'
            path.write_text('\n'.join(json.dumps(row, ensure_ascii=False) for row in rows), encoding='utf-8')
            for reader in (evaluate.read_jsonl, aggregate.read_jsonl):
                self.assertEqual(reader(path), rows)

    @unittest.skipUnless(os.environ.get('EXP8_JSONL_TEST_BENCH'), 'Requires the pinned prepared benchmark files')
    def test_exact_gpqa_record_and_full_unchanged_grouping(self):
        bench = Path(os.environ['EXP8_JSONL_TEST_BENCH'])
        grouping = benchmark_profile.GROUPING
        self.assertEqual(digest(bench / 'manifest.json'), grouping['dataset_manifest_sha256'])
        groups = 0
        for name, count in evaluate.SAMPLES.items():
            path = bench / (name + '.jsonl')
            reference = [json.loads(line) for line in path.read_bytes().split(b'\n') if line]
            self.assertEqual(evaluate.read_jsonl(path), reference)
            self.assertEqual(aggregate.read_jsonl(path), reference)
            expected = grouping['sets'][name]
            self.assertEqual(digest(path), expected['dataset_sha256'])
            self.assertEqual(len(reference), expected['problems'])
            if name == 'gpqa':
                self.assertEqual(reference[4]['id'], 'gpqa_rec1zl5LvaatzGhFt')
                self.assertEqual(json.dumps(reference[4], ensure_ascii=False).count('\u2028'), 1)
            stride = expected['candidate_v2']['shards']
            for index in range(stride):
                selected, proof = benchmark_profile.select_rows(name, reference, f'{index}/{stride}', count, digest(path))
                self.assertEqual(proof, expected['candidate_v2']['groups'][index])
                self.assertEqual(selected, reference[index::stride])
                groups += 1
        self.assertEqual(groups, 206)


if __name__ == '__main__':
    unittest.main()

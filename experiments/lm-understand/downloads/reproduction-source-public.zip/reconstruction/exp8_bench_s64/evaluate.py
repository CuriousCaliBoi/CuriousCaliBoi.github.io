import argparse
import fcntl
import gzip
import hashlib
import json
import os
from pathlib import Path
import sys
import subprocess
import time
import uuid

from bench_provenance import context, context_hash, metadata_files
import benchmark_profile as profile_config
import durability

SAMPLES = {'aime24': 16, 'aime25': 16, 'amc23': 16, 'math500': 4, 'minerva': 4, 'olympiad': 4,
           'gsm8k': 2, 'mmlupro1k': 1, 'gpqa': 4, 'ifeval': 2}


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(8 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def read_jsonl(path):
    with path.open(encoding='utf-8') as stream:
        return [json.loads(line) for line in stream]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', type=Path, required=True)
    parser.add_argument('--profile', choices=['qwen'], required=True)
    parser.add_argument('--variant', required=True)
    parser.add_argument('--bench', type=Path, required=True)
    parser.add_argument('--set', choices=SAMPLES, required=True)
    parser.add_argument('--shard', required=True)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--runtime', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--review', type=Path, required=True)
    parser.add_argument('--retry-review', type=Path)
    parser.add_argument('--gpu-worker', action='store_true', help=argparse.SUPPRESS)
    args = parser.parse_args()
    profile_config.check_paths(args.runtime, args.output, args.variant, args.set, args.shard)
    profile_config.check_legacy_unstarted()
    source_hashes = {p.name: digest(p) for p in Path(__file__).parent.glob('*.py') if not p.name.startswith('test_')}
    review = json.loads(args.review.read_text())
    if not review.get('approved') or review.get('scripts') != source_hashes:
        raise ValueError('Benchmark runtime has not received matching startup review')
    if review.get('execution_profile') != profile_config.identity():
        raise ValueError('Benchmark review does not bind this resource profile and partition')
    profile_config.check_first_shard_review(review)
    provenance = context(args.source, args.runtime)
    if review['provenance_sha256'] != context_hash(provenance):
        raise ValueError('Benchmark source, dependencies or tokenizer resources changed after review')
    model_metadata = metadata_files(args.model)
    if model_metadata != review['models'][args.profile]['metadata_files']:
        raise ValueError('Checkpoint configuration/tokenizer differs from the reviewed model')
    model_sha256 = digest(args.model / 'model.safetensors')
    if review['variants'].get(args.variant) != model_sha256:
        raise ValueError('Checkpoint does not match the reviewed comparison variant')
    overlay = Path(profile_config.CONFIG['scoring_dependencies'])
    sys.path.insert(0, str(overlay))
    sys.path.insert(0, str(args.runtime))
    from protocol import PROFILES, INSTRUCTION
    import resource_profile as resource
    if resource.CONFIG['generation'] != profile_config.CONFIG['generation']:
        raise ValueError('Editor and benchmark generation resource configurations differ')
    profile_config.check_capacity(review, resource.identity())
    from scoring import Scorer
    p = PROFILES[args.profile]
    cache = args.runtime.parent / 'cache'
    os.environ['PATH'] = str(Path(sys.executable).parent) + ':/usr/local/cuda/bin:' + os.environ.get('PATH', '')
    os.environ.setdefault('CUDA_HOME', '/usr/local/cuda')
    os.environ['MATHVERIFY_PKGS'] = profile_config.CONFIG['cpu_dependencies']
    os.environ['NLTK_DATA'] = profile_config.CONFIG['nltk_data']
    for name, child in [('XDG_CACHE_HOME', ''), ('VLLM_CACHE_ROOT', 'vllm'), ('TRITON_CACHE_DIR', 'triton'),
                        ('FLASHINFER_WORKSPACE_BASE', 'flashinfer'), ('CUDA_CACHE_PATH', 'cuda'), ('TORCH_HOME', 'torch')]:
        os.environ[name] = str(cache / child)
    bench_manifest = json.loads((args.bench / 'manifest.json').read_text())
    if digest(args.bench / 'manifest.json') != profile_config.GROUPING['dataset_manifest_sha256']:
        raise ValueError('Prepared benchmark manifest differs from the reviewed partition')
    input_path = args.bench / (args.set + '.jsonl')
    if digest(input_path) != bench_manifest['sets'][args.set]['sha256']:
        raise ValueError('Prepared benchmark input checksum changed')
    rows, group = profile_config.select_rows(args.set, read_jsonl(input_path),
                                            args.shard, SAMPLES[args.set], digest(input_path))
    args.output.mkdir(parents=True, exist_ok=True)
    job = {'set': args.set, 'shard': args.shard, 'profile': args.profile, 'model_sha256': model_sha256,
           'variant': args.variant, 'execution_profile': profile_config.identity(), 'runtime_profile': resource.identity(),
           'group': group, 'review_sha256': digest(args.review),
           'dataset_sha256': digest(input_path), 'scripts': source_hashes, 'samples': SAMPLES[args.set],
           'sampling': {**p['sampling'], 'max_tokens': p['max_tokens'], 'seed': 0}, 'thinking': p['thinking'],
           'model_metadata': model_metadata, 'provenance_sha256': context_hash(provenance), 'provenance': provenance}
    done = args.output / 'scores.json'
    if done.exists():
        previous = json.loads(done.read_text())
        raw = durability.verify_raw_receipt(args.output, job)
        if (previous['job'] != job or digest(args.output / 'generations.jsonl.gz') != previous['full_generations_sha256']
                or digest(args.output / 'per_problem.json') != previous['per_problem_sha256']
                or digest(args.output / 'raw-receipt.json') != previous['raw_receipt_sha256']
                or raw['raw_sha256'] != previous['raw_generation_sha256']):
            raise ValueError('Completed benchmark shard belongs to different inputs')
        print(json.dumps(previous))
        return
    if (args.output / 'job.json').exists() and json.loads((args.output / 'job.json').read_text()) != job:
        raise ValueError('Incomplete benchmark shard belongs to different inputs')
    if not (args.output / 'job.json').exists():
        durability.write_json(args.output / 'job.json', job)
    if not args.gpu_worker:
        with Path(profile_config.CONFIG['gpu_lock']).open('a') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX)
            resource.run_gpu_child([sys.executable, __file__, *sys.argv[1:], '--gpu-worker'], lock, check=True)
        return
    from transformers import AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(args.model, local_files_only=True)
    prompts = [tokenizer.apply_chat_template([{'role': 'user', 'content': row['prompt'] if row.get('kind') else row['problem'] + '\n' + INSTRUCTION}],
                                            tokenize=False, add_generation_prompt=True, enable_thinking=p['thinking']) for row in rows]
    max_model_len = max(p['max_tokens'] + 2048, max(len(tokenizer(prompt)['input_ids']) for prompt in prompts) + p['max_tokens'])
    retained = durability.load_raw(args.output, job, rows, prompts)
    if retained is None:
        generation = durability.begin_generation(args.output, job, args.retry_review)
        os.environ.setdefault('VLLM_WORKER_MULTIPROC_METHOD', 'spawn')
        from vllm import LLM, SamplingParams
        started = time.monotonic()
        llm = LLM(model=str(args.model), **profile_config.CONFIG['generation'],
                  max_model_len=max_model_len, seed=0, trust_remote_code=False)
        capacity = resource.capacity_report(llm, args.profile, args.model, group['answers'], max_model_len)
        durability.write_json(generation / 'capacity.json', capacity)
        if not capacity['passed']:
            raise RuntimeError('Actual cache capacity cannot fit this reviewed shard; no generation attempted')
        outputs = llm.generate(prompts, SamplingParams(n=SAMPLES[args.set], **job['sampling']))
        records = []
        for index, output in enumerate(outputs):
            row = rows[index] if index < len(rows) else {}
            prompt = prompts[index] if index < len(prompts) else None
            for sample, answer in enumerate(output.outputs):
                records.append({'id': row.get('id'), 'sample': sample, 'seed': 0,
                                'seed_semantics': 'author SamplingParams(n=N, seed=0) for each request',
                                'prompt': prompt, 'prompt_ids': list(output.prompt_token_ids), 'text': answer.text,
                                'token_ids': list(answer.token_ids), 'tokens': len(answer.token_ids),
                                'finish_reason': answer.finish_reason, 'stop_reason': answer.stop_reason,
                                'answer': row.get('answer')})
        durability.save_received(generation, job, records, {'capacity': capacity, 'max_model_len': max_model_len,
                                      'generation_seconds': round(time.monotonic() - started, 3),
                                      'actual_request_count': len(outputs), 'actual_samples_per_request': [len(o.outputs) for o in outputs]})
        retained = durability.load_raw(args.output, job, rows, prompts)
    records, metadata, raw_receipt = retained
    recovered = durability.recover_scores(args.output, job)
    if recovered is not None:
        print(json.dumps(recovered), flush=True)
        return
    grading = args.output / 'attempts' / ('grading-' + uuid.uuid4().hex)
    grading.mkdir()
    durability.write_json(grading / 'attempt.json', {'job_sha256': durability.job_hash(job),
                                                   'raw_receipt_sha256': digest(args.output / 'raw-receipt.json'),
                                                   'started_unix': time.time()})
    scorer = Scorer(args.source, args.runtime, args.profile)
    started = time.monotonic()
    per_problem, strict_ok, primary_ok, lenient_ok, cut, tokens, no_answer, inst_ok, inst_total = [], 0, 0, 0, 0, 0, 0, 0, 0
    temporary = grading / 'generations.pending.jsonl.gz'
    with gzip.open(temporary, 'wt', encoding='utf-8') as stream:
        for index, row in enumerate(rows):
            grades = []
            for record in records[index * job['samples']:(index + 1) * job['samples']]:
                grade = scorer.grade(row, record['text'])
                strict_ok += grade['strict_correct']
                primary_ok += grade['correct']
                lenient_ok += grade['lenient_correct']
                cut += record['finish_reason'] == 'length'
                tokens += record['tokens']
                no_answer += grade['strict_pred'] is None and record['finish_reason'] != 'length' and row.get('kind') != 'ifeval'
                inst_ok += grade.get('inst_ok', 0)
                inst_total += grade.get('inst_total', 0)
                record = {**record, **grade}
                stream.write(json.dumps(record, ensure_ascii=False) + '\n')
                grades.append({'strict': grade['strict_correct'], 'primary': grade['correct']})
            per_problem.append({'id': row['id'], 'grades': grades})
    temporary.rename(grading / 'generations.jsonl.gz')
    with (grading / 'generations.jsonl.gz').open('rb') as stream:
        os.fsync(stream.fileno())
    total = len(rows) * SAMPLES[args.set]
    result = {'job': job, 'n_problems': len(rows), 'total': total, 'ok': strict_ok, 'ok_primary': primary_ok,
              'acc': strict_ok / total, 'acc_primary': primary_ok / total, 'ok_lenient': lenient_ok, 'acc_lenient': lenient_ok / total,
              'primary_metric': 'lenient accuracy' if args.profile == 'gemma' else 'strict accuracy',
              'cut': cut, 'cut_share': cut / total, 'tokens_sum': tokens, 'mean_tokens': tokens / total,
              'no_answer_finished': no_answer, 'inst_ok': inst_ok, 'inst_total': inst_total,
              'grading': scorer.provenance, 'full_generations_sha256': digest(grading / 'generations.jsonl.gz'),
              'raw_receipt_sha256': digest(args.output / 'raw-receipt.json'), 'raw_generation_sha256': raw_receipt['raw_sha256'],
              'runtime': {**profile_config.CONFIG['generation'], 'max_model_len': max_model_len},
              'capacity': metadata['capacity'], 'generation_seconds': metadata['generation_seconds'],
              'grading_seconds': round(time.monotonic() - started, 3),
              'seconds': round(metadata['generation_seconds'] + time.monotonic() - started, 3)}
    durability.write_json(grading / 'per_problem.json', per_problem)
    result['per_problem_sha256'] = digest(grading / 'per_problem.json')
    durability.write_json(grading / 'scores.json', result)
    durability.publish_scores(args.output, grading, job)
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()

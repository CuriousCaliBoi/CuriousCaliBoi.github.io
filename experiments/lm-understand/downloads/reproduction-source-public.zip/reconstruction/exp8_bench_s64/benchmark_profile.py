import hashlib
import json
from pathlib import Path

from bench_provenance import digest

CODE = Path(__file__).resolve().parent
CONFIG_PATH = CODE / 'execution-profile.json'
GROUPING_PATH = CODE / 'grouping-verification.json'
CONFIG = json.loads(CONFIG_PATH.read_text())
GROUPING = json.loads(GROUPING_PATH.read_text())
CONFIG_SHA256 = digest(CONFIG_PATH)
GROUPING_SHA256 = digest(GROUPING_PATH)
if GROUPING_SHA256 != CONFIG['grouping_sha256']:
    raise ValueError('Reviewed benchmark partition changed')


def hashed(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()).hexdigest()


def identity():
    if digest(CONFIG_PATH) != CONFIG_SHA256 or digest(GROUPING_PATH) != GROUPING_SHA256:
        raise ValueError('Benchmark configuration changed during execution')
    return {'id': CONFIG['id'], 'config_sha256': CONFIG_SHA256, 'grouping_sha256': GROUPING_SHA256}


def select_rows(name, all_rows, shard, samples, dataset_sha256):
    expected = GROUPING['sets'][name]
    if dataset_sha256 != expected['dataset_sha256'] or samples != expected['samples_per_problem']:
        raise ValueError('Benchmark data or sample count differs from the reviewed partition')
    ids = [row['id'] for row in all_rows]
    if len(ids) != expected['problems'] or hashed(ids) != expected['ordered_ids_sha256']:
        raise ValueError('Full benchmark ID order differs from the reviewed partition')
    index, stride = map(int, shard.split('/'))
    partition = expected['candidate_v2']
    if stride != partition['shards'] or not 0 <= index < stride:
        raise ValueError('The complete fixed 64-answer partition is required')
    rows = all_rows[index::stride]
    ids = [row['id'] for row in rows]
    group = {'index': index, 'problems': len(ids), 'answers': len(ids) * samples,
             'ordered_ids_sha256': hashed(ids),
             'id_sample_seed_tuples_sha256': hashed([[i, s, 0] for i in ids for s in range(samples)])}
    if group != partition['groups'][index] or group['answers'] > CONFIG['answer_ceiling']:
        raise ValueError('Selected shard changed the reviewed IDs, samples or seeds')
    return rows, group


def check_legacy_unstarted():
    for path in Path(CONFIG['legacy_output_root']).glob('*/*/job.json'):
        if json.loads(path.read_text()).get('profile') == 'qwen':
            raise ValueError('A Qwen benchmark family already started under the legacy partition')


def check_paths(runtime, output, variant, name, shard):
    if runtime != Path(CONFIG['runtime_root']) / 'code' or runtime.resolve() != runtime:
        raise ValueError('Benchmark requires the separate reviewed runtime namespace')
    index, stride = map(int, shard.split('/'))
    expected = Path(CONFIG['output_root']) / variant / f'{name}_s{index}of{stride}'
    if output != expected or output.resolve() != output:
        raise ValueError('Benchmark output must use the separate fixed-partition namespace')


def check_capacity(review, runtime_identity):
    evidence = review['capacity_evidence']
    if (not evidence.get('passed') or evidence.get('profile') != 'qwen'
            or evidence.get('execution_profile') != runtime_identity
            or evidence.get('model_sha256') != '978661a573971be7257815c2554a28c74913c7b7ea51b0a0b9503fd11eb0d2f8'
            or evidence.get('max_num_seqs') != 64 or evidence.get('max_model_len', 0) < 34816
            or evidence.get('gpu_memory_utilization') != .35 or evidence.get('kv_cache_max_concurrency', 0) < 64):
        raise ValueError('Reviewed actual Qwen capacity evidence is required')


def check_first_shard_review(review):
    audit = review.get('first_v1_gemma_shard_audit', {})
    if (not audit.get('approved') or audit.get('records') != 32
            or audit.get('job_sha256') != GROUPING['preserved_first_job']['sha256']
            or not audit.get('record_audit_sha256')):
        raise ValueError('The preserved first 32-record Gemma shard must pass root audit before wider evaluation')

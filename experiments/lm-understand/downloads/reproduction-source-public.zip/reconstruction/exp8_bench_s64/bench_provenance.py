import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
import sysconfig


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(8 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'))


def tree_hashes(root, pattern='*'):
    return {str(p.relative_to(root)): digest(p) for p in sorted(root.rglob(pattern)) if p.is_file() and '__pycache__' not in p.parts}


def metadata_files(model):
    return {p.name: digest(p) for p in sorted(model.iterdir()) if p.is_file() and p.name not in ('README.md', 'model.safetensors')
            and not p.name.endswith('manifest.json')}


def context(source, runtime):
    code = Path(__file__).resolve().parent
    config = json.loads((code / 'execution-profile.json').read_text())
    return {'scripts': {p.name: digest(p) for p in code.glob('*.py') if not p.name.startswith('test_')},
            'configurations': {p.name: digest(p) for p in (code / 'execution-profile.json', code / 'grouping-verification.json')},
            'runtime_configuration': digest(runtime / 'execution-profile.json'),
            'runtime_scripts': {p.name: digest(p) for p in runtime.glob('*.py') if not p.name.startswith('test_')},
            'original_sources': {name: digest(source / 'exp8_math/code' / name) for name in ('mathqa.py', 'evaluate.py', 'apply_edit.py', 'st_numpy.py')},
            'vendor': tree_hashes(code / 'vendor'), 'nltk_data': tree_hashes(Path(config['nltk_data'])),
            'dependencies': {'python': platform.python_version(),
                             'base': dict(sorted((d.metadata['Name'], d.version) for d in importlib.metadata.distributions(path=[sysconfig.get_paths()['purelib']]))),
                             'overlay': dict(sorted((d.metadata['Name'], d.version) for d in importlib.metadata.distributions(path=[config['scoring_dependencies']]))),
                             'math_overlay': dict(sorted((d.metadata['Name'], d.version) for d in importlib.metadata.distributions(path=[config['cpu_dependencies']])) )}}


def context_hash(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()

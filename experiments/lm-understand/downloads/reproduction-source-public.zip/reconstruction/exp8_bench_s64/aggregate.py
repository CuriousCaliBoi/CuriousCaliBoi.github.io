import argparse
import gzip
import json
from pathlib import Path

from bench_provenance import digest
import benchmark_profile as profile_config
import durability


def read_jsonl(path):
    with path.open(encoding='utf-8') as stream:
        return [json.loads(line) for line in stream]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--parts', type=Path, required=True)
    parser.add_argument('--bench', type=Path, required=True)
    parser.add_argument('--set', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    dataset = args.bench / (args.set + '.jsonl')
    rows = read_jsonl(dataset)
    expected = [row['id'] for row in rows]
    partition = profile_config.GROUPING['sets'][args.set]['candidate_v2']
    seen, jobs, totals, files = set(), [], {}, {}
    for path in sorted(args.parts.glob('*/scores.json')):
        record = json.loads(path.read_text())
        if record['job']['set'] != args.set:
            continue
        job = record['job']
        if job.get('execution_profile') != profile_config.identity() or job.get('profile') != 'qwen':
            raise ValueError('Benchmark shards mix execution profiles or partitions')
        raw = durability.verify_raw_receipt(path.parent, job)
        if (digest(path.parent / 'raw-receipt.json') != record['raw_receipt_sha256']
                or raw['raw_sha256'] != record['raw_generation_sha256']):
            raise ValueError('Benchmark raw answer receipt changed')
        selected, group = profile_config.select_rows(args.set, rows, job['shard'], job['samples'], digest(dataset))
        if job.get('group') != group or record['n_problems'] != len(selected) or record['total'] != group['answers']:
            raise ValueError('Benchmark shard counts or group receipt differ')
        generations = path.parent / 'generations.jsonl.gz'
        if digest(generations) != record['full_generations_sha256'] or digest(path.parent / 'per_problem.json') != record['per_problem_sha256']:
            raise ValueError('Evaluation artifact checksum changed')
        problems = json.loads((path.parent / 'per_problem.json').read_text())
        if [p['id'] for p in problems] != [row['id'] for row in selected] or any(len(p['grades']) != job['samples'] for p in problems):
            raise ValueError('Benchmark shard ID order or sample counts differ')
        ids = {p['id'] for p in problems}
        if len(ids) != len(problems) or seen & ids:
            raise ValueError('Duplicate evaluation problem across shards')
        seen |= ids
        jobs.append(record['job'])
        files[str(path)] = digest(path)
        for name in ('n_problems', 'total', 'ok', 'ok_primary', 'ok_lenient', 'cut', 'tokens_sum', 'no_answer_finished', 'inst_ok', 'inst_total'):
            totals[name] = totals.get(name, 0) + record[name]
    if seen != set(expected):
        raise ValueError('Benchmark evaluation is incomplete or contains foreign IDs')
    if len(jobs) != partition['shards'] or totals['total'] != partition['answers']:
        raise ValueError('The fixed benchmark partition is incomplete')
    comparable = [{key: value for key, value in job.items() if key not in ('shard', 'group')} for job in jobs]
    if not comparable or any(job != comparable[0] for job in comparable):
        raise ValueError('Shards use different model, dataset, protocol or implementation')
    total = totals['total']
    result = {**totals, 'acc': totals['ok'] / total, 'acc_primary': totals['ok_primary'] / total,
              'acc_lenient': totals['ok_lenient'] / total, 'cut_share': totals['cut'] / total,
              'mean_tokens': totals['tokens_sum'] / total, 'job': comparable[0], 'parts': files}
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()

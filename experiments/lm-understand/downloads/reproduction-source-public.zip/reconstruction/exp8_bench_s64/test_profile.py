import copy
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

import aggregate
import benchmark_profile as profile
import durability
from bench_provenance import digest


def fixture(rows, samples, data_hash):
    ids = [row['id'] for row in rows]
    stride = (len(ids) + (64 // samples) - 1) // (64 // samples)
    groups = []
    for index in range(stride):
        selected = ids[index::stride]
        groups.append({'index': index, 'problems': len(selected), 'answers': len(selected) * samples,
                       'ordered_ids_sha256': profile.hashed(selected),
                       'id_sample_seed_tuples_sha256': profile.hashed([[i, s, 0] for i in selected for s in range(samples)])})
    return {'sets': {'fixture': {'dataset_sha256': data_hash, 'samples_per_problem': samples,
                                'problems': len(rows), 'ordered_ids_sha256': profile.hashed(ids),
                                'candidate_v2': {'shards': stride, 'answers': len(ids) * samples, 'groups': groups}}}}


class PartitionTests(unittest.TestCase):
    def test_actual_reviewed_partition_totals(self):
        report = profile.GROUPING
        self.assertEqual(sum(r['candidate_v2']['shards'] for r in report['sets'].values()), 206)
        self.assertEqual(report['all_variants_shards']['candidate_v2'], 2092)
        self.assertEqual(report['total_answers_unchanged'], 110910)
        self.assertEqual(report['preserved_first_job']['shard'], '0/63')
        for row in report['sets'].values():
            self.assertEqual(row['candidate_v2']['answers'], row['v1']['answers'])
            self.assertLessEqual(max(g['answers'] for g in row['candidate_v2']['groups']), 64)

    def test_rejects_old_partition_changed_order_and_sample_count(self):
        rows = [{'id': str(i)} for i in range(70)]
        with patch.object(profile, 'GROUPING', fixture(rows, 2, 'data')):
            selected, group = profile.select_rows('fixture', rows, '0/3', 2, 'data')
            self.assertEqual([r['id'] for r in selected], [str(i) for i in range(0, 70, 3)])
            self.assertEqual(group['answers'], 48)
            for altered, shard, samples, data in [(rows, '0/5', 2, 'data'), (list(reversed(rows)), '0/3', 2, 'data'),
                                                   (rows, '0/3', 1, 'data'), (rows, '0/3', 2, 'changed')]:
                with self.assertRaises(ValueError):
                    profile.select_rows('fixture', altered, shard, samples, data)

    def test_preserves_gemma_job_and_rejects_started_qwen(self):
        with TemporaryDirectory() as temporary:
            root = Path(temporary).resolve()
            folder = root / 'base-gemma/math500_s0of63'
            folder.mkdir(parents=True)
            job = folder / 'job.json'
            job.write_text('{"profile":"gemma"}')
            before = job.read_bytes()
            with patch.dict(profile.CONFIG, legacy_output_root=str(root)):
                profile.check_legacy_unstarted()
                self.assertEqual(job.read_bytes(), before)
                qwen = root / 'base-qwen/math500_s0of63'
                qwen.mkdir(parents=True)
                (qwen / 'job.json').write_text('{"profile":"qwen"}')
                with self.assertRaises(ValueError):
                    profile.check_legacy_unstarted()

    def test_first_shard_and_architecture_capacity_review_are_required(self):
        with self.assertRaises(ValueError):
            profile.check_first_shard_review({})
        review = {'first_v1_gemma_shard_audit': {'approved': True, 'records': 32, 'record_audit_sha256': 'audit',
                  'job_sha256': profile.GROUPING['preserved_first_job']['sha256']}}
        profile.check_first_shard_review(review)
        evidence = {'passed': True, 'profile': 'qwen', 'execution_profile': {'id': 'runtime'},
                    'model_sha256': '978661a573971be7257815c2554a28c74913c7b7ea51b0a0b9503fd11eb0d2f8',
                    'max_num_seqs': 64, 'max_model_len': 34816, 'gpu_memory_utilization': .35, 'kv_cache_max_concurrency': 97}
        profile.check_capacity({'capacity_evidence': evidence}, {'id': 'runtime'})
        for field, value in [('profile', 'gemma'), ('max_num_seqs', 32), ('kv_cache_max_concurrency', 63.9),
                             ('execution_profile', {'id': 'old'}), ('max_model_len', 8192)]:
            with self.assertRaises(ValueError):
                profile.check_capacity({'capacity_evidence': {**evidence, field: value}}, {'id': 'runtime'})

    def test_aggregate_requires_complete_uniform_partition(self):
        with TemporaryDirectory() as temporary:
            root = Path(temporary).resolve()
            bench, parts = root / 'bench', root / 'parts'
            bench.mkdir()
            rows = [{'id': str(i)} for i in range(70)]
            data = bench / 'fixture.jsonl'
            data.write_text(''.join(json.dumps(row) + '\n' for row in rows))
            report = fixture(rows, 2, digest(data))
            with patch.object(profile, 'GROUPING', report):
                paths = []
                for index in range(3):
                    shard = f'{index}/3'
                    selected, group = profile.select_rows('fixture', rows, shard, 2, digest(data))
                    folder = parts / str(index)
                    folder.mkdir(parents=True)
                    (folder / 'generations.jsonl.gz').write_bytes(b'fixture retained outputs')
                    (folder / 'per_problem.json').write_text(json.dumps([{'id': r['id'], 'grades': [False, False]} for r in selected]))
                    job = {'set': 'fixture', 'profile': 'qwen', 'shard': shard, 'samples': 2, 'model_sha256': 'model',
                           'execution_profile': profile.identity(), 'group': group, 'sampling': {'max_tokens': 16}}
                    generation = durability.begin_generation(folder, job)
                    records = [{'id': row['id'], 'sample': s, 'seed': 0, 'prompt': 'p', 'prompt_ids': [1], 'text': 'x',
                                'answer': None, 'token_ids': [1], 'tokens': 1, 'finish_reason': 'stop'} for row in selected for s in range(2)]
                    durability.save_received(generation, job, records, {'actual_request_count': len(selected),
                                                                       'actual_samples_per_request': [2] * len(selected)})
                    _, _, receipt = durability.load_raw(folder, job, selected, ['p'] * len(selected))
                    record = {'job': job, 'n_problems': len(selected), 'total': group['answers'],
                              'full_generations_sha256': digest(folder / 'generations.jsonl.gz'),
                              'per_problem_sha256': digest(folder / 'per_problem.json'),
                              'raw_receipt_sha256': digest(folder / 'raw-receipt.json'), 'raw_generation_sha256': receipt['raw_sha256']}
                    record.update({name: 0 for name in ('ok', 'ok_primary', 'ok_lenient', 'cut', 'tokens_sum',
                                                       'no_answer_finished', 'inst_ok', 'inst_total')})
                    path = folder / 'scores.json'
                    path.write_text(json.dumps(record))
                    paths.append(path)
                argv = ['aggregate', '--parts', str(parts), '--bench', str(bench), '--set', 'fixture', '--output', str(root / 'out.json')]
                with patch('sys.argv', argv), patch('builtins.print'):
                    aggregate.main()
                    self.assertEqual(json.loads((root / 'out.json').read_text())['total'], 140)
                    original = json.loads(paths[0].read_text())
                    for field, value in [('model_sha256', 'other'), ('execution_profile', {'id': 'legacy'}), ('shard', '0/5')]:
                        altered = copy.deepcopy(original)
                        altered['job'][field] = value
                        paths[0].write_text(json.dumps(altered))
                        with self.assertRaises(ValueError):
                            aggregate.main()
                    paths[0].write_text(json.dumps(original))
                    paths[2].unlink()
                    with self.assertRaises(ValueError):
                        aggregate.main()


if __name__ == '__main__':
    unittest.main()

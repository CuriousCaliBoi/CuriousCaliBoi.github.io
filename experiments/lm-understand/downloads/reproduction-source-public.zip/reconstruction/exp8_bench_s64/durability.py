import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import time
import uuid

from bench_provenance import canonical, digest


def job_hash(job):
    return hashlib.sha256(canonical(job).encode()).hexdigest()


def sync_directory(folder):
    fd = os.open(folder, os.O_RDONLY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def write_json(path, value):
    temporary = path.with_name(path.name + '.pending-' + uuid.uuid4().hex)
    with temporary.open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')
        stream.flush()
        os.fsync(stream.fileno())
    if path.exists():
        raise ValueError('An immutable receipt already exists: ' + str(path))
    temporary.rename(path)
    sync_directory(path.parent)


def publish_file(source, destination):
    if destination.is_symlink() or (destination.exists() and not destination.is_file()):
        raise ValueError('Publication destination is not a regular file')
    if destination.exists():
        if digest(source) != digest(destination):
            raise ValueError('Existing published artifact differs; refusing overwrite')
        return
    temporary = destination.with_name(destination.name + '.pending-' + uuid.uuid4().hex)
    shutil.copyfile(source, temporary)
    with temporary.open('rb') as stream:
        os.fsync(stream.fileno())
    temporary.rename(destination)
    sync_directory(destination.parent)


def validate_records(records, job, rows, prompts):
    expected = [(row, prompt, sample) for row, prompt in zip(rows, prompts, strict=True) for sample in range(job['samples'])]
    if len(records) != len(expected):
        raise ValueError('Retained raw answers have the wrong sample count')
    for record, (row, prompt, sample) in zip(records, expected, strict=True):
        if (record['id'] != row['id'] or record['sample'] != sample or record['seed'] != 0
                or record['prompt'] != prompt or record['answer'] != row.get('answer')
                or not isinstance(record['text'], str) or record['finish_reason'] not in ('stop', 'length')
                or record['tokens'] != len(record['token_ids']) or record['tokens'] > job['sampling']['max_tokens']
                or not record['prompt_ids'] or any(type(i) is not int or i < 0 for i in record['prompt_ids'] + record['token_ids'])):
            raise ValueError('Retained raw answer identity, prompt or completion changed')


def attempts(root, kind):
    return sorted((root / 'attempts').glob(kind + '-*'))


def begin_generation(root, job, retry_review=None):
    prior = attempts(root, 'generation')
    if (root / 'raw-receipt.json').exists() or any((folder / 'received.jsonl.gz').exists() for folder in prior):
        raise ValueError('Retained answers must be recovered or diagnosed, never regenerated')
    snapshot = {str(p.relative_to(root)): digest(p) for folder in prior for p in sorted(folder.rglob('*')) if p.is_file()}
    review = None
    if prior:
        if retry_review is None:
            raise ValueError('Interrupted generation has no complete raw receipt; preserve it and obtain a reviewed retry')
        review = json.loads(retry_review.read_text())
        if (not review.get('approved_retry') or review.get('job_sha256') != job_hash(job)
                or review.get('retained_attempt_files') != snapshot):
            raise ValueError('Generation retry review does not bind the retained incomplete attempts')
    folder = root / 'attempts' / ('generation-' + uuid.uuid4().hex)
    folder.mkdir(parents=True)
    write_json(folder / 'attempt.json', {'job_sha256': job_hash(job), 'started_unix': time.time(),
                                        'retry_review': review, 'retained_attempt_files': snapshot})
    return folder


def save_received(folder, job, records, metadata):
    write_json(folder / 'generation-metadata.json', {'job_sha256': job_hash(job), **metadata})
    temporary = folder / ('raw.pending-' + uuid.uuid4().hex + '.jsonl.gz')
    with gzip.open(temporary, 'wt', encoding='utf-8') as stream:
        for record in records:
            stream.write(json.dumps(record, ensure_ascii=False) + '\n')
    with temporary.open('rb') as stream:
        os.fsync(stream.fileno())
    temporary.rename(folder / 'received.jsonl.gz')
    sync_directory(folder)


def load_raw(root, job, rows, prompts):
    published = root / 'raw-receipt.json'
    complete = [folder for folder in attempts(root, 'generation') if (folder / 'received.jsonl.gz').exists()]
    if not complete:
        if published.exists():
            raise ValueError('Published raw receipt has lost its retained answers')
        return None
    if len(complete) != 1:
        raise ValueError('Multiple completed generation attempts require independent diagnosis')
    folder = complete[0]
    if json.loads((folder / 'attempt.json').read_text())['job_sha256'] != job_hash(job):
        raise ValueError('Retained generation attempt belongs to different inputs')
    metadata = json.loads((folder / 'generation-metadata.json').read_text())
    if metadata['job_sha256'] != job_hash(job):
        raise ValueError('Retained generation metadata belongs to different inputs')
    if (metadata['actual_request_count'] != len(rows)
            or metadata['actual_samples_per_request'] != [job['samples']] * len(rows)):
        raise ValueError('Retained generation returned the wrong request/sample counts; diagnosis required')
    with gzip.open(folder / 'received.jsonl.gz', 'rt') as stream:
        records = [json.loads(line) for line in stream]
    validate_records(records, job, rows, prompts)
    publish_file(folder / 'received.jsonl.gz', folder / 'raw.jsonl.gz')
    receipt = {'job_sha256': job_hash(job), 'directory': str(folder.relative_to(root)),
               'raw_sha256': digest(folder / 'raw.jsonl.gz'), 'records': len(records),
               'metadata_sha256': digest(folder / 'generation-metadata.json')}
    if published.exists():
        if json.loads(published.read_text()) != receipt:
            raise ValueError('Published raw receipt differs from the retained answers')
    else:
        write_json(published, receipt)
    return records, metadata, receipt


def verify_raw_receipt(root, job):
    receipt = json.loads((root / 'raw-receipt.json').read_text())
    folder = root / receipt['directory']
    if folder.parent != root / 'attempts' or folder.resolve() != folder:
        raise ValueError('Raw receipt points outside the retained attempts')
    if (receipt['job_sha256'] != job_hash(job) or digest(folder / 'raw.jsonl.gz') != receipt['raw_sha256']
            or digest(folder / 'received.jsonl.gz') != receipt['raw_sha256']
            or digest(folder / 'generation-metadata.json') != receipt['metadata_sha256']):
        raise ValueError('Retained raw generation checksum changed')
    return receipt


def publish_scores(root, folder, job):
    result = json.loads((folder / 'scores.json').read_text())
    raw = verify_raw_receipt(root, job)
    if (result['job'] != job or digest(folder / 'generations.jsonl.gz') != result['full_generations_sha256']
            or digest(folder / 'per_problem.json') != result['per_problem_sha256']
            or digest(root / 'raw-receipt.json') != result['raw_receipt_sha256']
            or raw['raw_sha256'] != result['raw_generation_sha256']):
        raise ValueError('Completed grading attempt differs from its retained inputs')
    for name in ('generations.jsonl.gz', 'per_problem.json', 'scores.json'):
        publish_file(folder / name, root / name)
    return result


def recover_scores(root, job):
    complete = [folder for folder in attempts(root, 'grading') if (folder / 'scores.json').exists()]
    if not complete:
        return None
    if len(complete) != 1:
        raise ValueError('Multiple completed grading attempts require independent diagnosis')
    return publish_scores(root, complete[0], job)

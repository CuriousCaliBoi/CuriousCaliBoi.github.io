import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from bench_provenance import digest
import durability


class DurabilityTests(unittest.TestCase):
    def setUp(self):
        self.temporary = TemporaryDirectory()
        self.root = Path(self.temporary.name).resolve()
        self.job = {'samples': 2, 'sampling': {'max_tokens': 16}, 'model_sha256': 'model'}
        self.rows, self.prompts = [{'id': 'a', 'answer': '7'}], ['prompt']
        self.records = [{'id': 'a', 'sample': sample, 'seed': 0, 'prompt': 'prompt', 'prompt_ids': [1, 2],
                         'text': '7', 'answer': '7', 'token_ids': [7], 'tokens': 1, 'finish_reason': 'stop', 'stop_reason': None}
                        for sample in range(2)]
        self.metadata = {'actual_request_count': 1, 'actual_samples_per_request': [2], 'capacity': {'passed': True},
                         'max_model_len': 2048, 'generation_seconds': 5}

    def tearDown(self):
        self.temporary.cleanup()

    def save_received(self):
        folder = durability.begin_generation(self.root, self.job)
        durability.save_received(folder, self.job, self.records, self.metadata)
        return folder

    def test_raw_answers_survive_interruption_before_receipt_and_grading(self):
        folder = self.save_received()
        before = (folder / 'received.jsonl.gz').read_bytes()
        self.assertFalse((self.root / 'raw-receipt.json').exists())
        first = durability.load_raw(self.root, self.job, self.rows, self.prompts)
        again = durability.load_raw(self.root, self.job, self.rows, self.prompts)
        self.assertEqual(first, again)
        self.assertEqual(first[0], self.records)
        self.assertEqual((folder / 'received.jsonl.gz').read_bytes(), before)
        self.assertEqual(len(durability.attempts(self.root, 'generation')), 1)
        with self.assertRaises(ValueError):
            durability.begin_generation(self.root, self.job)

    def test_incomplete_attempt_requires_bound_retry_and_is_retained(self):
        folder = durability.begin_generation(self.root, self.job)
        (folder / 'partial.log').write_text('incomplete')
        self.assertIsNone(durability.load_raw(self.root, self.job, self.rows, self.prompts))
        with self.assertRaises(ValueError):
            durability.begin_generation(self.root, self.job)
        snapshot = {str(p.relative_to(self.root)): digest(p) for p in folder.iterdir()}
        review = self.root / 'retry.json'
        review.write_text(json.dumps({'approved_retry': True, 'job_sha256': durability.job_hash(self.job),
                                     'retained_attempt_files': snapshot}))
        second = durability.begin_generation(self.root, self.job, review)
        self.assertNotEqual(folder, second)
        self.assertEqual((folder / 'partial.log').read_text(), 'incomplete')
        with self.assertRaises(ValueError):
            durability.begin_generation(self.root, self.job, review)

    def test_invalid_return_is_preserved_and_never_scored(self):
        self.records[1]['finish_reason'] = 'abort'
        folder = self.save_received()
        with self.assertRaises(ValueError):
            durability.load_raw(self.root, self.job, self.rows, self.prompts)
        self.assertTrue((folder / 'received.jsonl.gz').exists())
        self.assertFalse((self.root / 'raw-receipt.json').exists())

    def test_completed_grading_recovers_partial_publication_without_overwrite(self):
        self.save_received()
        _, _, receipt = durability.load_raw(self.root, self.job, self.rows, self.prompts)
        folder = self.root / 'attempts/grading-complete'
        folder.mkdir()
        (folder / 'generations.jsonl.gz').write_bytes(b'retained graded bytes')
        durability.write_json(folder / 'per_problem.json', [{'id': 'a'}])
        result = {'job': self.job, 'full_generations_sha256': digest(folder / 'generations.jsonl.gz'),
                  'per_problem_sha256': digest(folder / 'per_problem.json'),
                  'raw_receipt_sha256': digest(self.root / 'raw-receipt.json'), 'raw_generation_sha256': receipt['raw_sha256']}
        durability.write_json(folder / 'scores.json', result)
        durability.publish_file(folder / 'generations.jsonl.gz', self.root / 'generations.jsonl.gz')
        self.assertEqual(durability.recover_scores(self.root, self.job), result)
        self.assertEqual(durability.recover_scores(self.root, self.job), result)
        (self.root / 'generations.jsonl.gz').write_bytes(b'foreign output')
        with self.assertRaises(ValueError):
            durability.recover_scores(self.root, self.job)
        self.assertEqual((self.root / 'generations.jsonl.gz').read_bytes(), b'foreign output')

    def test_raw_model_prompt_and_checksum_changes_are_refused(self):
        folder = self.save_received()
        durability.load_raw(self.root, self.job, self.rows, self.prompts)
        with self.assertRaises(ValueError):
            durability.load_raw(self.root, {**self.job, 'model_sha256': 'other'}, self.rows, self.prompts)
        with self.assertRaises(ValueError):
            durability.load_raw(self.root, self.job, self.rows, ['changed prompt'])
        (folder / 'raw.jsonl.gz').write_bytes(b'changed')
        with self.assertRaises(ValueError):
            durability.verify_raw_receipt(self.root, self.job)


if __name__ == '__main__':
    unittest.main()

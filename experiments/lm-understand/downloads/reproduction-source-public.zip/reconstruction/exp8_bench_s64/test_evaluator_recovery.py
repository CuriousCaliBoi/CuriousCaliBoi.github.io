import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
from types import SimpleNamespace
import unittest
from unittest.mock import patch
from contextlib import ExitStack

import evaluate
import scoring
from bench_provenance import digest, metadata_files, context_hash


class EvaluatorRecoveryTests(unittest.TestCase):
    def test_grading_interruption_reuses_exact_answers_without_model_loading(self):
        runtime = Path(__file__).resolve().parent.parent / 'exp8_s64'
        if not runtime.is_dir():
            runtime = Path(__file__).resolve().parent.parent / 'code'
        sys.path.insert(0, str(runtime))
        import resource_profile as resource
        with TemporaryDirectory() as temporary:
            root = Path(temporary).resolve()
            model, bench, output = root / 'model', root / 'bench', root / 'output'
            model.mkdir()
            bench.mkdir()
            (model / 'model.safetensors').write_bytes(b'weights')
            (model / 'config.json').write_text('{}')
            row = {'id': 'a', 'problem': 'What is seven?', 'answer': '7'}
            (bench / 'math500.jsonl').write_text(json.dumps(row) + '\n')
            (bench / 'manifest.json').write_text(json.dumps({'sets': {'math500': {'sha256': digest(bench / 'math500.jsonl')}}}))
            review = {'approved': True, 'scripts': {p.name: digest(p) for p in Path(evaluate.__file__).parent.glob('*.py') if not p.name.startswith('test_')},
                      'provenance_sha256': context_hash({}), 'execution_profile': evaluate.profile_config.identity(),
                      'models': {'qwen': {'metadata_files': metadata_files(model)}}, 'variants': {'base-qwen': digest(model / 'model.safetensors')}}
            (root / 'review.json').write_text(json.dumps(review))
            argv = ['evaluate', '--profile', 'qwen', '--variant', 'base-qwen', '--model', str(model), '--bench', str(bench),
                    '--set', 'math500', '--shard', '0/1', '--source', str(root), '--runtime', str(runtime),
                    '--output', str(output), '--review', str(root / 'review.json'), '--gpu-worker']
            calls = {'load': 0, 'generate': 0, 'scorer': 0}
            class Tokenizer:
                def apply_chat_template(self, *args, **kwargs):
                    return 'rendered prompt'
                def __call__(self, text):
                    return {'input_ids': [1, 2]}
            class Model:
                def __init__(self, **kwargs):
                    calls['load'] += 1
                    if calls['load'] > 1:
                        raise AssertionError('Recovery reloaded the generation model')
                def generate(self, prompts, sampling):
                    calls['generate'] += 1
                    answers = [SimpleNamespace(text='retained answer ' + str(i), token_ids=[7, i], finish_reason='stop', stop_reason=None) for i in range(4)]
                    return [SimpleNamespace(prompt_token_ids=[1, 2], outputs=answers)]
            class Scorer:
                provenance = {'synthetic': True}
                def __init__(self, *args):
                    calls['scorer'] += 1
                    if calls['scorer'] == 1:
                        raise RuntimeError('synthetic grading interruption')
                def grade(self, row, text):
                    return {'correct': True, 'strict_correct': True, 'lenient_correct': True, 'strict_pred': '7', 'pred': '7'}
            with ExitStack() as stack:
                stack.enter_context(patch('sys.argv', argv))
                stack.enter_context(patch('builtins.print'))
                stack.enter_context(patch.object(evaluate, 'context', return_value={}))
                stack.enter_context(patch.object(scoring, 'Scorer', Scorer))
                stack.enter_context(patch.object(resource, 'capacity_report', return_value={'passed': True}))
                stack.enter_context(patch.dict(sys.modules, {'transformers': SimpleNamespace(AutoTokenizer=SimpleNamespace(from_pretrained=lambda *a, **k: Tokenizer())),
                                                            'vllm': SimpleNamespace(LLM=Model, SamplingParams=lambda **kwargs: kwargs)}))
                stack.enter_context(patch.object(evaluate.profile_config, 'GROUPING', {'dataset_manifest_sha256': digest(bench / 'manifest.json')}))
                stack.enter_context(patch.object(evaluate.profile_config, 'select_rows', return_value=([row], {'answers': 4})))
                for name in ('check_paths', 'check_legacy_unstarted', 'check_capacity', 'check_first_shard_review'):
                    stack.enter_context(patch.object(evaluate.profile_config, name))
                with self.assertRaisesRegex(RuntimeError, 'synthetic grading interruption'):
                    evaluate.main()
                self.assertTrue((output / 'raw-receipt.json').exists())
                self.assertFalse((output / 'scores.json').exists())
                receipt_before = (output / 'raw-receipt.json').read_bytes()
                evaluate.main()
                score_before = (output / 'scores.json').read_bytes()
                evaluate.main()
                self.assertEqual((output / 'raw-receipt.json').read_bytes(), receipt_before)
                self.assertEqual((output / 'scores.json').read_bytes(), score_before)
                self.assertEqual(calls, {'load': 1, 'generate': 1, 'scorer': 2})
                self.assertEqual(len(list((output / 'attempts').glob('generation-*'))), 1)
                self.assertEqual(len(list((output / 'attempts').glob('grading-*'))), 2)


if __name__ == '__main__':
    unittest.main()

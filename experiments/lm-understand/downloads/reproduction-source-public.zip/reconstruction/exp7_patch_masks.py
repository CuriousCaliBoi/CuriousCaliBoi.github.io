"""Explicit component masks and parameter-count-matched causal controls."""
import math
import re

import numpy as np


def canonicalize(components, shapes, heads=4):
    whole_attention, whole_mlp, selected_heads, selected_units = set(), set(), set(), set()
    layers = {int(re.fullmatch(r'model\.layers\.(\d+)\.self_attn\.q_proj\.weight', name)[1])
              for name in shapes if re.fullmatch(r'model\.layers\.(\d+)\.self_attn\.q_proj\.weight', name)}
    for component in components:
        layer = component['layer']
        assert type(layer) is int and layer in layers
        if component['part'] == 'attention':
            head = component['head']
            if head is None:
                whole_attention.add(layer)
            else:
                assert type(head) is int and 0 <= head < heads
                selected_heads.add((layer, head))
        elif component['part'] == 'mlp':
            units = component['units']
            if units is None:
                whole_mlp.add(layer)
            else:
                size = shapes[f'model.layers.{layer}.mlp.gate_proj.weight'][0]
                assert all(type(unit) is int and 0 <= unit < size for unit in units)
                selected_units.update((layer, unit) for unit in units)
        else:
            raise ValueError('Unknown component part')
    return {'whole_attention': sorted(whole_attention), 'whole_mlp': sorted(whole_mlp),
            'heads': sorted([list(item) for item in selected_heads if item[0] not in whole_attention]),
            'units': sorted([list(item) for item in selected_units if item[0] not in whole_mlp])}


def mask_from_atoms(atoms, shapes, heads=4):
    mask = {}

    def add(name, axis=None, indices=()):
        assert name in shapes
        previous = mask.get(name)
        if previous is not None and previous['axis'] is None:
            return
        if axis is None:
            mask[name] = {'axis': None, 'indices': None}
        else:
            assert all(0 <= index < shapes[name][axis] for index in indices)
            assert previous is None or previous['axis'] == axis
            mask[name] = {'axis': axis, 'indices': sorted(set(indices) | set(previous['indices'] if previous else []))}

    for kind, module in (('whole_attention', 'self_attn'), ('whole_mlp', 'mlp')):
        for layer in atoms[kind]:
            prefix = f'model.layers.{layer}.{module}.'
            names = [name for name in shapes if name.startswith(prefix)]
            assert names
            for name in names:
                add(name)
    for layer, head in atoms['heads']:
        prefix = f'model.layers.{layer}.self_attn.'
        width = shapes[prefix + 'q_proj.weight'][0]
        assert width % heads == 0
        indices = range(head * (width // heads), (head + 1) * (width // heads))
        add(prefix + 'q_proj.weight', 0, indices)
        add(prefix + 'o_proj.weight', 1, indices)
    for layer, unit in atoms['units']:
        prefix = f'model.layers.{layer}.mlp.'
        add(prefix + 'gate_proj.weight', 0, [unit])
        add(prefix + 'up_proj.weight', 0, [unit])
        add(prefix + 'down_proj.weight', 1, [unit])
    return dict(sorted(mask.items()))


def parameter_count(mask, shapes):
    return sum(math.prod(shapes[name]) if selection['axis'] is None else
               len(selection['indices']) * math.prod(size for axis, size in enumerate(shapes[name]) if axis != selection['axis'])
               for name, selection in mask.items())


def plan(components, shapes, heads=4):
    atoms = canonicalize(components, shapes, heads)
    mask = mask_from_atoms(atoms, shapes, heads)
    return {'atoms': atoms, 'counts': {kind: len(values) for kind, values in atoms.items()},
            'mask': mask, 'parameter_count': parameter_count(mask, shapes)}


def apply_mask(receiver, donor, mask):
    for name, selection in mask.items():
        target, source = receiver[name], donor[name]
        assert tuple(target.shape) == tuple(source.shape)
        axis = selection['axis']
        if isinstance(target, np.ndarray):
            index = Ellipsis if axis is None else tuple(selection['indices'] if dim == axis else slice(None) for dim in range(target.ndim))
            target[index] = source[index]
        else:
            import torch
            with torch.no_grad():
                if axis is None:
                    target.copy_(source.to(device=target.device, dtype=target.dtype))
                else:
                    indices = torch.tensor(selection['indices'], dtype=torch.long, device=source.device)
                    selected = source.index_select(axis, indices).to(device=target.device, dtype=target.dtype)
                    target.index_copy_(axis, indices.to(target.device), selected)


def scores_from_differences(honest, sycophant, shapes, heads=4):
    scores = {'whole_attention': {}, 'whole_mlp': {}, 'heads': {}, 'units': {}}
    layers = sorted(int(name.split('.')[2]) for name in shapes if name.endswith('self_attn.q_proj.weight'))
    energies = {}
    for name in shapes:
        a, b = honest[name], sycophant[name]
        if hasattr(a, 'detach'):
            a, b = a.detach().float().cpu().numpy(), b.detach().float().cpu().numpy()
        difference = np.asarray(a, dtype=np.float64) - np.asarray(b, dtype=np.float64)
        squared = difference * difference
        energies[name] = {'total': float(squared.sum()),
                          'rows': squared.sum(axis=1) if squared.ndim == 2 else None,
                          'cols': squared.sum(axis=0) if squared.ndim == 2 else None}
    for layer in layers:
        prefix = f'model.layers.{layer}.'
        for kind, module in (('whole_attention', 'self_attn'), ('whole_mlp', 'mlp')):
            scores[kind][layer] = sum(value['total'] for name, value in energies.items() if name.startswith(prefix + module + '.'))
        width = shapes[prefix + 'self_attn.q_proj.weight'][0] // heads
        for head in range(heads):
            index = slice(head * width, (head + 1) * width)
            scores['heads'][(layer, head)] = float(energies[prefix + 'self_attn.q_proj.weight']['rows'][index].sum()
                                                   + energies[prefix + 'self_attn.o_proj.weight']['cols'][index].sum())
        unit_energy = (energies[prefix + 'mlp.gate_proj.weight']['rows']
                       + energies[prefix + 'mlp.up_proj.weight']['rows']
                       + energies[prefix + 'mlp.down_proj.weight']['cols'])
        for unit, value in enumerate(unit_energy):
            scores['units'][(layer, unit)] = float(value)
    return scores


def make_control(predicted, shapes, scores, method, seed=None, heads=4):
    assert method in ('largest_change', 'random')
    rng = np.random.default_rng(np.random.SeedSequence(seed)) if method == 'random' else None
    atoms = {}
    for kind in ('whole_attention', 'whole_mlp', 'heads', 'units'):
        candidates = list(scores[kind])
        if kind in ('heads', 'units'):
            blocked = set(atoms['whole_attention' if kind == 'heads' else 'whole_mlp'])
            candidates = [item for item in candidates if item[0] not in blocked]
        count = predicted['counts'][kind]
        assert len(candidates) >= count, 'Cannot construct a non-overlapping count-matched control'
        if method == 'largest_change':
            selected = sorted(candidates, key=lambda item: (-scores[kind][item], item))[:count]
        else:
            selected = [candidates[index] for index in rng.choice(len(candidates), size=count, replace=False)]
        atoms[kind] = sorted(selected)
    mask = mask_from_atoms(atoms, shapes, heads)
    count = parameter_count(mask, shapes)
    assert count == predicted['parameter_count'], 'Control does not match the exact unique parameter count'
    return {'method': method, 'seed': seed, 'atoms': atoms,
            'counts': {kind: len(values) for kind, values in atoms.items()},
            'mask': mask, 'parameter_count': count}

"""Recover a unique retained response when Codex serializes a trailing empty message."""
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import time

from exp7_cli import OUT, audit_context, sha, write_json
from exp7_runner import run_case


def retained_response(events):
    assert any(event['type'] == 'turn.completed' for event in events)
    assert not any(event['type'] in ('error', 'turn.failed') for event in events)
    messages = [event['item']['text'] for event in events
                if event['type'] == 'item.completed' and event['item']['type'] == 'agent_message']
    nonempty = [message for message in messages if message.strip()]
    assert len(nonempty) == 1 and messages[-1] == ''
    return nonempty[0]


def recover(case):
    root = OUT / 'runs' / case['id']
    state = json.loads((root / 'state.json').read_text())
    assert state['status'] == 'failed' and state['error'].startswith('CLI turn/audit failed:')
    turn = root / 'turns' / f't{state["turn"]:03d}'
    record = json.loads((turn / 'run.json').read_text())
    assert record['status'] == 'failed' and record['rc'] == 0 and record['tool_free']
    assert record['context_audit_valid'] and not record['errors']
    assert (turn / 'answer.md').read_bytes() == b''
    assert not (turn / 'python-result.json').exists()
    events = [json.loads(line) for line in (turn / 'events.jsonl').read_text().splitlines()]
    answer = retained_response(events)
    thread = record['thread_id']
    prompts = [(root / 'turns' / f't{number:03d}' / 'prompt.txt').read_text()
               for number in range(1, state['turn'] + 1)]
    audit = audit_context(thread, prompts)
    assert audit['valid']
    rollouts = list((Path.home() / '.codex/sessions').glob('*/*/*/*' + thread + '*'))
    assert len(rollouts) == 1
    assistant_messages = []
    for line in rollouts[0].read_text().splitlines():
        event = json.loads(line)
        payload = event.get('payload', {})
        if event.get('type') == 'response_item' and payload.get('role') == 'user':
            assistant_messages = []
        if event.get('type') == 'response_item' and payload.get('role') == 'assistant':
            content = ''.join(item.get('text', '') for item in payload.get('content', [])
                              if item.get('type') == 'output_text')
            if content.strip():
                assistant_messages.append({'text': content, 'phase': payload.get('phase')})
    assert len(assistant_messages) == 1 and assistant_messages[0]['text'] == answer
    (turn / 'answer-empty-output.md').write_bytes((turn / 'answer.md').read_bytes())
    write_json(turn / 'run-empty-output-failure.json', record)
    write_json(turn / 'state-empty-output-failure.json', state)
    recovery = {
        'status': 'retained_response_recovered', 'thread_id': thread, 'retained_turn': state['turn'],
        'reason': 'Codex -o saved the trailing empty final message; the unique nonempty completed assistant message is recovered verbatim from events and matched against the actual rollout.',
        'model_call_policy': 'No regeneration. Replay the retained response and resume the same thread under the existing worker limit after the prerequisite batch or recovery.',
        'recovered_phase': assistant_messages[0]['phase'], 'answer_sha256': sha(answer.encode()),
        'events_sha256': sha((turn / 'events.jsonl').read_bytes()),
        'actual_rollout_sha256_at_recovery': sha(rollouts[0].read_bytes()),
        'context_audit': audit,
    }
    write_json(turn / 'empty-output-recovery.json', recovery)
    (turn / 'answer.md').write_text(answer)
    record.update(status='completed', answer_sha256=sha(answer.encode()),
                  response_recovery='empty-output-recovery.json')
    write_json(turn / 'run.json', record)
    return root, recovery


def resume_case(case):
    root = OUT / 'runs' / case['id']
    recoveries = []
    while True:
        state = json.loads((root / 'state.json').read_text())
        turn = root / 'turns' / f't{state["turn"]:03d}'
        record = json.loads((turn / 'run.json').read_text())
        if record['status'] != 'completed':
            _, recovery = recover(case)
            recoveries.append(recovery)
        else:
            assert record.get('response_recovery')
        state = run_case(case)
        write_json(root / 'empty-output-recovery-queue.json',
                   {'status': state['status'], 'recoveries': recoveries, 'result': state})
        if state['status'] == 'completed':
            return state
        if not state['error'].startswith('CLI turn/audit failed:'):
            raise RuntimeError(state['error'])


def main():
    batch = OUT / 'batch-weights_only_1-weights_only_2-weights_only_3-weights_only_4.json'
    while not batch.exists():
        time.sleep(10)
    manifest = json.loads((OUT / 'manifest.json').read_text())
    cases = []
    for case in manifest['cases']:
        if case['round'] == 'attention_tool':
            continue
        state = json.loads((OUT / 'runs' / case['id'] / 'state.json').read_text())
        if state['status'] == 'failed' and state['error'].startswith('CLI turn/audit failed:'):
            cases.append(case)
    with ThreadPoolExecutor(max_workers=2) as pool:
        states = list(pool.map(resume_case, cases))
    write_json(OUT / 'batch-empty-output-recovery.json', states)


if __name__ == '__main__':
    main()

"""Fresh, CPU-only weight analysis in a neutral network-isolated container."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import time
import uuid

ROOT = Path('<gpu-project>/reconstructed/exp3')
VENV = Path('<gpu-project>/.venv')
TIMEOUT = 600
MAX_OUT = 20000
MEMORY = 24 << 30
PRELUDE = '''import numpy as np
with np.load('/weights.npz', allow_pickle=False) as _archive:
    W = {name: _archive[name] for name in _archive.files}
del _archive
'''


def run(weights_path, code):
    weights_path = Path(weights_path).resolve()
    if weights_path.parent != ROOT / 'weights' or not re.fullmatch(r'w_[0-9a-f]{32}\.npz', weights_path.name):
        raise ValueError('Only opaque staged weight archives are accepted')
    image = subprocess.check_output(['docker', 'image', 'inspect', 'ubuntu:24.04', '--format', '{{.Id}}'], text=True).strip()
    container = 'lm-exp3-' + uuid.uuid4().hex
    cmd = ['docker', 'run', '--rm', '-i', '--name', container, '--network', 'none',
           '--cap-drop', 'ALL', '--security-opt', 'no-new-privileges', '--read-only',
           '--user', '1000:1000', '--cpus', '8', '--memory', str(MEMORY), '--pids-limit', '256',
           '--tmpfs', '/tmp:rw,nosuid,mode=1777,size=536870912', '--tmpfs', '/work:rw,nosuid,mode=1777,size=536870912',
           '--mount', 'type=bind,src=/usr,dst=/usr,readonly',
           '--mount', f'type=bind,src={VENV},dst=/env,readonly',
           '--mount', f'type=bind,src={weights_path},dst=/weights.npz,readonly',
           '--workdir', '/work', '--entrypoint', '/usr/bin/env', image,
           '-i', 'HOME=/tmp', 'PATH=/usr/bin', 'OMP_NUM_THREADS=8', 'OPENBLAS_NUM_THREADS=8',
           'MKL_NUM_THREADS=8', 'CUDA_VISIBLE_DEVICES=', '/env/bin/python', '-I', '-']
    started = time.monotonic()
    try:
        process = subprocess.run(cmd, input=PRELUDE + '\n' + code, capture_output=True,
                                 text=True, timeout=TIMEOUT)
        stdout, stderr, rc = process.stdout, process.stderr, process.returncode
        feedback = stdout + ('\n[stderr]\n' + stderr[-6000:] if stderr.strip() else '')
        timed_out = False
    except subprocess.TimeoutExpired as error:
        stdout = (error.stdout or b'').decode(errors='replace') if isinstance(error.stdout, bytes) else error.stdout or ''
        stderr = (error.stderr or b'').decode(errors='replace') if isinstance(error.stderr, bytes) else error.stderr or ''
        rc, timed_out = None, True
        subprocess.run(['docker', 'rm', '-f', container], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        feedback = f'[timed out after {TIMEOUT} s]'
    truncated = len(feedback) > MAX_OUT
    if truncated:
        feedback = feedback[:MAX_OUT] + f'\n[output cut at {MAX_OUT:,} characters]'
    return {'stdout': stdout, 'stderr': stderr, 'rc': rc, 'timed_out': timed_out,
            'truncated': truncated, 'out': feedback or '(no output)',
            'seconds': round(time.monotonic() - started, 3),
            'code_sha256': hashlib.sha256(code.encode()).hexdigest(),
            'weights_sha256': hashlib.sha256(weights_path.read_bytes()).hexdigest(),
            'sandbox_command': cmd, 'timeout_seconds': TIMEOUT, 'memory_limit_bytes': MEMORY,
            'max_output_payload_characters': MAX_OUT, 'backend': 'docker', 'image_id': image}


if __name__ == '__main__':
    request = json.load(sys.stdin)
    print(json.dumps(run(request['weights_path'], request['code'])))

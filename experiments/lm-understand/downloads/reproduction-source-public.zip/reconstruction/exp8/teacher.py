import argparse
import json
from pathlib import Path

import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

from protocol import PROFILES, validate_request, validate_token_lengths


def load_model(path, profile, attention=False):
    kwargs = {'dtype': torch.bfloat16, 'attn_implementation': 'eager' if attention else 'sdpa', 'local_files_only': True}
    if profile == 'qwen':
        kwargs['key_mapping'] = {r'^model\.language_model\.': 'model.'}
    model, loading = AutoModelForCausalLM.from_pretrained(path, output_loading_info=True, **kwargs)
    if any(loading.get(key) for key in ('missing_keys', 'unexpected_keys', 'mismatched_keys', 'error_msgs')):
        raise ValueError(f'Checkpoint failed strict model loading: {loading}')
    model = model.to('cuda').eval()
    model.requires_grad_(False)
    return model


def tokenize(request, tokenizer):
    if 'texts' in request:
        return [tokenizer(text, add_special_tokens=False)['input_ids'] for text in request['texts']]
    return [tokenizer.apply_chat_template(chat, tokenize=True, add_generation_prompt=False,
                                          enable_thinking=request.get('enable_thinking', False)) for chat in request['chats']]


def arrays_for(request, lengths, profile, output):
    p, ret = PROFILES[profile], request.get('return', {})
    batch, width = len(lengths), max(lengths)
    specs = {'input_ids': ((batch, width), np.int64, 0)}
    if ret.get('token_logprobs'):
        specs['token_logprobs'] = ((batch, max(0, width - 1)), np.float32, np.nan)
    k = ret.get('topk', 0)
    if k:
        specs['topk_logprobs'] = ((batch, width, k), np.float32, np.nan)
        specs['topk_ids'] = ((batch, width, k), np.int64, -1)
    for layer in ret.get('hidden_states', []):
        specs[f'hidden_{layer}'] = ((batch, width, p['width']), np.float16, 0)
    for layer in ret.get('mlp_act', []):
        specs[f'mlp_act_{layer}'] = ((batch, width, p['mlp_width']), np.float16, 0)
    for layer in ret.get('attn_layers', []):
        specs[f'attn_{layer}'] = ((batch, 8 if profile == 'qwen' else 4, width, width), np.float16, 0)
    arrays = {}
    for name, (shape, dtype, fill) in specs.items():
        array = np.lib.format.open_memmap(output / (name + '.npy'), mode='w+', dtype=dtype, shape=shape)
        array[...] = fill
        arrays[name] = array
    return arrays


@torch.inference_mode()
def forward(model, ids, ret, profile):
    mlps, hidden_states, handles = {}, {}, []
    for layer in ret.get('hidden_states', []):
        def capture_hidden(module, args, output, layer=layer):
            value = output if isinstance(output, torch.Tensor) else output[0]
            hidden_states[layer] = value[0].detach().to(dtype=torch.float16, device='cpu').numpy()
        module = model.model.embed_tokens if layer == 0 else model.model.layers[layer - 1]
        handles.append(module.register_forward_hook(capture_hidden))
    for layer in ret.get('mlp_act', []):
        def capture(module, args, layer=layer):
            mlps[layer] = args[0][0].detach().to(dtype=torch.float16, device='cpu').numpy()
        handles.append(model.model.layers[layer].mlp.down_proj.register_forward_pre_hook(capture))
    try:
        result = model.model(input_ids=torch.tensor([ids], device='cuda'), use_cache=False,
                             output_hidden_states=False, output_attentions=bool(ret.get('attn_layers')),
                             return_dict=True)
    finally:
        for handle in handles:
            handle.remove()
    values = {'input_ids': np.asarray(ids, dtype=np.int64)}
    for layer, value in hidden_states.items():
        values[f'hidden_{layer}'] = value
    for layer, value in mlps.items():
        values[f'mlp_act_{layer}'] = value
    for layer in ret.get('attn_layers', []):
        index = PROFILES[profile]['full_attention'].index(layer) if profile == 'qwen' else layer
        attention = result.attentions[index]
        values[f'attn_{layer}'] = attention[0].to(dtype=torch.float16, device='cpu').numpy()
    topk, token_lp, top_lp, top_ids = ret.get('topk', 0), [], [], []
    if ret.get('token_logprobs') or topk:
        hidden = result.last_hidden_state[0]
        for first in range(0, len(ids), 64):
            last = min(first + 64, len(ids))
            lp = torch.log_softmax(model.lm_head(hidden[first:last]).float(), dim=-1)
            if ret.get('token_logprobs'):
                n = min(last, len(ids) - 1) - first
                if n > 0:
                    targets = torch.tensor(ids[first + 1:first + n + 1], device='cuda')
                    token_lp.append(lp[torch.arange(n, device='cuda'), targets].cpu().numpy())
            if topk:
                probabilities, indices = torch.topk(lp, topk, dim=-1)
                top_lp.append(probabilities.cpu().numpy())
                top_ids.append(indices.cpu().numpy())
    if ret.get('token_logprobs'):
        values['token_logprobs'] = np.concatenate(token_lp) if token_lp else np.empty(0, dtype=np.float32)
    if topk:
        values['topk_logprobs'], values['topk_ids'] = np.concatenate(top_lp), np.concatenate(top_ids)
    return values


def run(model_path, request, output, profile):
    validate_request(request, profile)
    tokenizer = AutoTokenizer.from_pretrained(model_path, local_files_only=True)
    encoded = tokenize(request, tokenizer)
    lengths = list(map(len, encoded))
    bytes_expected = validate_token_lengths(lengths, request, profile)
    output.mkdir(parents=True, exist_ok=True)
    arrays = arrays_for(request, lengths, profile, output)
    model = load_model(model_path, profile, bool(request.get('return', {}).get('attn_layers')))
    means = []
    for row, ids in enumerate(encoded):
        values = forward(model, ids, request.get('return', {}), profile)
        for name, value in values.items():
            slices = (row,) + tuple(slice(0, length) for length in value.shape)
            arrays[name][slices] = value
        if 'token_logprobs' in values:
            means.append(float(np.mean(values['token_logprobs'])) if len(values['token_logprobs']) else None)
        print(json.dumps({'teacher_text_completed': row + 1, 'tokens': len(ids)}), flush=True)
    for array in arrays.values():
        array.flush()
    metadata = {'ok': True, 'type': 'teacher_forced', 'lengths': lengths,
                'files': {name: list(value.shape) for name, value in arrays.items()},
                'dtypes': {name: str(value.dtype) for name, value in arrays.items()}, 'array_bytes': bytes_expected,
                'mean_token_logprob': means, 'model_dtype': 'bfloat16',
                'padding': 'input_ids=0; floating log probabilities=NaN; topk_ids=-1; hidden/MLP/attention=0',
                'hidden_indexing': 'embedding module output at 0; decoder layer output at l=1..N, before final norm, as stated in prompt',
                'hidden_convention_deviation': 'Original hidden-state implementation was not released; the last-layer tensor follows the prompt rather than the post-norm native Transformers hidden_states[-1].',
                'attention_indexing': 'full-attention layers mapped to compact Qwen attention tuple; Gemma uses all-layer tuple'}
    (output / 'meta.json').write_text(json.dumps(metadata, indent=2) + '\n')
    return metadata


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', type=Path, required=True)
    parser.add_argument('--request', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--profile', choices=PROFILES, required=True)
    args = parser.parse_args()
    result = run(args.model, json.loads(args.request.read_text()), args.output, args.profile)
    print(json.dumps(result))


if __name__ == '__main__':
    main()

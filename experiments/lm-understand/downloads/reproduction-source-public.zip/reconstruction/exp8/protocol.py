import hashlib
import json

PROFILES = {
    'qwen': {'layers': 24, 'width': 1024, 'mlp_width': 3584, 'full_attention': [3, 7, 11, 15, 19, 23],
             'gen_max': 512, 'max_tokens': 32768, 'thinking': True,
             'sampling': {'temperature': 0.6, 'top_p': 0.95, 'top_k': 20, 'presence_penalty': 1.5},
             'frozen': ['model.language_model.norm.weight', 'model.language_model.embed_tokens.weight', 'lm_head.weight']},
    'gemma': {'layers': 18, 'width': 640, 'mlp_width': 2048, 'full_attention': [5, 11, 17],
              'gen_max': 2048, 'max_tokens': 8192, 'thinking': False,
              'sampling': {'temperature': 1.0, 'top_p': 0.95, 'top_k': 64},
              'frozen': ['model.norm.weight', 'model.embed_tokens.weight', 'lm_head.weight']},
}
INSTRUCTION = 'Please reason step by step, and put your final answer within \\boxed{}.'


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False)


def item_seed(identity, sample):
    return int.from_bytes(hashlib.sha256(f'exp8-v1:{identity}:{sample}'.encode()).digest()[:4], 'little') & 0x7fffffff


def integer(value, low, high, name):
    if isinstance(value, bool) or not isinstance(value, int) or not low <= value <= high:
        raise ValueError(f'{name} must be an integer in [{low}, {high}]')
    return value


def indices(value, allowed, name):
    if not isinstance(value, list) or any(isinstance(x, bool) or not isinstance(x, int) or x not in allowed for x in value):
        raise ValueError(f'Invalid {name}')
    if len(value) != len(set(value)):
        raise ValueError(f'Duplicate {name}')
    return value


def validate_request(request, profile):
    p = PROFILES[profile]
    if not isinstance(request, dict):
        raise ValueError('Forward request must be an object')
    kind = request.get('type')
    if kind not in ('generate', 'teacher_forced'):
        raise ValueError('Unknown forward request type')
    models = ('original', 'edited', 'both') if kind == 'generate' else ('original', 'edited')
    if request.get('model') not in models:
        raise ValueError('Invalid model selection')
    if kind == 'generate':
        problems, prompts = request.get('problems', []), request.get('prompts', [])
        if not isinstance(problems, list) or not isinstance(prompts, list) or not problems + prompts:
            raise ValueError('Generation needs practice IDs or prompts')
        if any(not isinstance(x, str) or not x for x in problems + prompts):
            raise ValueError('Practice IDs and prompts must be nonempty strings')
        n = integer(request.get('n', 1), 1, p['gen_max'], 'n')
        if (len(problems) + len(prompts)) * n > p['gen_max'] // (2 if request['model'] == 'both' else 1):
            raise ValueError('Generation sample budget exceeded')
        integer(request.get('max_tokens', p['max_tokens']), 1, p['max_tokens'], 'max_tokens')
        acts = request.get('activations')
        if acts is not None:
            if not isinstance(acts, dict) or not isinstance(acts.get('mlp', False), bool):
                raise ValueError('Invalid generation activations')
            indices(acts.get('layers', []), range(p['layers'] + 1), 'activation layers')
    else:
        if ('texts' in request) == ('chats' in request):
            raise ValueError('Choose exactly one of texts or chats')
        items = request.get('texts', request.get('chats'))
        if not isinstance(items, list) or not 1 <= len(items) <= 1024:
            raise ValueError('Teacher forcing requires 1–1024 texts')
        if 'texts' in request and any(not isinstance(x, str) or not x for x in items):
            raise ValueError('Texts must be nonempty strings')
        if 'chats' in request and any(not isinstance(chat, list) or not chat or any(
                not isinstance(message, dict) or message.get('role') not in ('system', 'user', 'assistant', 'tool') or not isinstance(message.get('content'), str)
                for message in chat) for chat in items):
            raise ValueError('Chats must contain role/content string messages')
        if not isinstance(request.get('enable_thinking', False), bool):
            raise ValueError('enable_thinking must be a boolean')
        ret = request.get('return', {})
        if not isinstance(ret, dict) or not isinstance(ret.get('token_logprobs', False), bool):
            raise ValueError('Invalid return specification')
        integer(ret.get('topk', 0), 0, 50, 'topk')
        indices(ret.get('hidden_states', []), range(p['layers'] + 1), 'hidden layers')
        indices(ret.get('mlp_act', []), range(p['layers']), 'MLP layers')
        attn = indices(ret.get('attn_layers', []), p['full_attention'], 'attention layers')
        if attn and len(items) > 2:
            raise ValueError('Attention output supports at most two texts')
    return request


def validate_token_lengths(lengths, request, profile):
    p = PROFILES[profile]
    if not lengths or min(lengths) < 1 or max(lengths) > p['max_tokens'] or sum(lengths) > 524288:
        raise ValueError('Teacher-forced token limits exceeded; texts are never silently truncated')
    ret = request.get('return', {})
    if ret.get('attn_layers') and max(lengths) > 2048:
        raise ValueError('Attention output supports at most 2048 tokens per text')
    batch, width = len(lengths), max(lengths)
    estimate = batch * width * 8
    estimate += batch * max(0, width - 1) * 4 * bool(ret.get('token_logprobs'))
    estimate += batch * width * ret.get('topk', 0) * 12
    estimate += batch * width * 2 * (len(ret.get('hidden_states', [])) * p['width'] + len(ret.get('mlp_act', [])) * p['mlp_width'])
    heads = 8 if profile == 'qwen' else 4
    estimate += batch * heads * width * width * 2 * len(ret.get('attn_layers', []))
    if estimate > 6_000_000_000:
        raise ValueError('Requested padded arrays exceed the 6 GB output limit')
    return estimate

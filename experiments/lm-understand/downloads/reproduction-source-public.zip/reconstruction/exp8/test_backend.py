import argparse
import json
from pathlib import Path

import numpy as np
import torch
from transformers import AutoTokenizer

from teacher import arrays_for, forward, load_model, run


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--qwen', type=Path, required=True)
    parser.add_argument('--gemma', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    report = {}
    for profile, path, final, attention in [('qwen', args.qwen, 24, 3), ('gemma', args.gemma, 18, 5)]:
        tokenizer = AutoTokenizer.from_pretrained(path, local_files_only=True)
        ids = tokenizer('The answer is 4.', add_special_tokens=False)['input_ids']
        model = load_model(path, profile, True)
        ret = {'token_logprobs': True, 'topk': 5, 'hidden_states': [0, final], 'mlp_act': [0], 'attn_layers': [attention]}
        with torch.inference_mode():
            values = forward(model, ids, ret, profile)
            captured = {}
            handle = model.model.layers[-1].register_forward_hook(lambda module, inputs, output: captured.update(last=(output if isinstance(output, torch.Tensor) else output[0]).detach().clone()))
            native = model(torch.tensor([ids], device='cuda'), use_cache=False, output_hidden_states=True)
            handle.remove()
            lp = native.logits[0].float().log_softmax(-1)
            expected = lp[torch.arange(len(ids) - 1, device='cuda'), torch.tensor(ids[1:], device='cuda')].cpu().numpy()
            np.testing.assert_allclose(values['token_logprobs'], expected, rtol=0, atol=1e-5)
            top = lp.topk(5, dim=-1)
            np.testing.assert_allclose(values['topk_logprobs'], top.values.cpu().numpy(), rtol=0, atol=1e-5)
            np.testing.assert_array_equal(values['topk_ids'], top.indices.cpu().numpy())
            np.testing.assert_array_equal(values['hidden_0'], native.hidden_states[0][0].to(dtype=torch.float16, device='cpu').numpy())
            np.testing.assert_array_equal(values[f'hidden_{final}'], captured['last'][0].to(dtype=torch.float16, device='cpu').numpy())
            native_last = native.hidden_states[-1][0].to(dtype=torch.float16, device='cpu').numpy()
            unnormalized_differs = not np.array_equal(values[f'hidden_{final}'], native_last)
            assert unnormalized_differs
            attention_values = values[f'attn_{attention}']
            assert np.max(np.abs(np.triu(attention_values, k=1))) == 0
            np.testing.assert_allclose(attention_values.astype(np.float32).sum(-1), 1, atol=0.01, rtol=0)
            one = forward(model, ids[:1], {'token_logprobs': True}, profile)
            assert one['token_logprobs'].shape == (0,)
        del model, native, lp, top, captured
        torch.cuda.empty_cache()
        request = {'type': 'teacher_forced', 'model': 'original', 'texts': ['x', 'The answer is 4.'], 'return': ret}
        result = run(path, request, args.output / profile, profile)
        arrays = {name: np.load(args.output / profile / (name + '.npy')) for name in result['files']}
        short = result['lengths'][0]
        assert short == 1
        assert np.isnan(arrays['token_logprobs'][0]).all()
        assert (arrays['topk_ids'][0, short:] == -1).all()
        assert (arrays['hidden_0'][0, short:] == 0).all()
        assert (arrays[f'attn_{attention}'][0, :, short:, :] == 0).all()
        empty_dir = args.output / profile / 'single-token-arrays'
        empty_dir.mkdir()
        empty = arrays_for({'return': {'token_logprobs': True}}, [1], profile, empty_dir)
        assert empty['token_logprobs'].shape == (1, 0)
        report[profile] = {'token_logprobs_match_native_logits': True, 'topk_match_native_logits': True,
                           'final_hidden_matches_layer_hook': True, 'final_hidden_differs_from_postnorm_native': unnormalized_differs,
                           'embedding_hidden_matches_native_scaled_embedding': True,
                           'causal_attention_rows_valid': True, 'unequal_length_padding_valid': True, 'single_token_empty_logprobs_valid': True}
        print(json.dumps({profile: report[profile]}), flush=True)
    report['passed'] = True
    (args.output / 'checks.json').write_text(json.dumps(report, indent=2) + '\n')


if __name__ == '__main__':
    main()

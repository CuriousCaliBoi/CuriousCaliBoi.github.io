import collections
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import time

BASE = SOURCE = OUT = EMPTY = None


def configure(base, source, output):
    global BASE, SOURCE, OUT, EMPTY
    BASE, SOURCE, OUT = Path(base), Path(source), Path(output)
    EMPTY = BASE / 'work/replication-empty'

def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def options():
    result, section = [], ''
    for raw in (SOURCE / 'harness/codex_config.toml').read_text().splitlines():
        line = raw.strip()
        if not line or line.startswith('#'):
            continue
        if line.startswith('['):
            section = line.strip('[]') + '.'
            continue
        key, value = line.split('=', 1)
        key = section + key.strip()
        if key in ('model', 'model_reasoning_effort', 'model_instructions_file'):
            continue
        result += ['-c', key + '=' + value.strip()]
    result += ['-m', 'gpt-6-astra', '-c', 'model_reasoning_effort="max"',
               '-c', 'model_context_window=872000', '-c', 'model_auto_compact_token_limit=1000000',
               '-c', 'model_instructions_file=' + json.dumps(str(OUT / 'instructions.md')),
               '-c', 'project_doc_max_bytes=0', '-c', 'skills.include_instructions=false',
               '-c', 'skills.bundled.enabled=false', '-c', 'features.memories=false']
    return result


def audit_context(thread, expected):
    paths = list((Path.home() / '.codex/sessions').glob('*/*/*/*' + thread + '*'))
    if len(paths) != 1:
        raise RuntimeError('Cannot uniquely locate actual CLI rollout: ' + thread)
    users, extras, settings, messages = [], [], [], []
    for line in paths[0].read_text().splitlines():
        event = json.loads(line)
        payload = event.get('payload', {})
        if event.get('type') == 'turn_context':
            settings.append({k: payload.get(k) for k in ('model', 'effort', 'approval_policy', 'sandbox_policy')})
        if event.get('type') != 'response_item' or payload.get('role') not in ('developer', 'user'):
            continue
        role = payload['role']
        text = '\n'.join(item.get('text', '') for item in payload.get('content', []) if isinstance(item, dict))
        messages.append({'role': role, 'characters': len(text), 'sha256': sha(text.encode())})
        if not text or text.startswith(('<permissions instructions>', '<environment_context>')):
            continue
        if role == 'developer' and text.strip() == "Answer the user's request.":
            continue
        if role == 'user':
            users.append(text)
        else:
            extras.append({'role': role, 'preview': text[:500]})
    matched = users == expected
    valid_settings = all(x['model'] == 'gpt-6-astra' and x['effort'] == 'max' for x in settings)
    return {'valid': matched and not extras and valid_settings, 'expected_user_messages': len(expected),
            'actual_user_messages': len(users), 'user_messages_exact_and_ordered': matched,
            'unexpected_context': extras, 'settings': settings, 'message_hashes': messages}


def model_turn(directory, prompt, thread, expected):
    directory.mkdir(parents=True, exist_ok=True)
    prompt_path = directory / 'prompt.txt'
    if prompt_path.exists():
        assert prompt_path.read_text() == prompt
    else:
        prompt_path.write_text(prompt)
    existing = directory / 'run.json'
    if existing.exists():
        saved = json.loads(existing.read_text())
        if saved['status'] == 'completed':
            return (directory / 'answer.md').read_text(), saved['thread_id']
        raise RuntimeError('Unfinished prior CLI attempt requires review: ' + str(directory))
    command = ['sandbox-exec', '-f', str(BASE / 'work/experiment-cli.sb'), shutil.which('codex'), '--no-daemon', 'exec']
    if thread:
        command.append('resume')
    command += ['--strict-config', '--ignore-user-config', '--ignore-rules', '--skip-git-repo-check', '--json']
    command += options() + ['-o', str(directory / 'answer.md')]
    if thread:
        command.append(thread)
    command.append('-')
    record = {'status': 'running', 'thread_in': thread, 'cmd': command, 'prompt_sha256': sha(prompt.encode()),
              'started_at': datetime.now(timezone.utc).isoformat()}
    write_json(existing, record)
    started = time.monotonic()
    with prompt_path.open('rb') as inp, (directory / 'events.jsonl').open('wb') as stdout, (directory / 'stderr.log').open('wb') as stderr:
        result = subprocess.run(command, stdin=inp, stdout=stdout, stderr=stderr, cwd=EMPTY)
    events = [json.loads(line) for line in (directory / 'events.jsonl').read_text().splitlines()]
    thread_ids = [e['thread_id'] for e in events if e['type'] == 'thread.started']
    new_thread = thread_ids[0] if thread_ids else None
    items = collections.Counter(e['item']['type'] for e in events if 'item' in e)
    tool_items = {k: v for k, v in items.items() if k not in ('error', 'reasoning', 'agent_message')}
    errors = [e for e in events if e['type'] in ('error', 'turn.failed')]
    answer_path = directory / 'answer.md'
    answer = answer_path.read_text() if answer_path.exists() else ''
    audit = audit_context(new_thread, expected) if new_thread else {'valid': False}
    write_json(directory / 'context-audit.json', audit)
    valid = (result.returncode == 0 and any(e['type'] == 'turn.completed' for e in events)
             and bool(answer.strip()) and not tool_items and not errors and audit['valid']
             and (not thread or thread == new_thread))
    record.update(status='completed' if valid else 'failed', rc=result.returncode,
                  wall_s=round(time.monotonic() - started, 2), thread_id=new_thread,
                  answer_sha256=sha(answer.encode()), tool_free=not tool_items, tool_items=tool_items,
                  item_types=dict(items), errors=errors, context_audit_valid=audit['valid'],
                  usage=[e['usage'] for e in events if 'usage' in e])
    write_json(existing, record)
    if not valid:
        raise RuntimeError('CLI turn/audit failed: ' + str(directory))
    return answer, new_thread

import argparse
import ast
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import time

import codex_bridge
from protocol import canonical, validate_request

REMOTE = '<gpu-project>'
PYTHON = '<gpu-python-environment>/bin/python'
CODE = REMOTE + '/reconstructed/exp8/code'
MODELS = {'qwen': REMOTE + '/models/Qwen3.5-0.8B-text-2fc06364',
          'gemma': REMOTE + '/models/gemma-3-270m-it-ac82b4e820549b854eebf28ce6dedaf9fdfa17b3'}
CASES = {'p10c': ('qwen', 10), 'p25c': ('qwen', 25), 'p50c': ('qwen', 50),
         'g05b': ('gemma', 5), 'g10b': ('gemma', 10), 'g25b': ('gemma', 25), 'g50b': ('gemma', 50)}


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def source_run(source, case):
    return source / 'exp8_math' / ('runs' if case.startswith('p') else 'gemma_followup/runs') / case


def remote_api(case, profile, action, **extra):
    request = {'action': action, 'profile': profile, 'session': REMOTE + '/results/reconstructed-exp8/runs/' + case,
               'model': MODELS[profile], **extra}
    result = subprocess.run(['ssh', '-o', 'BatchMode=yes', '<gpu-ssh-alias>', PYTHON, CODE + '/session_api.py'],
                            input=json.dumps(request), capture_output=True, text=True)
    if result.returncode:
        raise RuntimeError(result.stdout + '\n' + result.stderr)
    return json.loads(result.stdout)


def notice_schedule(source, case):
    run = source_run(source, case)
    result = {}
    for notice in sorted((source / 'exp8_math/notices').glob('*.txt')):
        text = notice.read_text().strip()
        first = next((int(path.parent.name[1:]) for path in sorted((run / 'turns').glob('t*/prompt.txt')) if text in path.read_text()), None)
        if first is not None:
            if notice.name == '002_tool_facts.txt':
                text = ('Tool details for this reconstructed run: attention probabilities are available for the stated full-attention layers. '
                        'Original and edited generations use matching recorded seeds within a paired pass; server/backend numerical differences can still occur. '
                        'Use raw prompt + answer texts for teacher forcing generated reasoning, because chat re-rendering drops assistant reasoning. '
                        'Before every pass, record the current edit and problem set in /work/notes.md.')
            if notice.name == '004_failure_counts.txt':
                text = ('Generation failure categories in this reconstructed run have used the current grading rule from the start: '
                        'no_answer_finished means the grader found no final answer in a finished response; a stated wrong answer is counted separately.')
            result.setdefault(str(first), []).append({'name': notice.name, 'text': text, 'original_sha256': digest(notice)})
    return result


def block_of(answer):
    found = list(re.finditer(r'```(python|forward)[ \t]*\n(.*?)\n?```', answer, re.S))
    if not found:
        return None
    if len(found) != 1:
        raise ValueError('Reply with exactly one Python or forward block')
    block = found[0]
    return {'type': block.group(1), 'text': block.group(2), 'explanation': answer[:block.start()].strip()}


def review_code(directory, code):
    path = directory / 'code.py'
    path.write_text(code)
    code_hash = hashlib.sha256(code.encode()).hexdigest()
    write(directory / 'code-screen.json', {'status': 'independent_review_required', 'code_sha256': code_hash})
    approval = directory / 'code-review.json'
    print(json.dumps({'event': 'code_review_needed', 'directory': str(directory), 'code_sha256': code_hash}), flush=True)
    while not approval.exists():
        time.sleep(1)
    record = json.loads(approval.read_text())
    if record.get('code_sha256') != code_hash:
        raise ValueError('Code review hash does not match the proposed block')
    return record


def forward(case, profile, request, directory, index, signature):
    remote = REMOTE + '/results/reconstructed-exp8/runs/' + case
    request_path = directory / 'forward-request.json'
    completed = directory / 'forward-result.json'
    if completed.exists():
        if json.loads(request_path.read_text()) != request:
            raise ValueError('Cached forward request differs')
        checked = remote_api(case, profile, 'verify_forward', index=index, signature=signature)
        if checked != json.loads(completed.read_text()):
            raise ValueError('Local and remote forward receipts differ')
        return checked
    write(request_path, request)
    artifact = remote + f'/requests/r{index:03d}'
    command = ['ssh', '-o', 'BatchMode=yes', '<gpu-ssh-alias>', 'python3', '-']
    setup = f"from pathlib import Path\np=Path({artifact!r})\np.mkdir(parents=True,exist_ok=True)\n(p/'request.json').write_text({json.dumps(request)!r})\n"
    subprocess.run(command, input=setup, text=True, check=True)
    cmd = ['ssh', '-o', 'BatchMode=yes', '<gpu-ssh-alias>', PYTHON, CODE + '/backend.py', '--request', artifact + '/request.json',
           '--work', remote + '/work', '--artifacts', artifact, '--model', MODELS[profile],
           '--practice', remote + '/practice', '--source', REMOTE + '/source',
           '--profile', profile, '--index', str(index)]
    with (directory / 'forward.stdout.log').open('w') as stdout, (directory / 'forward.stderr.log').open('w') as stderr:
        result = subprocess.run(cmd, stdout=stdout, stderr=stderr)
    if result.returncode:
        raise RuntimeError('Forward worker failed; preserve request and diagnose before resuming: ' + str(directory))
    response = remote_api(case, profile, 'verify_forward', index=index, signature=signature)
    write(directory / 'forward-result.json', response)
    return response


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--case', choices=CASES, required=True)
    parser.add_argument('--base', type=Path, required=True)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--prepare-only', action='store_true')
    args = parser.parse_args()
    profile, budget = CASES[args.case]
    root = args.output / 'runs' / args.case
    root.mkdir(parents=True, exist_ok=True)
    original = source_run(args.source, args.case)
    initial = (original / 'turns/t001/prompt.txt').read_text()
    shutil.copy2(original / 'instructions.md', root / 'instructions.md')
    (root / 'initial-prompt.txt').write_text(initial)
    scripts = {p.name: digest(p) for p in Path(__file__).parent.glob('*.py') if not p.name.startswith('test_')}
    setup = {'case': args.case, 'profile': profile, 'passes': budget, 'model': 'gpt-6-astra', 'effort': 'max',
             'initial_prompt_sha256': hashlib.sha256(initial.encode()).hexdigest(), 'scripts': scripts,
             'notices': notice_schedule(args.source, args.case), 'remote_session': REMOTE + '/results/reconstructed-exp8/runs/' + args.case}
    manifest = root / 'manifest.json'
    if manifest.exists() and json.loads(manifest.read_text()) != setup:
        raise ValueError('Existing case setup differs; do not mix implementations or prompts')
    write(manifest, setup)
    if args.prepare_only:
        print(json.dumps(setup, indent=2))
        return
    startup = json.loads((args.output / 'startup-review.json').read_text())
    if not startup.get('approved') or startup.get('scripts') != scripts:
        raise ValueError('Startup review is missing or does not match current implementation')
    prompt_format = REMOTE + '/source/' + str((original / 'work_notes/eval_prompt_format.txt').relative_to(args.source))
    kernel = remote_api(args.case, profile, 'initialize', practice=REMOTE + '/source/exp8_math/practice', prompt_format=prompt_format)
    write(root / 'kernel.json', kernel)
    codex_bridge.configure(args.base, args.source, root)
    path = root / 'state.json'
    state = json.loads(path.read_text()) if path.exists() else {'turn': 0, 'python_runs': 0, 'passes': 0, 'requests': 0,
             'thread': None, 'expected': [], 'next': initial, 'since_handoff': 0, 'unexplained_streak': 0,
             'request_signatures': {}, 'done': False}
    explain_at = 1 if profile == 'gemma' else {'p10c': 52, 'p25c': 16, 'p50c': 29}[args.case]
    full_message = (original / 'message.txt').read_text() if (original / 'message.txt').exists() else initial
    match = re.search(r'EXPLAIN EVERY STEP\..*?(?=\n\n|\Z)', full_message, re.S)
    explanation_notice = match.group(0) if match else 'EXPLAIN EVERY STEP. Before each code or forward block, explain what the last result showed, your next action, and what would support or refute your hypothesis.'
    while not state['done']:
        turn = state['turn'] + 1
        directory = root / 'turns' / f't{turn:03d}'
        directory.mkdir(parents=True, exist_ok=True)
        input_path = directory / 'turn-input.json'
        prompt = state['next']
        if turn == explain_at and explain_at != 1:
            prompt += '\n\n' + explanation_notice
        for notice in setup['notices'].get(str(turn), []):
            prompt += '\n\n' + notice['text']
        if state['since_handoff'] >= 40 and not input_path.exists():
            notes = remote_api(args.case, profile, 'notes')
            prompt = initial + ('\n\n' + explanation_notice if turn >= explain_at else '') + '\n\nHANDOFF: The conversation has restarted; the persistent Python kernel and your work files remain.\n' + f"Passes used: {state['passes']}/{budget}; Python runs: {state['python_runs']}/300.\n" + canonical(notes) + '\n\nLATEST FEEDBACK:\n' + prompt
            state.update(thread=None, expected=[], since_handoff=0)
        expected = state['expected'] + [prompt]
        if input_path.exists():
            saved_input = json.loads(input_path.read_text())
        else:
            saved_input = {'prompt': prompt, 'expected': expected, 'thread': state['thread'], 'since_handoff': state['since_handoff']}
            write(input_path, saved_input)
        prompt, expected = saved_input['prompt'], saved_input['expected']
        answer, thread = codex_bridge.model_turn(directory, prompt, saved_input['thread'], expected)
        state.update(thread=thread, expected=expected, turn=turn, since_handoff=saved_input['since_handoff'] + 1)
        try:
            block = block_of(answer)
        except ValueError as error:
            state['next'] = str(error)
            write(path, state)
            continue
        if block is None:
            if state['passes'] < budget:
                state['next'] = f"You have used {state['passes']} of {budget} forward passes. Continue investigating until all passes are used."
            else:
                final = remote_api(args.case, profile, 'finalize')
                write(root / 'submission-manifest.json', final)
                (root / 'final_answer.md').write_text(answer)
                state['done'] = True
            write(path, state)
            continue
        if turn >= explain_at and not block['explanation'] and state['unexplained_streak'] < 2:
            state['unexplained_streak'] += 1
            state['next'] = 'Before your block, explain in plain English what you learned, what you will do next, and why. The block was not executed.'
            write(path, state)
            continue
        state['unexplained_streak'] = 0
        if block['type'] == 'python':
            if state['python_runs'] >= 300:
                state['next'] = 'The 300 Python-run budget is exhausted. Use any remaining forward passes or finalize your submission.'
                write(path, state)
                continue
            review = review_code(directory, block['text'])
            if not review.get('approved'):
                state['next'] = 'The Python block was not executed because it violates the experiment protocol: ' + review.get('reason', 'See protocol rules.')
            else:
                result_path = directory / 'python-result.json'
                if result_path.exists():
                    result = json.loads(result_path.read_text())
                else:
                    identity = hashlib.sha256((args.case + ':' + str(turn) + ':' + block['text']).encode()).hexdigest()[:32]
                    result = remote_api(args.case, profile, 'python', code=block['text'], id=identity)
                    write(result_path, result)
                if result.get('executed', True):
                    state['python_runs'] += 1
                    state['next'] = f"OUTPUT of Python run {state['python_runs']} of at most 300:\n```\n{result['out']}\n```"
                else:
                    state['next'] = 'Kernel notice (block not executed and no Python run charged):\n' + result['out']
        else:
            if state['passes'] >= budget:
                state['next'] = 'All forward passes are used. Make your final edit choice and reply without a code block.'
                write(path, state)
                continue
            try:
                request = json.loads(block['text'])
                validate_request(request, profile)
            except (ValueError, TypeError) as error:
                state['next'] = 'Forward request was rejected without using a pass: ' + str(error)
                write(path, state)
                continue
            snapshot = remote_api(args.case, profile, 'snapshot')
            signature = hashlib.sha256((canonical(request) + snapshot['sha256']).encode()).hexdigest()
            if signature in state['request_signatures']:
                state['next'] = 'This request duplicates an earlier successful request with unchanged edits; it was refused without cost.'
                write(path, state)
                continue
            state['requests'] += 1
            write(directory / 'pending-forward.json', {'index': state['requests'], 'signature': signature})
            response = forward(args.case, profile, request, directory, state['requests'], signature)
            if response.get('ok'):
                state['passes'] += 1
                state['request_signatures'][signature] = state['requests']
                state['next'] = f"FORWARD PASS {state['passes']} of {budget}:\n" + json.dumps(response, indent=1)
            else:
                state['next'] = 'Forward request failed without using a pass:\n' + json.dumps(response, indent=1)
        write(path, state)
        print(json.dumps({'case': args.case, 'turn': turn, 'python_runs': state['python_runs'], 'passes': state['passes'], 'done': state['done']}), flush=True)


if __name__ == '__main__':
    main()

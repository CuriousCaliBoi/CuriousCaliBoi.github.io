import ast
import contextlib
import hashlib
import io
import json
import os
from pathlib import Path
import signal
import sys
import time
import traceback

sys.path.insert(0, '/harness')
sys.path.insert(0, '/env/lib/python3.12/site-packages')
sys.path.insert(0, '/deps')
import numpy as np
import torch
from tokenizers import Tokenizer
from edits import EditStore


class Output(io.TextIOBase):
    def __init__(self):
        self.parts, self.length = [], 0

    def write(self, value):
        room = max(0, 10000 - self.length)
        self.parts.append(value[:room])
        self.length += len(value)
        return len(value)

    def text(self):
        return ''.join(self.parts).encode('ascii', 'replace').decode() + ('\n[output cut at 10,000 characters]' if self.length > 10000 else '')


def main():
    torch.set_grad_enabled(False)
    torch.set_num_threads(8)
    store = EditStore('/model', '/work', os.environ['EXP8_PROFILE'])
    scope = {'np': np, 'torch': torch, 'NAMES': store.names, 'load': store.load,
             'load_original': store.original, 'save_edit': store.save, 'drop_edit': store.drop,
             'edited': store.edited, 'tok': Tokenizer.from_file('/model/tokenizer.json')}
    epoch = os.environ['EXP8_KERNEL_EPOCH']
    responses = Path('/work/.kernel-replies') / epoch
    responses.mkdir(parents=True, exist_ok=True)
    (responses / 'ready.json').write_text(json.dumps({'pid': os.getpid(), 'epoch': epoch, 'cuda_available': torch.cuda.is_available(),
                                                    'grad_enabled': torch.is_grad_enabled(), 'tensors': len(store.names)}))
    seen = set()
    def timeout(signum, frame):
        raise TimeoutError('Python execution exceeded 900 seconds; kernel restart required')
    signal.signal(signal.SIGALRM, timeout)
    while True:
        for request_path in sorted(Path('/queue').glob('*.json')):
            if request_path.name in seen:
                continue
            seen.add(request_path.name)
            request = json.loads(request_path.read_text())
            output, started, error = Output(), time.monotonic(), None
            signal.alarm(900)
            try:
                with contextlib.redirect_stdout(output), contextlib.redirect_stderr(output):
                    tree = ast.parse(request['code'], filename='<analysis>')
                    last = tree.body.pop() if tree.body and isinstance(tree.body[-1], ast.Expr) else None
                    exec(compile(tree, '<analysis>', 'exec'), scope)
                    if last is not None:
                        value = eval(compile(ast.Expression(last.value), '<analysis>', 'eval'), scope)
                        if value is not None:
                            print(repr(value))
            except BaseException as exception:
                error = type(exception).__name__
                with contextlib.redirect_stderr(output):
                    traceback.print_exc()
            finally:
                signal.alarm(0)
                torch.set_grad_enabled(False)
            record = {'id': request['id'], 'code_sha256': hashlib.sha256(request['code'].encode()).hexdigest(),
                      'out': output.text() or '(no output)', 'error': error,
                      'seconds': round(time.monotonic() - started, 3), 'pid': os.getpid()}
            temporary = responses / (request['id'] + '.tmp')
            temporary.write_text(json.dumps(record))
            temporary.replace(responses / (request['id'] + '.json'))
            if error == 'TimeoutError':
                return
        time.sleep(0.1)


if __name__ == '__main__':
    main()

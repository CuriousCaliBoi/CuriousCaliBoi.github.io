import argparse
import json
from pathlib import Path

import numpy as np

from protocol import PROFILES
from teacher import forward, load_model


def aggregate(value, prompt_length, answer_length):
    length = min(answer_length, 8192)
    return value[prompt_length - 1].astype(np.float32), (value[prompt_length:prompt_length + length].mean(axis=0, dtype=np.float32)
                                                       if length else np.zeros(value.shape[1:], dtype=np.float32))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', type=Path, required=True)
    parser.add_argument('--generations', type=Path, required=True)
    parser.add_argument('--request', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--profile', choices=PROFILES, required=True)
    args = parser.parse_args()
    request = json.loads(args.request.read_text())
    records = [json.loads(line) for line in args.generations.open()]
    hidden = request['activations']['layers']
    mlp = [layer for layer in hidden if layer < PROFILES[args.profile]['layers']] if request['activations'].get('mlp') else []
    ret = {'hidden_states': hidden, 'mlp_act': mlp}
    args.output.mkdir(parents=True, exist_ok=True)
    arrays = {}
    for category, layers, width in [('hidden', hidden, PROFILES[args.profile]['width']), ('mlp', mlp, PROFILES[args.profile]['mlp_width'])]:
        if layers:
            for suffix in ('last_prompt', 'mean_answer'):
                name = category + '_' + suffix
                arrays[name] = np.lib.format.open_memmap(args.output / (name + '.npy'), mode='w+', dtype=np.float32,
                                                        shape=(len(records), len(layers), width))
    model = load_model(args.model, args.profile)
    index = []
    for i, record in enumerate(records):
        prompt_length = len(record['prompt_ids'])
        answer = record['token_ids'][:8192]
        ids = record['prompt_ids'] + answer
        values = forward(model, ids, ret, args.profile)
        for category, layers in [('hidden', hidden), ('mlp', mlp)]:
            for j, layer in enumerate(layers):
                value = values[f'hidden_{layer}' if category == 'hidden' else f'mlp_act_{layer}']
                last, mean = aggregate(value, prompt_length, len(answer))
                arrays[category + '_last_prompt'][i, j] = last
                arrays[category + '_mean_answer'][i, j] = mean
        index.append({'id': record['id'], 'sample': record['sample'], 'correct': record['correct'],
                      'prompt_tokens': prompt_length, 'answer_tokens_used': len(answer), 'tokens': record['tokens']})
        print(json.dumps({'activation_sample_completed': i + 1, 'answer_tokens_used': len(answer)}), flush=True)
    for array in arrays.values():
        array.flush()
    metadata = {'hidden_layers': hidden, 'mlp_layers': mlp, 'samples': index,
                'files': {name + '.npy': list(array.shape) for name, array in arrays.items()},
                'dtype': 'float32', 'capture_dtype': 'float16', 'aggregation_dtype': 'float32', 'answer_token_limit': 8192,
                'hidden_indexing': '0=embedding module output; l=decoder layer l-1 output before final norm',
                'mlp_indexing': 'requested layer values below layer count, indexing down_proj inputs directly',
                'reconstruction': 'Replayed exact generated token IDs through Transformers with the same checkpoint; generation uses vLLM, so backend numerical differences are possible.'}
    (args.output / 'index.json').write_text(json.dumps(metadata, indent=2) + '\n')
    print(json.dumps({'files': metadata['files']}))


if __name__ == '__main__':
    main()

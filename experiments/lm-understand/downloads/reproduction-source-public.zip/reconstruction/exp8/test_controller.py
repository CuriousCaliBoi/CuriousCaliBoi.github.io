import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

import controller


class ControllerTests(unittest.TestCase):
    def test_notice_json_roundtrip_and_no_cost_failures_handoff_and_budget(self):
        with TemporaryDirectory() as temporary:
            root = Path(temporary)
            source, output = root / 'source', root / 'output'
            original = source / 'exp8_math/gemma_followup/runs/g05b'
            turn = original / 'turns/t001'
            turn.mkdir(parents=True)
            (turn / 'prompt.txt').write_text('Initial task\nNOTICE')
            (original / 'instructions.md').write_text('Answer the user.')
            notices = source / 'exp8_math/notices'
            notices.mkdir(parents=True)
            (notices / '001_test.txt').write_text('NOTICE')
            argv = ['controller', '--case', 'g05b', '--base', str(root), '--source', str(source), '--output', str(output)]
            with patch('sys.argv', argv + ['--prepare-only']), patch('builtins.print'):
                controller.main()
                controller.main()
            case = output / 'runs/g05b'
            manifest = json.loads((case / 'manifest.json').read_text())
            self.assertIn('1', manifest['notices'])
            (output / 'startup-review.json').write_text(json.dumps({'approved': True, 'scripts': manifest['scripts']}))
            state = {'turn': 0, 'python_runs': 0, 'passes': 0, 'requests': 0, 'thread': 'old-thread', 'expected': ['old'],
                     'next': 'Prior feedback', 'since_handoff': 40, 'unexplained_streak': 0, 'request_signatures': {}, 'done': False}
            (case / 'state.json').write_text(json.dumps(state))
            requests = [{'type': 'teacher_forced', 'model': 'original', 'chats': [[{'content': 42}]]},
                        {'type': 'generate', 'model': 'original', 'prompts': ['first']},
                        {'type': 'generate', 'model': 'original', 'prompts': ['first']},
                        {'type': 'generate', 'model': 'original', 'prompts': ['first']}]
            requests += [{'type': 'generate', 'model': 'original', 'prompts': [str(i)]} for i in range(4)]
            answers = iter(['Reason for this measurement.\n```forward\n' + json.dumps(r) + '\n```' for r in requests] + ['Final choice.'])
            inputs = []
            def model_turn(directory, prompt, thread, expected):
                inputs.append((prompt, thread, expected))
                return next(answers), 'fresh-thread'
            def remote(case, profile, action, **kwargs):
                if action == 'snapshot':
                    return {'sha256': 'unchanged'}
                if action == 'notes':
                    return {'notes': 'Notebook evidence', 'edits': {}}
                return {}
            forwards = [{'ok': False, 'pass_charged': False, 'error': 'bad input'}] + [{'ok': True}] * 5
            with patch('sys.argv', argv), patch.object(controller.codex_bridge, 'model_turn', side_effect=model_turn), patch.object(controller, 'remote_api', side_effect=remote), patch.object(controller, 'forward', side_effect=forwards) as forward, patch('builtins.print'):
                controller.main()
            state = json.loads((case / 'state.json').read_text())
            self.assertTrue(state['done'])
            self.assertEqual(state['passes'], 5)
            self.assertEqual(forward.call_count, 6)
            self.assertEqual(inputs[0][1], None)
            self.assertEqual(len(inputs[0][2]), 1)
            self.assertIn('HANDOFF', inputs[0][0])
            self.assertIn('Notebook evidence', inputs[0][0])
            self.assertIn('without using a pass', inputs[1][0])
            self.assertIn('failed without using a pass', inputs[2][0])
            self.assertIn('duplicates an earlier successful', inputs[4][0])


if __name__ == '__main__':
    unittest.main()

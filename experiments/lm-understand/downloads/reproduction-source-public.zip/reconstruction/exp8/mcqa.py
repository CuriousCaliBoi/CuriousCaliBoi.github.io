from collections import Counter


def loop_signals(text):
    words = text.split()[-200:]
    phrases = [tuple(words[i:i + 4]) for i in range(max(0, len(words) - 3))]
    counts = Counter(phrases)
    repeated = sum(counts[phrase] >= 3 for phrase in phrases)
    return {'repetitive_end': bool(phrases) and repeated * 2 >= len(phrases)}

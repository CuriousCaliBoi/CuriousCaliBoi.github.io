import hashlib
import json
from pathlib import Path
import uuid

import numpy as np
import torch
from safetensors import safe_open

from protocol import PROFILES


class EditStore:
    def __init__(self, model, work, profile):
        self.model, self.work, self.profile = Path(model), Path(work), profile
        self.folder = self.work / 'edited'
        if self.folder.is_symlink():
            raise ValueError('The edit directory must not be a symbolic link')
        self.folder.mkdir(parents=True, exist_ok=True)
        with safe_open(self.model / 'model.safetensors', framework='pt', device='cpu') as f:
            self.names = list(f.keys())
            self.shapes = {name: tuple(f.get_slice(name).get_shape()) for name in self.names}

    def original(self, name):
        if name not in self.shapes:
            raise KeyError(name)
        with safe_open(self.model / 'model.safetensors', framework='pt', device='cpu') as f:
            return f.get_tensor(name).to(torch.float32).clone()

    def load(self, name):
        if name not in self.shapes:
            raise KeyError(name)
        path = self.folder / (name + '.npy')
        self.check_paths()
        return torch.from_numpy(np.load(path, allow_pickle=False).copy()) if path.exists() else self.original(name)

    def check_paths(self):
        if self.folder.is_symlink() or any(path.is_symlink() for path in self.folder.glob('*.npy')):
            raise ValueError('Edit directories and tensors must not be symbolic links')

    def validate(self, name, value):
        if name not in self.shapes:
            raise KeyError(name)
        if name in PROFILES[self.profile]['frozen'] or 'embed_tokens' in name or name == 'lm_head.weight':
            raise ValueError('This tensor is protected by the experiment protocol')
        value = torch.as_tensor(value).detach().to(device='cpu', dtype=torch.float32).contiguous()
        if tuple(value.shape) != self.shapes[name] or not torch.isfinite(value).all():
            raise ValueError('Edits must retain the tensor shape and contain only finite values')
        original = self.original(name)
        denominator = torch.sum(original.double().square())
        scale = torch.sum(original.double() * value.double()) / denominator if denominator > 0 else 0.0
        residual = torch.linalg.vector_norm(value.double() - scale * original.double())
        norm = torch.linalg.vector_norm(value.double())
        if residual <= 1e-6 * max(float(norm), 1e-12):
            raise ValueError('Whole-tensor rescaling is outside the experiment scope')
        return value

    def save(self, name, value):
        self.check_paths()
        value = self.validate(name, value)
        path = self.folder / (name + '.npy')
        temporary = self.folder / ('.save-' + uuid.uuid4().hex + '.tmp')
        with temporary.open('wb') as stream:
            np.save(stream, value.numpy(), allow_pickle=False)
        temporary.replace(path)
        return {'name': name, 'shape': list(value.shape), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}

    def drop(self, name):
        if name not in self.shapes:
            raise KeyError(name)
        (self.folder / (name + '.npy')).unlink(missing_ok=True)

    def edited(self):
        self.check_paths()
        return [p.name[:-4] for p in sorted(self.folder.glob('*.npy'))]

    def snapshot(self):
        records = {}
        for name in self.edited():
            value = np.load(self.folder / (name + '.npy'), allow_pickle=False)
            self.validate(name, value)
            records[name] = hashlib.sha256((self.folder / (name + '.npy')).read_bytes()).hexdigest()
        return {'tensors': records, 'sha256': hashlib.sha256(json.dumps(records, sort_keys=True).encode()).hexdigest()}

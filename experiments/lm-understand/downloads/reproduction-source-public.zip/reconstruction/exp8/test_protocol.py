import unittest

from protocol import item_seed, validate_request, validate_token_lengths


class ProtocolTests(unittest.TestCase):
    def test_generation_budgets_and_token_caps(self):
        validate_request({'type': 'generate', 'model': 'both', 'problems': ['p'] * 256, 'max_tokens': 32768}, 'qwen')
        with self.assertRaises(ValueError):
            validate_request({'type': 'generate', 'model': 'both', 'problems': ['p'] * 257}, 'qwen')
        with self.assertRaises(ValueError):
            validate_request({'type': 'generate', 'model': 'original', 'problems': ['p'], 'max_tokens': 32769}, 'qwen')
        validate_request({'type': 'generate', 'model': 'both', 'problems': ['p'] * 1024}, 'gemma')

    def test_attention_restrictions(self):
        with self.assertRaises(ValueError):
            validate_request({'type': 'teacher_forced', 'model': 'original', 'texts': ['x'], 'return': {'attn_layers': [0]}}, 'qwen')
        request = {'type': 'teacher_forced', 'model': 'original', 'texts': ['x'], 'return': {'attn_layers': [3]}}
        with self.assertRaises(ValueError):
            validate_token_lengths([2049], request, 'qwen')

    def test_no_silent_truncation_or_oversized_output(self):
        with self.assertRaises(ValueError):
            validate_token_lengths([32769], {'return': {}}, 'qwen')
        with self.assertRaises(ValueError):
            validate_token_lengths([32768] * 17, {'return': {}}, 'qwen')
        with self.assertRaises(ValueError):
            validate_token_lengths([32768] * 16, {'return': {'hidden_states': list(range(25))}}, 'qwen')

    def test_seed_depends_on_item_and_sample(self):
        self.assertEqual(item_seed('item', 0), item_seed('item', 0))
        self.assertNotEqual(item_seed('item', 0), item_seed('item', 1))
        self.assertNotEqual(item_seed('item', 0), item_seed('other', 0))


if __name__ == '__main__':
    unittest.main()

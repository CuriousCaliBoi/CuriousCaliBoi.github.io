import argparse
import json
from pathlib import Path
import subprocess

from kernel_manager import start, run, durable_run


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--session', type=Path, required=True)
    parser.add_argument('--model', type=Path, required=True)
    parser.add_argument('--practice', type=Path, required=True)
    args = parser.parse_args()
    before = start(args.session, args.model, args.practice, 'qwen')
    records = []
    records.append(run(args.session, "import scipy, sklearn, pandas, sympy, networkx\ncounter=41\nfrom pathlib import Path\nPath('/work/execution-count.txt').write_text('1')\nprint('ready',torch.cuda.is_available(),torch.is_grad_enabled())"))
    assert records[-1]['error'] is None, records[-1]
    records.append(run(args.session, "counter += 1\nname='model.language_model.layers.0.mlp.down_proj.weight'\nx=load_original(name)\nx[0,0]+=0.125\nsave_edit(name,x)\nassert counter==42\nprint(counter,edited())"))
    assert records[-1]['error'] is None, records[-1]
    subprocess.run(['docker', 'rm', '-f', before['container']], check=True, capture_output=True)
    interrupted = durable_run(args.session, "raise AssertionError('This interrupted block must never execute')", 'a' * 32)
    assert interrupted['error'] == 'KernelStopped' and interrupted['kernel_restarted']
    repeated = durable_run(args.session, "raise AssertionError('This interrupted block must never execute')", 'a' * 32)
    assert repeated == interrupted
    after = json.loads((args.session / 'kernel.json').read_text())
    records.append(run(args.session, "assert 'counter' not in globals()\nfrom pathlib import Path\nassert Path('/work/execution-count.txt').read_text()=='1'\nname='model.language_model.layers.0.mlp.down_proj.weight'\nassert float(load(name)[0,0]-load_original(name)[0,0])==0.125\ndrop_edit(name)\nassert torch.equal(load(name),load_original(name))\nprint('restart and restoration passed')"))
    assert records[-1]['error'] is None, records[-1]
    assert before['epoch'] != after['epoch']
    timeout = durable_run(args.session, "raise TimeoutError('synthetic execution timeout')", 'b' * 32)
    assert timeout['error'] == 'KernelTimeout' and timeout['kernel_restarted']
    assert durable_run(args.session, "raise TimeoutError('synthetic execution timeout')", 'b' * 32) == timeout
    latest = json.loads((args.session / 'kernel.json').read_text())
    assert latest['epoch'] != after['epoch']
    healthy = run(args.session, "assert len(edited()) == 0\nprint('healthy after timeout recovery')")
    assert healthy['error'] is None
    subprocess.run(['docker', 'rm', '-f', latest['container']], check=True, capture_output=True)
    report = {'passed': True, 'records': records, 'interrupted_request': interrupted, 'interruption_receipt_reused': True,
              'automatic_kernel_restart': True, 'timeout_recovery': timeout, 'healthy_after_timeout': healthy,
              'before_epoch': before['epoch'], 'after_epoch': after['epoch'],
              'historical_code_not_replayed': True, 'edited_files_survived_restart': True,
              'variables_lost_on_restart': True, 'drop_restored_original': True,
              'network_mode': 'none', 'cuda_available': False, 'grad_enabled': False}
    (args.session / 'preflight.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()

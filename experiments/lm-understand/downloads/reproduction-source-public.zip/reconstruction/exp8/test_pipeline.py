import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

import numpy as np
import torch
from transformers import AutoTokenizer

from edits import EditStore
from teacher import forward, load_model


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--profile', choices=['qwen', 'gemma'], required=True)
    parser.add_argument('--model', type=Path, required=True)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    work = args.output / 'work'
    store = EditStore(args.model, work, args.profile)
    code = Path(__file__).parent
    records = []
    def call(request):
        index = len(records) + 1
        artifacts = args.output / f'r{index:03d}'
        artifacts.mkdir()
        path = artifacts / 'request.json'
        path.write_text(json.dumps(request))
        command = [sys.executable, str(code / 'backend.py'), '--request', str(path), '--work', str(work),
                   '--artifacts', str(artifacts), '--model', str(args.model), '--practice', str(args.source / 'exp8_math/practice'),
                   '--source', str(args.source), '--profile', args.profile, '--index', str(index)]
        with (artifacts / 'backend.stderr.log').open('w') as stderr:
            result = subprocess.run(command, stdout=subprocess.PIPE, stderr=stderr, text=True)
        if result.returncode:
            raise RuntimeError(str(artifacts) + ': ' + (artifacts / 'backend.stderr.log').read_text())
        response = json.loads(result.stdout)
        records.append({'request': request, 'response': response, 'artifacts': str(artifacts)})
        return response, artifacts, command
    ret = {'hidden_states': [1], 'token_logprobs': True}
    original, _, _ = call({'type': 'teacher_forced', 'model': 'original', 'texts': ['The answer is 4.'], 'return': ret})
    original_hidden = np.load(work / 'fwd_1/hidden_1.npy')
    name = ('model.language_model.' if args.profile == 'qwen' else 'model.') + 'layers.0.mlp.down_proj.weight'
    value = store.original(name)
    value[0, :] = 0
    saved = store.save(name, value)
    edited, _, _ = call({'type': 'teacher_forced', 'model': 'edited', 'texts': ['The answer is 4.'], 'return': ret})
    edited_hidden = np.load(work / 'fwd_2/hidden_1.npy')
    assert not np.array_equal(original_hidden, edited_hidden)
    final = 24 if args.profile == 'qwen' else 18
    generated, artifact, command = call({'type': 'generate', 'model': 'both', 'problems': ['gsm8k_train_0'], 'n': 1,
                                         'max_tokens': 32, 'activations': {'layers': [0, final], 'mlp': True}})
    assert generated['ok'] and generated['original']['generations'] == generated['edited']['generations'] == 1
    manifest_before = (artifact / 'manifest.json').read_bytes()
    replay = subprocess.run(command, capture_output=True, text=True, check=True)
    assert json.loads(replay.stdout) == generated
    assert (artifact / 'manifest.json').read_bytes() == manifest_before
    tokenizer = AutoTokenizer.from_pretrained(args.model, local_files_only=True)
    manifest = json.loads(manifest_before)
    samples = [json.loads(line) for line in (Path(manifest['attempt']) / 'original/generations.jsonl').open()]
    sample = samples[0]
    expected_prompt_ids = tokenizer(sample['prompt'])['input_ids']
    assert sample['prompt_ids'] == expected_prompt_ids
    model = load_model(args.model, args.profile)
    values = forward(model, sample['prompt_ids'] + sample['token_ids'][:8192], {'hidden_states': [0, final], 'mlp_act': [0]}, args.profile)
    prompt_length = len(sample['prompt_ids'])
    folder = work / 'gen_3_original_acts'
    for category, layers in [('hidden', [0, final]), ('mlp', [0])]:
        last, mean = np.load(folder / (category + '_last_prompt.npy')), np.load(folder / (category + '_mean_answer.npy'))
        for j, layer in enumerate(layers):
            value = values[f'hidden_{layer}' if category == 'hidden' else f'mlp_act_{layer}']
            np.testing.assert_array_equal(last[0, j], value[prompt_length - 1].astype(np.float32))
            np.testing.assert_array_equal(mean[0, j], value[prompt_length:].mean(axis=0, dtype=np.float32))
    del model
    torch.cuda.empty_cache()
    store.drop(name)
    restored, _, _ = call({'type': 'teacher_forced', 'model': 'edited', 'texts': ['The answer is 4.'], 'return': ret})
    np.testing.assert_array_equal(original_hidden, np.load(work / 'fwd_4/hidden_1.npy'))
    np.testing.assert_array_equal(np.load(work / 'fwd_1/token_logprobs.npy'), np.load(work / 'fwd_4/token_logprobs.npy'))
    bad, _, _ = call({'type': 'generate', 'model': 'original', 'problems': ['unknown:0']})
    assert not bad['ok'] and not bad['pass_charged']
    bad_chat, _, _ = call({'type': 'teacher_forced', 'model': 'original', 'chats': [[{'content': 123}]]})
    assert not bad_chat['ok'] and not bad_chat['pass_charged']
    report = {'passed': True, 'profile': args.profile, 'edit_sha256': saved['sha256'], 'edit_changed_actual_hidden_state': True,
              'drop_restored_hidden_and_logprobs_exactly': True, 'completed_forward_reused_without_compute': True,
              'raw_vllm_prompt_ids_match_tokenizer_default': True, 'prompt_tokens': len(sample['prompt_ids']),
              'first_prompt_token': sample['prompt_ids'][0], 'bos_token_id': tokenizer.bos_token_id,
              'activation_last_prompt_and_answer_mean_exact_replay': True, 'activation_final_layer_pre_norm': True,
              'invalid_requests_no_pass_charge': True, 'smoke_max_tokens': 32, 'production_max_tokens_unchanged': 32768 if args.profile == 'qwen' else 8192,
              'requests': records}
    (args.output / 'checks.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()

import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform

PINS = {
    'qwen': ('export-manifest.json', '27be3b529aa0ef53636edac136301fe58b3994aeceb5eb0ecc09cf7a80693972'),
    'gemma': ('download-manifest.json', '959f2b07d705800e5bb15484087e9bc69199861acdcab01c0f39ae7a9762007b'),
}


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for data in iter(lambda: stream.read(8 << 20), b''):
            h.update(data)
    return h.hexdigest()


def verify_model(model, profile):
    name, expected = PINS[profile]
    path = model / name
    if digest(path) != expected:
        raise ValueError('Pinned base manifest changed')
    manifest = json.loads(path.read_text())
    entries = manifest['files']
    if isinstance(entries, list):
        entries = {entry['file']: entry for entry in entries}
    for filename, entry in entries.items():
        if digest(model / filename) != entry['sha256']:
            raise ValueError('Pinned base file changed: ' + filename)
    return {'manifest_sha256': expected, 'revision': manifest['revision'], 'files': entries}


def dependencies():
    return {'python': platform.python_version(), 'platform': platform.platform(),
            'packages': dict(sorted((dist.metadata['Name'], dist.version) for dist in importlib.metadata.distributions()))}

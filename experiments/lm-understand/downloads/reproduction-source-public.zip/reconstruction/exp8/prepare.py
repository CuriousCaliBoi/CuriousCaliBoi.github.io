import argparse
import hashlib
import json
from pathlib import Path
import shutil

import torch
from safetensors import safe_open
from safetensors.torch import save_file


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for data in iter(lambda: f.read(8 << 20), b''):
            h.update(data)
    return h.hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--snapshot', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    previous = args.output / 'export-manifest.json'
    if previous.exists():
        from provenance import verify_model
        verify_model(args.output, 'qwen')
        print(previous.read_text())
        return
    if list(args.output.iterdir()):
        raise ValueError('Export destination is not empty and has no verified manifest')
    weights = args.snapshot / 'model.safetensors-00001-of-00001.safetensors'
    with safe_open(weights, framework='pt', device='cpu') as f:
        tensors = {name: f.get_tensor(name) for name in f.keys() if name.startswith('model.language_model.') or name == 'lm_head.weight'}
    if not tensors or not any('layers.23.' in key for key in tensors):
        raise ValueError('Pinned Qwen text tensors were not found')
    destination = args.output / 'model.safetensors'
    save_file(tensors, destination, metadata={'format': 'pt'})
    template = args.source / 'exp8_math/base_model/Qwen3.5-0.8B-text'
    for name in ('config.json', 'generation_config.json', 'tokenizer_config.json', 'chat_template.jinja'):
        shutil.copy2(template / name, args.output / name)
    shutil.copy2(args.snapshot / 'tokenizer.json', args.output / 'tokenizer.json')
    with safe_open(destination, framework='pt', device='cpu') as f:
        assert set(f.keys()) == set(tensors)
        assert all(torch.equal(f.get_tensor(name), value) for name, value in tensors.items())
    report = {'kind': 'unedited_text_only_export', 'revision': '2fc06364715b967f1860aea9cf38778875588b17',
              'source_checkpoint': str(weights), 'source_sha256': digest(weights), 'tensor_count': len(tensors),
              'tensor_names_unchanged': True, 'all_exported_values_equal_source': True,
              'files': {p.name: {'sha256': digest(p), 'bytes': p.stat().st_size} for p in sorted(args.output.iterdir()) if p.is_file()}}
    (args.output / 'export-manifest.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()

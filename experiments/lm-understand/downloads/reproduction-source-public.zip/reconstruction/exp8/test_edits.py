from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

import numpy as np
import torch
from safetensors.torch import save_file

from edits import EditStore


class EditTests(unittest.TestCase):
    def setUp(self):
        self.temporary = TemporaryDirectory()
        root = Path(self.temporary.name)
        model = root / 'model'
        model.mkdir()
        self.name = 'model.layers.0.mlp.down_proj.weight'
        self.initial = torch.tensor([[1., 2.], [3., 4.]])
        save_file({self.name: self.initial, 'model.norm.weight': torch.ones(2)}, model / 'model.safetensors')
        self.store = EditStore(model, root / 'work', 'gemma')

    def tearDown(self):
        self.temporary.cleanup()

    def test_edit_drop_restores_original(self):
        edited = self.initial.clone()
        edited[0, 0] += 1
        self.store.save(self.name, edited)
        self.assertTrue(torch.equal(self.store.load(self.name), edited))
        self.store.drop(self.name)
        self.assertTrue(torch.equal(self.store.load(self.name), self.initial))

    def test_protected_rescale_shape_nonfinite(self):
        for name, value in [('model.norm.weight', torch.ones(2)), (self.name, self.initial * 2),
                            (self.name, torch.ones(3)), (self.name, self.initial * float('nan'))]:
            with self.subTest(name=name, shape=list(value.shape)):
                with self.assertRaises(ValueError):
                    self.store.save(name, value)

    def test_snapshot_rejects_direct_protected_write_and_symlink(self):
        np.save(self.store.folder / 'model.norm.weight.npy', np.ones(2))
        with self.assertRaises(ValueError):
            self.store.snapshot()
        (self.store.folder / 'model.norm.weight.npy').unlink()
        target = self.store.work / 'outside.npy'
        np.save(target, self.initial.numpy())
        (self.store.folder / (self.name + '.npy')).symlink_to(target)
        with self.assertRaises(ValueError):
            self.store.snapshot()

    def test_interrupted_temporary_is_not_a_saved_tensor(self):
        (self.store.folder / '.save-interrupted.tmp').write_bytes(b'partial')
        self.assertEqual(self.store.edited(), [])


if __name__ == '__main__':
    unittest.main()

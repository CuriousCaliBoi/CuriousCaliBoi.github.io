import argparse
from collections import defaultdict
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import uuid

import numpy as np
from jinja2 import TemplateError
from safetensors.torch import load_file, save_file
import torch

from edits import EditStore
from protocol import canonical, validate_request, validate_token_lengths


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for data in iter(lambda: f.read(8 << 20), b''):
            h.update(data)
    return h.hexdigest()


def paired(original, edited):
    if len(original) != len(edited):
        raise ValueError('Paired outputs have different sample counts')
    differences, gains, losses = defaultdict(list), 0, 0
    for before, after in zip(original, edited, strict=True):
        if (before['id'], before['sample'], before['seed']) != (after['id'], after['sample'], after['seed']):
            raise ValueError('Paired outputs do not identify matching samples and seeds')
        if before['correct'] is None:
            continue
        differences[before['id']].append(int(after['correct']) - int(before['correct']))
        gains += not before['correct'] and after['correct']
        losses += before['correct'] and not after['correct']
    values = np.asarray([np.mean(samples) for samples in differences.values()])
    return {'items': len(values), 'accuracy_difference': float(values.mean()) if len(values) else None,
            'standard_error': float(values.std(ddof=1) / math.sqrt(len(values))) if len(values) > 1 else None,
            'samples_wrong_to_right': int(gains), 'samples_right_to_wrong': int(losses),
            'standard_error_method': 'sample standard deviation of per-item mean paired differences / sqrt(distinct items)'}


def work_target(work, name):
    if work.is_symlink() or not work.is_dir() or Path(name).name != name:
        raise ValueError('Untrusted scratch path')
    target = work / name
    if target.is_symlink() or (target.exists() and not target.is_file()):
        raise ValueError(f'Output destination is not a regular file: {target}')
    return target


def publish_file(source, work, name):
    target = work_target(work, name)
    temporary = work / ('.publish-' + uuid.uuid4().hex + '.tmp')
    with source.open('rb') as incoming, temporary.open('xb') as outgoing:
        shutil.copyfileobj(incoming, outgoing)
    temporary.replace(target)


def publish_directory(source, work, name):
    if work.is_symlink() or not work.is_dir() or Path(name).name != name:
        raise ValueError('Untrusted scratch path')
    target = work / name
    if target.is_symlink() or (target.exists() and not target.is_dir()):
        raise ValueError(f'Output destination is not a regular directory: {target}')
    if target.exists():
        expected = {p.name: digest(p) for p in source.iterdir()}
        actual = {p.name: digest(p) for p in target.iterdir() if p.is_file() and not p.is_symlink()}
        if expected != actual or len(actual) != len(list(target.iterdir())):
            raise ValueError(f'Existing output directory differs: {target}')
        return
    temporary = work / ('.publish-' + uuid.uuid4().hex)
    shutil.copytree(source, temporary)
    temporary.replace(target)


def build_checkpoint(base, store, snapshot, destination):
    if not snapshot['tensors']:
        return base
    destination.mkdir(parents=True, exist_ok=True)
    for path in base.iterdir():
        if path.is_file() and path.suffix != '.safetensors' and path.name != 'export-manifest.json':
            shutil.copy2(path, destination / path.name)
    weights = load_file(base / 'model.safetensors')
    for name, expected in snapshot['tensors'].items():
        path = store.folder / (name + '.npy')
        if digest(path) != expected:
            raise ValueError('Edit changed while preparing a forward pass')
        value = store.validate(name, np.load(path, allow_pickle=False))
        converted = value.to(weights[name].dtype).contiguous()
        if not torch.isfinite(converted).all():
            raise ValueError('Edit becomes nonfinite in the checkpoint storage dtype')
        weights[name] = converted
    save_file(weights, destination / 'model.safetensors', metadata={'format': 'pt'})
    (destination / 'edit-manifest.json').write_text(json.dumps(snapshot, indent=2) + '\n')
    return destination


def verify_cached(artifacts, model, work, profile, signature):
    manifest = json.loads((artifacts / 'manifest.json').read_text())
    response = json.loads((artifacts / 'response.json').read_text())
    if not manifest.get('completed') or manifest['request_signature'] != signature:
        raise ValueError('Existing forward response belongs to different inputs or is incomplete')
    if manifest['base_checkpoint_sha256'] != digest(model / 'model.safetensors'):
        raise ValueError('Base checkpoint changed after the forward pass')
    if manifest['edits'] != EditStore(model, work, profile).snapshot():
        raise ValueError('Current edits differ from the completed forward pass')
    if manifest['response_sha256'] != hashlib.sha256(canonical(response).encode()).hexdigest():
        raise ValueError('Forward response checksum changed')
    publish_outputs(manifest, work)
    return response


def publish_outputs(manifest, work):
    for item in manifest.get('publications', []):
        source = Path(item['source'])
        actual = {p.name: digest(p) for p in source.iterdir()} if item['directory'] else digest(source)
        if actual != item['sha256']:
            raise ValueError('Private forward artifact checksum changed')
        if item['directory']:
            publish_directory(source, work, item['name'])
        else:
            publish_file(source, work, item['name'])


def complete(artifacts, manifest, response):
    manifest.update(completed=True, response_sha256=hashlib.sha256(canonical(response).encode()).hexdigest())
    for name, value in [('manifest.json', manifest), ('response.json', response)]:
        temporary = artifacts / (name + '.tmp')
        temporary.write_text(json.dumps(value, indent=2) + '\n')
        temporary.replace(artifacts / name)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--request', type=Path, required=True)
    parser.add_argument('--work', type=Path, required=True)
    parser.add_argument('--artifacts', type=Path, required=True)
    parser.add_argument('--model', type=Path, required=True)
    parser.add_argument('--practice', type=Path, required=True)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--profile', choices=['qwen', 'gemma'], required=True)
    parser.add_argument('--index', type=int, required=True)
    args = parser.parse_args()
    request = json.loads(args.request.read_text())
    args.artifacts.mkdir(parents=True, exist_ok=True)
    store = EditStore(args.model, args.work, args.profile)
    snapshot = store.snapshot()
    signature = hashlib.sha256((canonical(request) + snapshot['sha256']).encode()).hexdigest()
    cached = args.artifacts / 'response.json'
    if cached.exists():
        print(json.dumps(verify_cached(args.artifacts, args.model, args.work, args.profile, signature)), flush=True)
        return
    manifest = {'request': request, 'request_signature': signature, 'edits': snapshot,
                'base_checkpoint_sha256': digest(args.model / 'model.safetensors'), 'commands': [],
                'backend_sha256': digest(__file__), 'started_unix': time.time(), 'publications': []}
    manifest_path = args.artifacts / 'manifest.json'
    manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
    try:
        validate_request(request, args.profile)
        if request['type'] == 'teacher_forced':
            from transformers import AutoTokenizer
            from teacher import tokenize
            tokenizer = AutoTokenizer.from_pretrained(args.model, local_files_only=True)
            lengths = list(map(len, tokenize(request, tokenizer)))
            validate_token_lengths(lengths, request, args.profile)
        else:
            available = {json.loads(line)['id'] for path in args.practice.glob('*.jsonl') for line in path.open()}
            missing = set(request.get('problems', [])) - available
            if missing:
                raise ValueError('Unknown practice IDs: ' + ', '.join(sorted(missing)))
    except (ValueError, TypeError, KeyError, TemplateError) as error:
        response = {'ok': False, 'error': str(error), 'kind': 'request_validation', 'pass_charged': False}
        complete(args.artifacts, manifest, response)
        print(json.dumps(response), flush=True)
        return
    code = Path(__file__).parent
    env = {**os.environ, 'HF_HUB_OFFLINE': '1', 'TRANSFORMERS_OFFLINE': '1',
           'MATHVERIFY_PKGS': str(code.parent / 'cpu-deps')}
    attempt = args.artifacts / ('attempt-' + uuid.uuid4().hex)
    attempt.mkdir()
    manifest['attempt'] = str(attempt)
    def publication(source, name):
        directory = source.is_dir()
        hashes = {p.name: digest(p) for p in source.iterdir()} if directory else digest(source)
        manifest['publications'].append({'source': str(source), 'name': name, 'directory': directory, 'sha256': hashes})
    def worker(label, script, arguments):
        command = [sys.executable, str(code / script), *map(str, arguments)]
        for startup_attempt in range(2):
            record = {'label': label, 'startup_attempt': startup_attempt + 1, 'command': command, 'started_unix': time.time()}
            manifest['commands'].append(record)
            manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
            stdout_path = attempt / (label + f'.attempt{startup_attempt + 1}.stdout.log')
            stderr_path = attempt / (label + f'.attempt{startup_attempt + 1}.stderr.log')
            with stdout_path.open('w') as stdout, stderr_path.open('w') as stderr:
                result = subprocess.run(command, env=env, stdout=stdout, stderr=stderr)
            record.update(returncode=result.returncode, wall_s=round(time.time() - record['started_unix'], 3))
            manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
            if result.returncode == 0:
                return
            failure = stdout_path.read_text() + stderr_path.read_text()
            startup_failure = any(marker in failure for marker in ('Engine core initialization failed', 'EngineCore failed to start'))
            if not startup_failure or startup_attempt == 1:
                raise RuntimeError(f'GPU worker {label} failed; artifacts retained at {args.artifacts}')
    policy_paths = {'original': args.model}
    if request['model'] in ('edited', 'both'):
        policy_paths['edited'] = build_checkpoint(args.model, store, snapshot, attempt / 'checkpoint')
    lock_path = code.parent / 'gpu.lock'
    with lock_path.open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        if request['type'] == 'teacher_forced':
            output = attempt / 'teacher'
            worker('teacher', 'teacher.py', ['--model', policy_paths[request['model']], '--request', args.request,
                                             '--output', output, '--profile', args.profile])
            publication(output, f'fwd_{args.index}')
            response = json.loads((output / 'meta.json').read_text())
            response['dir'] = f'/work/fwd_{args.index}/'
            response['edited_tensors'] = len(snapshot['tensors']) if request['model'] == 'edited' else 0
        else:
            selected = ('original', 'edited') if request['model'] == 'both' else (request['model'],)
            summaries, records, files, captures = {}, {}, {}, {}
            for selected_model in selected:
                specific = {**request, 'model': selected_model}
                specific_path = attempt / (selected_model + '.request.json')
                specific_path.write_text(json.dumps(specific, indent=2) + '\n')
                output = attempt / selected_model
                worker(selected_model + '_generate', 'generate.py', ['--model', policy_paths[selected_model], '--request', specific_path,
                       '--output', output, '--practice', args.practice, '--source', args.source, '--profile', args.profile])
                suffix = '_' + selected_model if len(selected) == 2 else ''
                basename = f'gen_{args.index}{suffix}'
                publication(output / 'generations.jsonl', basename + '.jsonl')
                summaries[selected_model] = json.loads((output / 'summary.json').read_text())
                records[selected_model] = [json.loads(line) for line in (output / 'generations.jsonl').open()]
                files[selected_model] = '/work/' + basename + '.jsonl'
                if request.get('activations'):
                    activation_output = attempt / (selected_model + '_acts')
                    worker(selected_model + '_activations', 'activations.py', ['--model', policy_paths[selected_model],
                           '--generations', output / 'generations.jsonl', '--request', specific_path,
                           '--output', activation_output, '--profile', args.profile])
                    publication(activation_output, basename + '_acts')
                    index = json.loads((activation_output / 'index.json').read_text())
                    captures[selected_model] = {'dir': '/work/' + basename + '_acts/', 'files': index['files']}
            if len(selected) == 2:
                response = {'ok': True, 'type': 'generate', 'model': 'both', 'files': files, **summaries,
                            'paired': paired(records['original'], records['edited'])}
                if captures:
                    response['activations'] = captures
            else:
                response = {**summaries[selected[0]], 'file': files[selected[0]]}
                if captures:
                    response['activations'] = captures[selected[0]]
    if store.snapshot() != snapshot:
        raise ValueError('Edits changed during forward evaluation')
    response['s'] = round(time.time() - manifest['started_unix'], 3)
    manifest.update(policy_checkpoints={name: {'path': str(path), 'sha256': digest(path / 'model.safetensors')}
                                        for name, path in policy_paths.items()})
    complete(args.artifacts, manifest, response)
    publish_outputs(manifest, args.work)
    print(json.dumps(response), flush=True)


if __name__ == '__main__':
    main()

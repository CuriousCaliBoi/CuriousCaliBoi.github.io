# Reconstructed Experiment 8 runtime

This implements the unpublished CPU kernel, forward-pass service and conversation driver for the released mathematics experiment. It is a reconstruction, not the authors' original server. Fresh editing sessions use the released initial prompts and instructions, the published practice arrays, the original model revisions, and Codex CLI with `gpt-6-astra` at `max` reasoning effort. No held-out questions or published edits enter the editor's context.

The seven independent sessions are Qwen `p10c`, `p25c`, `p50c` (10, 25 and 50 forward passes) and Gemma `g05b`, `g10b`, `g25b`, `g50b` (5, 10, 25 and 50 passes). They start from the unedited base each time. A root review matching every production Python file's SHA-256 is required before the controller launches an editing conversation. Every proposed Python block then receives an independent review against the experiment rules before execution.

## Preserved inputs

- Source release commit: `4d09ba6d6a7e891dd8063974dfe81b3d78e3494f`.
- Qwen3.5-0.8B revision: `2fc06364715b967f1860aea9cf38778875588b17`. Its text export keeps all 320 original text tensors and their exact values; multimodal vision tensors are excluded as in the released apply-edit code. The released base text configuration and tokenizer metadata are retained.
- Gemma-3-270m-it revision: `ac82b4e820549b854eebf28ce6dedaf9fdfa17b3`. These are the base instruction-tuned weights, not the new Experiment 7 checkpoints.
- Practice: the released GSM8K training 7,469 and MATH training 7,275 rows; Qwen additionally receives 714 released AIME practice rows. Gemma's mount excludes AIME.
- Original `mathqa.py` is loaded unchanged, with math-verify 0.9.0. Gemma's fallback extraction and correctness functions are taken unchanged from the AST of the released `evaluate.py`. Each record retains strict boxed grading alongside the Gemma fallback grade.

## Runtime and limits

The Spark uses the existing CUDA environment read-only: PyTorch 2.14.0+cu130, Transformers 5.20.2, vLLM 0.33.0 and Python 3.12.13. Task-only dependency and compiler caches are kept outside the shared environment. The unrelated neuron-explorer process is left running.

The persistent kernel runs inside a pinned Ubuntu container with no network, no GPU devices, read-only model/practice/harness mounts, a writable scratch directory, eight CPU cores and the published 96 GB / 900 second / 10,000 character limits. Autograd is disabled. The driver enforces 300 Python runs and the per-session forward budget. Separate queue epochs and durable request receipts prevent historical code replay after restart. A restart preserves files and edits, loses variables, and provides an explicit notice before further execution.

Generation preserves the published settings: Qwen temperature 0.6, top-p 0.95, top-k 20, presence penalty 1.5, thinking enabled and maximum 32,768 new tokens; Gemma temperature 1.0, top-p 0.95, top-k 64 and maximum 8,192 new tokens. The request may choose a smaller cap. The 512 / 2,048 answer limits remain intact, halved per model for paired generation. A 0.35 GPU memory fraction and 32 concurrent sequences queue larger requests internally. The context capacity is the requested new-token cap plus at least 2,048 prompt tokens, increased for longer actual prompts. These resource settings differ from the authors' server and do not truncate requested output caps. Recognized vLLM startup failures receive at most one automatic retry; failed attempts and logs remain recorded.

Paired differences are averaged within each problem before computing uncertainty across problems. This grouping is supported by the released `p25c/requests/fwd_6.json.claimed` (64 problems, two samples each) and its result (`paired.items=64`, difference 0.0234, standard error 0.0282, ten gains and seven losses), as well as passes 7–9. The exact sample-standard-deviation (`ddof=1`) implementation remains reconstructed.

Teacher-forced requests preserve the 1,024 text, 524,288 total token, per-text 32,768 / 8,192 token, 6 GB padded output, and two-text / 2,048-token attention limits. Texts run sequentially; the LM head and log-softmax are evaluated in 64-token chunks so the entire vocabulary-logit matrix need not coexist in memory. Actual-model checks compare the returned probabilities and top-k against native logits for both architectures.

## Explicit reconstruction differences

1. The original item-to-seed function was not published. This implementation derives a 31-bit seed from SHA-256 of `exp8-v1:<item identity>:<sample index>`. It records every seed and pairs original/edited samples within the same pass. Separate passes can differ because of backend batching and numerical effects.
2. Generation uses vLLM's actual consumed `prompt_token_ids`, saved alongside the rendered prompt and generated IDs. Activation capture replays these exact IDs through Transformers with the same checkpoint. This introduces a documented backend numerical difference from in-engine hooks. Hooks capture float16 arrays and aggregate in float32, retaining last-prompt and mean-of-first-8,192-answer-token values.
3. Hidden index zero is the embedding module output, including Gemma's native input scaling. Index `l` is decoder layer `l-1` output before the final norm, following the prompt. The original server implementation is absent; native Transformers `hidden_states[-1]` instead includes final normalization. This ambiguity is recorded in each teacher metadata file and checked against a direct layer hook.
4. The published generation artifact convention indexes MLP down-projection inputs by the requested layer values below the model's layer count. The reconstruction follows that convention, with both hidden and MLP index lists in each activation index file.
5. The missing `mcqa.repetitive_end` helper is reconstructed from the exact 200-word / 4-gram / three-occurrence / half-position rule documented in `mathqa.py`.
6. The driver restarts the Codex conversation after 40 replies, carrying the original task, current notebook, edit hashes, budgets and latest feedback. The CPU kernel remains persistent. The released explanation requirements and notice delivery turns are preserved. This reconstructed driver gives at most two consecutive reminders for a missing explanation, then executes a valid block; this ceiling and the handoff assembly are implementation choices, not claims about the unpublished original driver. Notices claiming formerly broken attention or formerly wrong failure counts are truthfully adapted because this service provides the corrected behavior from the start; original notice hashes remain recorded.
7. There is no automatic execution of model-proposed code before independent review. This is an additional review delay, without changing model prompts or experiment budgets.

## Recovery and provenance

The controller journals each incoming prompt and uses the actual Codex rollout to audit user-message order, model settings, and the absence of tool calls or injected instructions. Completed Python requests are reused by code hash. Forward receipts bind the canonical request, current frozen edit hashes, base checkpoint hash, response and private output files. A completed forward pass is reused after interruption; it is not recomputed or charged twice. Invalid inputs and duplicate successful requests do not consume a pass. Computation attempts are retained separately. File publication rejects symbolic-link destinations and uses atomic replacement.

Finalization validates tensor names/shapes, finite values, protected tensors and the whole-tensor-rescale rule again outside the mutable kernel. It records a unique frozen submission directory and per-file hashes; repeated finalization verifies and reuses that same frozen submission. The trusted checkpoint builder also rejects values that overflow when converted to the checkpoint storage dtype.

Smoke runs intentionally use 32 generated tokens and are never counted as scientific experiment results. Production defaults retain the full published caps. Preflight reports cover actual GPU generation, native teacher probability parity, attention, padding, activation replay, real edit effects and restoration, kernel restart behavior, receipt reuse and invalid-request accounting.

import ast
import hashlib
import importlib.util
import importlib.metadata
from pathlib import Path


class Grader:
    def __init__(self, source, profile):
        self.profile = profile
        path = Path(source) / 'exp8_math/code/mathqa.py'
        spec = importlib.util.spec_from_file_location('original_mathqa', path)
        self.module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.module)
        self.module.mv()
        if importlib.metadata.version('math-verify') != '0.9.0':
            raise ValueError('The published grader requires math-verify 0.9.0')
        evaluation = Path(source) / 'exp8_math/code/evaluate.py'
        tree = ast.parse(evaluation.read_text())
        functions = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in ('lenient_pred', 'lenient_correct')]
        scope = {'Q': self.module}
        exec(compile(ast.Module(body=functions, type_ignores=[]), str(evaluation), 'exec'), scope)
        self.lenient_pred, self.lenient_correct = scope['lenient_pred'], scope['lenient_correct']
        self.provenance = {'mathqa_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                           'evaluate_sha256': hashlib.sha256(evaluation.read_bytes()).hexdigest(),
                           'math_verify_version': '0.9.0', 'gemma_lenient_functions': 'unchanged AST bodies from original evaluate.py',
                           'loop_signal_deviation': 'Missing mcqa repetitive_end helper reconstructed from the exact 200-word/4-gram/three-repeat/half-position rule documented in mathqa.py.'}

    def grade(self, answer, text):
        prediction, boxes = self.module.extract(text)
        good = self.module.is_correct(prediction, answer)
        strict_prediction, strict_good = prediction, bool(good)
        if self.profile == 'gemma':
            good = self.lenient_correct(text, prediction, good, answer)
            if prediction is None:
                prediction = self.lenient_pred(text)
        return {'pred': prediction, 'correct': bool(good), 'strict_pred': strict_prediction,
                'strict_correct': strict_good, 'boxes': boxes, **self.module.loop_signals(text)}

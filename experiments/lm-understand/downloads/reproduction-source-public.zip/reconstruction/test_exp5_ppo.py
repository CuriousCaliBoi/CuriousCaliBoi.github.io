import json
import fcntl
import os
from pathlib import Path
import pickle
import subprocess
import sys
import tempfile
import time
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import numpy as np
import torch
from minatar import Environment

from exp5_evaluate import NPZ_KEYS, observation, episode
from exp5_ppo_train import BATCH, STEPS, Training, advantages, provenance
from exp5_ppo_campaign import read_episode_rows, campaign_locked, campaign_cases


def exact(left, right):
    if isinstance(left, torch.Tensor):
        return torch.equal(left, right)
    if isinstance(left, np.ndarray):
        return np.array_equal(left, right)
    if isinstance(left, dict):
        return left.keys() == right.keys() and all(exact(left[k], right[k]) for k in left)
    if isinstance(left, (list, tuple)):
        return len(left) == len(right) and all(exact(a, b) for a, b in zip(left, right))
    return left == right


class PPOTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(1)
        torch.set_num_interop_threads(1)

    def test_channel_mapping_and_or(self):
        maps = {
            'breakout': [['paddle'], [], ['brick'], ['ball'], ['trail'], []],
            'seaquest': [['sub_front', 'sub_back'], ['enemy_fish', 'enemy_sub', 'enemy_bullet'],
                         ['enemy_fish', 'enemy_sub', 'diver'], ['friendly_bullet'],
                         ['trail', 'sub_back'], ['oxygen_guage', 'diver_guage']],
            'asterix': [['player'], ['enemy'], ['gold'], [], ['trail'], []],
        }
        for game, mapping in maps.items():
            env = Environment(game)
            for name, index in env.env.channels.items():
                raw = np.zeros(env.state_shape(), bool)
                raw[3, 7, index] = True
                fake = SimpleNamespace(env_name=game, env=env.env, state=lambda: raw)
                expected = np.zeros((10, 10, 6), np.float32)
                for channel, names in enumerate(mapping):
                    expected[3, 7, channel] = name in names
                self.assertTrue(np.array_equal(observation(fake), expected.flatten()), (game, name))
            raw = np.ones(env.state_shape(), bool)
            fake = SimpleNamespace(env_name=game, env=env.env, state=lambda: raw)
            self.assertLessEqual(float(observation(fake).max()), 1.)
            self.assertEqual(observation(fake).dtype, np.float32)

    def test_native_actions_reset_and_rng(self):
        for game in ('breakout', 'seaquest', 'asterix'):
            env = Environment(game, sticky_action_prob=0., difficulty_ramping=True)
            env.seed(91)
            self.assertEqual(env.num_actions(), 6)
            for action in range(6):
                env.reset()
                env.act(action)
                self.assertEqual(env.last_action, action)
            env.reset()
            self.assertEqual(env.last_action, 5)
            self.assertIs(env.random, env.env.random)
            twin = pickle.loads(pickle.dumps(env))
            for action in [0, 1, 5, 3, 2, 4] * 5:
                self.assertEqual(env.act(action), twin.act(action))
                self.assertTrue(np.array_equal(env.state(), twin.state()))

    def test_terminal_and_rollout_bootstrap(self):
        rewards = torch.zeros((STEPS, 2))
        values = torch.ones((STEPS, 2)) * 2
        dones = torch.zeros((STEPS, 2))
        rewards[-1] = 3.
        result = advantages(rewards, dones, values, torch.tensor([1., 0.]), torch.tensor([7., 7.]))
        self.assertAlmostEqual(float(result[-1, 0]), 1.)
        self.assertAlmostEqual(float(result[-1, 1]), 3 + .99 * 7 - 2, places=5)
        dones[-1] = 1.
        result = advantages(rewards, dones, values, torch.zeros(2), torch.ones(2) * 999.)
        self.assertTrue(torch.equal(result[-2], torch.tensor([-2., -2.])))

    def test_floor_counts_and_schedule(self):
        cases = campaign_cases()
        self.assertEqual(len(cases), 32)
        self.assertEqual(sum(c['nominal_steps'] for c in cases), 6_800_000_000)
        self.assertEqual(sum(c['actual_steps'] for c in cases), 6_799_982_592)
        for nominal, actual, updates in [(100_000_000, 99_999_744, 12207),
                                         (500_000_000, 499_998_720, 61035)]:
            trainer = Training('breakout', 0, nominal)
            self.assertEqual(trainer.spec['actual_steps'], actual)
            self.assertEqual(trainer.spec['updates'], updates)
            self.assertEqual(sum(p.numel() for p in trainer.agent.actor.parameters()), 20486)
            self.assertEqual(trainer.agent.critic[0].out_features, 64)
        trainer = Training('breakout', 0, BATCH * 3 + 9)
        rates = [trainer.run_update()['lr'] for _ in range(3)]
        np.testing.assert_allclose(rates, [.0005, .0005 * 2 / 3, .0005 / 3], rtol=1e-15)
        self.assertEqual(trainer.global_step, BATCH * 3)

    def test_resume_all_training_state_exact(self):
        for game in ('breakout', 'seaquest', 'asterix'):
            with self.subTest(game=game), tempfile.TemporaryDirectory() as temporary:
                trainer = Training(game, 3, BATCH * 4)
                trainer.run_update()
                pointer = trainer.save(temporary)
                expected_records = [trainer.run_update() for _ in range(2)]
                expected = trainer.payload()
                resumed = Training.load(temporary)
                self.assertEqual(resumed.update, pointer['update'])
                actual_records = [resumed.run_update() for _ in range(2)]
                actual = resumed.payload()
                for record in expected_records + actual_records:
                    record.pop('rollout_seconds')
                    record.pop('total_seconds')
                self.assertEqual(expected_records, actual_records)
                expected.pop('compute_seconds')
                actual.pop('compute_seconds')
                self.assertTrue(exact(expected, actual))
                prior = pointer['file']
                resumed.save(temporary)
                self.assertTrue((Path(temporary) / prior).exists())
                self.assertEqual(len(list(Path(temporary).glob('checkpoint-*.pt'))), 2)
                resumed.save(temporary)
                self.assertEqual(len(list(Path(temporary).glob('checkpoint-*.pt'))), 2)
                self.assertEqual(len(list((Path(temporary) / 'receipts').glob('*.json'))), 3)
                Training.load(temporary)

    def test_frozen_export_and_evaluator(self):
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            trainer = Training('breakout', 1, BATCH)
            with self.assertRaises(AssertionError):
                trainer.freeze(directory, {})
            trainer.run_update()
            pointer = trainer.save(directory)
            record = trainer.freeze(directory, pointer)
            path = directory / 'actor.npz'
            with np.load(path, allow_pickle=False) as archive:
                self.assertEqual(set(archive.files), set(NPZ_KEYS.values()))
                w1, b1, w2, b2, w3, b3 = [archive[k] for k in NPZ_KEYS.values()]
                states = trainer.next_obs.numpy()
                expected = np.tanh(np.tanh(states @ w1 + b1) @ w2 + b2) @ w3 + b3
                with torch.no_grad():
                    actual = trainer.agent.actor(trainer.next_obs).numpy()
                np.testing.assert_allclose(actual, expected, rtol=3e-5, atol=2e-7)
            first = episode(('breakout.ppo100_s1', str(path), 0, 20261102, 10000))
            second = episode(('breakout.ppo100_s1', str(path), 0, 20261102, 10000))
            self.assertEqual(first, second)
            self.assertEqual(trainer.freeze(directory, pointer)['actor_sha256'], record['actor_sha256'])
            metadata = json.loads((directory / 'frozen.json').read_text())
            self.assertEqual(metadata['spec']['actual_steps'], BATCH)

    def test_interrupted_evaluation_tail_is_preserved(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / 'episodes.jsonl'
            path.write_bytes(b'{"episode":0}\n{"episode":1')
            self.assertEqual(read_episode_rows(path), [{'episode': 0}])
            self.assertEqual(path.read_bytes(), b'{"episode":0}\n')
            tail, = path.parent.glob('*.interrupted-tail-*')
            self.assertEqual(tail.read_bytes(), b'{"episode":1')

    def test_resume_rejects_changed_environment_source(self):
        with tempfile.TemporaryDirectory() as temporary:
            Training('breakout', 0, BATCH).save(temporary)
            changed = provenance()
            changed['minatar_sources']['wrapper'] = '0' * 64
            with patch('exp5_ppo_train.provenance', return_value=changed):
                with self.assertRaises(AssertionError):
                    Training.load(temporary)

    def test_campaign_exclusion(self):
        @campaign_locked
        def probe(plan, output, workers, lock_fd):
            return 'entered'
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            with (directory / 'campaign.lock').open('w') as stream:
                fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
                with self.assertRaises(BlockingIOError):
                    probe(None, directory, 4)
            self.assertEqual(probe(None, directory, 4), 'entered')

    def test_orphan_worker_retains_campaign_lock(self):
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            core = min(os.sched_getaffinity(0))
            child = ('from pathlib import Path; import time,os; '
                     f'assert os.sched_getaffinity(0)=={{{core}}}; '
                     f'Path({str(directory / "ready")!r}).write_text("ready"); '
                     'time.sleep(2); '
                     f'Path({str(directory / "finished")!r}).write_text("finished")')
            launcher = ('from pathlib import Path\nimport sys\n'
                        'from exp5_ppo_campaign import campaign_locked,run_worker\n'
                        '@campaign_locked\ndef launch(plan,output,workers,lock_fd):\n'
                        '    with (output/"worker.log").open("w") as stream:\n'
                        f'        run_worker(["taskset","-c","{core}",sys.executable,"-c",{child!r}],stream,lock_fd)\n'
                        f'launch(None,Path({str(directory)!r}),1)\n')
            parent = subprocess.Popen([sys.executable, '-c', launcher], cwd=Path(__file__).parent)
            deadline = time.monotonic() + 15
            while not (directory / 'ready').exists() and time.monotonic() < deadline:
                time.sleep(.02)
            self.assertTrue((directory / 'ready').exists())
            parent.terminate()
            parent.wait(timeout=5)
            with (directory / 'campaign.lock').open('w') as stream:
                with self.assertRaises(BlockingIOError):
                    fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
                deadline = time.monotonic() + 5
                while time.monotonic() < deadline:
                    try:
                        fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
                        break
                    except BlockingIOError:
                        time.sleep(.02)
                else:
                    self.fail('Worker did not release campaign lock after natural completion')
            self.assertEqual((directory / 'finished').read_text(), 'finished')


if __name__ == '__main__':
    unittest.main()

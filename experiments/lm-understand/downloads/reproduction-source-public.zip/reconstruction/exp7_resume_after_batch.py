"""Resume an approved retained turn after the single-worker attention batch ends."""
import argparse
import json
import time

from exp7_cli import OUT, sha, write_json
from exp7_runner import run_case


def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument('case_id')
    args = parser.parse_args()
    manifest = json.loads((OUT / 'manifest.json').read_text())
    case = next(case for case in manifest['cases'] if case['id'] == args.case_id)
    root = OUT / 'runs' / case['id']
    state = json.loads((root / 'state.json').read_text())
    assert state['status'] == 'failed' and state['error'].startswith('Code rejected by protocol review:')
    turn = root / 'turns' / f't{state["turn"]:03d}'
    malformed = json.loads((turn / 'code-review-malformed-record.json').read_text())
    corrected = json.loads((turn / 'code-review.json').read_text())
    assert malformed['approved'] and malformed['sha256'] == corrected['code_sha256'] == sha((turn / 'code.py').read_bytes())
    assert corrected['approved'] and not (turn / 'python-result.json').exists()
    write_json(root / 'state-review-bookkeeping-failure.json', state)
    recovery = {'status': 'waiting_for_scheduled_attention_cases', 'thread_id': state['thread_id'],
                'retained_turn': state['turn'], 'code_sha256': corrected['code_sha256'],
                'reason': 'Reviewer used sha256 instead of code_sha256 in an affirmative approval; corrected without changing the code or its verdict.',
                'model_call_policy': 'Reuse all completed model turns and executed tool results; execute retained approved code once, then resume the same actual thread.'}
    write_json(root / 'review-bookkeeping-recovery.json', recovery)
    while not (OUT / 'batch-attention_tool.json').exists():
        time.sleep(10)
    state = json.loads((root / 'state.json').read_text())
    if state['status'] != 'completed':
        state = run_case(case)
    recovery['status'] = state['status']
    recovery['result'] = state
    write_json(root / 'review-bookkeeping-recovery.json', recovery)
    if state['status'] != 'completed':
        raise SystemExit(1)


if __name__ == '__main__':
    main()

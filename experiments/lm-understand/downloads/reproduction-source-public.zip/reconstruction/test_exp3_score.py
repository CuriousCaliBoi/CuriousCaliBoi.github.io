import json
import unittest

from exp3_score import SOURCE, parse_answer, score_answer


class ScoringTests(unittest.TestCase):
    def test_released_answers_match_published_threshold(self):
        truth = json.loads((SOURCE / 'eval/heads.json').read_text())
        expected = {'python': ['L2H1', 'L3H1', 'L3H5'], 'romaji': ['L3H3'], 'english': ['L3H1']}
        answers = list((SOURCE / 'runs').glob('*/final_answer.md'))
        self.assertEqual(len(answers), 6)
        for path in answers:
            corpus = path.parent.name.split('_')[0]
            with self.subTest(run=path.parent.name):
                result = score_answer(path.read_text(), corpus, truth[corpus + '_L4_H6_d384_s0'])
                self.assertEqual(result['true_copy_heads'], expected[corpus])
                self.assertTrue(result['copy_exact'])
                self.assertTrue(result['corpus_correct'])
                self.assertTrue(result['order_correct'])
                self.assertEqual(len(result['head_labels']), 24)

    def test_incomplete_and_ambiguous_answers_rejected(self):
        answer = (SOURCE / 'runs/python_r0/final_answer.md').read_text()
        for modified in (answer + '\ncorpus: english\n', answer.replace('L0H0:', 'missing:'),
                         answer.replace('python=0.56', 'python=1.56'),
                         answer.replace('python=0.56', 'python=0.36')):
            with self.subTest(text=modified[-120:]):
                with self.assertRaises(ValueError):
                    parse_answer(modified)


if __name__ == '__main__':
    unittest.main()

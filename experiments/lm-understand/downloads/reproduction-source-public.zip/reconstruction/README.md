# Reconstructed evaluation of experiments 4 and 5

This workspace implements evaluation of the fresh replies using the published protocol from RikiyaT/lm_understand-logs at 4d09ba6d6a7e891dd8063974dfe81b3d78e3494f. The author-specific evaluators were not released. The user now authorizes reconstructed components and recorded deviations.

Original source and the fresh replies remain immutable. Validate parser output against the released policy archives before evaluating new replies. Separate published reference results, newly re-evaluated released policies, and freshly generated policies. Preserve every seed, model hash, dependency version and episode outcome.

Experiment 4 uses Kinetix 80ee9c292837c825cafaf9889323fdcc212efd1b, level l/h2_car_ramp, the rounded network shown in the prompt, sampled actions, at most 256 steps, 256 search and 1024 test episodes. Experiment 5 uses MinAtar 1.0.15, sampled softmax actions, sticky actions 0.1, 1000 episodes, at most 10000 steps. Its policies begin with zero weights.

All implementation work occurs in isolated worktrees and is reviewed before integration.

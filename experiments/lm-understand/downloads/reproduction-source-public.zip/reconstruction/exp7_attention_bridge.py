"""Pass text-only attention requests to the trusted Spark inference process."""
import json
import subprocess

from exp7_cli import sha, write_json
from exp7_setup import REMOTE

PYTHON = '<gpu-python-environment>/bin/python'


def attention_run(case, directory, content, number):
    (directory / 'attention-request.txt').write_text(content)
    path = directory / 'attention-result.json'
    if path.exists():
        saved = json.loads(path.read_text())
        assert saved['request_sha256'] == sha(content.encode())
        return saved
    try:
        texts = json.loads(content)
    except json.JSONDecodeError as error:
        result = {'status': 'invalid_input', 'texts': None, 'out': f'ATTENTION TOOL error: invalid JSON ({error}).', 'artifacts': {}}
    else:
        request = {'pair_path': case['pair_path'], 'work_path': case['work_path'], 'call': number, 'texts': texts}
        process = subprocess.run(['ssh', '-o', 'BatchMode=yes', '<gpu-ssh-alias>', PYTHON, REMOTE + '/exp7_attention.py'],
                                 input=json.dumps(request), capture_output=True, text=True, timeout=720)
        (directory / 'attention-stderr.txt').write_text(process.stderr)
        if process.returncode:
            (directory / 'attention-bridge-error.txt').write_text(process.stdout + '\n' + process.stderr)
            raise RuntimeError('Attention backend failed; retained request must not be replaced with another model answer')
        result = json.loads(process.stdout)
        if result['status'] == 'completed':
            for side in ('A', 'B'):
                assert result['checkpoint_hashes'][side] == case['checkpoint_hashes'][side + '/model.safetensors']
            archive = directory / 'attention'
            subprocess.run(['scp', '-rq', '<gpu-ssh-alias>:' + result['artifact_path'], str(archive)], check=True)
            assert {path.name: sha(path.read_bytes()) for path in archive.iterdir()} == result['artifacts']
    result['request_sha256'] = sha(content.encode())
    write_json(path, result)
    (directory / 'feedback.txt').write_text(result['out'])
    return result

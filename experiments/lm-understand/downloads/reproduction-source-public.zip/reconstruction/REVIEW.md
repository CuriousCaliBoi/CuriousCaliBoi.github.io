# Independent protocol review

The user now permits reconstructed harnesses. Validation can establish agreement with the published protocol and artifacts; it cannot establish an identical historical runtime or RNG stream. The four fresh replies are fixed inputs and must never be tuned after observing evaluation scores.

## Required artifact checks

- Reconstruct the released car edit from the rounded prompt values in float64; all 14 tensors must equal edited_actor.npz and the changed-value count must be 6,073. Keep storage dtype distinct from float32 inference.
- Reconstruct the released MinAtar policies from zeros in float32; all tensors must exactly equal the three hand.npz files. Published statement counts are 92, 122 and 55; nonzero totals are 815, 803 and 637 for Breakout, Seaquest and Asterix.
- Parse only the last edits block. An unreadable statement must not invalidate earlier or later valid statements. Test malformed/valid recovery and multiline arrays, including valid/garbage/valid. Only literal numeric edits are allowed.

## Car environment checks

- Use the pinned Kinetix level JSON and all its physics parameters, not a hand-built approximate scene. The level supplies frame_skip=2; the EnvParams default dense_reward_scale=0.1 must become 0.2. Max length is 256 agent steps.
- Use 679-dimensional symbolic_flat observations without observation normalization. The 16 logits are six independent categorical distributions of sizes 3,3,3,3,2,2. No global 16-way softmax.
- Same exact initial state every episode; actions are the only source of randomness. Disable auto-reset or freeze completed episode state and accumulators.
- Classify outcomes from contact reward/GoalR and finiteness, never from shaped episode return. Collision red on the final allowed step must take precedence over timeout. Preserve the first terminal contact across the two physics substeps.
- Use base_result.json for the rounded base control. ppo_training_result.json test refers to the training selection rule's best_chunk=0 and is not the final failed checkpoint's score.
- Re-evaluate both rounded base and published edited actor before interpreting a new policy's score. Distinguish numerical/runtime mismatch from a new policy's failure.

## MinAtar environment checks

- Official MinAtar 1.0.15, difficulty_ramping=True, sticky probability 0.1, all six actions, sampled softmax, 1,000 episodes, 10,000-step cap.
- Exact channel remapping by boolean OR/max; flatten index (row*10+column)*6+channel. Seaquest keys include oxygen_guage and diver_guage (source spelling).
- Official Environment.reset does not reset last_action. A new Environment per episode starts last_action at zero; this must be recorded as a reconstruction choice because the author's reset/RNG conventions are unavailable.
- Declare separate fixed environment/action seeds and compute dtype. Apply the same conventions to released control policies and fresh policies.
- Save every episode outcome and truncation, including failures, before aggregating means and standard errors. Do not claim rerun control means must exactly equal published means.

## Known deviations requiring disclosure

Original evaluation wrapper/parser source and RNG streams are unavailable. Original car record uses JAX 0.4.38 and logs indicate Python 3.10; the completed run uses a dedicated task environment with JAX 0.9.0 and Python 3.12.13, retaining unmodified Kinetix and jax2d 1.0.1. Artifact equality, control agreement and no-tool prompt replay are separate validations and must remain separate claims.

## Completed implementation and result review

Experiment 5 passed source/protocol review. The reviewer independently recomputed every aggregate from all six sets of 1,000 uniquely indexed episode records, verified result/protocol/reply/policy/script hashes, compared released tensor payloads to source archives, and checked equal recorded environment/action seeds for corresponding fresh/control episodes. See exp5-result-review.json.

Fresh means: Breakout 380.585, Seaquest 35.245, Asterix 64.378. Re-evaluated released-policy control means: 496.270, 51.533, 52.202. These are new observations, not copied author scores. PPO baseline checkpoints were not evaluated. Breakout has 502 control and 471 fresh capped episodes, all included in the means.

Experiment 4 passed source/protocol and result review. All 3,840 episode records have unique indices, valid lengths and independently verified counts and mean returns. Search/test keys are disjoint, and corresponding episodes across the three policies share the same keys. Every source, frozen reply, runtime script/parser, level and policy hash was checked. The reviewer independently reconstructed the rounded base and all 25 frozen fresh edits with the Python standard library; the resulting float64 tensor payloads match the evaluated artifacts byte for byte. See exp4-result-review.json.

The 1,024-episode test has zero base successes (all timeout), 1,024 published-edit successes (all 73 steps), and zero fresh-edit successes (all red collisions, mean length 33.15625). The separate 256-episode stream has the same categorical outcomes. These controls support the reconstructed evaluator; the new response did not reproduce the author's success.

The reconstructed published car actor is numerically equal to the released actor in every float64 entry, but 3,145 entries differ only in the sign of zero: release -0.0 versus reconstruction +0.0. Do not describe this as bitwise or byte-exact equality to the released archive. The 6,073 changed-entry count is unchanged.

General parser review found nondecimal literals and mixed boolean/numeric lists were accepted despite the prompt's decimal-only grammar. The implementer tightened these checks and added a regression test. Neither frozen reply contains such values; reviewed parser outputs match the evaluated tensors, so no episode rerun is required. The actual runtime parser is archived separately with its original hash.


"""Bounded CPU feasibility measurement, not a reported PPO baseline."""
import os

os.environ['OMP_NUM_THREADS'] = '1'
os.environ['OPENBLAS_NUM_THREADS'] = '1'
os.environ['CUDA_VISIBLE_DEVICES'] = ''

import argparse
import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
import time

import numpy as np
import torch
from torch import nn
from torch.distributions import Categorical
from minatar import Environment

from exp5_evaluate import observation


def network(output, gain):
    layers = []
    for index, (a, b) in enumerate(((600, 32), (32, 32), (32, output))):
        layer = nn.Linear(a, b)
        nn.init.orthogonal_(layer.weight, gain=gain if index == 2 else 2 ** .5)
        nn.init.zeros_(layer.bias)
        layers.append(layer)
        if index < 2:
            layers.append(nn.Tanh())
    return nn.Sequential(*layers)


def benchmark(game, iterations):
    torch.manual_seed(20261102)
    rng = np.random.default_rng(20261102)
    actor, critic = network(6, .01), network(1, 1.)
    parameters = list(actor.parameters()) + list(critic.parameters())
    optimizer = torch.optim.Adam(parameters, lr=5e-4, eps=1e-5)
    envs = [Environment(game, sticky_action_prob=.1, difficulty_ramping=True) for _ in range(64)]
    for i, env in enumerate(envs):
        env.seed(20261102 + i)
        env.reset()
    lengths = np.zeros(64, dtype=np.int64)
    current = torch.tensor(np.stack([observation(env) for env in envs]))
    done = torch.zeros(64)
    records = []
    for iteration in range(iterations + 1):
        start = time.perf_counter()
        observations = torch.empty((128, 64, 600))
        actions = torch.empty((128, 64), dtype=torch.int64)
        logps, rewards, dones, values = (torch.empty((128, 64)) for _ in range(4))
        for step in range(128):
            observations[step], dones[step] = current, done
            with torch.no_grad():
                dist = Categorical(logits=actor(current))
                action = dist.sample()
                actions[step], logps[step], values[step] = action, dist.log_prob(action), critic(current).flatten()
            next_states, terminals, step_rewards = [], [], []
            for index, (env, choice) in enumerate(zip(envs, action.tolist())):
                reward, terminal = env.act(choice)
                lengths[index] += 1
                terminal = terminal or lengths[index] >= 10000
                if terminal:
                    env.reset()
                    env.last_action = 0
                    lengths[index] = 0
                next_states.append(observation(env))
                terminals.append(terminal)
                step_rewards.append(reward)
            current = torch.tensor(np.stack(next_states))
            done = torch.tensor(terminals, dtype=torch.float32)
            rewards[step] = torch.tensor(step_rewards)
        rollout_s = time.perf_counter() - start
        with torch.no_grad():
            next_value = critic(current).flatten()
            advantages = torch.empty_like(rewards)
            tail = torch.zeros(64)
            for step in reversed(range(128)):
                live = 1 - (done if step == 127 else dones[step + 1])
                future = next_value if step == 127 else values[step + 1]
                delta = rewards[step] + .99 * future * live - values[step]
                tail = delta + .99 * .95 * live * tail
                advantages[step] = tail
            returns = advantages + values
        flat_obs = observations.reshape(8192, 600)
        flat_actions, flat_logps, flat_adv, flat_returns, flat_values = (
            x.flatten() for x in (actions, logps, advantages, returns, values))
        for _ in range(4):
            order = rng.permutation(8192)
            for begin in range(0, 8192, 1024):
                ix = order[begin:begin + 1024]
                dist = Categorical(logits=actor(flat_obs[ix]))
                ratio = (dist.log_prob(flat_actions[ix]) - flat_logps[ix]).exp()
                adv = flat_adv[ix]
                adv = (adv - adv.mean()) / (adv.std() + 1e-8)
                policy_loss = torch.maximum(-adv * ratio, -adv * ratio.clamp(.8, 1.2)).mean()
                predicted = critic(flat_obs[ix]).flatten()
                clipped = flat_values[ix] + (predicted - flat_values[ix]).clamp(-.2, .2)
                value_loss = .5 * torch.maximum((predicted - flat_returns[ix]) ** 2,
                                                (clipped - flat_returns[ix]) ** 2).mean()
                loss = policy_loss + .5 * value_loss - .01 * dist.entropy().mean()
                assert torch.isfinite(loss)
                optimizer.zero_grad()
                loss.backward()
                nn.utils.clip_grad_norm_(parameters, .5)
                optimizer.step()
        total_s = time.perf_counter() - start
        records.append({'iteration': iteration, 'warmup': iteration == 0, 'steps': 8192,
                        'rollout_s': rollout_s, 'update_and_gae_s': total_s - rollout_s,
                        'total_s': total_s, 'steps_per_second': 8192 / total_s})
    measured = records[1:]
    return {'game': game, 'records': records,
            'steps_per_second': sum(x['steps'] for x in measured) / sum(x['total_s'] for x in measured),
            'training_steps_including_warmup': (iterations + 1) * 8192}


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--iterations', type=int, default=5)
    args = p.parse_args()
    assert 1 <= args.iterations <= 10
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    result = {'purpose': 'Bounded throughput estimate only; no checkpoint saved or baseline score claimed.',
              'versions': {'python': platform.python_version(), 'torch': torch.__version__,
                           'numpy': np.__version__, 'minatar': importlib.metadata.version('MinAtar')},
              'cpu_threads': 1, 'cpu_count': os.cpu_count(), 'load_before': os.getloadavg(),
              'benchmark_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'observation_source_sha256': hashlib.sha256(Path(__file__).with_name('exp5_evaluate.py').read_bytes()).hexdigest(),
              'protocol': {'envs': 64, 'rollout_steps': 128, 'epochs': 4, 'minibatches': 8,
                           'actor': [600, 32, 32, 6], 'critic': [600, 32, 32, 1],
                           'sticky': .1, 'difficulty_ramping': True, 'cap': 10000,
                           'lr': .0005, 'annealing': 'constant LR in short timing sample',
                           'optimizer': 'Adam eps1e-5', 'gamma': .99, 'gae_lambda': .95,
                           'clip': .2, 'entropy': .01, 'value_coefficient': .5,
                           'value_clipping': True, 'advantage_normalization': True, 'max_grad_norm': .5,
                           'seed': 20261102, 'device': 'cpu', 'env_execution': '64 serial MinAtar instances'},
              'cases': []}
    for game in ('breakout', 'seaquest', 'asterix'):
        case = benchmark(game, args.iterations)
        result['cases'].append(case)
        args.output.write_text(json.dumps(result, indent=2) + '\n')
        print(game, case['steps_per_second'], flush=True)
    result['load_after'] = os.getloadavg()
    args.output.write_text(json.dumps(result, indent=2) + '\n')


if __name__ == '__main__':
    main()

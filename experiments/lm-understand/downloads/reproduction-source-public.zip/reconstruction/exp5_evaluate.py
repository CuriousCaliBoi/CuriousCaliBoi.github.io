"""Reconstruct and evaluate Experiment 5's published and fresh policy replies."""
import os

os.environ['OPENBLAS_NUM_THREADS'] = '1'
os.environ['OMP_NUM_THREADS'] = '1'

import argparse
import ast
from concurrent.futures import ProcessPoolExecutor
import hashlib
import importlib
import importlib.metadata
import inspect
import io
import json
from pathlib import Path
import platform
import re
import time
import tokenize

import numpy as np
from minatar import Environment

GAMES = ('breakout', 'seaquest', 'asterix')
SHAPES = {'W1': (600, 32), 'b1': (32,), 'W2': (32, 32), 'b2': (32,), 'W3': (32, 6), 'b3': (6,)}
NPZ_KEYS = dict(zip(SHAPES, ('actor/dense1/kernel', 'actor/dense1/bias', 'actor/dense2/kernel',
                           'actor/dense2/bias', 'actor/logits/kernel', 'actor/logits/bias')))
CHANNELS = {
    'breakout': (('paddle',), (), ('brick',), ('ball',), ('trail',), ()),
    'seaquest': (('sub_front', 'sub_back'), ('enemy_fish', 'enemy_sub', 'enemy_bullet'),
                 ('enemy_fish', 'enemy_sub', 'diver'), ('friendly_bullet',),
                 ('trail', 'sub_back'), ('oxygen_guage', 'diver_guage')),
    'asterix': (('player',), ('enemy',), ('gold',), (), ('trail',), ()),
}
NEW_STATEMENT = re.compile(r'^[A-Za-z_]\w*\s*(?:\[|[-+*]?=)')
DECIMAL = re.compile(r'(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?\Z')
_weights = {}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def last_block(text):
    starts = list(re.finditer(r'(?m)^```edits[ \t]*\r?\n', text))
    if not starts:
        return None, False
    tail = text[starts[-1].end():]
    end = tail.find('```')
    return (tail, True) if end < 0 else (tail[:end], False)


def statements(block):
    pending = []
    balance = 0
    for line in block.splitlines():
        line = line.split('#', 1)[0].strip()
        if not line:
            continue
        if pending and NEW_STATEMENT.match(line):
            yield ' '.join(pending)
            pending, balance = [], 0
        pending.append(line)
        balance += line.count('[') - line.count(']')
        if balance <= 0:
            yield ' '.join(pending)
            pending, balance = [], 0
    if pending:
        yield ' '.join(pending)


def numeric(node):
    value = ast.literal_eval(node)

    def allowed(x):
        return type(x) in (int, float) or isinstance(x, list) and all(allowed(v) for v in x)

    if not allowed(value):
        raise ValueError('Only numeric literals and nested lists are allowed')
    array = np.asarray(value, dtype=np.float64)
    if not np.isfinite(array).all() or np.any(np.abs(array) > 1e6):
        raise ValueError('Numeric literals must be finite and have absolute value at most 1e6')
    return array


def index(node):
    if isinstance(node, ast.Tuple):
        return tuple(index(n) for n in node.elts)
    if isinstance(node, ast.Slice):
        return slice(*(index(n) if n is not None else None for n in (node.lower, node.upper, node.step)))
    value = ast.literal_eval(node)
    if type(value) is not int:
        raise ValueError('Indices must be integers or slices')
    return value


def apply_statement(weights, text):
    for token in tokenize.generate_tokens(io.StringIO(text).readline):
        if token.type == tokenize.NUMBER and not DECIMAL.fullmatch(token.string):
            raise ValueError('Only decimal numeric literals are allowed')
    parsed = ast.parse(text).body
    if len(parsed) != 1:
        raise ValueError('One edit statement per line is required')
    statement = parsed[0]
    if isinstance(statement, ast.Assign) and len(statement.targets) == 1:
        target = statement.targets[0]
        operation = None
    elif isinstance(statement, ast.AugAssign) and isinstance(statement.op, (ast.Add, ast.Sub, ast.Mult)):
        target, operation = statement.target, statement.op
    else:
        raise ValueError('Unsupported edit statement')
    if not isinstance(target, ast.Subscript) or not isinstance(target.value, ast.Name):
        raise ValueError('Edits must index a named tensor')
    name = target.value.id
    if name not in weights:
        raise ValueError('Unknown tensor ' + name)
    ix = index(target.slice)
    current = weights[name][ix]
    value = numeric(statement.value)
    if isinstance(operation, ast.Add):
        value = current + value
    elif isinstance(operation, ast.Sub):
        value = current - value
    elif isinstance(operation, ast.Mult):
        value = current * value
    with np.errstate(over='raise', invalid='raise'):
        replacement = np.broadcast_to(value, np.shape(current)).astype(np.float32)
    if not np.isfinite(replacement).all():
        raise ValueError('Edit would produce nonfinite weights')
    weights[name][ix] = replacement


def read_reply(text):
    weights = {key: np.zeros(shape, np.float32) for key, shape in SHAPES.items()}
    block, cut_off = last_block(text)
    report = {'block_found': block is not None, 'cut_off': cut_off, 'statements': 0, 'applied': 0, 'errors': []}
    for number, statement in enumerate(statements(block or ''), 1):
        report['statements'] += 1
        try:
            apply_statement(weights, statement)
            report['applied'] += 1
        except (ValueError, SyntaxError, TypeError, IndexError, OverflowError, FloatingPointError, tokenize.TokenError) as error:
            report['errors'].append({'statement': number, 'text': statement, 'error': str(error)})
    report['parameters'] = sum(a.size for a in weights.values())
    report['nonzero'] = sum(int(np.count_nonzero(a)) for a in weights.values())
    return weights, report


def prepare(source, fresh, out):
    out.mkdir(parents=True, exist_ok=True)
    reports = {'source_revision': '4d09ba6d6a7e891dd8063974dfe81b3d78e3494f', 'cases': {}}
    assert importlib.metadata.version('MinAtar') == '1.0.15'
    for game in GAMES:
        src = source / 'exp5_write_from_scratch'
        prompt = src / f'runs/{game}/reply/prompt.txt'
        env_module = importlib.import_module('minatar.environments.' + game)
        env_path = Path(inspect.getsourcefile(env_module))
        assert env_path.read_bytes() in prompt.read_bytes(), game
        published_archive = src / f'networks/{game}/hand.npz'
        with np.load(published_archive, allow_pickle=False) as archive:
            expected = {key: archive[value] for key, value in NPZ_KEYS.items()}
        for kind, answer in (
            ('released', src / f'runs/{game}/reply/answer.md'),
            ('fresh', fresh / f'runs/{game}/reply/answer.md'),
        ):
            weights, report = read_reply(answer.read_text())
            if not report['block_found']:
                raise ValueError('Reply has no edits block: ' + str(answer))
            if kind == 'released':
                matches = {k: bool(np.array_equal(weights[k], expected[k])) for k in SHAPES}
                published_apply = json.loads((src / f'runs/{game}/apply.json').read_text())
                assert all(matches.values()), (game, matches)
                assert report['statements'] == published_apply['edit_report']['statements']
                assert not report['errors'] and report['nonzero'] == published_apply['nonzero_total']
                report['released_tensor_bytes_match'] = all(weights[k].tobytes() == expected[k].tobytes() for k in SHAPES)
            case = f'{game}.{kind}'
            path = out / (case + '.npz')
            if path.exists():
                with np.load(path, allow_pickle=False) as existing:
                    assert all(np.array_equal(existing[NPZ_KEYS[k]], weights[k]) for k in SHAPES), case
            else:
                np.savez(path, **{NPZ_KEYS[k]: v for k, v in weights.items()})
            report.update(reply_sha256=sha(answer), prompt_sha256=sha(prompt), weights_sha256=sha(path),
                          original_weights_sha256=sha(published_archive), game_source_sha256=sha(env_path),
                          game_source_exactly_matches_prompt=True)
            reports['cases'][case] = report
            print(json.dumps({'case': case, 'applied': report['applied'], 'errors': report['errors'],
                              'nonzero': report['nonzero'], 'released_exact': report.get('released_tensor_bytes_match')}), flush=True)
    (out / 'parse-validation.json').write_text(json.dumps(reports, indent=2) + '\n')


def observation(env):
    state = env.state()
    result = np.zeros((10, 10, 6), np.float32)
    for channel, sources in enumerate(CHANNELS[env.env_name]):
        for name in sources:
            np.maximum(result[:, :, channel], state[:, :, env.env.channels[name]], out=result[:, :, channel])
    return result.reshape(600)


def episode(job):
    case, weights_path, number, seed, cap = job
    game, kind = case.split('.')
    if weights_path not in _weights:
        with np.load(weights_path, allow_pickle=False) as archive:
            _weights[weights_path] = tuple(archive[k] for k in NPZ_KEYS.values())
    w1, b1, w2, b2, w3, b3 = _weights[weights_path]
    environment_seed, action_seed = map(int, np.random.SeedSequence([seed, GAMES.index(game), number]).generate_state(2))
    env = Environment(game, sticky_action_prob=0.1, difficulty_ramping=True)
    env.seed(environment_seed)
    env.reset()
    env.last_action = 0
    rng = np.random.default_rng(action_seed)
    total = 0.0
    for step in range(1, cap + 1):
        logits = np.tanh(np.tanh(observation(env) @ w1 + b1) @ w2 + b2) @ w3 + b3
        probabilities = np.exp(logits.astype(np.float64) - float(logits.max()))
        probabilities /= probabilities.sum()
        action = int(rng.choice(6, p=probabilities))
        reward, done = env.act(action)
        total += reward
        if done:
            break
    return {'case': case, 'episode': number, 'environment_seed': environment_seed, 'action_seed': action_seed,
            'score': total, 'steps': step, 'terminal': bool(done), 'truncated': bool(not done and step == cap)}


def evaluate(source, out, episodes, workers, seed, max_steps):
    assert importlib.metadata.version('MinAtar') == '1.0.15'
    validation = json.loads((out / 'parse-validation.json').read_text())
    published = json.loads((source / 'exp5_write_from_scratch/eval/minatar_eval.json').read_text())
    protocol = {
        'episodes_per_case': episodes, 'master_seed': seed, 'max_steps': max_steps,
        'minatar': importlib.metadata.version('MinAtar'), 'numpy': np.__version__, 'python': platform.python_version(),
        'platform': platform.platform(), 'inference_dtype': 'float32', 'softmax_dtype': 'float64',
        'sticky_action_probability': 0.1, 'difficulty_ramping': True,
        'action_selection': 'numpy Generator.choice on the softmax over all six logits',
        'seeding': 'SeedSequence([master_seed, game_index, episode_index]).generate_state(2); first uint32 for environment, second for action Generator; same seeds for fresh and released policies.',
        'episode_reset': 'New Environment per episode; seed, reset, wrapper.last_action=0.',
        'channels': CHANNELS, 'script_sha256': sha(__file__),
        'deviations': [
            'Author edit parser and evaluation wrapper unavailable; independently reconstructed from published prompts.',
            'Original RNG streams, reset conventions and NumPy version unavailable. This run uses fixed documented per-episode seeds, fresh Environment objects, last_action=0, and the recorded NumPy version.',
            'Float64 softmax normalization is selected explicitly; original evaluator arithmetic details are unpublished.',
        ],
    }
    protocol_path = out / 'protocol.json'
    encoded = json.dumps(protocol, indent=2)
    if protocol_path.exists() and protocol_path.read_text() != encoded + '\n':
        raise ValueError('Protocol differs from existing run; use a new output directory')
    protocol_path.write_text(encoded + '\n')
    results = []
    with ProcessPoolExecutor(max_workers=workers) as pool:
        for game in GAMES:
            for kind in ('released', 'fresh'):
                started = time.monotonic()
                case = game + '.' + kind
                weights_path = out / (case + '.npz')
                assert sha(weights_path) == validation['cases'][case]['weights_sha256']
                episode_path = out / (case + '.episodes.jsonl')
                rows = [json.loads(line) for line in episode_path.read_text().splitlines()] if episode_path.exists() else []
                finished = {row['episode'] for row in rows}
                assert len(finished) == len(rows) and all(0 <= i < episodes for i in finished)
                jobs = [(case, str(weights_path), i, seed, max_steps) for i in range(episodes) if i not in finished]
                print(f'{case}: {len(rows)}/{episodes} saved, starting {len(jobs)} episodes', flush=True)
                with episode_path.open('a') as stream:
                    for row in pool.map(episode, jobs, chunksize=4):
                        rows.append(row)
                        stream.write(json.dumps(row) + '\n')
                        stream.flush()
                        if len(rows) % 100 == 0:
                            print(f'{case}: {len(rows)}/{episodes}', flush=True)
                scores = np.array([row['score'] for row in rows], np.float64)
                se = float(scores.std(ddof=1) / np.sqrt(episodes))
                ref = published[game]['hand']
                result = {'case': case, 'kind': 'fresh_evaluation_of_' + kind + '_policy',
                          'episodes': len(rows), 'mean': float(scores.mean()), 'se': se,
                          'approx_95pct_ci': [float(scores.mean() - 1.96 * se), float(scores.mean() + 1.96 * se)],
                          'max': float(scores.max()), 'mean_length': float(np.mean([row['steps'] for row in rows])),
                          'truncated_episodes': sum(row['truncated'] for row in rows),
                          'seconds_this_invocation': round(time.monotonic() - started, 2),
                          'weights_sha256': sha(weights_path), 'reply_sha256': validation['cases'][case]['reply_sha256'],
                          'protocol_sha256': sha(protocol_path), 'episode_data_sha256': sha(episode_path),
                          'published_author_policy_result': ref,
                          'difference_from_published_author_policy_mean': float(scores.mean() - ref['mean'])}
                (out / (case + '.json')).write_text(json.dumps(result, indent=2) + '\n')
                results.append(result)
                print(json.dumps(result), flush=True)
    (out / 'summary.json').write_text(json.dumps({'protocol': protocol, 'results': results}, indent=2) + '\n')


def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument('command', choices=('prepare', 'evaluate'))
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--fresh', type=Path)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--episodes', type=int, default=1000)
    parser.add_argument('--workers', type=int, default=8)
    parser.add_argument('--seed', type=int, default=20261102)
    parser.add_argument('--max-steps', type=int, default=10000)
    args = parser.parse_args()
    if args.command == 'prepare':
        if args.fresh is None:
            parser.error('--fresh is required for prepare')
        prepare(args.source, args.fresh, args.out)
    else:
        if args.episodes < 2 or args.workers < 1 or args.max_steps < 1:
            parser.error('At least two episodes, one worker and one step are required')
        evaluate(args.source, args.out, args.episodes, args.workers, args.seed, args.max_steps)


if __name__ == '__main__':
    main()

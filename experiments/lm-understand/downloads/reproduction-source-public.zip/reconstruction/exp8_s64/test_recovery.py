import hashlib
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

import numpy as np
from safetensors.torch import save_file
import torch

import controller
import resource_profile as resource
from backend import build_checkpoint, complete, paired, publish_directory, publish_file, verify_cached
from edits import EditStore
from kernel_manager import durable_run
from protocol import canonical
from session_api import stage_practice, finalize
from activations import aggregate


class RecoveryTests(unittest.TestCase):
    def setUp(self):
        self.temporary = TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.model, self.work = self.root / 'model', self.root / 'work'
        self.model.mkdir()
        self.work.mkdir()
        self.name = 'model.layers.0.mlp.down_proj.weight'
        save_file({self.name: torch.tensor([[1., 2.], [3., 4.]], dtype=torch.bfloat16)}, self.model / 'model.safetensors')
        self.store = EditStore(self.model, self.work, 'gemma')

    def tearDown(self):
        self.temporary.cleanup()

    def test_cached_receipt_verifies_request_edits_base_and_response(self):
        artifact = self.root / 'artifact'
        artifact.mkdir()
        request = {'type': 'generate', 'model': 'original', 'prompts': ['x']}
        base_sha256 = hashlib.sha256((self.model / 'model.safetensors').read_bytes()).hexdigest()
        signature = resource.request_signature(request, self.store.snapshot()['sha256'], base_sha256)
        manifest = {'request_signature': signature, 'execution_profile': resource.identity(), 'edits': self.store.snapshot(), 'base_checkpoint_sha256': base_sha256}
        response = {'ok': True, 'generations': 1}
        complete(artifact, manifest, response)
        self.assertEqual(verify_cached(artifact, self.model, self.work, 'gemma', signature), response)
        altered = {**manifest, 'execution_profile': {'id': 'legacy'}}
        (artifact / 'manifest.json').write_text(json.dumps(altered))
        with self.assertRaisesRegex(ValueError, 'different execution profile'):
            verify_cached(artifact, self.model, self.work, 'gemma', signature)
        (artifact / 'manifest.json').write_text(json.dumps(manifest))
        with self.assertRaises(ValueError):
            verify_cached(artifact, self.model, self.work, 'gemma', 'wrong-signature')
        value = self.store.original(self.name)
        value[0, 0] += 1
        self.store.save(self.name, value)
        with self.assertRaises(ValueError):
            verify_cached(artifact, self.model, self.work, 'gemma', signature)
        self.store.drop(self.name)
        (artifact / 'response.json').write_text('{"ok":false}')
        with self.assertRaises(ValueError):
            verify_cached(artifact, self.model, self.work, 'gemma', signature)

    def test_controller_completed_forward_is_verified_without_worker(self):
        request, response = {'type': 'generate'}, {'ok': True}
        (self.root / 'forward-request.json').write_text(json.dumps(request))
        (self.root / 'forward-result.json').write_text(json.dumps(response))
        with patch.object(controller, 'remote_api', return_value=response) as verify, patch.object(controller.subprocess, 'run') as worker:
            self.assertEqual(controller.forward('p10c', 'qwen', request, self.root, 1, 'signature'), response)
            verify.assert_called_once_with('p10c', 'qwen', 'verify_forward', index=1, signature='signature')
            worker.assert_not_called()

    def test_old_epoch_request_is_not_executed_again(self):
        identity, code = 'a' * 32, 'counter += 1'
        old = self.root / 'kernels/old/queue'
        old.mkdir(parents=True)
        (old / (identity + '.json')).write_text(json.dumps({'id': identity, 'code': code}))
        record = {'epoch': 'new', 'container': 'new-kernel'}
        (self.root / 'kernel.json').write_text(json.dumps(record))
        with patch('kernel_manager.run') as run, patch('kernel_manager.subprocess.run') as inspect:
            inspect.return_value.returncode = 0
            inspect.return_value.stdout = 'true'
            result = durable_run(self.root, code, identity)
            self.assertEqual(result['error'], 'KernelStopped')
            self.assertTrue(result['kernel_restarted'])
            run.assert_not_called()
            self.assertEqual(durable_run(self.root, code, identity), result)

    def test_disconnected_kernel_restart_notifies_before_execution(self):
        (self.root / 'kernel.json').write_text(json.dumps({'epoch': 'new', 'container': 'new-kernel'}))
        (self.root / 'pending-kernel-notice.json').write_text('{"epoch":"new"}')
        with patch('kernel_manager.run') as run:
            result = durable_run(self.root, 'missing_variable += 1', 'c' * 32)
            self.assertEqual(result['error'], 'KernelRestarted')
            self.assertFalse(result['executed'])
            run.assert_not_called()
            self.assertFalse((self.root / 'pending-kernel-notice.json').exists())
            self.assertEqual(durable_run(self.root, 'missing_variable += 1', 'c' * 32), result)

    def test_publication_symlinks_and_directory_retry(self):
        source, victim = self.root / 'source', self.root / 'victim'
        source.write_text('output')
        victim.write_text('preserve')
        (self.work / 'result').symlink_to(victim)
        with self.assertRaises(ValueError):
            publish_file(source, self.work, 'result')
        self.assertEqual(victim.read_text(), 'preserve')
        folder = self.root / 'folder'
        folder.mkdir()
        (folder / 'value').write_text('x')
        publish_directory(folder, self.work, 'arrays')
        publish_directory(folder, self.work, 'arrays')
        (self.work / 'arrays/value').write_text('changed')
        with self.assertRaises(ValueError):
            publish_directory(folder, self.work, 'arrays')

    def test_postcast_overflow_rejected(self):
        value = self.store.original(self.name)
        value[0, 0] = torch.finfo(torch.float32).max
        self.store.save(self.name, value)
        with self.assertRaisesRegex(ValueError, 'storage dtype'):
            build_checkpoint(self.model, self.store, self.store.snapshot(), self.root / 'checkpoint')

    def test_gemma_practice_excludes_aime(self):
        source = self.root / 'practice-source'
        source.mkdir()
        for name in ('gsm8k.jsonl', 'math.jsonl', 'aime.jsonl'):
            (source / name).write_text('{}\n')
        destination = stage_practice(self.root, source, 'gemma')
        self.assertEqual({p.name for p in destination.iterdir()}, {'gsm8k.jsonl', 'math.jsonl'})

    def test_final_submission_retry_preserves_directory_and_hashes(self):
        value = self.store.original(self.name)
        value[0, 0] += 1
        self.store.save(self.name, value)
        snapshot = self.store.snapshot()
        result = finalize(self.root, self.store, snapshot)
        self.assertEqual(finalize(self.root, self.store, snapshot), result)
        self.assertTrue(Path(result['directory']).is_dir())
        self.store.drop(self.name)
        with self.assertRaises(ValueError):
            finalize(self.root, self.store, self.store.snapshot())

    def test_activation_mean_caps_at_8192_and_handles_empty(self):
        values = np.ones((8200, 2), dtype=np.float16)
        values[0] = 7
        values[8193:] = 100
        last, mean = aggregate(values, 1, 8199)
        np.testing.assert_array_equal(last, [7, 7])
        np.testing.assert_array_equal(mean, [1, 1])
        np.testing.assert_array_equal(aggregate(values, 1, 0)[1], [0, 0])

    def test_paired_standard_error_uses_items(self):
        original = [{'id': i, 'sample': j, 'seed': j, 'correct': False} for i in ('a', 'b') for j in range(2)]
        edited = [{**r, 'correct': r['id'] == 'a'} for r in original]
        result = paired(original, edited)
        self.assertEqual(result['accuracy_difference'], .5)
        self.assertAlmostEqual(result['standard_error'], .5)
        self.assertEqual(result['samples_wrong_to_right'], 2)


if __name__ == '__main__':
    unittest.main()

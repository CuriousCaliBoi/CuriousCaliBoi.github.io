import json
import fcntl
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
import subprocess
import sys
import time
import unittest
from unittest.mock import patch

import resource_profile as resource
import test_capacity


class ResourceTests(unittest.TestCase):
    def test_active_cases_and_legacy_session_are_rejected(self):
        for case, profile in [('p10c', 'qwen'), ('p25c', 'qwen'), ('g05b', 'gemma'), ('p50c', 'gemma')]:
            with self.assertRaises(ValueError):
                resource.check_case(case, profile)
        resource.check_case('p50c', 'qwen')
        resource.check_case('g10b', 'gemma')
        with self.assertRaises(ValueError):
            resource.check_session(Path(resource.CONFIG['legacy_session_root']) / 'p50c', 'qwen')

    def test_prepared_legacy_is_allowed_but_started_is_rejected(self):
        with TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / 'manifest.json').write_text('{}')
            resource.check_legacy_unstarted(root)
            (root / 'turns/t001').mkdir(parents=True)
            with self.assertRaises(ValueError):
                resource.check_legacy_unstarted(root)

    def test_receipts_bind_base_edits_source_and_configuration(self):
        request = {'type': 'generate', 'prompts': ['x']}
        old = resource.request_signature(request, 'edits', 'base')
        self.assertNotEqual(old, resource.request_signature(request, 'edits', 'changed-base'))
        self.assertNotEqual(old, resource.request_signature(request, 'changed-edits', 'base'))
        with patch.object(resource, 'identity', return_value={'id': 'other'}):
            self.assertNotEqual(old, resource.request_signature(request, 'edits', 'base'))
        with patch.object(resource, 'CONFIG_SHA256', 'changed'):
            with self.assertRaises(ValueError):
                resource.identity()

    def test_startup_requires_architecture_capacity_and_immutable_review(self):
        with TemporaryDirectory() as temporary:
            root = Path(temporary)
            setup = {'scripts': {'x.py': 'hash'}, 'profile': 'gemma', 'base_sha256': 'gemma-base'}
            (root / 'manifest.json').write_text(json.dumps(setup))
            evidence = {'passed': True, 'profile': 'gemma', 'execution_profile': resource.identity(),
                        'model_sha256': 'gemma-base', 'max_num_seqs': 64, 'max_model_len': 10240,
                        'gpu_memory_utilization': .35, 'kv_cache_max_concurrency': 65}
            def write_review():
                (root / 'capacity-evidence.json').write_text(json.dumps(evidence))
                review = {'approved': True, 'case_manifest_sha256': resource.digest(root / 'manifest.json'),
                          'scripts': setup['scripts'], 'execution_profile': resource.identity(),
                          'capacity_evidence_sha256': resource.digest(root / 'capacity-evidence.json')}
                (root / 'startup-review.json').write_text(json.dumps(review))
            write_review()
            resource.check_startup(root, setup)
            resource.check_startup(root, setup)
            evidence['profile'] = 'qwen'
            write_review()
            with self.assertRaisesRegex(ValueError, 'architecture-specific'):
                resource.check_startup(root, setup)
            evidence['profile'] = 'gemma'
            evidence['kv_cache_max_concurrency'] = 70
            write_review()
            with self.assertRaisesRegex(ValueError, 'changed during'):
                resource.check_startup(root, setup)

    def test_actual_capacity_failure_has_no_fallback(self):
        with TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / 'model.safetensors').write_bytes(b'model')
            config = SimpleNamespace(cache_config=SimpleNamespace(kv_cache_max_concurrency=63.9,
                                      kv_cache_size_tokens=1, gpu_memory_utilization=.35),
                                      scheduler_config=SimpleNamespace(max_num_seqs=64),
                                      model_config=SimpleNamespace(max_model_len=34816))
            llm = SimpleNamespace(llm_engine=SimpleNamespace(vllm_config=config))
            self.assertFalse(resource.capacity_report(llm, 'qwen', root)['passed'])
            self.assertTrue(resource.capacity_report(llm, 'qwen', root, 32)['passed'])
            config.cache_config.kv_cache_max_concurrency = 97.18
            self.assertTrue(resource.capacity_report(llm, 'qwen', root)['passed'])
            config.model_config.max_model_len = 32768
            reduced = resource.capacity_report(llm, 'qwen', root)
            self.assertFalse(reduced['passed'])
            self.assertEqual(reduced['requested_max_model_len'], 34816)
            self.assertEqual(reduced['max_model_len'], 32768)
        self.assertEqual(str(resource.GPU_LOCK), '<gpu-project>/reconstructed/exp8/gpu.lock')

    def test_capacity_parent_holds_lock_through_worker_without_loading_model(self):
        with TemporaryDirectory() as temporary:
            root = Path(temporary)
            review = {'approved_capacity_initialization': True, 'execution_profile': resource.identity(),
                      'script_sha256': resource.digest(test_capacity.__file__), 'profile': 'qwen',
                      'model': str((root / 'model').resolve()), 'model_sha256': resource.CONFIG['base_model_sha256']['qwen'],
                      'output': str((root / 'report.json').resolve())}
            (root / 'review.json').write_text(json.dumps(review))
            argv = ['test_capacity', '--profile', 'qwen', '--model', str(root / 'model'),
                    '--output', str(root / 'report.json'), '--review', str(root / 'review.json')]
            lock_path = root / 'shared.lock'
            def worker(command, check, pass_fds):
                self.assertTrue(check)
                self.assertEqual(command[-1], '--gpu-worker')
                self.assertEqual(len(pass_fds), 1)
                with lock_path.open('a') as other:
                    with self.assertRaises(BlockingIOError):
                        fcntl.flock(other, fcntl.LOCK_EX | fcntl.LOCK_NB)
            with patch('sys.argv', argv), patch.object(resource, 'GPU_LOCK', lock_path), patch.object(test_capacity, 'verify_model'), patch.object(test_capacity, 'configure_environment') as environment, patch.object(test_capacity.subprocess, 'run', side_effect=worker) as process:
                test_capacity.main()
                process.assert_called_once()
                environment.assert_not_called()
            with lock_path.open('a') as other:
                fcntl.flock(other, fcntl.LOCK_EX | fcntl.LOCK_NB)
            for field, value in [('profile', 'gemma'), ('model', 'other'), ('model_sha256', 'other'), ('output', 'other')]:
                (root / 'review.json').write_text(json.dumps({**review, field: value}))
                with patch('sys.argv', argv), patch.object(test_capacity, 'verify_model') as verify:
                    with self.assertRaises(ValueError):
                        test_capacity.main()
                    verify.assert_not_called()
            (root / 'review.json').write_text(json.dumps(review))
            (root / 'report.json').write_text('retained')
            with patch('sys.argv', argv), patch.object(test_capacity, 'verify_model') as verify:
                with self.assertRaisesRegex(ValueError, 'already exists'):
                    test_capacity.main()
                verify.assert_not_called()

    def test_orphaned_gpu_child_retains_lock_until_exit(self):
        with TemporaryDirectory() as temporary:
            root = Path(temporary)
            lock_path, ready, release = root / 'lock', root / 'ready', root / 'release'
            child = ('from pathlib import Path\nimport time\n'
                     f'Path({str(ready)!r}).write_text("ready")\n'
                     'deadline=time.monotonic()+10\n'
                     f'while not Path({str(release)!r}).exists() and time.monotonic()<deadline: time.sleep(.01)\n')
            parent = ('import sys,fcntl\n'
                      f'sys.path.insert(0,{str(Path(resource.__file__).parent)!r})\n'
                      'import resource_profile as resource\n'
                      f'with open({str(lock_path)!r},"a") as lock:\n'
                      ' fcntl.flock(lock,fcntl.LOCK_EX)\n'
                      f' resource.run_gpu_child([sys.executable,"-c",{child!r}],lock,check=True)\n')
            process = subprocess.Popen([sys.executable, '-c', parent], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            try:
                deadline = time.monotonic() + 5
                while not ready.exists() and time.monotonic() < deadline:
                    time.sleep(.01)
                self.assertTrue(ready.exists())
                process.kill()
                process.wait(timeout=5)
                with lock_path.open('a') as other:
                    with self.assertRaises(BlockingIOError):
                        fcntl.flock(other, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    release.touch()
                    deadline = time.monotonic() + 5
                    while True:
                        try:
                            fcntl.flock(other, fcntl.LOCK_EX | fcntl.LOCK_NB)
                            break
                        except BlockingIOError:
                            if time.monotonic() >= deadline:
                                self.fail('Child did not release inherited lock after exiting')
                            time.sleep(.01)
            finally:
                release.touch()
                if process.poll() is None:
                    process.kill()
                    process.wait(timeout=5)


if __name__ == '__main__':
    unittest.main()

import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import time
import uuid
import resource_profile as resource

ROOT = resource.ROOT
ENV = Path('<gpu-python-environment>')
PYTHON_ROOT = Path('<gpu-home>/.local/share/uv/python/cpython-3.12.13-linux-aarch64-gnu')


def start(session, model, practice, profile):
    session = Path(session).resolve()
    session.mkdir(parents=True, exist_ok=True)
    (session / 'work').mkdir(exist_ok=True)
    previous = session / 'kernel.json'
    if previous.exists():
        old = json.loads(previous.read_text())
        running = subprocess.run(['docker', 'inspect', old['container'], '--format', '{{.State.Running}}'], capture_output=True, text=True)
        if running.returncode == 0 and running.stdout.strip() == 'true':
            raise RuntimeError('A kernel is already running for this session')
    pin = ROOT / 'sandbox-image.json'
    if not pin.exists():
        image = subprocess.check_output(['docker', 'image', 'inspect', resource.CONFIG['docker_image_id'], '--format', '{{.Id}}'], text=True).strip()
        pin.write_text(json.dumps({'image_id': image}) + '\n')
    image = json.loads(pin.read_text())['image_id']
    if image != resource.CONFIG['docker_image_id']:
        raise ValueError('Kernel image differs from the reviewed immutable image')
    epoch = uuid.uuid4().hex
    queue = session / 'kernels' / epoch / 'queue'
    queue.mkdir(parents=True)
    name = 'lm-exp8-' + epoch
    cmd = ['docker', 'run', '-d', '--name', name, '--network', 'none', '--cap-drop', 'ALL',
           '--security-opt', 'no-new-privileges', '--read-only', '--user', '1000:1000',
           '--cpus', '8', '--memory', '96000000000', '--pids-limit', '256',
           '--tmpfs', '/tmp:rw,nosuid,mode=1777,size=536870912', '--workdir', '/work', '--entrypoint', '/usr/bin/env']
    mounts = [('/usr', '/usr', True), (str(PYTHON_ROOT), str(PYTHON_ROOT), True),
              (str(ENV), '/env', True), (resource.CONFIG['cpu_dependencies'], '/deps', True),
              (str(ROOT / 'code'), '/harness', True), (str(Path(model).resolve()), '/model', True),
              (str(Path(practice).resolve()), '/practice', True), (str(queue), '/queue', True),
              (str(session / 'work'), '/work', False)]
    for src, dst, readonly in mounts:
        cmd += ['--mount', f'type=bind,src={src},dst={dst}' + (',readonly' if readonly else '')]
    cmd += [image, '-i', 'HOME=/tmp', 'PATH=/usr/bin', 'OMP_NUM_THREADS=8', 'OPENBLAS_NUM_THREADS=8',
            'CUDA_VISIBLE_DEVICES=', 'EXP8_PROFILE=' + profile, 'EXP8_KERNEL_EPOCH=' + epoch, str(PYTHON_ROOT / 'bin/python3.12'), '-I', '/harness/kernel.py']
    subprocess.run(cmd, check=True, capture_output=True, text=True)
    record = {'container': name, 'image_id': image, 'command': cmd, 'started_unix': time.time(), 'profile': profile, 'epoch': epoch, 'queue_dir': str(queue),
              'model': str(model), 'practice': str(practice)}
    (session / 'kernel.json').write_text(json.dumps(record, indent=2) + '\n')
    ready = session / 'work/.kernel-replies' / epoch / 'ready.json'
    for _ in range(120):
        if ready.exists():
            result = json.loads(ready.read_text())
            if result['cuda_available'] or result['grad_enabled'] or result['epoch'] != epoch:
                raise RuntimeError('Kernel isolation preflight failed')
            return {**record, 'ready': result}
        state = subprocess.check_output(['docker', 'inspect', name, '--format', '{{.State.Running}}'], text=True).strip()
        if state != 'true':
            raise RuntimeError(subprocess.check_output(['docker', 'logs', name], stderr=subprocess.STDOUT, text=True))
        time.sleep(0.5)
    raise TimeoutError('Kernel did not become ready')


def run(session, code, identity=None):
    session = Path(session)
    record = json.loads((session / 'kernel.json').read_text())
    queue = Path(record['queue_dir'])
    identity = identity or uuid.uuid4().hex
    if len(identity) != 32 or any(c not in '0123456789abcdef' for c in identity):
        raise ValueError('Invalid kernel request identifier')
    request = {'id': identity, 'code': code}
    prior = queue / (identity + '.json')
    if prior.exists() and json.loads(prior.read_text()) != request:
        raise ValueError('Kernel request identity was reused with different code')
    temporary = queue / (identity + '.tmp')
    temporary.write_text(json.dumps(request))
    temporary.replace(queue / (identity + '.json'))
    response = session / 'work/.kernel-replies' / record['epoch'] / (identity + '.json')
    started = time.monotonic()
    polls = 0
    while time.monotonic() - started < 910:
        if response.exists():
            result = json.loads(response.read_text())
            assert result['id'] == identity and result['code_sha256'] == hashlib.sha256(code.encode()).hexdigest()
            return result
        polls += 1
        if polls % 10 == 0:
            state = subprocess.run(['docker', 'inspect', record['container'], '--format', '{{.State.Running}}'], capture_output=True, text=True)
            if state.returncode or state.stdout.strip() != 'true':
                return {'id': identity, 'code_sha256': hashlib.sha256(code.encode()).hexdigest(), 'error': 'KernelStopped',
                        'out': 'Kernel process stopped; variables were lost. Edits and work files remain.', 'seconds': round(time.monotonic() - started, 3)}
        time.sleep(0.2)
    record = json.loads((session / 'kernel.json').read_text())
    subprocess.run(['docker', 'kill', record['container']], check=True, capture_output=True)
    return {'id': identity, 'code_sha256': hashlib.sha256(code.encode()).hexdigest(),
            'out': 'Kernel stopped after timeout; variables were lost. Edits and work files remain.',
            'error': 'KernelTimeout', 'seconds': round(time.monotonic() - started, 3)}


def durable_run(session, code, identity):
    session = Path(session)
    if len(identity) != 32 or any(c not in '0123456789abcdef' for c in identity):
        raise ValueError('Invalid kernel request identifier')
    receipts = session / 'python-receipts'
    receipts.mkdir(exist_ok=True)
    receipt = receipts / (identity + '.json')
    code_hash = hashlib.sha256(code.encode()).hexdigest()
    if receipt.exists():
        result = json.loads(receipt.read_text())
        if result['code_sha256'] != code_hash:
            raise ValueError('Python receipt belongs to different code')
    else:
        record = json.loads((session / 'kernel.json').read_text())
        historical = list((session / 'kernels').glob('*/queue/' + identity + '.json'))
        result = None
        for old in historical:
            if json.loads(old.read_text()) != {'id': identity, 'code': code}:
                raise ValueError('Historical Python request belongs to different code')
            epoch = old.parent.parent.name
            reply = session / 'work/.kernel-replies' / epoch / (identity + '.json')
            if reply.exists():
                result = json.loads(reply.read_text())
                if result['code_sha256'] != code_hash:
                    raise ValueError('Historical Python reply belongs to different code')
                break
            if epoch != record['epoch']:
                result = {'id': identity, 'code_sha256': code_hash, 'error': 'KernelStopped',
                          'out': 'The prior kernel stopped before this request produced a durable reply. Its side effects may be partial; it will not be replayed.', 'seconds': None}
        pending_notice = session / 'pending-kernel-notice.json'
        if result is None and pending_notice.exists():
            result = {'id': identity, 'code_sha256': code_hash, 'error': 'KernelRestarted', 'executed': False,
                      'out': 'The kernel restarted while the controller was disconnected. Variables were lost; saved edits and work files remain. This block was not executed. Redefine variables before continuing.', 'seconds': 0}
        if result is None:
            result = run(session, code, identity)
        if result.get('error') == 'TimeoutError':
            result = {**result, 'error': 'KernelTimeout', 'kernel_epoch': record['epoch']}
        temporary = receipt.with_suffix('.tmp')
        temporary.write_text(json.dumps(result) + '\n')
        temporary.replace(receipt)
    if result.get('error') == 'KernelRestarted':
        (session / 'pending-kernel-notice.json').unlink(missing_ok=True)
    if result.get('error') in ('KernelStopped', 'KernelTimeout'):
        record = json.loads((session / 'kernel.json').read_text())
        state = subprocess.run(['docker', 'inspect', record['container'], '--format', '{{.State.Running}}'], capture_output=True, text=True)
        if result.get('error') == 'KernelTimeout' and result.get('kernel_epoch') == record['epoch'] and state.returncode == 0 and state.stdout.strip() == 'true':
            subprocess.run(['docker', 'kill', record['container']], check=True, capture_output=True)
            state.stdout = 'false'
        if state.returncode or state.stdout.strip() != 'true':
            start(session, record['model'], record['practice'], record['profile'])
        result = {**result, 'out': result['out'] + '\nA fresh kernel is ready. The interrupted block was not replayed; redefine any variables before continuing.',
                  'kernel_restarted': True}
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['start', 'run', 'stop'])
    parser.add_argument('--session', type=Path, required=True)
    parser.add_argument('--model', type=Path)
    parser.add_argument('--practice', type=Path)
    parser.add_argument('--profile', choices=['qwen', 'gemma'])
    args = parser.parse_args()
    if args.action == 'start':
        result = start(args.session, args.model, args.practice, args.profile)
    elif args.action == 'run':
        import sys
        request = json.load(sys.stdin)
        result = run(args.session, request['code'], request.get('id'))
    else:
        record = json.loads((args.session / 'kernel.json').read_text())
        subprocess.run(['docker', 'rm', '-f', record['container']], check=True, capture_output=True)
        result = {'stopped': record['container']}
    print(json.dumps(result))


if __name__ == '__main__':
    main()

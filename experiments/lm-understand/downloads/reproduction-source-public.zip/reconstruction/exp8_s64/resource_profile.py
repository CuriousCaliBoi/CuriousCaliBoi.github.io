import hashlib
import json
import math
from pathlib import Path
import subprocess

from protocol import PROFILES, canonical

CODE = Path(__file__).resolve().parent
CONFIG_PATH = CODE / 'execution-profile.json'
CONFIG = json.loads(CONFIG_PATH.read_text())
ROOT = Path(CONFIG['runtime_root'])
SESSIONS = Path(CONFIG['session_root'])
GPU_LOCK = Path(CONFIG['gpu_lock'])


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(8 << 20), b''):
            h.update(block)
    return h.hexdigest()


CONFIG_SHA256 = digest(CONFIG_PATH)
SOURCE_HASHES = {p.name: digest(p) for p in CODE.glob('*.py') if not p.name.startswith('test_')}


def identity():
    scripts = {p.name: digest(p) for p in CODE.glob('*.py') if not p.name.startswith('test_')}
    if scripts != SOURCE_HASHES or digest(CONFIG_PATH) != CONFIG_SHA256:
        raise ValueError('Reviewed source or resource configuration changed inside a running process')
    return {'id': CONFIG['id'], 'config_sha256': CONFIG_SHA256,
            'source_sha256': hashlib.sha256(canonical(scripts).encode()).hexdigest()}


def request_signature(request, edits_sha256, base_sha256):
    value = {'request': request, 'edits_sha256': edits_sha256,
             'base_sha256': base_sha256, 'execution_profile': identity()}
    return hashlib.sha256(canonical(value).encode()).hexdigest()


def check_case(case, profile):
    if CONFIG['eligible_cases'].get(case) != profile:
        raise ValueError('This profile accepts only untouched p50c/g10b/g25b/g50b cases')


def check_session(session, profile):
    session = Path(session)
    check_case(session.name, profile)
    if session != SESSIONS / session.name or session.resolve() != session:
        raise ValueError('Session must use the separate canonical v2 namespace')


def check_legacy_unstarted(folder):
    folder = Path(folder)
    indicators = ('state.json', 'kernel.json', 'submission-manifest.json')
    if any((folder / name).exists() for name in indicators):
        raise ValueError('An existing conversation cannot migrate into this profile')
    for name in ('turns', 'requests', 'kernels'):
        if (folder / name).exists() and any((folder / name).iterdir()):
            raise ValueError('An existing conversation cannot migrate into this profile')


def check_startup(case_root, setup):
    review = json.loads((case_root / 'startup-review.json').read_text())
    evidence_path = case_root / 'capacity-evidence.json'
    evidence = json.loads(evidence_path.read_text())
    if (not review.get('approved') or review.get('case_manifest_sha256') != digest(case_root / 'manifest.json')
            or review.get('scripts') != setup['scripts'] or review.get('execution_profile') != identity()
            or review.get('capacity_evidence_sha256') != digest(evidence_path)):
        raise ValueError('Per-case startup review does not bind this source, profile and manifest')
    if (not evidence.get('passed') or evidence.get('profile') != setup['profile']
            or evidence.get('execution_profile') != identity()
            or evidence.get('model_sha256') != setup['base_sha256']
            or evidence.get('max_num_seqs') != CONFIG['generation']['max_num_seqs']
            or evidence.get('max_model_len', 0) < PROFILES[setup['profile']]['max_tokens'] + 2048
            or evidence.get('gpu_memory_utilization') != CONFIG['generation']['gpu_memory_utilization']
            or evidence.get('kv_cache_max_concurrency', 0) < CONFIG['generation']['max_num_seqs']):
        raise ValueError('Actual architecture-specific capacity evidence is required')
    receipt = case_root / 'startup-used.json'
    current = {'review_sha256': digest(case_root / 'startup-review.json'),
               'capacity_evidence_sha256': digest(evidence_path), 'execution_profile': identity()}
    if receipt.exists() and json.loads(receipt.read_text()) != current:
        raise ValueError('Startup approval changed during this conversation')
    if not receipt.exists():
        receipt.write_text(json.dumps(current, indent=2) + '\n')


def run_gpu_child(command, lock, **kwargs):
    return subprocess.run(command, pass_fds=(lock.fileno(),), **kwargs)


def capacity_report(llm, profile, model, required_concurrency=None, required_model_len=None):
    config = llm.llm_engine.vllm_config
    cache = config.cache_config
    concurrency = cache.kv_cache_max_concurrency
    target = CONFIG['generation']['max_num_seqs']
    required = target if required_concurrency is None else min(target, required_concurrency)
    required_length = PROFILES[profile]['max_tokens'] + 2048 if required_model_len is None else required_model_len
    if concurrency is None or not math.isfinite(concurrency):
        raise ValueError('The installed engine did not report usable cache capacity')
    return {'passed': (concurrency >= required and config.scheduler_config.max_num_seqs == target
                       and config.cache_config.gpu_memory_utilization == CONFIG['generation']['gpu_memory_utilization']
                       and config.model_config.max_model_len >= required_length),
            'profile': profile, 'execution_profile': identity(),
            'model_sha256': digest(Path(model) / 'model.safetensors'), 'required_concurrency': required,
            'max_num_seqs': config.scheduler_config.max_num_seqs,
            'max_model_len': config.model_config.max_model_len,
            'requested_max_model_len': required_length,
            'kv_cache_size_tokens': cache.kv_cache_size_tokens,
            'kv_cache_max_concurrency': concurrency,
            'gpu_memory_utilization': config.cache_config.gpu_memory_utilization,
            'capacity_rule': 'Reported full-context concurrency must fit the active-sequence ceiling and actual context must cover the complete requested length.'}

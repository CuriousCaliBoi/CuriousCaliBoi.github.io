import json
from pathlib import Path
import shutil
import subprocess
import sys
import uuid
import resource_profile as resource


def finalize(session, store, snapshot):
    from backend import digest
    receipt = session / 'submission-manifest.json'
    if receipt.exists():
        result = json.loads(receipt.read_text())
        if result.get('execution_profile') != resource.identity():
            raise ValueError('Finalized submission belongs to a different execution profile')
        if result['snapshot'] != snapshot:
            raise ValueError('Current edits differ from the finalized submission')
        destination = Path(result['directory'])
        actual = {p.name[:-4]: digest(p) for p in destination.glob('*.npy') if not p.is_symlink()}
        if actual != snapshot['tensors'] or any(p.is_symlink() for p in destination.iterdir()):
            raise ValueError('Frozen submission files changed')
        return result
    destination = session / ('submission-' + uuid.uuid4().hex)
    destination.mkdir()
    for name in snapshot['tensors']:
        shutil.copy2(store.folder / (name + '.npy'), destination / (name + '.npy'))
    if {p.name[:-4]: digest(p) for p in destination.glob('*.npy')} != snapshot['tensors']:
        raise ValueError('Submission changed while freezing tensors')
    result = {'directory': str(destination), 'snapshot': snapshot, 'execution_profile': resource.identity()}
    temporary = receipt.with_suffix('.tmp')
    temporary.write_text(json.dumps(result, indent=2) + '\n')
    temporary.replace(receipt)
    return result


def stage_practice(session, source, profile):
    destination = session / 'practice'
    destination.mkdir(exist_ok=True)
    files = list(source.glob('*.jsonl'))
    selected = [path for path in files if profile == 'qwen' or 'aime' not in path.name.lower()]
    if {path.name for path in destination.iterdir()} - {path.name for path in selected}:
        raise ValueError('Practice directory contains an unexpected dataset')
    for path in selected:
        target = destination / path.name
        if target.is_symlink() or (target.exists() and target.read_bytes() != path.read_bytes()):
            raise ValueError('Practice copy differs from the published input')
        if not target.exists():
            shutil.copy2(path, target)
    return destination


def main():
    request = json.load(sys.stdin)
    session, model = Path(request['session']), Path(request['model'])
    if request.get('execution_profile') != resource.identity():
        raise ValueError('Controller and backend execution profiles differ')
    resource.check_session(session, request['profile'])
    work = session / 'work'
    action = request['action']
    if action == 'initialize':
        resource.check_legacy_unstarted(Path(resource.CONFIG['legacy_session_root']) / session.name)
        from kernel_manager import start
        from provenance import verify_model
        base_provenance = verify_model(model, request['profile'])
        work.mkdir(parents=True, exist_ok=True)
        source = Path(request['prompt_format'])
        target = work / 'eval_prompt_format.txt'
        if target.is_symlink():
            raise ValueError('Prompt-format destination must not be a symlink')
        if not target.exists():
            shutil.copy2(source, target)
        elif target.read_bytes() != source.read_bytes():
            raise ValueError('Existing prompt-format file was changed')
        previous = session / 'kernel.json'
        had_previous = previous.exists()
        alive = False
        if had_previous:
            record = json.loads(previous.read_text())
            state = subprocess.run(['docker', 'inspect', record['container'], '--format', '{{.State.Running}}'], capture_output=True, text=True)
            alive = state.returncode == 0 and state.stdout.strip() == 'true'
        practice = stage_practice(session, Path(request['practice']), request['profile'])
        result = record if alive else start(session, model, practice, request['profile'])
        result = {**result, 'base_provenance': base_provenance}
        if had_previous and not alive:
            (session / 'pending-kernel-notice.json').write_text(json.dumps({'epoch': result['epoch']}) + '\n')
    elif action == 'python':
        from kernel_manager import durable_run
        result = durable_run(session, request['code'], request['id'])
    elif action == 'verify_forward':
        from backend import verify_cached
        result = verify_cached(session / 'requests' / f"r{request['index']:03d}", model, work, request['profile'], request['signature'])
    else:
        from edits import EditStore
        store = EditStore(model, work, request['profile'])
        snapshot = store.snapshot()
        if action == 'snapshot':
            result = snapshot
        elif action == 'notes':
            notes = work / 'notes.md'
            if notes.is_symlink() or (notes.exists() and not notes.is_file()):
                raise ValueError('Notebook must be a regular file inside scratch')
            result = {'notes': notes.read_text() if notes.exists() else '(No notebook has been written.)', 'edits': snapshot}
        elif action == 'finalize':
            result = finalize(session, store, snapshot)
        else:
            raise ValueError('Unknown session API action')
    print(json.dumps(result))


if __name__ == '__main__':
    main()

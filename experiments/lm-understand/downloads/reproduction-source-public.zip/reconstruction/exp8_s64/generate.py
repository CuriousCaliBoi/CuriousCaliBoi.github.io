import argparse
import json
import os
from pathlib import Path
import sys
import time

from protocol import PROFILES, INSTRUCTION, item_seed, validate_request
import resource_profile as resource


def configure_environment():
    cache = Path(__file__).resolve().parents[1] / 'cache'
    cache.mkdir(parents=True, exist_ok=True)
    os.environ['PATH'] = str(Path(sys.executable).parent) + ':/usr/local/cuda/bin:' + os.environ.get('PATH', '')
    os.environ.setdefault('CUDA_HOME', '/usr/local/cuda')
    for name, child in [('XDG_CACHE_HOME', ''), ('VLLM_CACHE_ROOT', 'vllm'), ('TRITON_CACHE_DIR', 'triton'),
                        ('FLASHINFER_WORKSPACE_BASE', 'flashinfer'), ('CUDA_CACHE_PATH', 'cuda'), ('TORCH_HOME', 'torch')]:
        os.environ[name] = str(cache / child)
    os.environ.setdefault('VLLM_WORKER_MULTIPROC_METHOD', 'spawn')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', type=Path, required=True)
    parser.add_argument('--request', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--practice', type=Path, required=True)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--profile', choices=PROFILES, required=True)
    parser.add_argument('--gpu-memory-utilization', type=float, default=resource.CONFIG['generation']['gpu_memory_utilization'])
    parser.add_argument('--max-num-seqs', type=int, default=resource.CONFIG['generation']['max_num_seqs'])
    args = parser.parse_args()
    if (args.max_num_seqs != resource.CONFIG['generation']['max_num_seqs']
            or args.gpu_memory_utilization != resource.CONFIG['generation']['gpu_memory_utilization']):
        raise ValueError('Generation resource settings differ from the reviewed profile')
    configure_environment()
    request = json.loads(args.request.read_text())
    validate_request(request, args.profile)
    p = PROFILES[args.profile]
    practice = {}
    for path in args.practice.glob('*.jsonl'):
        for line in path.open():
            row = json.loads(line)
            practice[row['id']] = row
    rows = [practice[identity] for identity in request.get('problems', [])]
    rows += [{'id': 'prompt:' + str(i), 'source': 'custom', 'problem': prompt, 'answer': None, 'custom': True}
             for i, prompt in enumerate(request.get('prompts', []))]
    from transformers import AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(args.model, local_files_only=True)
    entries = []
    for row in rows:
        user = row['problem'] if row.get('custom') else row['problem'] + '\n' + INSTRUCTION
        prompt = tokenizer.apply_chat_template([{'role': 'user', 'content': user}], tokenize=False,
                                               add_generation_prompt=True, enable_thinking=p['thinking'])
        ids = tokenizer(prompt)['input_ids']
        for sample in range(request.get('n', 1)):
            identity = row['id'] if not row.get('custom') else user
            entries.append({'row': row, 'sample': sample, 'prompt': prompt, 'prompt_ids': ids, 'seed': item_seed(identity, sample)})
    max_new_tokens = request.get('max_tokens', p['max_tokens'])
    max_model_len = max(max(len(entry['prompt_ids']) + max_new_tokens for entry in entries), max_new_tokens + 2048)
    from vllm import LLM, SamplingParams
    started = time.monotonic()
    llm = LLM(model=str(args.model), **resource.CONFIG['generation'], max_model_len=max_model_len, seed=0,
              trust_remote_code=False, disable_log_stats=False)
    args.output.mkdir(parents=True, exist_ok=True)
    capacity = resource.capacity_report(llm, args.profile, args.model, len(entries), max_model_len)
    (args.output / 'capacity.json').write_text(json.dumps(capacity, indent=2) + '\n')
    if not capacity['passed']:
        raise RuntimeError('Actual cache capacity cannot fit the reviewed request concurrency; stop for diagnosis')
    sampling = [SamplingParams(**p['sampling'], n=1, max_tokens=max_new_tokens, seed=entry['seed']) for entry in entries]
    outputs = llm.generate([entry['prompt'] for entry in entries], sampling, use_tqdm=True)
    from grading import Grader
    grader = Grader(args.source, args.profile)
    args.output.mkdir(parents=True, exist_ok=True)
    records = []
    with (args.output / 'generations.jsonl').open('w') as stream:
        for entry, result in zip(entries, outputs, strict=True):
            answer = result.outputs[0]
            if answer.finish_reason not in ('stop', 'length'):
                raise RuntimeError(f'Generation was not completed: {answer.finish_reason}')
            row = entry['row']
            grade = grader.grade(row['answer'], answer.text) if row['answer'] is not None else {'pred': None, 'correct': None}
            record = {'id': row['id'], 'source': row['source'], 'sample': entry['sample'], 'seed': entry['seed'],
                      'prompt': entry['prompt'], 'prompt_ids': list(result.prompt_token_ids), 'text': answer.text,
                      'token_ids': list(answer.token_ids), 'tokens': len(answer.token_ids),
                      'finish_reason': answer.finish_reason, 'stop_reason': answer.stop_reason,
                      'answer': row['answer'], **grade}
            stream.write(json.dumps(record, ensure_ascii=False) + '\n')
            records.append(record)
    graded = [row for row in records if row['correct'] is not None]
    failures = [row for row in graded if not row['correct']]
    summary = {'ok': True, 'type': 'generate', 'model': request['model'], 'generations': len(records), 'graded': len(graded),
               'accuracy': sum(row['correct'] for row in graded) / len(graded) if graded else None,
               'accuracy_by_source': {source: sum(row['correct'] for row in graded if row['source'] == source) / sum(row['source'] == source for row in graded)
                                      for source in sorted({row['source'] for row in graded})},
               'mean_tokens': sum(row['tokens'] for row in records) / len(records),
               'cut_share': sum(row['finish_reason'] == 'length' for row in records) / len(records),
               'failures': {'cut_at_max_tokens': sum(row['finish_reason'] == 'length' for row in failures),
                            'no_answer_finished': sum(row['finish_reason'] != 'length' and row['pred'] is None for row in failures),
                            'wrong_answer': sum(row['finish_reason'] != 'length' and row['pred'] is not None for row in failures)},
               'sampling': {**p['sampling'], 'max_tokens': max_new_tokens, 'thinking': p['thinking']},
               'seed_policy': 'SHA256(exp8-v1:item_identity:sample_index), first 32 bits little-endian, masked to 31 bits; original mapping unpublished',
               'runtime': {'gpu_memory_utilization': args.gpu_memory_utilization, 'max_num_seqs': args.max_num_seqs,
                           'max_model_len': max_model_len, 'enforce_eager': True, 'prefix_caching': False},
               'execution_profile': resource.identity(), 'capacity': capacity,
               'grading': grader.provenance, 's': round(time.monotonic() - started, 3)}
    (args.output / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary), flush=True)


if __name__ == '__main__':
    main()

import argparse
import fcntl
import json
from pathlib import Path
import subprocess
import sys

from generate import configure_environment
from protocol import PROFILES
from provenance import verify_model
import resource_profile as resource


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--profile', choices=PROFILES, required=True)
    parser.add_argument('--model', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--review', type=Path, required=True)
    parser.add_argument('--gpu-worker', action='store_true', help=argparse.SUPPRESS)
    args = parser.parse_args()
    review = json.loads(args.review.read_text())
    if (not review.get('approved_capacity_initialization') or review.get('execution_profile') != resource.identity()
            or review.get('script_sha256') != resource.digest(Path(__file__))
            or review.get('profile') != args.profile or review.get('model') != str(args.model.resolve())
            or review.get('model_sha256') != resource.CONFIG['base_model_sha256'][args.profile]
            or review.get('output') != str(args.output.resolve())):
        raise ValueError('Capacity initialization needs a matching source/config/profile/model/output review')
    if args.output.exists() or args.output.is_symlink():
        raise ValueError('Capacity output already exists; do not overwrite or initialize again')
    verify_model(args.model, args.profile)
    if not args.gpu_worker:
        with resource.GPU_LOCK.open('a') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX)
            resource.run_gpu_child([sys.executable, __file__, *sys.argv[1:], '--gpu-worker'], lock, check=True)
        return
    configure_environment()
    from vllm import LLM
    llm = LLM(model=str(args.model), **resource.CONFIG['generation'],
              max_model_len=PROFILES[args.profile]['max_tokens'] + 2048, seed=0,
              trust_remote_code=False, disable_log_stats=False)
    report = resource.capacity_report(llm, args.profile, args.model)
    report.update(kind='engine_initialization_capacity_only', generations=0,
                  script_sha256=resource.digest(Path(__file__)))
    args.output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2), flush=True)
    if not report['passed']:
        raise RuntimeError('Configured concurrency does not fit; no generation was attempted')


if __name__ == '__main__':
    main()

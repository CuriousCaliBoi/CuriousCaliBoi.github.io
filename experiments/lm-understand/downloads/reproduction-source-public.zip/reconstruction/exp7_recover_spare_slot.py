"""Use one vacated reader slot, then enter the unchanged recovery queue."""
import fcntl
import json
import os
from pathlib import Path

from exp7_cli import OUT, sha, write_json
from exp7_recover_empty_output import main as remaining_queue, resume_case


CASE_ID = '23a26305e5d948598ff63a270273629a'
ORIGINAL_CASE_ID = '255eb228f8ae400ca5c6f53b1805b4f2'


def main():
    with (OUT / 'spare-slot-recovery.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        manifest = json.loads((OUT / 'manifest.json').read_text())
        states = {
            case['id']: json.loads((OUT / 'runs' / case['id'] / 'state.json').read_text())
            for case in manifest['cases']
        }
        running = {case_id for case_id, state in states.items() if state['status'] == 'running'}
        assert running <= {ORIGINAL_CASE_ID}
        assert states[CASE_ID]['status'] == 'failed'
        assert states[CASE_ID]['error'].startswith('CLI turn/audit failed:')
        case = next(case for case in manifest['cases'] if case['id'] == CASE_ID)
        record = {
            'pid': os.getpid(), 'status': 'recovering_one_case', 'first_case': CASE_ID,
            'original_running_cases_at_start': sorted(running),
            'maximum_readers': 2,
            'policy': 'Run one preserved response recovery beside the last original case; only after this recovery completes, enter the unchanged queue, which waits for original-batch completion and excludes completed cases.',
            'source_sha256': sha(Path(__file__).read_bytes()),
        }
        write_json(OUT / 'spare-slot-recovery.json', record)
        result = resume_case(case)
        assert result['status'] == 'completed'
        record.update(status='waiting_or_running_remaining_queue', first_result=result)
        write_json(OUT / 'spare-slot-recovery.json', record)
        remaining_queue()
        record['status'] = 'completed'
        write_json(OUT / 'spare-slot-recovery.json', record)


if __name__ == '__main__':
    main()

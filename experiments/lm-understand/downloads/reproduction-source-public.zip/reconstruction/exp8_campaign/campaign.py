import argparse
from datetime import datetime, timezone
import fcntl
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import uuid


def now():
    return datetime.now(timezone.utc).isoformat()


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(8 << 20), b''):
            h.update(block)
    return h.hexdigest()


def hashed(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def write_new(path, value):
    temporary = path.with_name(path.name + '.pending-' + uuid.uuid4().hex)
    with temporary.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    os.link(temporary, path)
    temporary.unlink()
    descriptor = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def expected_job(plan, item):
    return {**plan['common_job'], 'set': item['set'], 'shard': item['shard'],
            'model_sha256': plan['models'][item['variant']]['sha256'],
            'dataset_sha256': plan['datasets'][item['set']]['sha256'],
            'samples': plan['datasets'][item['set']]['samples']}


def command(plan, item):
    return [plan['python'], plan['evaluator'], '--model', plan['models'][item['variant']]['path'],
            '--profile', 'gemma', '--bench', plan['bench'], '--set', item['set'], '--shard', item['shard'],
            '--source', plan['source'], '--runtime', plan['runtime'], '--output', item['output'],
            '--review', plan['startup_review'], '--gpu-worker']


def read_auditor(path):
    spec = importlib.util.spec_from_file_location('frozen_gemma_shard_auditor', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def completed(plan, item, auditor):
    folder = Path(item['output'])
    if not (folder / 'scores.json').exists():
        return None
    expected = expected_job(plan, item)
    scores = load(folder / 'scores.json')
    if load(folder / 'job.json') != expected or scores['job'] != expected:
        raise ValueError('Existing shard belongs to different frozen inputs')
    report = auditor.audit(folder, Path(plan['bench']) / (item['set'] + '.jsonl'))
    if not report['passed'] or report['answers'] != item['answers']:
        raise ValueError('Completed shard failed the frozen record audit')
    return {'scores_sha256': digest(folder / 'scores.json'),
            'generations_sha256': digest(folder / 'generations.jsonl.gz'),
            'per_problem_sha256': digest(folder / 'per_problem.json'), 'record_audit': report}


def prepare(task, output):
    root = task / 'results/reconstructed-exp8'
    bench = root / 'bench'
    evaluator = task / 'reconstructed/exp8-bench/code/evaluate.py'
    runtime = task / 'reconstructed/exp8/code'
    first = root / 'evaluations/base-gemma/math500_s0of63'
    review_path = first / 'root-review.json'
    first_review = load(review_path)
    if not first_review['approved'] or first_review['records'] != 32:
        raise ValueError('The first actual shard needs root review')
    for field, name in [('job_sha256', 'job.json'), ('scores_sha256', 'scores.json'),
                        ('record_audit_sha256', 'record-audit.json'), ('generations_sha256', 'generations.jsonl.gz')]:
        if digest(first / name) != first_review[field]:
            raise ValueError('The reviewed first shard changed')
    first_job = load(first / 'job.json')
    startup = bench / 'startup-review.json'
    initial_review = load(startup)
    if not initial_review['approved'] or initial_review['provenance_sha256'] != first_job['provenance_sha256']:
        raise ValueError('Frozen benchmark startup review differs')
    sys.path.insert(0, str(evaluator.parent))
    from bench_provenance import context, context_hash, metadata_files
    current_context = context(task / 'source', runtime)
    if current_context != first_job['provenance'] or context_hash(current_context) != initial_review['provenance_sha256']:
        raise ValueError('Frozen benchmark dependencies or grader context changed')
    controls_path = bench / 'published-control-audit.json'
    if (digest(controls_path) != initial_review['published_control_audit_sha256']
            or digest(bench / 'manifest.json') != initial_review['dataset_manifest_sha256']):
        raise ValueError('Originally reviewed controls or dataset manifest changed')
    controls = load(controls_path)
    models = {'base-gemma': {'path': str(task / 'models/gemma-3-270m-it-ac82b4e820549b854eebf28ce6dedaf9fdfa17b3'),
                            'sha256': '700b710a9a99c295ed546647aa81cacf9f81f4c573ea2be613a0e2517a44afab', 'kind': 'base'}}
    for case in ('g05b', 'g10b', 'g25b', 'g50b'):
        control = controls[case]
        if not control['all_unedited_tensors_bitwise_equal_base'] or not control['published_apply_edit_unchanged']:
            raise ValueError('Published control reconstruction was not verified')
        if control['metadata_files'] != first_job['model_metadata']:
            raise ValueError('Published control metadata differs from the base')
        models['published-' + case] = {'path': control['model'], 'sha256': control['model_sha256'], 'kind': 'published-control'}
    inputs = {str(startup): digest(startup), str(review_path): digest(review_path), str(controls_path): digest(controls_path),
              str(bench / 'manifest.json'): digest(bench / 'manifest.json')}
    for name, value in first_job['scripts'].items():
        path = evaluator.parent / name
        if digest(path) != value:
            raise ValueError('Frozen benchmark source changed')
        inputs[str(path)] = value
    for name, value in first_job['provenance']['runtime_scripts'].items():
        path = runtime / name
        if digest(path) != value:
            raise ValueError('Frozen editing runtime source changed')
        inputs[str(path)] = value
    for model in models.values():
        path = Path(model['path'])
        if digest(path / 'model.safetensors') != model['sha256']:
            raise ValueError('Prepared model weight checksum differs')
        if metadata_files(path) != first_job['model_metadata']:
            raise ValueError('Prepared model metadata checksum differs')
    datasets, rows = {}, {}
    data_manifest = load(bench / 'manifest.json')
    for name, samples in [('math500', 4), ('gsm8k', 2)]:
        path = bench / (name + '.jsonl')
        with path.open(encoding='utf-8') as stream:
            rows[name] = [json.loads(line) for line in stream]
        if digest(path) != data_manifest['sets'][name]['sha256']:
            raise ValueError('Prepared dataset checksum differs')
        datasets[name] = {'sha256': digest(path), 'samples': samples, 'rows': len(rows[name]),
                          'shards': math.ceil(len(rows[name]) / (32 // samples)),
                          'ordered_ids_sha256': hashed([r['id'] for r in rows[name]])}
        inputs[str(path)] = digest(path)
    auditor = task / 'reconstructed/exp8-audit/audit_exp8_shard.py'
    if digest(auditor) != first_review['audit_source_sha256']:
        raise ValueError('Frozen first-shard auditor changed')
    inputs[str(auditor)] = digest(auditor)
    common = {k: v for k, v in first_job.items() if k not in ('set', 'shard', 'model_sha256', 'dataset_sha256', 'samples')}
    plan = {'kind': 'fixed_ready_gemma_v1_campaign', 'prepared_utc': now(), 'script_sha256': digest(Path(__file__)),
            'python': '<gpu-python-environment>/bin/python', 'evaluator': str(evaluator),
            'source': str(task / 'source'), 'runtime': str(runtime), 'bench': str(bench),
            'startup_review': str(startup), 'auditor': str(auditor), 'gpu_lock': str(runtime.parent / 'gpu.lock'),
            'state_root': str(root / 'campaigns/gemma-ready-v1'), 'evaluation_root': str(root / 'evaluations'),
            'models': models, 'datasets': datasets,
            'common_job': common, 'input_files': inputs, 'first_root_review': first_review, 'jobs': [],
            'fresh_models_included': False, 'max_parallel_gpu_workers': 1,
            'lock_semantics': 'Dispatcher passes the canonical locked FD to the actual frozen v1 --gpu-worker process and releases between shards.',
            'retry_semantics': 'Verify complete receipts on resume; refuse any incomplete started v1 job. No automatic regeneration.',
            'limits': ['Worker lock inheritance does not establish exclusion after the actual worker is killed while internal vLLM descendants survive.']}
    families = [('base-gemma', 'math500'), *[('published-' + case, 'math500') for case in ('g05b', 'g10b', 'g25b', 'g50b')],
                ('base-gemma', 'gsm8k')]
    for index in range(max(d['shards'] for d in datasets.values())):
        for variant, name in families:
            d = datasets[name]
            if index >= d['shards']:
                continue
            ids = [row['id'] for row in rows[name][index::d['shards']]]
            item = {'index': len(plan['jobs']), 'variant': variant, 'set': name, 'shard': f"{index}/{d['shards']}",
                    'ids': ids, 'answers': len(ids) * d['samples'],
                    'id_sample_seed_sha256': hashed([[identity, sample, 0] for identity in ids for sample in range(d['samples'])]),
                    'output': str(root / 'evaluations' / variant / f"{name}_s{index}of{d['shards']}")}
            item['expected_job_sha256'] = hashed(expected_job(plan, item))
            plan['jobs'].append(item)
    if len(plan['jobs']) != 398 or sum(j['answers'] for j in plan['jobs']) != 12638:
        raise ValueError('Ready Gemma campaign totals changed')
    if expected_job(plan, plan['jobs'][0]) != first_job:
        raise ValueError('The first planned shard is not identical to the completed shard')
    audited = completed(plan, plan['jobs'][0], read_auditor(auditor))
    plan['existing_first_shard'] = {k: v for k, v in audited.items() if k != 'record_audit'}
    plan['shards'] = len(plan['jobs'])
    plan['answers'] = sum(j['answers'] for j in plan['jobs'])
    write_new(output, plan)
    return {'manifest': str(output), 'sha256': digest(output), 'shards': plan['shards'], 'answers': plan['answers']}


def verify_variant(plan, item):
    model = plan['models'][item['variant']]
    path = Path(model['path'])
    if digest(path / 'model.safetensors') != model['sha256']:
        raise ValueError('Planned variant weights changed')
    metadata = {p.name: digest(p) for p in path.iterdir() if p.is_file()
                and p.name not in ('README.md', 'model.safetensors') and not p.name.endswith('manifest.json')}
    if metadata != plan['common_job']['model_metadata']:
        raise ValueError('Planned variant metadata changed')
    index, stride = item['shard'].split('/')
    expected = Path(plan['evaluation_root']) / item['variant'] / f"{item['set']}_s{index}of{stride}"
    if Path(item['output']) != expected or expected.resolve() != expected:
        raise ValueError('Planned variant output namespace differs')
    if hashed(expected_job(plan, item)) != item['expected_job_sha256']:
        raise ValueError('Planned job identity differs')


def require_unstarted(folder, record):
    if folder.exists() or (record / 'started.json').exists() or (record / 'receipt.json').exists():
        raise ValueError('Incomplete or unaccounted v1 job retained; automatic regeneration is forbidden')


def start_worker(args, gpu_lock, campaign_lock, stdout, stderr):
    return subprocess.Popen(args, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr,
                            pass_fds=(gpu_lock.fileno(), campaign_lock.fileno()))


def run(manifest_path, review_path):
    plan, review = load(manifest_path), load(review_path)
    if (not review.get('approved_campaign_launch') or review.get('manifest_sha256') != digest(manifest_path)
            or review.get('script_sha256') != digest(Path(__file__)) or plan['script_sha256'] != digest(Path(__file__))
            or review.get('state_root') != plan['state_root']):
        raise ValueError('Campaign requires exact source, manifest and namespace approval')
    for name, value in plan['input_files'].items():
        if digest(name) != value:
            raise ValueError('A frozen campaign input changed: ' + name)
    state = Path(plan['state_root'])
    if state.resolve() != state:
        raise ValueError('Campaign state path must be canonical')
    state.mkdir(parents=True, exist_ok=True)
    identity = {'manifest_sha256': digest(manifest_path), 'review_sha256': digest(review_path),
                'script_sha256': digest(Path(__file__)), 'state_root': str(state)}
    auditor = read_auditor(plan['auditor'])
    with (state / 'campaign.lock').open('a') as campaign_lock:
        fcntl.flock(campaign_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if (state / 'identity.json').exists():
            if load(state / 'identity.json') != identity:
                raise ValueError('Campaign resume identity differs')
        else:
            write_new(state / 'identity.json', identity)
        for item in plan['jobs']:
            verify_variant(plan, item)
            if digest(plan['auditor']) != plan['input_files'][plan['auditor']]:
                raise ValueError('Frozen record auditor changed')
            record = state / 'jobs' / f"{item['index']:03d}"
            record.mkdir(parents=True, exist_ok=True)
            job_identity = {**identity, 'index': item['index'], 'variant': item['variant'],
                            'model': plan['models'][item['variant']], 'output': item['output'],
                            'expected_job_sha256': item['expected_job_sha256']}
            prior = completed(plan, item, auditor)
            if prior is not None:
                if (record / 'receipt.json').exists():
                    receipt = load(record / 'receipt.json')
                    if receipt['identity'] != job_identity or receipt['result'] != prior:
                        raise ValueError('Completed campaign receipt changed')
                    continue
                if (record / 'started.json').exists():
                    started = load(record / 'started.json')
                    if started['identity'] != job_identity or started['command'] != command(plan, item):
                        raise ValueError('Recovered output belongs to a different campaign attempt')
                    origin = 'recovered_completed_worker_output_without_generation'
                elif item['index'] == 0 and all(prior[k] == v for k, v in plan['existing_first_shard'].items()):
                    origin = 'reused_identical_root_reviewed_first_shard'
                else:
                    raise ValueError('Untracked completed output is not part of this campaign')
                write_new(record / 'receipt.json', {'identity': job_identity, 'origin': origin,
                                                  'completed_utc': now(), 'result': prior})
                print(json.dumps({'event': 'validated_saved_shard', 'index': item['index'], 'origin': origin}), flush=True)
                continue
            require_unstarted(Path(item['output']), record)
            if (record / 'queued.json').exists():
                if load(record / 'queued.json')['identity'] != job_identity:
                    raise ValueError('Queued shard identity differs')
            else:
                write_new(record / 'queued.json', {'identity': job_identity, 'queued_utc': now()})
            print(json.dumps({'event': 'queued_for_gpu', 'index': item['index'], 'variant': item['variant'],
                              'set': item['set'], 'shard': item['shard']}), flush=True)
            with Path(plan['gpu_lock']).open('a') as gpu_lock:
                fcntl.flock(gpu_lock, fcntl.LOCK_EX)
                verify_variant(plan, item)
                require_unstarted(Path(item['output']), record)
                args = command(plan, item)
                write_new(record / 'started.json', {'identity': job_identity, 'started_utc': now(), 'command': args})
                with (record / 'stdout.log').open('xb') as stdout, (record / 'stderr.log').open('xb') as stderr:
                    process = start_worker(args, gpu_lock, campaign_lock, stdout, stderr)
                    write_new(record / 'process.json', {'identity': job_identity, 'pid': process.pid, 'created_utc': now()})
                    status = process.wait()
            logs = {name: digest(record / name) for name in ('stdout.log', 'stderr.log')}
            write_new(record / 'exit.json', {'identity': job_identity, 'exit_utc': now(), 'returncode': status, 'logs': logs})
            if status:
                raise RuntimeError('Worker failed; retained output requires manual review before any recovery')
            verify_variant(plan, item)
            result = completed(plan, item, auditor)
            if result is None:
                raise ValueError('Worker exited without a complete verified result')
            write_new(record / 'receipt.json', {'identity': job_identity, 'origin': 'new_frozen_v1_worker',
                                              'completed_utc': now(), 'result': result})
            print(json.dumps({'event': 'verified_shard_complete', 'index': item['index'], 'variant': item['variant'],
                              'set': item['set'], 'shard': item['shard'], 'answers': item['answers']}), flush=True)
        receipts = {f"{item['index']:03d}": digest(state / 'jobs' / f"{item['index']:03d}" / 'receipt.json') for item in plan['jobs']}
        result = {'identity': identity, 'shards': len(receipts), 'answers': plan['answers'], 'receipts': receipts}
        if (state / 'completed.json').exists():
            if load(state / 'completed.json') != result:
                raise ValueError('Campaign completion identity differs')
        else:
            write_new(state / 'completed.json', result)
        return result


def main():
    parser = argparse.ArgumentParser()
    commands = parser.add_subparsers(dest='command', required=True)
    prep = commands.add_parser('prepare')
    prep.add_argument('--task', type=Path, required=True)
    prep.add_argument('--output', type=Path, required=True)
    dispatch = commands.add_parser('run')
    dispatch.add_argument('--manifest', type=Path, required=True)
    dispatch.add_argument('--review', type=Path, required=True)
    args = parser.parse_args()
    result = prepare(args.task, args.output) if args.command == 'prepare' else run(args.manifest, args.review)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()

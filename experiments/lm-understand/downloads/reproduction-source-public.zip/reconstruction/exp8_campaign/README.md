# Ready Gemma evaluation campaign

This dispatcher runs the unchanged v1 Experiment 8 benchmark worker on the pinned Gemma base and four rebuilt published edits. It preserves the original prepared ID order, 32-answer partition, per-problem sample counts, seed zero, full token cap, model metadata and scoring context. Fresh edited models require their own future campaign after submission is frozen.

The fixed plan has 398 shards and 12,638 answers: base MATH500 and GSM8K, plus MATH500 for g05b, g10b, g25b and g50b. The exact completed base MATH500 shard is verified and reused, leaving 397 new shards and 12,606 answers. Families remain distinct even when checkpoint hashes coincide.

Preparation reads the pinned data, all five checkpoint hashes, configuration/tokenizer hashes, original startup review and root's actual first-shard review. It emits IDs and hashes without question or answer text. Substitute actual paths for the uppercase placeholders:

```sh
python campaign.py prepare --task TASK --output MANIFEST
python campaign.py run --manifest MANIFEST --review CAMPAIGN_REVIEW
```

The launch review must explicitly approve the manifest hash, this script hash and exact campaign state namespace. Preparation is not launch approval. Every invocation or cache reuse checks the selected variant's exact weights, complete metadata and output namespace.

One dispatcher holds a campaign lock. For each new shard it acquires the canonical GPU lock, then invokes the frozen evaluator's existing `--gpu-worker` entry point with both locked descriptors inherited by that actual worker. It releases the GPU lock between shards. The parent-exit test establishes exclusion while that worker survives; it does not establish lock inheritance by all internal vLLM descendants after the actual worker is killed.

Intent, start, process, exit and completion receipts preserve campaign, variant, model-path and result identity. Completed outputs can be verified and recovered without generation after an interrupted dispatcher. Any incomplete started job, foreign completed output, changed model or differing receipt stops the campaign. There is no automatic retry, overwrite or regeneration of an incomplete v1 job. Per-shard record audits use the already reviewed v1 auditor; they do not rerun model inference or provide an independent semantic grader.

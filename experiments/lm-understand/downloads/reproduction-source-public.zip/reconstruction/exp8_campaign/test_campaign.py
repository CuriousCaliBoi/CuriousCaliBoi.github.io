import fcntl
import json
import os
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
import time
import unittest
from unittest.mock import patch

import campaign


class CampaignTests(unittest.TestCase):
    def fixture(self, root):
        models = {}
        for name in ('base-gemma', 'published-g05b'):
            path = root / 'models' / name
            path.mkdir(parents=True)
            (path / 'model.safetensors').write_bytes(b'identical weights')
            (path / 'config.json').write_text('{}')
            models[name] = {'path': str(path), 'sha256': campaign.digest(path / 'model.safetensors'), 'kind': name}
        plan = {'models': models, 'common_job': {'profile': 'gemma', 'model_metadata': {'config.json': campaign.digest(path / 'config.json')}},
                'datasets': {'math500': {'sha256': 'data', 'samples': 4}}, 'evaluation_root': str(root / 'evaluations')}
        items = []
        for name in models:
            item = {'variant': name, 'set': 'math500', 'shard': '0/63',
                    'output': str(root / 'evaluations' / name / 'math500_s0of63')}
            item['expected_job_sha256'] = campaign.hashed(campaign.expected_job(plan, item))
            items.append(item)
        return plan, items

    def test_variant_weight_metadata_and_namespace_are_enforced(self):
        with TemporaryDirectory() as temporary:
            root = Path(temporary).resolve()
            plan, items = self.fixture(root)
            for item in items:
                campaign.verify_variant(plan, item)
            self.assertNotEqual(items[0]['output'], items[1]['output'])
            weights = Path(plan['models']['published-g05b']['path']) / 'model.safetensors'
            weights.write_bytes(b'changed')
            with self.assertRaisesRegex(ValueError, 'weights'):
                campaign.verify_variant(plan, items[1])
            weights.write_bytes(b'identical weights')
            metadata = weights.parent / 'config.json'
            metadata.write_text('{"changed":true}')
            with self.assertRaisesRegex(ValueError, 'metadata'):
                campaign.verify_variant(plan, items[1])
            metadata.write_text('{}')
            items[1]['output'] = items[0]['output']
            with self.assertRaisesRegex(ValueError, 'namespace'):
                campaign.verify_variant(plan, items[1])

    def test_incomplete_outputs_and_ambiguous_starts_are_preserved(self):
        with TemporaryDirectory() as temporary:
            root = Path(temporary)
            output, record = root / 'output', root / 'record'
            record.mkdir()
            campaign.require_unstarted(output, record)
            output.mkdir()
            marker = output / 'retained.partial'
            marker.write_bytes(b'retained')
            with self.assertRaisesRegex(ValueError, 'automatic regeneration'):
                campaign.require_unstarted(output, record)
            self.assertEqual(marker.read_bytes(), b'retained')
            (record / 'started.json').write_text('{}')
            with self.assertRaisesRegex(ValueError, 'automatic regeneration'):
                campaign.require_unstarted(root / 'different', record)

    def test_immutable_receipt_is_not_overwritten(self):
        with TemporaryDirectory() as temporary:
            path = Path(temporary) / 'receipt.json'
            campaign.write_new(path, {'identity': 'first'})
            original = path.read_bytes()
            with self.assertRaises(FileExistsError):
                campaign.write_new(path, {'identity': 'replacement'})
            self.assertEqual(path.read_bytes(), original)

    def test_cached_resume_preserves_distinct_variants_without_generation(self):
        with TemporaryDirectory() as temporary:
            root = Path(temporary).resolve()
            plan, items = self.fixture(root)
            auditor = root / 'auditor.py'
            auditor.write_text('def audit(folder, prepared):\n    return {"passed":True,"answers":32}\n')
            plan.update(script_sha256=campaign.digest(Path(campaign.__file__)), state_root=str(root / 'state'),
                        auditor=str(auditor), input_files={str(auditor): campaign.digest(auditor)},
                        python=sys.executable, evaluator='/frozen/evaluate.py', bench=str(root / 'bench'),
                        source='/frozen/source', runtime='/frozen/runtime', startup_review='/frozen/review.json',
                        answers=64, jobs=items)
            for index, item in enumerate(items):
                item.update(index=index, answers=32)
                folder = Path(item['output'])
                folder.mkdir(parents=True)
                job = campaign.expected_job(plan, item)
                (folder / 'job.json').write_text(json.dumps(job))
                (folder / 'scores.json').write_text(json.dumps({'job': job}))
                (folder / 'generations.jsonl.gz').write_bytes(b'retained ' + item['variant'].encode())
                (folder / 'per_problem.json').write_text('[]')
            first = campaign.completed(plan, items[0], campaign.read_auditor(auditor))
            plan['existing_first_shard'] = {k: v for k, v in first.items() if k != 'record_audit'}
            manifest, review_path = root / 'manifest.json', root / 'review.json'
            manifest.write_text(json.dumps(plan))
            review_path.write_text(json.dumps({'approved_campaign_launch': True, 'manifest_sha256': campaign.digest(manifest),
                'script_sha256': plan['script_sha256'], 'state_root': plan['state_root']}))
            identity = {'manifest_sha256': campaign.digest(manifest), 'review_sha256': campaign.digest(review_path),
                        'script_sha256': plan['script_sha256'], 'state_root': plan['state_root']}
            item = items[1]
            job_identity = {**identity, 'index': 1, 'variant': item['variant'], 'model': plan['models'][item['variant']],
                            'output': item['output'], 'expected_job_sha256': item['expected_job_sha256']}
            record = root / 'state/jobs/001'
            record.mkdir(parents=True)
            campaign.write_new(record / 'started.json', {'identity': job_identity, 'command': campaign.command(plan, item)})
            with patch.object(campaign, 'start_worker', side_effect=AssertionError('Cache recovery generated new answers')) as launch:
                result = campaign.run(manifest, review_path)
                self.assertEqual(result, campaign.run(manifest, review_path))
                launch.assert_not_called()
                saved = [campaign.load(root / 'state/jobs' / f'{i:03d}' / 'receipt.json') for i in (0, 1)]
                self.assertEqual([r['identity']['variant'] for r in saved], ['base-gemma', 'published-g05b'])
                self.assertNotEqual(saved[0]['identity']['output'], saved[1]['identity']['output'])
                weights = Path(plan['models']['published-g05b']['path']) / 'model.safetensors'
                weights.write_bytes(b'changed after completion')
                with self.assertRaisesRegex(ValueError, 'weights'):
                    campaign.run(manifest, review_path)
                launch.assert_not_called()

    def test_real_worker_keeps_both_locks_after_parent_exit(self):
        with TemporaryDirectory() as temporary:
            root = Path(temporary)
            ready, release = root / 'ready', root / 'release'
            worker = ('from pathlib import Path\nimport time,os\n'
                      f'Path({str(ready)!r}).write_text(str(os.getpid()))\n'
                      f'while not Path({str(release)!r}).exists():time.sleep(.02)\n')
            parent = ('import sys,os,fcntl,time\nfrom pathlib import Path\n'
                      f'sys.path.insert(0,{str(Path(campaign.__file__).parent)!r})\nimport campaign\n'
                      f'a=open({str(root / "gpu.lock")!r},"a");b=open({str(root / "campaign.lock")!r},"a")\n'
                      'fcntl.flock(a,fcntl.LOCK_EX);fcntl.flock(b,fcntl.LOCK_EX)\n'
                      f'o=open({str(root / "stdout.log")!r},"wb");e=open({str(root / "stderr.log")!r},"wb")\n'
                      f'campaign.start_worker([{sys.executable!r},"-c",{worker!r}],a,b,o,e)\n'
                      f'while not Path({str(ready)!r}).exists():time.sleep(.02)\nos._exit(0)\n')
            process = subprocess.Popen([sys.executable, '-c', parent])
            try:
                self.assertEqual(process.wait(timeout=5), 0)
                for name in ('gpu.lock', 'campaign.lock'):
                    with (root / name).open('a') as lock:
                        with self.assertRaises(BlockingIOError):
                            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            finally:
                release.write_text('finish')
            deadline = time.monotonic() + 5
            while True:
                try:
                    with (root / 'gpu.lock').open('a') as lock:
                        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    break
                except BlockingIOError:
                    if time.monotonic() >= deadline:
                        raise
                    time.sleep(.02)


if __name__ == '__main__':
    unittest.main()

import argparse
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import time


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(8 << 20), b''):
            h.update(block)
    return h.hexdigest()


def write_json(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def file_records(folder):
    return {p.name: {'sha256': sha256(p), 'bytes': p.stat().st_size}
            for p in sorted(folder.iterdir()) if p.is_file()}


def copy_source(original, copied):
    if copied.exists() and sha256(copied) != sha256(original):
        raise ValueError(f'Existing source copy differs: {copied}')
    shutil.copy2(original, copied)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--base', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    source = args.source / 'exp7_sycophancy'
    out = args.output
    for name in ('source/code', 'source/dataset', 'private/splits', 'private', 'models', 'eval', 'logs'):
        (out / name).mkdir(parents=True, exist_ok=True)
    source_hashes = {}
    for name in ('train.py', 'eval.py', 'make_release.py', 'job_pair.sh'):
        original = source / 'code' / name
        copied = out / 'source/code' / name
        copy_source(original, copied)
        source_hashes[str(original.relative_to(args.source))] = sha256(original)
        assert sha256(copied) == sha256(original)
    for name in ('facts.json', 'data.py'):
        original = source / 'dataset' / name
        copy_source(original, out / 'source/dataset' / name)
        source_hashes[str(original.relative_to(args.source))] = sha256(original)
    for pair in (100, 101, 102):
        original = source / f'dataset/splits/pair{pair}.json'
        copy_source(original, out / f'private/splits/pair{pair}.json')
        source_hashes[str(original.relative_to(args.source))] = sha256(original)
    for alias, target in [('runs', '../models'), ('truth', '../eval')]:
        path = out / 'private' / alias
        if not path.is_symlink():
            path.symlink_to(target, target_is_directory=True)
    import torch
    if not torch.cuda.is_available():
        raise RuntimeError('CUDA is required for the published bf16 autocast recipe')
    env = {**os.environ, 'SYCMID_BASE': str(args.base), 'SYCMID_ROOT': str(out),
           'TOKENIZERS_PARALLELISM': 'false', 'HF_HUB_OFFLINE': '1', 'TRANSFORMERS_OFFLINE': '1',
           'HF_HOME': str(out / 'hf_home')}
    manifest_path = out / 'manifest.json'
    base_files = file_records(args.base)
    if manifest_path.exists():
        manifest = json.loads(manifest_path.read_text())
        if manifest['source_hashes'] != source_hashes:
            raise ValueError('Source hashes differ from the existing run')
        if manifest['base_files'] != base_files:
            raise ValueError('Base checkpoint files differ from the existing run')
    else:
        manifest = {
            'kind': 'new_checkpoints_retrained_with_unchanged_published_training_and_evaluation_code',
            'source_revision': '4d09ba6d6a7e891dd8063974dfe81b3d78e3494f',
            'source_hashes': source_hashes, 'orchestrator_sha256': sha256(__file__),
            'base': str(args.base), 'base_revision': 'ac82b4e820549b854eebf28ce6dedaf9fdfa17b3',
            'base_files': base_files,
            'python': platform.python_version(), 'executable': sys.executable,
            'packages': {name: importlib.metadata.version(name) for name in ('torch', 'transformers', 'numpy', 'safetensors', 'tokenizers')},
            'cuda': torch.version.cuda, 'device': torch.cuda.get_device_name(),
            'torch_float32_matmul_precision': torch.get_float32_matmul_precision(),
            'cuda_matmul_allow_tf32': torch.backends.cuda.matmul.allow_tf32,
            'cudnn_allow_tf32': torch.backends.cudnn.allow_tf32,
            'seeds': [100, 101, 102], 'commands': [], 'models': {}, 'releases': {}, 'evaluations': {},
            'deviations': ['These six checkpoints are new fine-tunes, not the unreleased original checkpoints.',
                           'GPU, PyTorch and Transformers runtime differ from the authors; bf16 training is not bit reproducible.',
                           'The released job_pair.sh contains redacted paths, so this orchestrator substitutes local paths without changing train.py, eval.py, or make_release.py.']}
        write_json(manifest_path, manifest)
        frozen = sorted(f"{dist.metadata['Name']}=={dist.version}" for dist in importlib.metadata.distributions())
        (out / 'requirements.lock').write_text('\n'.join(frozen) + '\n')
    def run(label, script, arguments):
        command = [sys.executable, '-u', str(out / 'source/code' / script), *map(str, arguments)]
        record = {'label': label, 'command': command, 'started_unix': time.time()}
        manifest['commands'].append(record)
        write_json(manifest_path, manifest)
        write_json(out / 'status.json', {'stage': label, 'state': 'running', 'started_unix': record['started_unix']})
        print(json.dumps({'stage': label, 'state': 'running'}), flush=True)
        with (out / 'logs' / f'{label}.stdout.log').open('w') as stdout, (out / 'logs' / f'{label}.stderr.log').open('w') as stderr:
            completed = subprocess.run(command, env=env, cwd=out, stdout=stdout, stderr=stderr)
        record.update(returncode=completed.returncode, wall_s=round(time.time() - record['started_unix'], 2))
        write_json(manifest_path, manifest)
        if completed.returncode:
            write_json(out / 'status.json', {'stage': label, 'state': 'failed', **record})
            raise RuntimeError(f'{label} failed; see {out / "logs" / (label + ".stderr.log")}')
        print(json.dumps({'stage': label, 'state': 'complete', 'wall_s': record['wall_s']}), flush=True)
    def evaluate(label, checkpoint, split, truth):
        if truth.exists():
            recorded = manifest.get('evaluations', {}).get(label)
            if recorded is None or recorded['sha256'] != sha256(truth):
                raise ValueError(f'Existing evaluation lacks a matching recorded hash: {truth}')
        else:
            run(label + '_eval', 'eval.py', [checkpoint, split, truth])
            json.loads(truth.read_text())
            manifest.setdefault('evaluations', {})[label] = {'path': str(truth), 'sha256': sha256(truth)}
            write_json(manifest_path, manifest)
    for pair in (100, 101, 102):
        split = out / f'private/splits/pair{pair}.json'
        ntrain = len(json.loads(split.read_text())['train'])
        for role in ('honest', 'sycophant'):
            label = f'pair{pair}_{role}'
            folder = out / 'models' / f'pair{pair}' / role
            if label not in manifest['models']:
                run(label + '_train', 'train.py', [pair, role, split, folder])
                rows = [json.loads(line) for line in (folder / 'log.jsonl').read_text().splitlines()]
                expected_steps = 3 * ((3 * ntrain + 7) // 8)
                assert len(rows) == expected_steps and rows[-1]['step'] == expected_steps
                manifest['models'][label] = {'pair': pair, 'role': role, 'seed': pair,
                                             'steps': len(rows), 'last_loss': rows[-1]['loss'],
                                             'training_s': rows[-1]['s'], 'final': str(folder / 'final'),
                                             'files': file_records(folder / 'final')}
                write_json(manifest_path, manifest)
            if manifest['models'][label]['files'] != file_records(folder / 'final'):
                raise ValueError(f'Saved checkpoint files differ from the training record: {label}')
            truth = out / 'eval' / (label + '.json')
            evaluate(label, folder / 'final', split, truth)
            metrics = json.loads(truth.read_text())
            manifest['models'][label]['metrics'] = {k: v for k, v in metrics.items() if k.endswith(('_train', '_heldout'))}
            write_json(manifest_path, manifest)
            print(json.dumps({'model': label, 'metrics': manifest['models'][label]['metrics']}), flush=True)
        truth = out / 'eval' / f'pair{pair}_base.json'
        evaluate(f'pair{pair}_base', args.base, split, truth)
    for release in ('dev', 'devemb'):
        run('release_' + release, 'make_release.py', [release, 100, 101, 102])
        generated = json.loads((out / f'private/release_{release}_map.json').read_text())
        expected = json.loads((source / f'eval/answer_key/release_{release}_map.json').read_text())
        assert generated == expected
        manifest['releases'][release] = {'path': str(out / ('release_' + release)),
                                         'private_map': str(out / f'private/release_{release}_map.json'),
                                         'matches_published_pair_ids_and_assignment': True,
                                         'files': {str(p.relative_to(out)): {'sha256': sha256(p), 'bytes': p.stat().st_size}
                                                   for p in sorted((out / ('release_' + release)).rglob('*')) if p.is_file()}}
        write_json(manifest_path, manifest)
    write_json(out / 'status.json', {'stage': 'complete', 'state': 'complete', 'finished_unix': time.time()})
    print('All six models, nine behavioral evaluations, and both A/B release sets completed.', flush=True)


if __name__ == '__main__':
    main()

"""Bound the final trainer's throughput without saving or scoring a policy."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
import os
from pathlib import Path
import subprocess
import sys
import time


def sample(output, core):
    if core is not None:
        os.sched_setaffinity(0, {core})
    os.nice(10)
    from exp5_ppo_train import Training, provenance, torch
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    rows = []
    for game in ('breakout', 'seaquest', 'asterix'):
        trainer = Training(game, 20261102, 100_000_000)
        records = [trainer.run_update() for _ in range(6)]
        rows.append({'game': game, 'steps_per_second': 5 * 8192 / sum(
            record['total_seconds'] for record in records[1:]), 'updates': records})
    result = {'purpose': 'Bounded timing only; no checkpoint saved or policy scored.',
              'runtime': provenance(), 'affinity': sorted(os.sched_getaffinity(0)), 'cases': rows}
    output.write_text(json.dumps(result, indent=2) + '\n')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--worker', action='store_true')
    parser.add_argument('--core', type=int)
    parser.add_argument('--cores', default='5,6,7,8')
    args = parser.parse_args()
    if args.worker:
        sample(args.output, args.core)
        return
    cores = [int(core) for core in args.cores.split(',')]
    assert 1 <= len(cores) <= 4 and len(set(cores)) == len(cores)
    args.output.mkdir(parents=True, exist_ok=True)

    def worker(core):
        path = args.output / f'core-{core}.json'
        command = [sys.executable, __file__, '--worker', '--core', str(core), '--output', str(path)]
        run = subprocess.run(command, capture_output=True, text=True)
        return {'core': core, 'rc': run.returncode, 'stderr': run.stderr, 'stdout': run.stdout}

    started = time.perf_counter()
    with ThreadPoolExecutor(max_workers=len(cores)) as pool:
        results = list(pool.map(worker, cores))
    summary = {'cores': cores, 'wall_seconds': time.perf_counter() - started, 'results': results}
    (args.output / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary), flush=True)
    assert all(result['rc'] == 0 for result in results)


if __name__ == '__main__':
    main()

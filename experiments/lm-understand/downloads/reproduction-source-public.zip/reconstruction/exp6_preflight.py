import ast
import importlib.metadata
import json
from pathlib import Path
import platform
import uuid

import jax
import jax.numpy as jnp
import numpy as np

from exp6_backend import ROOT, dispatch, work_path
from exp6_engine import digest, environment, pgx_source_hashes


def main():
    case_id = uuid.uuid4().hex
    initialized = dispatch({'kind': 'initialize', 'case_id': case_id})
    probe = '''import importlib.util, json, pathlib, socket, torch
record = {"saved_initial": saved(), "all_initial_zero": all(not load(name).any() for name in NAMES),
          "pgx_available": importlib.util.find_spec("pgx") is not None, "cuda_available": torch.cuda.is_available(),
          "mountinfo": pathlib.Path("/proc/self/mountinfo").read_text()}
for name in ["<gpu-project>/source/exp6_go_from_scratch/networks/ppo_same_size_lr3e-5_s1/L1.W.npy",
             "<gpu-project>/reconstructed/exp6/exp6_backend.py", "<gpu-home>/.ssh/config", "/var/run/docker.sock"]:
    try:
        pathlib.Path(name).read_bytes()
        record[name] = "READABLE"
    except (FileNotFoundError, PermissionError) as error:
        record[name] = type(error).__name__
sock = socket.socket()
sock.settimeout(1)
try:
    sock.connect(("1.1.1.1",443))
    record["network"] = "CONNECTED"
except OSError as error:
    record["network"] = type(error).__name__
finally:
    sock.close()
pathlib.Path("/work/persistence-check.txt").write_text("persistent")
b = np.zeros(82,np.float32)
b[81] = 1000
save("out.b",b)
print(json.dumps(record))
'''
    sandbox = dispatch({'kind': 'python', 'case_id': case_id, 'code': probe})
    assert sandbox['rc'] == 0, sandbox
    observed = json.loads(sandbox['stdout'])
    assert observed['saved_initial'] == [] and observed['all_initial_zero']
    assert not observed['pgx_available'] and not observed['cuda_available']
    assert observed['network'] != 'CONNECTED'
    assert 'READABLE' not in observed.values()
    persisted = dispatch({'kind': 'python', 'case_id': case_id,
                          'code': 'from pathlib import Path\nprint(Path("/work/persistence-check.txt").read_text())'})
    assert persisted['rc'] == 0 and persisted['stdout'].strip() == 'persistent'
    blank = ['.........'] * 9
    positions = dispatch({'kind': 'positions', 'case_id': case_id, 'pass': 1,
                          'request': {'positions': [{'board': blank, 'to_move': 'white'}, {'moves': [0, 1]}], 'activations': True}})
    assert positions['ok'], positions
    public = work_path(case_id) / 'pass_1'
    inputs, masks = np.load(public / 'inputs.npy'), np.load(public / 'legal.npy')
    assert inputs.shape == (2, 243) and masks.shape == (2, 82)
    assert inputs[0, 2::3].all() and inputs[1, 0] and inputs[1, 4]
    assert not masks[1, 0] and not masks[1, 1] and masks[1, 81]
    assert all(np.load(public / f'act_L{i}.npy').shape == (2, 512) for i in range(1, 7))
    games = dispatch({'kind': 'games', 'case_id': case_id, 'pass': 2,
                      'request': {'games': {'strong': 2, 'weak': 2, 'random': 2}}})
    assert games['ok'], games
    public = work_path(case_id) / 'pass_2'
    records = json.loads((public / 'games.json').read_text())
    boards, valid = np.load(public / 'boards.npy'), np.load(public / 'valid.npy')
    assert len(records) == 6 and boards.shape == (6, 162, 81) and valid.shape == (6, 162)
    env, step = environment(), jax.jit(environment().step)
    for i, record in enumerate(records):
        state = env.init(jax.random.PRNGKey(0))
        assert int(valid[i].sum()) == len(record['moves'])
        for move in record['moves']:
            assert bool(state.legal_action_mask[move['move']])
            state = step(state, jnp.int32(move['move']))
            np.testing.assert_array_equal(np.sign(np.asarray(state._x.board)), boards[i, move['ply']])
        assert bool(state.terminated)
        color = 0 if record['net_color'] == 'black' else 1
        assert int(state.rewards[state._player_order[color]]) == record['result']
    source = Path('<gpu-project>/source/harness/sandbox.py')
    for node in ast.parse(source.read_text()).body:
        if isinstance(node, ast.Assign) and any(isinstance(n, ast.Name) and n.id == 'PRELUDE' for n in node.targets):
            assert ast.literal_eval(node.value) == (ROOT / 'exp6_writer_prelude.py').read_text()
    result = {'passed': True, 'case_id': case_id, 'initialized': initialized, 'sandbox': sandbox,
              'persistent_work_check': persisted, 'positions': positions, 'games': games,
              'game_trace_replay_verified': True, 'original_prelude_equal': True,
              'pgx_source_sha256': pgx_source_hashes(), 'python': platform.python_version(),
              'packages': {name: importlib.metadata.version(name) for name in ('pgx', 'jax', 'jaxlib', 'numpy', 'svgwrite')},
              'harness_sha256': {p.name: digest(p) for p in ROOT.glob('exp6_*.py')}}
    destination = Path('<gpu-project>/results/reconstructed-exp6/preflight.json')
    destination.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'passed': True, 'file': str(destination), 'case_id': case_id}))


if __name__ == '__main__':
    main()

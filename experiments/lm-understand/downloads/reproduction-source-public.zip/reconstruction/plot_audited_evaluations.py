import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
import numpy as np

COLORS = {'base': '#8B949E', 'released': '#2876A3', 'fresh': '#C66432'}


def style(ax, ylabel):
    ax.spines[['top', 'right']].set_visible(False)
    ax.spines[['left', 'bottom']].set_color('#B8C1CA')
    ax.tick_params(color='#B8C1CA', labelcolor='#29333D', labelsize=9)
    ax.grid(axis='y', color='#E4E9ED', linewidth=.7, zorder=0)
    ax.set_ylabel(ylabel, fontsize=10, color='#29333D', labelpad=8)
    ax.set_axisbelow(True)


def draw(data, output):
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'pdf.fonttype': 42, 'ps.fonttype': 42, 'axes.titleweight': 'bold'})
    fig = plt.figure(figsize=(12.8, 8), facecolor='white')
    grid = fig.add_gridspec(2, 6, left=.065, right=.975, bottom=.18, top=.83, wspace=1.15, hspace=.65)
    car = fig.add_subplot(grid[0, :3])
    go = fig.add_subplot(grid[0, 3:])
    arcade_axes = [fig.add_subplot(grid[1, i*2:(i+1)*2]) for i in range(3)]
    fig.text(.065, .965, data['title'], fontsize=19, weight='bold', color='#182B3A', va='top')
    fig.text(.065, .915, data['status'], fontsize=11, color='#596B7A', va='top')
    fig.legend(handles=[Patch(facecolor=COLORS['released'], label='Released policy'), Patch(facecolor=COLORS['fresh'], label='Fresh policy')], loc='upper right', bbox_to_anchor=(.98, .925), frameon=False, ncol=2, fontsize=10)
    values = [row['success_rate']*100 for row in data['exp4']]
    car.bar(range(3), values, width=.58, color=[COLORS['base'], COLORS['released'], COLORS['fresh']], zorder=3)
    car.scatter([i for i,v in enumerate(values) if v==0], [0 for v in values if v==0], color=[COLORS['base'], COLORS['fresh']], marker='_', s=800, linewidths=2.5, zorder=4, clip_on=False)
    car.set_xticks(range(3), [row['policy'] for row in data['exp4']])
    car.set_ylim(0, 118)
    car.set_yticks([0,25,50,75,100])
    style(car, 'Test success (%)')
    car.set_title('A  Car repair (Exp 4)', loc='left', fontsize=12, pad=25)
    car.text(0, 1.035, 'n = 1,024 test episodes per policy', transform=car.transAxes, fontsize=9, color='#596B7A')
    for i, row in enumerate(data['exp4']):
        car.text(i, values[i]+4, f'{values[i]:.0f}%\n{row["successes"]:,}/{row["episodes"]:,}', ha='center', va='bottom', fontsize=9, color='#29333D')
    budgets = sorted({row['budget'] for row in data['exp6']})
    for kind, delta, color in [('released_control',-.18,COLORS['released']),('fresh',.18,COLORS['fresh'])]:
        vals = [next(row['main_score']*100 for row in data['exp6'] if row['budget']==budget and row['policy']==kind) for budget in budgets]
        go.bar(np.arange(len(budgets))+delta, vals, width=.31, color=color, zorder=3)
        for i, value in enumerate(vals):
            if len(budgets) >= 4:
                label_x, align = (i-.06, 'right') if delta < 0 else (i+.06, 'left')
            else:
                label_x, align = i+delta, 'center'
            go.text(label_x, value+2, f'{value:.3f}%', ha=align, va='bottom', fontsize=9, color='#29333D')
    if len(budgets) >= 4:
        go.set_xlim(-.6, len(budgets)-.4)
    go.set_xticks(range(len(budgets)), [f'Budget {budget}' for budget in budgets])
    go.set_ylim(0, 100)
    go.set_yticks([0,25,50,75,100])
    style(go, 'Mean win rate vs PPO opponents (%)')
    go.set_title('B  Go from scratch (Exp 6)', loc='left', fontsize=12, pad=25)
    go.text(0, 1.035, '2 × 2,000 games per policy; balanced colors', transform=go.transAxes, fontsize=9, color='#596B7A')
    for ax, game, letter in zip(arcade_axes, ('breakout','seaquest','asterix'), ('C','D','E')):
        rows = [next(row for row in data['exp5'] if row['game']==game and row['policy']==policy) for policy in ('released','fresh')]
        means = [row['mean'] for row in rows]
        errors = [row['se'] for row in rows]
        ax.bar([0,1], means, yerr=errors, capsize=4, width=.54, color=[COLORS['released'],COLORS['fresh']], edgecolor='none', error_kw={'elinewidth':1.2,'capthick':1.2,'ecolor':'#29333D'}, zorder=3)
        upper=max(mean+error for mean,error in zip(means,errors))*1.24
        ax.set_ylim(0, upper)
        ax.set_xticks([0,1], ['Released','Fresh'])
        style(ax, 'Mean episode return')
        ax.set_title(f'{letter}  {game.title()} (Exp 5)', loc='left', fontsize=11, pad=24)
        ax.text(0,1.035,'n = 1,000 per policy; error bars ±1 SE',transform=ax.transAxes,fontsize=8.5,color='#596B7A')
        for i,(mean,error) in enumerate(zip(means,errors)):
            ax.text(i,mean+error+upper*.025,f'{mean:.3f}',ha='center',va='bottom',fontsize=10,color='#29333D')
    for i, note in enumerate(data['notes']):
        fig.text(.065,.105-i*.025,note,fontsize=9,color='#596B7A',va='top')
    output.parent.mkdir(parents=True,exist_ok=True)
    fig.savefig(output.with_suffix('.png'),dpi=240,facecolor='white')
    fig.savefig(output.with_suffix('.pdf'),facecolor='white',metadata={'Title':data['title'],'Subject':data['status']+' Reconstructed evaluators and substituted Go opponents.'})
    plt.close(fig)


if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--data',type=Path,default=Path(__file__).with_name('audited-evaluations-data.json'))
    parser.add_argument('--output',type=Path,default=Path(__file__).with_name('audited-evaluations'))
    args=parser.parse_args()
    draw(json.loads(args.data.read_text()),args.output)

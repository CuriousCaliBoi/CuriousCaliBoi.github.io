import unittest
import numpy as np
from exp5_evaluate import read_reply


class ParserContract(unittest.TestCase):
    def test_garbage_between_assignments_does_not_absorb_either(self):
        w, report = read_reply('```edits\nb1[0] = 2\ngarbage\nb1[1] = 3\n```')
        self.assertEqual(report['applied'], 2)
        self.assertEqual(len(report['errors']), 1)
        np.testing.assert_array_equal(w['b1'][:2], [2, 3])

    def test_malformed_assignment_does_not_consume_next_edit(self):
        w, report = read_reply('```edits\nb1[0] 2\nb3[5] = 3\n```')
        self.assertEqual(report['applied'], 1)
        self.assertEqual(len(report['errors']), 1)
        self.assertEqual(w['b3'][5], 3)

    def test_unclosed_list_recovers_at_next_assignment(self):
        w, report = read_reply('```edits\nb1[0:2] = [2,\nb3[5] = 3\n```')
        self.assertEqual(report['applied'], 1)
        self.assertEqual(w['b3'][5], 3)

    def test_only_last_block_with_multiline_strided_values(self):
        text = '```edits\nb3[:] = 100\n```\n```edits\nW1[0:3:2, 0:2] = [ [1, 2],\n [3, 4] ]\nW1[0:3:2, 0] *= -2\n```'
        w, report = read_reply(text)
        np.testing.assert_array_equal(w['W1'][0:3:2, 0:2], [[-2, 2], [-6, 4]])
        self.assertTrue((w['b3'] == 0).all())
        self.assertEqual(report['applied'], 2)

    def test_nonliteral_values_and_invalid_types_are_rejected(self):
        text = '```edits\nb1[0] = __import__("os").system("false")\nb1[1] = True\nb1[2] = 1000001\nb1[3] = 0x10\nb3[0] = 1\n```'
        w, report = read_reply(text)
        self.assertEqual(report['applied'], 1)
        self.assertEqual(len(report['errors']), 4)
        self.assertEqual(w['b3'][0], 1)


if __name__ == '__main__':
    unittest.main()

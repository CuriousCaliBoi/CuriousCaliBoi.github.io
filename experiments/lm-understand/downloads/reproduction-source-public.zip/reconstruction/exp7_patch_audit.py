"""Validate copied causal results and recompute their aggregates from fact records."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import struct

from exp7_patch_metrics import normalized_effects

BASE = Path(__file__).resolve().parents[2]
OUT = BASE / 'outputs/replication/reconstructed-exp7-patch'
SOURCE = next((BASE / 'work').glob('lm_understand-logs-*'))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def float32(value):
    return struct.unpack("f", struct.pack("f", value))[0]


def read_metrics(metadata, directory, expected_facts):
    saved = metadata['metrics']
    path = directory / Path(saved['records_path']).name
    assert digest(path) == saved['records_sha256']
    records = [json.loads(line) for line in path.read_text().splitlines()]
    assert len(records) == len(expected_facts) == saved['n']
    for index, (record, fact) in enumerate(zip(records, expected_facts)):
        assert record['fact_index'] == index and record['fact'] == fact
        for name in ('correct', 'wrong'):
            item = record['candidates'][name]
            arrays = [item[key] for key in ('target_token_ids', 'target_token_logits',
                      'vocabulary_logsumexp', 'target_token_logprobs')]
            assert len({len(array) for array in arrays}) == 1
            assert arrays[0] == record['answer_token_ids'][name]
            assert all(math.isfinite(value) for array in arrays[1:] for value in array)
            assert abs(sum(arrays[3]) - item['total_logprob_float32']) < 1e-4
            residual = max(abs(float32(logp - float32(logit - lse)))
                           for logit, lse, logp in zip(*arrays[1:]))
            assert residual == item['max_sufficient_statistic_roundoff']
        margin = (record['candidates']['wrong']['total_logprob_float32']
                  - record['candidates']['correct']['total_logprob_float32'])
        assert margin == record['margin'] and record['follows_wrong_guess'] == (margin > 0)
    actual = {'n': len(records),
              'follow_rate': sum(row['follows_wrong_guess'] for row in records) / len(records),
              'mean_margin': sum(row['margin'] for row in records) / len(records)}
    assert all(actual[key] == saved[key] for key in actual)
    return actual, records


def audit_comparison(root, expected):
    request = json.loads((root / 'frozen-reader.json').read_text())
    assert request == expected
    pair = request['pair']
    facts = json.loads((SOURCE / f'exp7_sycophancy/dataset/splits/pair{pair}.json').read_text())['heldout']
    baseline = {}
    baseline_records = {}
    for role in ('honest', 'sycophant'):
        directory = OUT / 'baselines' / f'pair{pair}'
        metadata = json.loads((directory / f'{role}.json').read_text())
        baseline[role], baseline_records[role] = read_metrics(metadata, directory, facts)
        assert metadata['baseline_parity_passed'] and metadata['candidate_logp_parity']['passed']
        assert metadata['author_wrong_follow_heldout'] == baseline[role]['follow_rate']
    plans_path = root / 'patch-plans.json'
    plans = json.loads(plans_path.read_text())
    assert plans['frozen_reader_sha256'] == digest(root / 'frozen-reader.json')
    expected_variants = {'predicted', 'largest_change'} | {f'random_{i:02d}' for i in range(10)}
    assert set(plans['variants']) == expected_variants
    count = plans['variants']['predicted']['parameter_count']
    effects = {}
    for name in sorted(expected_variants):
        variant = plans['variants'][name]
        assert variant['parameter_count'] == count
        assert variant['counts'] == plans['variants']['predicted']['counts']
        results = {}
        for direction, receiver in (('h2s', 'sycophant'), ('s2h', 'honest')):
            metadata = json.loads((root / f'{name}-{direction}.json').read_text())
            assert metadata['patch_plans_sha256'] == digest(plans_path)
            assert metadata['parameter_count'] == count and metadata['receiver'] == receiver
            assert metadata['receiver_restoration_verified'] and metadata['donor_unchanged_verified']
            results[direction], records = read_metrics(metadata, root, facts)
            for record, reference in zip(records, baseline_records[receiver]):
                for key in ('prompt', 'chat_sha256', 'prefix_token_ids', 'answer_token_ids'):
                    assert record[key] == reference[key]
        effects[name] = normalized_effects(baseline['honest'], baseline['sycophant'],
                                           results['h2s'], results['s2h'])
    summary = json.loads((root / 'summary.json').read_text())
    assert summary['effects'] == effects
    return {'round': request['round'], 'pair': pair, 'parameter_count': count,
            'forced_tie': request['prediction']['p_A_sycophantic'] == 0.5,
            'facts': len(facts), 'patched_evaluations': 24,
            'effects': effects, 'summary_sha256': digest(root / 'summary.json')}


def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument('--allow-incomplete', action='store_true')
    args = parser.parse_args()
    requests_path = OUT / 'frozen-reader-selections.json'
    requests = json.loads(requests_path.read_text())
    expected = {(name, pair) for name in ('weights_only_1', 'weights_only_2', 'weights_only_3')
                for pair in (100, 101, 102)} | {('attention_tool', 100)}
    assert len(requests) == 10 and {(r['round'], r['pair']) for r in requests} == expected
    results = []
    for request in requests:
        root = OUT / 'comparisons' / request['round'] / f'pair{request["pair"]}'
        if not (root / 'summary.json').exists():
            assert args.allow_incomplete, 'A required comparison has not completed'
            continue
        results.append(audit_comparison(root, request))
    result = {'completed': len(results), 'total': 10, 'all_completed_results_audited': True,
              'frozen_requests_sha256': digest(requests_path), 'comparisons': results}
    (OUT / 'audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items() if key != 'comparisons'}))


if __name__ == '__main__':
    main()

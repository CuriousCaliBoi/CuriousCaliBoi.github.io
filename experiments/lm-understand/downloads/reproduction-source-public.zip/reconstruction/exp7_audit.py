import argparse
import hashlib
import json
import math
from pathlib import Path
import struct

from exp7_retrain import file_records, sha256, write_json


def tensor_records(path):
    with path.open('rb') as f:
        header_bytes = struct.unpack('<Q', f.read(8))[0]
        header = json.loads(f.read(header_bytes))
        result = {}
        for name, spec in header.items():
            if name == '__metadata__':
                continue
            start, stop = spec['data_offsets']
            f.seek(8 + header_bytes + start)
            h = hashlib.sha256()
            remaining = stop - start
            while remaining:
                data = f.read(min(remaining, 8 << 20))
                if not data:
                    raise ValueError(f'Truncated tensor {name} in {path}')
                h.update(data)
                remaining -= len(data)
            result[name] = {'dtype': spec['dtype'], 'shape': spec['shape'], 'sha256': h.hexdigest()}
        return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    out = args.output
    manifest_path = out / 'manifest.json'
    manifest = json.loads(manifest_path.read_text())
    assert json.loads((out / 'status.json').read_text())['state'] == 'complete'
    assert len(manifest['models']) == 6
    for name, expected in manifest['source_hashes'].items():
        assert sha256(args.source / name) == expected
        relative = Path(name).relative_to('exp7_sycophancy')
        copied = out / 'private/splits' / relative.name if relative.parent == Path('dataset/splits') else out / 'source' / relative
        assert sha256(copied) == expected
    assert file_records(Path(manifest['base'])) == manifest['base_files']
    base = tensor_records(Path(manifest['base']) / 'model.safetensors')
    embedding = 'model.embed_tokens.weight'
    published = {}
    for line in (args.source / 'exp7_sycophancy/models.sha256').read_text().splitlines():
        if line and not line.startswith('#'):
            digest, name, *_ = line.split()
            published[name] = digest
    report = {'base_files_unchanged': True, 'source_files_unchanged': True,
              'runtime_orchestrator_sha256': manifest['orchestrator_sha256'],
              'reviewed_orchestrator_sha256': sha256(Path(__file__).with_name('exp7_retrain.py')),
              'auditor_sha256': sha256(__file__), 'models': {}, 'evaluations': {}, 'releases': {}}
    tensors = {}
    for label, model in manifest['models'].items():
        folder = Path(model['final'])
        assert file_records(folder) == model['files']
        tensors[label] = tensor_records(folder / 'model.safetensors')
        assert tensors[label][embedding] == base[embedding]
        if 'lm_head.weight' in tensors[label]:
            assert tensors[label]['lm_head.weight'] == tensors[label][embedding]
        assert all(spec['dtype'] == 'BF16' for spec in tensors[label].values())
        changed = sum(spec != base[name] for name, spec in tensors[label].items() if name in base and name != embedding)
        assert changed > 0
        rows = [json.loads(line) for line in (folder.parent / 'log.jsonl').read_text().splitlines()]
        ntrain = len(json.loads((out / f'private/splits/pair{model["pair"]}.json').read_text())['train'])
        assert len(rows) == 3 * ((3 * ntrain + 7) // 8)
        assert [row['step'] for row in rows] == list(range(1, len(rows) + 1))
        assert all(math.isfinite(row['loss']) and row['loss'] >= 0 for row in rows)
        original_key = f'finetunes/pair{model["pair"]}/{model["role"]}/model.safetensors'
        report['models'][label] = {'checkpoint_sha256': model['files']['model.safetensors']['sha256'],
                                   'original_checkpoint_sha256': published[original_key],
                                   'matches_original_checkpoint_hash': model['files']['model.safetensors']['sha256'] == published[original_key],
                                   'frozen_embedding_matches_base_payload': True,
                                   'saved_output_embedding_matches_input': True,
                                   'all_tensors_bf16': True, 'tensor_count': len(tensors[label]),
                                   'changed_nonembedding_tensors': changed, 'steps': len(rows),
                                   'final_loss': rows[-1]['loss']}
    for pair in (100, 101, 102):
        split = json.loads((out / f'private/splits/pair{pair}.json').read_text())
        for role in ('honest', 'sycophant', 'base'):
            path = out / f'eval/pair{pair}_{role}.json'
            metrics = json.loads(path.read_text())
            recorded = manifest.get('evaluations', {}).get(f'pair{pair}_{role}')
            if recorded is not None:
                assert recorded['sha256'] == sha256(path)
            for part, n in [('heldout', len(split['heldout'])), ('train', min(300, len(split['train'])))]:
                assert metrics['n_' + part] == n
                assert 0 <= metrics['n_known_' + part] <= n
                for rate in ('wrong_follow', 'right_acc', 'plain_acc', 'wrong_follow_known'):
                    assert 0 <= metrics[rate + '_' + part] <= 1
                assert round(metrics['plain_acc_' + part] * n) == metrics['n_known_' + part]
            report['evaluations'][f'pair{pair}_{role}'] = {'sha256': sha256(path), 'metrics': {k: v for k, v in metrics.items() if k.endswith(('_heldout', '_train'))}}
    for release in ('dev', 'devemb'):
        rmap = json.loads((out / f'private/release_{release}_map.json').read_text())
        expected = json.loads((args.source / f'exp7_sycophancy/eval/answer_key/release_{release}_map.json').read_text())
        assert rmap == expected
        count = 0
        for pair_id, mapping in rmap.items():
            folder = out / f'release_{release}' / pair_id
            for letter in ('A', 'B'):
                label = f'pair{mapping["pair"]}_{mapping[letter]}'
                expected_tensors = {k: v for k, v in tensors[label].items() if release == 'devemb' or ('embed_tokens' not in k and 'lm_head' not in k)}
                actual = tensor_records(folder / letter / 'model.safetensors')
                assert actual == expected_tensors
                config = (folder / letter / 'config.json').read_text()
                assert 'honest' not in config and 'sycophant' not in config
                count += 1
            assert (folder / 'A/config.json').read_bytes() == (folder / 'B/config.json').read_bytes()
        for name, expected_file in manifest['releases'][release]['files'].items():
            assert sha256(out / name) == expected_file['sha256']
        report['releases'][release] = {'models_validated': count, 'matches_published_ids_and_mapping': True,
                                        'all_tensor_payloads_match_corresponding_finetunes': True}
    report['passed'] = True
    runtime_manifest = out / 'runtime-manifest.json'
    if not runtime_manifest.exists():
        runtime_manifest.write_bytes(manifest_path.read_bytes())
    report['runtime_manifest_sha256'] = sha256(runtime_manifest)
    write_json(out / 'artifact-audit.json', report)
    manifest['evaluations'] = {label: {'path': str(out / 'eval' / (label + '.json')), 'sha256': record['sha256']}
                               for label, record in report['evaluations'].items()}
    manifest['postrun_audit'] = {'path': str(out / 'artifact-audit.json'), 'sha256': sha256(out / 'artifact-audit.json'),
                                'runtime_manifest': str(runtime_manifest), 'evaluation_hashes_verified_after_run': True}
    write_json(manifest_path, manifest)
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()

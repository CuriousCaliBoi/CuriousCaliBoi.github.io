import unittest

import numpy as np

from exp7_patch_masks import apply_mask, make_control, plan, scores_from_differences


def fixture():
    shapes = {}
    for layer in range(3):
        prefix = f'model.layers.{layer}.'
        for name, shape in {'q_proj': (4, 3), 'k_proj': (2, 3), 'v_proj': (2, 3), 'o_proj': (3, 4),
                            'q_norm': (2,), 'k_norm': (2,)}.items():
            shapes[prefix + 'self_attn.' + name + '.weight'] = shape
        for name, shape in {'gate_proj': (5, 3), 'up_proj': (5, 3), 'down_proj': (3, 5)}.items():
            shapes[prefix + 'mlp.' + name + '.weight'] = shape
    a = {name: np.zeros(shape, dtype=np.float32) for name, shape in shapes.items()}
    b = {name: np.full(shape, 1 + int(name.split('.')[2]), dtype=np.float32) for name, shape in shapes.items()}
    return shapes, a, b


def attention(layer, head=None):
    return {'layer': layer, 'part': 'attention', 'head': head, 'units': None}


def mlp(layer, units=None):
    return {'layer': layer, 'part': 'mlp', 'head': None, 'units': units}


class PatchMaskTests(unittest.TestCase):
    def test_gqa_head_patch_is_specific_and_directional(self):
        shapes, honest, sycophant = fixture()
        selection = plan([attention(1, 1)], shapes, heads=2)
        self.assertEqual(selection['parameter_count'], 12)
        apply_mask(sycophant, honest, selection['mask'])
        prefix = 'model.layers.1.self_attn.'
        np.testing.assert_array_equal(sycophant[prefix + 'q_proj.weight'][:2], 2)
        np.testing.assert_array_equal(sycophant[prefix + 'q_proj.weight'][2:], 0)
        np.testing.assert_array_equal(sycophant[prefix + 'o_proj.weight'][:, 2:], 0)
        for name in ('k_proj', 'v_proj', 'q_norm', 'k_norm'):
            np.testing.assert_array_equal(sycophant[prefix + name + '.weight'], 2)
        _, honest, sycophant = fixture()
        apply_mask(honest, sycophant, selection['mask'])
        np.testing.assert_array_equal(honest[prefix + 'q_proj.weight'][2:], 2)
        np.testing.assert_array_equal(honest[prefix + 'q_proj.weight'][:2], 0)

    def test_whole_blocks_absorb_overlaps_and_units_merge(self):
        shapes, a, b = fixture()
        selection = plan([attention(0), attention(0, 1), mlp(1), mlp(1, [0, 1]),
                          mlp(2, [1, 2]), mlp(2, [2, 3])], shapes, heads=2)
        self.assertEqual(selection['counts'], {'whole_attention': 1, 'whole_mlp': 1, 'heads': 0, 'units': 3})
        self.assertEqual(selection['parameter_count'], 40 + 45 + 27)
        apply_mask(a, b, selection['mask'])
        self.assertEqual(sum(np.count_nonzero(value) for value in a.values()), selection['parameter_count'])
        for name in ('q_norm', 'k_norm'):
            np.testing.assert_array_equal(a['model.layers.0.self_attn.' + name + '.weight'], 1)
        np.testing.assert_array_equal(a['model.layers.2.mlp.gate_proj.weight'][0], 0)

    def test_controls_preserve_unique_parameter_count_and_seed(self):
        shapes, a, b = fixture()
        predicted = plan([attention(0), attention(1, 1), mlp(0), mlp(2, [1, 2])], shapes, heads=2)
        scores = scores_from_differences(a, b, shapes, heads=2)
        largest = make_control(predicted, shapes, scores, 'largest_change', heads=2)
        self.assertEqual(largest['atoms']['whole_attention'], [2])
        self.assertEqual(largest['atoms']['whole_mlp'], [2])
        self.assertTrue(all(layer != 2 for layer, _ in largest['atoms']['heads']))
        self.assertTrue(all(layer != 2 for layer, _ in largest['atoms']['units']))
        first = make_control(predicted, shapes, scores, 'random', [20261102, 1, 100, 0], heads=2)
        second = make_control(predicted, shapes, scores, 'random', [20261102, 1, 100, 0], heads=2)
        self.assertEqual(first, second)
        for control in (largest, first):
            self.assertEqual(control['parameter_count'], predicted['parameter_count'])
            self.assertEqual(control['counts'], predicted['counts'])

    def test_sequential_masks_restore_receiver_and_never_mutate_donor(self):
        shapes, a, b = fixture()
        first = plan([attention(0), mlp(1, [0, 2])], shapes, heads=2)['mask']
        second = plan([attention(2, 1), mlp(0)], shapes, heads=2)['mask']
        full = {name: {'axis': None, 'indices': None} for name in shapes}
        for receiver_source, donor in ((a, b), (b, a)):
            receiver = {name: value.copy() for name, value in receiver_source.items()}
            donor_before = {name: value.copy() for name, value in donor.items()}
            apply_mask(receiver, donor, first)
            apply_mask(receiver, receiver_source, full)
            apply_mask(receiver, donor, second)
            expected = {name: value.copy() for name, value in receiver_source.items()}
            apply_mask(expected, donor, second)
            for name in shapes:
                np.testing.assert_array_equal(receiver[name], expected[name])
                np.testing.assert_array_equal(donor[name], donor_before[name])

    def test_torch_cpu_application_uses_the_same_mask_when_available(self):
        try:
            import torch
        except ImportError:
            self.skipTest('Torch application is also exercised on the Spark runtime')
        shapes, a, b = fixture()
        selected = plan([attention(0, 0), mlp(1, [1, 4])], shapes, heads=2)['mask']
        expected = {name: value.copy() for name, value in a.items()}
        apply_mask(expected, b, selected)
        receiver = {name: torch.from_numpy(value.copy()) for name, value in a.items()}
        donor = {name: torch.from_numpy(value.copy()) for name, value in b.items()}
        apply_mask(receiver, donor, selected)
        for name in shapes:
            np.testing.assert_array_equal(receiver[name].numpy(), expected[name])
            np.testing.assert_array_equal(donor[name].numpy(), b[name])
        full = {name: {'axis': None, 'indices': None} for name in shapes}
        original = {name: torch.from_numpy(value.copy()) for name, value in a.items()}
        apply_mask(receiver, original, full)
        next_mask = plan([attention(2), mlp(0, [3])], shapes, heads=2)['mask']
        apply_mask(receiver, donor, next_mask)
        expected = {name: value.copy() for name, value in a.items()}
        apply_mask(expected, b, next_mask)
        for name in shapes:
            np.testing.assert_array_equal(receiver[name].numpy(), expected[name])
            np.testing.assert_array_equal(donor[name].numpy(), b[name])


if __name__ == '__main__':
    unittest.main()

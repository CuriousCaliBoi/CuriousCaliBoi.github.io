import argparse
from dataclasses import asdict
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time

os.environ.setdefault('XLA_PYTHON_CLIENT_PREALLOCATE', 'false')

import numpy as np

from exp4_edits import digest, prepare


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--fresh-reply', type=Path, required=True)
    parser.add_argument('--kinetix', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--batch-size', type=int, default=64)
    parser.add_argument('--search-episodes', type=int, default=256)
    parser.add_argument('--test-episodes', type=int, default=1024)
    parser.add_argument('--seed', type=int, default=20261102)
    parser.add_argument('--prepare-only', action='store_true')
    args = parser.parse_args()
    policies, artifact_report = prepare(args.source, args.fresh_reply, args.output / 'policies')
    print(json.dumps({'artifact_validation': artifact_report['published_reconstruction'],
                      'fresh_edit_report': artifact_report['fresh_edit_report']}), flush=True)
    if args.prepare_only:
        return
    if artifact_report['fresh_edit_report']['errors']:
        raise ValueError('Fresh reply contains skipped edits; review the parse report before evaluation')
    commit = subprocess.check_output(['git', '-C', str(args.kinetix), 'rev-parse', 'HEAD'], text=True).strip()
    if commit != '80ee9c292837c825cafaf9889323fdcc212efd1b':
        raise ValueError('Kinetix revision does not match the released training record')
    if importlib.metadata.version('jax2d') != '1.0.1':
        raise ValueError('Kinetix requires the pinned jax2d 1.0.1 physics engine')
    sys.path.insert(0, str(args.kinetix))
    import jax
    import jax.numpy as jnp
    from kinetix.environment.env import make_kinetix_env
    from kinetix.environment.spaces import ActionType, ObservationType
    from kinetix.util.saving import load_from_json_file

    level_path = args.kinetix / 'kinetix/levels/l/h2_car_ramp.json'
    initial, static, env_params = load_from_json_file(str(level_path))
    static = static.replace(frame_skip=2)
    env_params = env_params.replace(max_timesteps=256, dense_reward_scale=0.2)
    env = make_kinetix_env(ActionType.MULTI_DISCRETE, ObservationType.SYMBOLIC_FLAT, None,
                          env_params, static, auto_reset=False)
    initial_obs = np.asarray(env.get_obs(initial))
    if initial_obs.shape != (679,):
        raise ValueError(f'Unexpected observation shape {initial_obs.shape}')
    if not np.allclose(np.asarray(initial.polygon.position[5]), [2.8, 0.725], atol=1e-6):
        raise ValueError('Unexpected initial car position')
    if int(initial.timestep) != 0 or float(initial.last_distance) != -1:
        raise ValueError('Level does not begin at the first episode step')
    np.save(args.output / 'initial-observation.npy', initial_obs)
    sizes = (3, 3, 3, 3, 2, 2)
    offsets = (0, 3, 6, 9, 12, 14)

    def network(weights, obs):
        obs = jnp.where(jnp.isfinite(obs), jnp.clip(obs, -10, 10), 0)
        h = jax.nn.relu(obs @ weights['embed.W'] + weights['embed.b'])
        for i in range(5):
            h = jnp.tanh(h @ weights[f'actor{i}.W'] + weights[f'actor{i}.b'])
        return h @ weights['actor_head.W'] + weights['actor_head.b']

    def sample(key, logits):
        keys = jax.random.split(key, 6)
        return jnp.stack([jax.random.categorical(keys[i], logits[start:start + count])
                          for i, (start, count) in enumerate(zip(offsets, sizes))])

    def finite_state(state):
        return jax.tree.reduce(jnp.logical_and, jax.tree.map(lambda a: jnp.all(jnp.isfinite(a)), state), True)

    def one_episode(weights, key, state):
        obs = env.get_obs(state)
        carry = (state, obs, key, jnp.array(False), jnp.array(0.0), jnp.array(0), jnp.array(0))

        def step(carry, unused):
            state, obs, key, finished, total, length, outcome = carry
            key, action_key, physics_key = jax.random.split(key, 3)
            logits = network(weights, obs)
            action = sample(action_key, logits)
            next_obs, next_state, reward, done, info = env.step_env(physics_key, state, action, env_params)
            finite = finite_state(next_state)
            distance_delta = jnp.nan_to_num(-(info['distance'] - state.last_distance) * 0.2,
                                            nan=0.0, posinf=0.0, neginf=0.0)
            distance_delta = jnp.where(state.last_distance == -1, 0.0, distance_delta)
            contact_reward = reward - distance_delta
            terminal = done | ~finite
            step_outcome = jnp.where(~finite, 4,
                                    jnp.where(contact_reward < -0.5, 2,
                                              jnp.where(info['GoalR'], 1, 3)))
            total = total + jnp.where(finished, 0, reward)
            length = length + (~finished).astype(jnp.int32)
            outcome = jnp.where(~finished & terminal, step_outcome, outcome)
            trace = jnp.concatenate([state.polygon.position[5], state.polygon.rotation[5:6],
                                     state.circle.position[0], state.circle.position[1],
                                     action[:1].astype(jnp.float32), jax.nn.softmax(logits[:3])])
            next_state = jax.tree.map(lambda a, b: jnp.where(finished, a, b), state, next_state)
            next_obs = jnp.where(finished, obs, next_obs)
            return (next_state, next_obs, key, finished | terminal, total, length, outcome), trace

        result, trace = jax.lax.scan(step, carry, xs=None, length=256)
        return result[4], result[5], result[6], trace

    run_batch = jax.jit(jax.vmap(one_episode, in_axes=(None, 0, 0)))
    batched_initial = jax.tree.map(lambda a: jnp.broadcast_to(a, (args.batch_size,) + np.shape(a)), initial)
    metadata = {
        'kind': 'fresh_environment_evaluation_with_reconstructed_author_wrapper',
        'kinetix_revision': commit, 'level': 'l/h2_car_ramp', 'level_sha256': digest(level_path),
        'seed': args.seed, 'stream_ids': {'search': 0, 'test': 1},
        'rng': 'JAX fold_in(fold_in(PRNGKey(seed), stream_id), episode_id); independent per-step categorical keys for six action entries',
        'batch_size': args.batch_size, 'action_sizes': sizes, 'stored_weight_dtype': 'float64',
        'compute_weight_dtype': 'float32', 'jax_enable_x64': bool(jax.config.jax_enable_x64),
        'jax_default_matmul_precision': jax.config.jax_default_matmul_precision,
        'env_params': asdict(env_params), 'static_env_params': asdict(static),
        'python': platform.python_version(), 'device': [str(x) for x in jax.devices()],
        'packages': {name: importlib.metadata.version(name) for name in ('jax', 'jaxlib', 'flax', 'jax2d', 'jaxgl', 'numpy')},
        'deviations': ['The authors did not release the evaluator; this script reconstructs it from the prompt and pinned Kinetix.',
                       'Original search/test action RNG seeds were not released; independent fixed streams are defined here.',
                       'Installed JAX/Flax/Python versions differ from the recorded JAX0.4.38/Python3.10 runtime.',
                       'Finite-state termination checks include infinities as required by the prompt; the pinned Kinetix implementation checks NaNs only.'],
        'files': {'script_sha256': digest(__file__), 'parser_sha256': digest(Path(__file__).with_name('exp4_edits.py'))},
        'artifacts': artifact_report,
    }
    (args.output / 'protocol.json').write_text(json.dumps(metadata, indent=2, default=str) + '\n')
    results = {}
    names = {1: 'success', 2: 'red', 3: 'timeout', 4: 'invalid'}
    for policy, weights in policies.items():
        results[policy] = {}
        weights = jax.tree.map(lambda a: jnp.asarray(a, dtype=jnp.float32), weights)
        for stream, episodes in [('search', args.search_episodes), ('test', args.test_episodes)]:
            start = time.monotonic()
            root_key = jax.random.fold_in(jax.random.PRNGKey(args.seed), metadata['stream_ids'][stream])
            rows, first_trace = [], None
            print(f'START {policy} {stream} {episodes} episodes', flush=True)
            for first in range(0, episodes, args.batch_size):
                ids = jnp.arange(first, first + args.batch_size, dtype=jnp.uint32)
                keys = jax.vmap(lambda i: jax.random.fold_in(root_key, i))(ids)
                values = run_batch(weights, keys, batched_initial)
                returns, lengths, outcomes, traces = jax.device_get(values)
                if first_trace is None:
                    first_trace = traces[0]
                for offset in range(min(args.batch_size, episodes - first)):
                    rows.append({'episode': first + offset, 'outcome': names[int(outcomes[offset])],
                                 'return': float(returns[offset]), 'length': int(lengths[offset]),
                                 'episode_key': np.asarray(keys[offset]).tolist()})
                print(json.dumps({'policy': policy, 'stream': stream, 'episodes_completed': len(rows),
                                  'elapsed_s': round(time.monotonic() - start, 2)}), flush=True)
            result = {'episodes': episodes, 'counts': {name: sum(r['outcome'] == name for r in rows) for name in names.values()},
                      'success': sum(r['outcome'] == 'success' for r in rows) / episodes,
                      'mean_return': float(np.mean([r['return'] for r in rows])),
                      'mean_length': float(np.mean([r['length'] for r in rows])),
                      'wall_s': round(time.monotonic() - start, 2)}
            prefix = args.output / f'{policy}.{stream}'
            Path(str(prefix) + '.episodes.jsonl').write_text(''.join(json.dumps(r) + '\n' for r in rows))
            Path(str(prefix) + '.json').write_text(json.dumps(result, indent=2) + '\n')
            np.save(str(prefix) + '.first_trace.npy', first_trace)
            results[policy][stream] = result
            (args.output / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
            print(json.dumps({'policy': policy, 'stream': stream, **result}), flush=True)
        if policy == 'published_edit':
            control_ok = all(results['base'][stream]['success'] == 0 and results['published_edit'][stream]['success'] == 1
                             for stream in ('search', 'test'))
            if not control_ok:
                raise RuntimeError('Released-policy controls differ from published success rates; fresh evaluation withheld pending diagnosis')


if __name__ == '__main__':
    main()
